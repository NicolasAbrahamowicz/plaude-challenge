(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/frontend_e6570363._.js",
  "static/chunks/9e883__pnpm_05027f31._.js"
],
    source: "dynamic"
});
