(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__fdbf81b8._.css",
  "static/chunks/9e883__pnpm_5e1b08bd._.js"
],
    source: "dynamic"
});
