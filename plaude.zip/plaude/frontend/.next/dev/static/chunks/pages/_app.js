__turbopack_load_page_chunks__("/_app", [
  "static/chunks/09dc3_next_dist_compiled_ff92a7e9._.js",
  "static/chunks/09dc3_next_dist_shared_lib_5f00c707._.js",
  "static/chunks/09dc3_next_dist_client_60a0b423._.js",
  "static/chunks/09dc3_next_dist_6428617f._.js",
  "static/chunks/09dc3_next_app_76e9d8f1.js",
  "static/chunks/[next]_entry_page-loader_ts_10b07042._.js",
  "static/chunks/d0c99_react-dom_de2d155b._.js",
  "static/chunks/9e883__pnpm_89ffd8cd._.js",
  "static/chunks/[root-of-the-server]__6a99bfdf._.js",
  "static/chunks/frontend_pages__app_2da965e7._.js",
  "static/chunks/turbopack-frontend_pages__app_ba0dec97._.js"
])
