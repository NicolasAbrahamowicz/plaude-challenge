(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/09dc3_next_dist_compiled_ff92a7e9._.js",
  "static/chunks/09dc3_next_dist_shared_lib_8fe09578._.js",
  "static/chunks/09dc3_next_dist_client_60a0b423._.js",
  "static/chunks/09dc3_next_dist_2110ee6a._.js",
  "static/chunks/09dc3_next_error_253d8efd.js",
  "static/chunks/[next]_entry_page-loader_ts_29d091cb._.js",
  "static/chunks/d0c99_react-dom_de2d155b._.js",
  "static/chunks/9e883__pnpm_89ffd8cd._.js",
  "static/chunks/[root-of-the-server]__2b803f7d._.js"
],
    source: "entry"
});
