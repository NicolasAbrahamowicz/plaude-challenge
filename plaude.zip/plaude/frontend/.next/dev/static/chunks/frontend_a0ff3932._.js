(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f809e475._.js",
  "static/chunks/09dc3_next_dist_compiled_react-dom_81fe59d6._.js",
  "static/chunks/09dc3_next_dist_compiled_react-server-dom-turbopack_38d1ce17._.js",
  "static/chunks/09dc3_next_dist_compiled_next-devtools_index_ba2b8658.js",
  "static/chunks/09dc3_next_dist_compiled_49c4dae8._.js",
  "static/chunks/09dc3_next_dist_client_11d8dc17._.js",
  "static/chunks/09dc3_next_dist_2019bf85._.js",
  "static/chunks/f1f29_@swc_helpers_cjs_3e84b336._.js"
],
    source: "entry"
});
