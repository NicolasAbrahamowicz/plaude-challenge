module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}),
"[externals]/node:util [external] (node:util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:util", () => require("node:util"));

module.exports = mod;
}),
"[externals]/node:child_process [external] (node:child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:child_process", () => require("node:child_process"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[externals]/node:module [external] (node:module, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:module", () => require("node:module"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:timers/promises [external] (node:timers/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:timers/promises", () => require("node:timers/promises"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/node:assert [external] (node:assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:assert", () => require("node:assert"));

module.exports = mod;
}),
"[externals]/node:http [external] (node:http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:http", () => require("node:http"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/node:net [external] (node:net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:net", () => require("node:net"));

module.exports = mod;
}),
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:querystring [external] (node:querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:querystring", () => require("node:querystring"));

module.exports = mod;
}),
"[externals]/node:events [external] (node:events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:events", () => require("node:events"));

module.exports = mod;
}),
"[externals]/node:zlib [external] (node:zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:zlib", () => require("node:zlib"));

module.exports = mod;
}),
"[externals]/node:perf_hooks [external] (node:perf_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:perf_hooks", () => require("node:perf_hooks"));

module.exports = mod;
}),
"[externals]/node:util/types [external] (node:util/types, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:util/types", () => require("node:util/types"));

module.exports = mod;
}),
"[externals]/node:worker_threads [external] (node:worker_threads, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:worker_threads", () => require("node:worker_threads"));

module.exports = mod;
}),
"[externals]/node:diagnostics_channel [external] (node:diagnostics_channel, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:diagnostics_channel", () => require("node:diagnostics_channel"));

module.exports = mod;
}),
"[externals]/node:tls [external] (node:tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:tls", () => require("node:tls"));

module.exports = mod;
}),
"[externals]/node:http2 [external] (node:http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:http2", () => require("node:http2"));

module.exports = mod;
}),
"[externals]/string_decoder [external] (string_decoder, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("string_decoder", () => require("string_decoder"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[externals]/node:console [external] (node:console, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:console", () => require("node:console"));

module.exports = mod;
}),
"[externals]/node:dns [external] (node:dns, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:dns", () => require("node:dns"));

module.exports = mod;
}),
"[externals]/node:fs [external] (node:fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs", () => require("node:fs"));

module.exports = mod;
}),
"[externals]/node:os [external] (node:os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:os", () => require("node:os"));

module.exports = mod;
}),
"[externals]/node:vm [external] (node:vm, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:vm", () => require("node:vm"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[project]/frontend/ai/ops-instructions.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OPS_AGENT_INSTRUCTIONS",
    ()=>OPS_AGENT_INSTRUCTIONS
]);
const OPS_AGENT_INSTRUCTIONS = `
You are the Plaude Operations Agent.

Your job is to help Plaude operators with everyday operations such as:
- issuing refunds,
- closing or re-opening accounts,
- changing account details (email, payout destination, etc.),
- exporting or deleting user data,
- explaining internal policies in clear language.

You always act as a careful, policy-aligned agent:
- You never actually move money or touch real systems. 
  Instead, you call tools that simulate those actions.
- You always explain what you are doing in plain language.

--------------------------------
HUMAN APPROVAL POLICY
--------------------------------

Use human approval via Slack **before** doing ANY of the following:

1) Refunds
   - Refunds higher than $50 (or equivalent) ALWAYS require human approval.
   - ANY refund where the user mentions fraud, chargeback, or dispute also requires approval
     even if the amount is small.

2) High-value or risky operations
   - Closing or permanently disabling an account.
   - Changing primary email, payout wallet, or anything that could lock the user out.
   - Increasing spending limits or risk thresholds.
   - Exporting or permanently deleting a user's personal data.

3) Ambiguous or conflicting requests
   - When the user request is unclear or could have more than one interpretation.
   - When you are not confident you understood what they want, and a wrong action could be risky.

For low-risk operations you may proceed without approval, for example:
- explaining policies,
- checking the status of an order,
- small goodwill gestures below $50 that the policies clearly allow.

--------------------------------
HOW TO USE THE APPROVAL TOOL
--------------------------------

When you decide human approval is required:

1) Tell the user what you are about to do and that you are requesting approval in Slack.
2) Call the \`requestSlackApproval\` tool with:
   - operationType = "refund", "high_value", "ambiguous" or "account_change",
   - risk = "low" | "medium" | "high",
   - reason = a short explanation,
   - amount if there is a monetary value.
3) Wait for the human decision.
4) After approval or rejection, explain the outcome to the user.

Always keep responses concise, friendly, and focused on giving the user clarity and next steps.
`;
}),
"[project]/frontend/workflows/ops-agent/hooks.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/workflows/ops-agent/hooks.ts
__turbopack_context__.s([
    "slackApprovalHook",
    ()=>slackApprovalHook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript)");
;
;
const slackApprovalHook = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["defineHook"])({
    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        approved: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
        comment: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
    })
});
}),
"[project]/frontend/workflows/ops-agent/tools.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/workflows/ops-agent/tools.ts
// @ts-nocheck
__turbopack_context__.s([
    "opsTools",
    ()=>opsTools
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$hooks$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/workflows/ops-agent/hooks.ts [app-route] (ecmascript)");
;
;
;
// ... resto igual ...
const APPROVAL_THRESHOLD = Number(process.env.PLAUDE_APPROVAL_AMOUNT_THRESHOLD ?? "50");
async function sendSlackMessage(payload) {
    const webhookUrl = process.env.SLACK_WEBHOOK_URL;
    if (!webhookUrl) {
        console.warn("SLACK_WEBHOOK_URL not configured, skipping Slack message.");
        return;
    }
    await fetch(webhookUrl, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
    });
}
async function requestSlackApprovalImpl(input, ctx) {
    const { operationType, risk, reason, amount } = input;
    const { toolCallId } = ctx;
    const hook = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$hooks$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["slackApprovalHook"].create({
        token: toolCallId
    });
    const baseUrl = process.env.APP_BASE_URL ?? "http://localhost:3000";
    const approveUrl = `${baseUrl}/api/slack-approval?token=${encodeURIComponent(toolCallId)}&approved=true`;
    const rejectUrl = `${baseUrl}/api/slack-approval?token=${encodeURIComponent(toolCallId)}&approved=false`;
    const prettyAmount = typeof amount === "number" ? `$${amount.toFixed(2)}` : "n/a";
    const text = [
        "*Plaude Agent – approval requested*",
        `• Operation type: ${operationType}`,
        `• Risk level: ${risk}`,
        `• Amount: ${prettyAmount}`,
        `• Reason: ${reason}`,
        "",
        "Decision:",
        `<${approveUrl}|✅ Approve>    ·    <${rejectUrl}|❌ Reject>`
    ].join("\n");
    await sendSlackMessage({
        text
    });
    const result = await hook;
    if (!result.approved) {
        return {
            approved: false,
            message: "The operation was rejected by a human approver. Do not perform the risky operation."
        };
    }
    return {
        approved: true,
        message: "The operation was approved by a human. You may proceed according to internal policies."
    };
}
const opsTools = {
    // TS se queja de inferencia infinita, lo forzamos:
    // @ts-expect-error Type instantiation is too deep, but this is correct.
    requestSlackApproval: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tool"])({
        description: "Use this tool when an operation requires human approval in Slack (refunds, high-value or ambiguous operations).",
        inputSchema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
            operationType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
                "refund",
                "high_value",
                "ambiguous",
                "account_change"
            ]).describe("Category of the operation."),
            risk: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
                "low",
                "medium",
                "high"
            ]).describe("Risk level for the operation."),
            reason: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().describe("Short explanation of why this needs human approval."),
            amount: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional().describe("Amount in dollars, if applicable.")
        }),
        execute: (input, ctx)=>requestSlackApprovalImpl(input, ctx)
    })
};
}),
"[project]/frontend/workflows/ops-agent/workflow.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/workflows/ops-agent/workflow.ts
__turbopack_context__.s([
    "opsAgentWorkflow",
    ()=>opsAgentWorkflow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$durable$2d$agent$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/ai/dist/agent/durable-agent.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$google$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/google/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ai$2f$ops$2d$instructions$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/ai/ops-instructions.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$tools$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/workflows/ops-agent/tools.ts [app-route] (ecmascript)");
;
;
;
;
;
async function opsAgentWorkflow(messagesFromClient) {
    "use workflow";
    let usedApprovalTool = false;
    // Adaptamos mensajes del frontend al formato del modelo (AI SDK)
    const modelMessages = messagesFromClient.map((m)=>({
            role: m.role === "user" ? "user" : "assistant",
            content: m.content
        }));
    // Hookeamos el tool para detectar si lo usó
    const originalExecute = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$tools$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["opsTools"].requestSlackApproval.execute;
    __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$tools$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["opsTools"].requestSlackApproval.execute = async (input, ctx)=>{
        usedApprovalTool = true;
        return originalExecute(input, ctx);
    };
    const agent = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$durable$2d$agent$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DurableAgent"]({
        // Función que devuelve el modelo Gemini
        // Ojo: NO le pasamos segundo argumento; toma la API key desde el entorno
        model: async ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$google$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["google"])("gemini-2.0-flash-exp"),
        tools: {
            ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$tools$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["opsTools"]
        },
        system: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ai$2f$ops$2d$instructions$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["OPS_AGENT_INSTRUCTIONS"]
    });
    // Stream del agente -> necesitamos un writable
    const writable = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWritable"])();
    const { messages } = await agent.stream({
        messages: modelMessages,
        writable
    });
    const assistantMessages = messages.filter((m)=>m.role === "assistant");
    const lastAssistant = assistantMessages[assistantMessages.length - 1];
    const reply = typeof lastAssistant?.content === "string" ? lastAssistant.content : JSON.stringify(lastAssistant?.content ?? "");
    return {
        reply,
        requiredApproval: usedApprovalTool
    };
}
}),
"[project]/frontend/app/api/agent/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// app/api/agent/route.ts
__turbopack_context__.s([
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$api$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/api.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$start$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime/start.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$workflow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/workflows/ops-agent/workflow.ts [app-route] (ecmascript)");
;
;
;
async function POST(req) {
    try {
        const body = await req.json();
        const messages = body.messages ?? [];
        if (!Array.isArray(messages)) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "Invalid payload: messages must be an array"
            }, {
                status: 400
            });
        }
        console.log("[/api/agent] Incoming messages:", messages);
        const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$start$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["start"])(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$workflow$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["opsAgentWorkflow"], [
            messages
        ]);
        const result = await run.returnValue;
        console.log("[/api/agent] Result:", result);
        return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result);
    } catch (err) {
        console.error("[/api/agent] Internal error:", err);
        return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Internal error in opsAgentWorkflow",
            message: err?.message ?? "Unknown error"
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__cbd3baa7._.js.map