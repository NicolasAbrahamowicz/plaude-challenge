module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/frontend/lib/approval-store.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/lib/approval-store.ts
__turbopack_context__.s([
    "getApprovalDecision",
    ()=>getApprovalDecision,
    "saveApprovalDecision",
    ()=>saveApprovalDecision
]);
const approvalStore = new Map();
function saveApprovalDecision(decision) {
    approvalStore.set(decision.id, decision);
}
function getApprovalDecision(id) {
    return approvalStore.get(id) ?? null;
}
}),
"[project]/frontend/app/api/slack-decision/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/app/api/slack-decision/route.ts
__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$groq$40$2$2e$0$2e$33_zod$40$3$2e$25$2e$76$2f$node_modules$2f40$ai$2d$sdk$2f$groq$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@ai-sdk+groq@2.0.33_zod@3.25.76/node_modules/@ai-sdk/groq/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$lib$2f$approval$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/lib/approval-store.ts [app-route] (ecmascript)");
;
;
;
;
async function GET(req) {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const decision = searchParams.get("decision");
    const amountParam = searchParams.get("amount");
    if (!id || !decision || ![
        "approve",
        "reject"
    ].includes(decision)) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            ok: false,
            error: "Invalid parameters"
        }, {
            status: 400
        });
    }
    const amount = amountParam ? Number(amountParam) : undefined;
    const decisionText = decision === "approve" ? "APPROVED" : "REJECTED";
    // Intentamos generar un mensaje lindo con Groq, si no hay API key
    // devolvemos algo fijo.
    let aiMessage = decision === "approve" ? "Your refund has been approved. You should see the amount credited shortly." : "We reviewed your request and unfortunately the refund has been rejected.";
    const apiKey = process.env.GROQ_API_KEY;
    if (apiKey) {
        try {
            const { text } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateText"])({
                model: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$groq$40$2$2e$0$2e$33_zod$40$3$2e$25$2e$76$2f$node_modules$2f40$ai$2d$sdk$2f$groq$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["groq"])(process.env.GROQ_MODEL || "llama-3.1-8b-instant", {
                    apiKey
                }),
                system: "You are an operations agent writing short, clear messages to customers about refunds. Be polite and professional.",
                prompt: `A human operator in Slack has ${decisionText} a refund request${amount ? ` for ${amount} USD` : ""}. Write a short message (2–3 sentences) to the customer explaining the decision and next steps.`
            });
            if (text && text.trim().length > 0) {
                aiMessage = text.trim();
            }
        } catch (err) {
            console.error("[slack-decision] Groq error:", err);
        }
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$lib$2f$approval$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["saveApprovalDecision"])({
        id,
        decision: decision === "approve" ? "approved" : "rejected",
        amount: Number.isNaN(amount || NaN) ? undefined : amount,
        createdAt: Date.now(),
        aiMessage
    });
    const humanText = decision === "approve" ? "✅ Approval recorded." : "❌ Rejection recorded.";
    const html = `<html>
  <body style="font-family: system-ui, sans-serif; padding: 16px;">
    <h2>${humanText}</h2>
    <p>You can close this window.</p>
  </body>
</html>`;
    return new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](html, {
        status: 200,
        headers: {
            "Content-Type": "text/html; charset=utf-8"
        }
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__8a904fbe._.js.map