module.exports = [
"[project]/frontend/.next-internal/server/app/api/agent/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend__next-internal_server_app_api_agent_route_actions_d165826f.js.map