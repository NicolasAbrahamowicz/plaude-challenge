module.exports = [
"[project]/frontend/.next-internal/server/app/api/slack-decision/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend__next-internal_server_app_api_slack-decision_route_actions_3ec6f52f.js.map