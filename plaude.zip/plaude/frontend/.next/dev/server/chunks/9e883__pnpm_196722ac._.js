module.exports = [
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/headers.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var headers_exports = {};
__export(headers_exports, {
    CITY_HEADER_NAME: ()=>CITY_HEADER_NAME,
    COUNTRY_HEADER_NAME: ()=>COUNTRY_HEADER_NAME,
    EMOJI_FLAG_UNICODE_STARTING_POSITION: ()=>EMOJI_FLAG_UNICODE_STARTING_POSITION,
    IP_HEADER_NAME: ()=>IP_HEADER_NAME,
    LATITUDE_HEADER_NAME: ()=>LATITUDE_HEADER_NAME,
    LONGITUDE_HEADER_NAME: ()=>LONGITUDE_HEADER_NAME,
    POSTAL_CODE_HEADER_NAME: ()=>POSTAL_CODE_HEADER_NAME,
    REGION_HEADER_NAME: ()=>REGION_HEADER_NAME,
    REQUEST_ID_HEADER_NAME: ()=>REQUEST_ID_HEADER_NAME,
    geolocation: ()=>geolocation,
    ipAddress: ()=>ipAddress
});
module.exports = __toCommonJS(headers_exports);
const CITY_HEADER_NAME = "x-vercel-ip-city";
const COUNTRY_HEADER_NAME = "x-vercel-ip-country";
const IP_HEADER_NAME = "x-real-ip";
const LATITUDE_HEADER_NAME = "x-vercel-ip-latitude";
const LONGITUDE_HEADER_NAME = "x-vercel-ip-longitude";
const REGION_HEADER_NAME = "x-vercel-ip-country-region";
const POSTAL_CODE_HEADER_NAME = "x-vercel-ip-postal-code";
const REQUEST_ID_HEADER_NAME = "x-vercel-id";
const EMOJI_FLAG_UNICODE_STARTING_POSITION = 127397;
function getHeader(headers, key) {
    return headers.get(key) ?? void 0;
}
function getHeaderWithDecode(request, key) {
    const header = getHeader(request.headers, key);
    return header ? decodeURIComponent(header) : void 0;
}
function getFlag(countryCode) {
    const regex = new RegExp("^[A-Z]{2}$").test(countryCode);
    if (!countryCode || !regex) return void 0;
    return String.fromCodePoint(...countryCode.split("").map((char)=>EMOJI_FLAG_UNICODE_STARTING_POSITION + char.charCodeAt(0)));
}
function ipAddress(input) {
    const headers = "headers" in input ? input.headers : input;
    return getHeader(headers, IP_HEADER_NAME);
}
function getRegionFromRequestId(requestId) {
    if (!requestId) {
        return "dev1";
    }
    return requestId.split(":")[0];
}
function geolocation(request) {
    return {
        // city name may be encoded to support multi-byte characters
        city: getHeaderWithDecode(request, CITY_HEADER_NAME),
        country: getHeader(request.headers, COUNTRY_HEADER_NAME),
        flag: getFlag(getHeader(request.headers, COUNTRY_HEADER_NAME)),
        countryRegion: getHeader(request.headers, REGION_HEADER_NAME),
        region: getRegionFromRequestId(getHeader(request.headers, REQUEST_ID_HEADER_NAME)),
        latitude: getHeader(request.headers, LATITUDE_HEADER_NAME),
        longitude: getHeader(request.headers, LONGITUDE_HEADER_NAME),
        postalCode: getHeader(request.headers, POSTAL_CODE_HEADER_NAME)
    };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    CITY_HEADER_NAME,
    COUNTRY_HEADER_NAME,
    EMOJI_FLAG_UNICODE_STARTING_POSITION,
    IP_HEADER_NAME,
    LATITUDE_HEADER_NAME,
    LONGITUDE_HEADER_NAME,
    POSTAL_CODE_HEADER_NAME,
    REGION_HEADER_NAME,
    REQUEST_ID_HEADER_NAME,
    geolocation,
    ipAddress
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-env.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_env_exports = {};
__export(get_env_exports, {
    getEnv: ()=>getEnv
});
module.exports = __toCommonJS(get_env_exports);
const getEnv = (env = process.env)=>({
        /**
   * An indicator to show that System Environment Variables have been exposed to your project's Deployments.
   * @example "1"
   */ VERCEL: get(env, "VERCEL"),
        /**
   * An indicator that the code is running in a Continuous Integration environment.
   * @example "1"
   */ CI: get(env, "CI"),
        /**
   * The Environment that the app is deployed and running on.
   * @example "production"
   */ VERCEL_ENV: get(env, "VERCEL_ENV"),
        /**
   * The domain name of the generated deployment URL. The value does not include the protocol scheme https://.
   * NOTE: This Variable cannot be used in conjunction with Standard Deployment Protection.
   * @example "*.vercel.app"
   */ VERCEL_URL: get(env, "VERCEL_URL"),
        /**
   * The domain name of the generated Git branch URL. The value does not include the protocol scheme https://.
   * @example "*-git-*.vercel.app"
   */ VERCEL_BRANCH_URL: get(env, "VERCEL_BRANCH_URL"),
        /**
   * A production domain name of the project. This is useful to reliably generate links that point to production such as OG-image URLs.
   * The value does not include the protocol scheme https://.
   * @example "myproject.vercel.app"
   */ VERCEL_PROJECT_PRODUCTION_URL: get(env, "VERCEL_PROJECT_PRODUCTION_URL"),
        /**
   * The ID of the Region where the app is running.
   *
   * Possible values:
   * - arn1 (Stockholm, Sweden)
   * - bom1 (Mumbai, India)
   * - cdg1 (Paris, France)
   * - cle1 (Cleveland, USA)
   * - cpt1 (Cape Town, South Africa)
   * - dub1 (Dublin, Ireland)
   * - fra1 (Frankfurt, Germany)
   * - gru1 (São Paulo, Brazil)
   * - hkg1 (Hong Kong)
   * - hnd1 (Tokyo, Japan)
   * - iad1 (Washington, D.C., USA)
   * - icn1 (Seoul, South Korea)
   * - kix1 (Osaka, Japan)
   * - lhr1 (London, United Kingdom)
   * - pdx1 (Portland, USA)
   * - sfo1 (San Francisco, USA)
   * - sin1 (Singapore)
   * - syd1 (Sydney, Australia)
   * - dev1 (Development Region)
   *
   * @example "iad1"
   */ VERCEL_REGION: get(env, "VERCEL_REGION"),
        /**
   * The unique identifier for the deployment, which can be used to implement Skew Protection.
   * @example "dpl_7Gw5ZMBpQA8h9GF832KGp7nwbuh3"
   */ VERCEL_DEPLOYMENT_ID: get(env, "VERCEL_DEPLOYMENT_ID"),
        /**
   * When Skew Protection is enabled in Project Settings, this value is set to 1.
   * @example "1"
   */ VERCEL_SKEW_PROTECTION_ENABLED: get(env, "VERCEL_SKEW_PROTECTION_ENABLED"),
        /**
   * The Protection Bypass for Automation value, if the secret has been generated in the project's Deployment Protection settings.
   */ VERCEL_AUTOMATION_BYPASS_SECRET: get(env, "VERCEL_AUTOMATION_BYPASS_SECRET"),
        /**
   * The Git Provider the deployment is triggered from.
   * @example "github"
   */ VERCEL_GIT_PROVIDER: get(env, "VERCEL_GIT_PROVIDER"),
        /**
   * The origin repository the deployment is triggered from.
   * @example "my-site"
   */ VERCEL_GIT_REPO_SLUG: get(env, "VERCEL_GIT_REPO_SLUG"),
        /**
   * The account that owns the repository the deployment is triggered from.
   * @example "acme"
   */ VERCEL_GIT_REPO_OWNER: get(env, "VERCEL_GIT_REPO_OWNER"),
        /**
   * The ID of the repository the deployment is triggered from.
   * @example "117716146"
   */ VERCEL_GIT_REPO_ID: get(env, "VERCEL_GIT_REPO_ID"),
        /**
   * The git branch of the commit the deployment was triggered by.
   * @example "improve-about-page"
   */ VERCEL_GIT_COMMIT_REF: get(env, "VERCEL_GIT_COMMIT_REF"),
        /**
   * The git SHA of the commit the deployment was triggered by.
   * @example "fa1eade47b73733d6312d5abfad33ce9e4068081"
   */ VERCEL_GIT_COMMIT_SHA: get(env, "VERCEL_GIT_COMMIT_SHA"),
        /**
   * The message attached to the commit the deployment was triggered by.
   * @example "Update about page"
   */ VERCEL_GIT_COMMIT_MESSAGE: get(env, "VERCEL_GIT_COMMIT_MESSAGE"),
        /**
   * The username attached to the author of the commit that the project was deployed by.
   * @example "johndoe"
   */ VERCEL_GIT_COMMIT_AUTHOR_LOGIN: get(env, "VERCEL_GIT_COMMIT_AUTHOR_LOGIN"),
        /**
   * The name attached to the author of the commit that the project was deployed by.
   * @example "John Doe"
   */ VERCEL_GIT_COMMIT_AUTHOR_NAME: get(env, "VERCEL_GIT_COMMIT_AUTHOR_NAME"),
        /**
   * The git SHA of the last successful deployment for the project and branch.
   * NOTE: This Variable is only exposed when an Ignored Build Step is provided.
   * @example "fa1eade47b73733d6312d5abfad33ce9e4068080"
   */ VERCEL_GIT_PREVIOUS_SHA: get(env, "VERCEL_GIT_PREVIOUS_SHA"),
        /**
   * The pull request id the deployment was triggered by. If a deployment is created on a branch before a pull request is made, this value will be an empty string.
   * @example "23"
   */ VERCEL_GIT_PULL_REQUEST_ID: get(env, "VERCEL_GIT_PULL_REQUEST_ID")
    });
const get = (env, key)=>{
    const value = env[key];
    return value === "" ? void 0 : value;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getEnv
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_context_exports = {};
__export(get_context_exports, {
    SYMBOL_FOR_REQ_CONTEXT: ()=>SYMBOL_FOR_REQ_CONTEXT,
    getContext: ()=>getContext
});
module.exports = __toCommonJS(get_context_exports);
const SYMBOL_FOR_REQ_CONTEXT = Symbol.for("@vercel/request-context");
function getContext() {
    const fromSymbol = globalThis;
    return fromSymbol[SYMBOL_FOR_REQ_CONTEXT]?.get?.() ?? {};
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    SYMBOL_FOR_REQ_CONTEXT,
    getContext
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/wait-until.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var wait_until_exports = {};
__export(wait_until_exports, {
    waitUntil: ()=>waitUntil
});
module.exports = __toCommonJS(wait_until_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const waitUntil = (promise)=>{
    if (promise === null || typeof promise !== "object" || typeof promise.then !== "function") {
        throw new TypeError(`waitUntil can only be called with a Promise, got ${typeof promise}`);
    }
    return (0, import_get_context.getContext)().waitUntil?.(promise);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    waitUntil
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/middleware.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var middleware_exports = {};
__export(middleware_exports, {
    next: ()=>next,
    rewrite: ()=>rewrite
});
module.exports = __toCommonJS(middleware_exports);
function handleMiddlewareField(init, headers) {
    if (init?.request?.headers) {
        if (!(init.request.headers instanceof Headers)) {
            throw new Error("request.headers must be an instance of Headers");
        }
        const keys = [];
        for (const [key, value] of init.request.headers){
            headers.set("x-middleware-request-" + key, value);
            keys.push(key);
        }
        headers.set("x-middleware-override-headers", keys.join(","));
    }
}
function rewrite(destination, init) {
    const headers = new Headers(init?.headers ?? {});
    headers.set("x-middleware-rewrite", String(destination));
    handleMiddlewareField(init, headers);
    return new Response(null, {
        ...init,
        headers
    });
}
function next(init) {
    const headers = new Headers(init?.headers ?? {});
    headers.set("x-middleware-next", "1");
    handleMiddlewareField(init, headers);
    return new Response(null, {
        ...init,
        headers
    });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    next,
    rewrite
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/in-memory-cache.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var in_memory_cache_exports = {};
__export(in_memory_cache_exports, {
    InMemoryCache: ()=>InMemoryCache
});
module.exports = __toCommonJS(in_memory_cache_exports);
class InMemoryCache {
    constructor(){
        this.cache = {};
    }
    async get(key) {
        const entry = this.cache[key];
        if (entry) {
            if (entry.ttl && entry.lastModified + entry.ttl * 1e3 < Date.now()) {
                await this.delete(key);
                return null;
            }
            return entry.value;
        }
        return null;
    }
    async set(key, value, options) {
        this.cache[key] = {
            value,
            lastModified: Date.now(),
            ttl: options?.ttl,
            tags: new Set(options?.tags || [])
        };
    }
    async delete(key) {
        delete this.cache[key];
    }
    async expireTag(tag) {
        const tags = Array.isArray(tag) ? tag : [
            tag
        ];
        for(const key in this.cache){
            if (Object.prototype.hasOwnProperty.call(this.cache, key)) {
                const entry = this.cache[key];
                if (tags.some((t)=>entry.tags.has(t))) {
                    delete this.cache[key];
                }
            }
        }
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    InMemoryCache
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/build-client.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var build_client_exports = {};
__export(build_client_exports, {
    BuildCache: ()=>BuildCache
});
module.exports = __toCommonJS(build_client_exports);
var import_index = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)");
class BuildCache {
    constructor({ endpoint, headers, onError, timeout = 500 }){
        this.get = async (key)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const res = await fetch(`${this.endpoint}${key}`, {
                    headers: this.headers,
                    method: "GET",
                    signal: controller.signal
                });
                if (res.status === 404) {
                    clearTimeout(timeoutId);
                    return null;
                }
                if (res.status === 200) {
                    const cacheState = res.headers.get(import_index.HEADERS_VERCEL_CACHE_STATE);
                    if (cacheState !== import_index.PkgCacheState.Fresh) {
                        res.body?.cancel?.();
                        clearTimeout(timeoutId);
                        return null;
                    }
                    const result = await res.json();
                    clearTimeout(timeoutId);
                    return result;
                } else {
                    clearTimeout(timeoutId);
                    throw new Error(`Failed to get cache: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
                return null;
            }
        };
        this.set = async (key, value, options)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const optionalHeaders = {};
                if (options?.ttl) {
                    optionalHeaders[import_index.HEADERS_VERCEL_REVALIDATE] = options.ttl.toString();
                }
                if (options?.tags && options.tags.length > 0) {
                    optionalHeaders[import_index.HEADERS_VERCEL_CACHE_TAGS] = options.tags.join(",");
                }
                if (options?.name) {
                    optionalHeaders[import_index.HEADERS_VERCEL_CACHE_ITEM_NAME] = options.name;
                }
                const res = await fetch(`${this.endpoint}${key}`, {
                    method: "POST",
                    headers: {
                        ...this.headers,
                        ...optionalHeaders
                    },
                    body: JSON.stringify(value),
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to set cache: ${res.status} ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.delete = async (key)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const res = await fetch(`${this.endpoint}${key}`, {
                    method: "DELETE",
                    headers: this.headers,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to delete cache: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.expireTag = async (tag)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                if (Array.isArray(tag)) {
                    tag = tag.join(",");
                }
                const res = await fetch(`${this.endpoint}revalidate?tags=${tag}`, {
                    method: "POST",
                    headers: this.headers,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to revalidate tag: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.endpoint = endpoint;
        this.headers = headers;
        this.onError = onError;
        this.timeout = timeout;
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    BuildCache
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var cache_exports = {};
__export(cache_exports, {
    HEADERS_VERCEL_CACHE_ITEM_NAME: ()=>HEADERS_VERCEL_CACHE_ITEM_NAME,
    HEADERS_VERCEL_CACHE_STATE: ()=>HEADERS_VERCEL_CACHE_STATE,
    HEADERS_VERCEL_CACHE_TAGS: ()=>HEADERS_VERCEL_CACHE_TAGS,
    HEADERS_VERCEL_REVALIDATE: ()=>HEADERS_VERCEL_REVALIDATE,
    PkgCacheState: ()=>PkgCacheState,
    getCache: ()=>getCache
});
module.exports = __toCommonJS(cache_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
var import_in_memory_cache = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/in-memory-cache.js [app-route] (ecmascript)");
var import_build_client = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/build-client.js [app-route] (ecmascript)");
const defaultKeyHashFunction = (key)=>{
    let hash = 5381;
    for(let i = 0; i < key.length; i++){
        hash = hash * 33 ^ key.charCodeAt(i);
    }
    return (hash >>> 0).toString(16);
};
const defaultNamespaceSeparator = "$";
let inMemoryCacheInstance = null;
let buildCacheInstance = null;
const getCache = (cacheOptions)=>{
    const resolveCache = ()=>{
        let cache;
        if ((0, import_get_context.getContext)().cache) {
            cache = (0, import_get_context.getContext)().cache;
        } else {
            cache = getCacheImplementation(process.env.SUSPENSE_CACHE_DEBUG === "true");
        }
        return cache;
    };
    return wrapWithKeyTransformation(resolveCache, createKeyTransformer(cacheOptions));
};
function createKeyTransformer(cacheOptions) {
    const hashFunction = cacheOptions?.keyHashFunction || defaultKeyHashFunction;
    return (key)=>{
        if (!cacheOptions?.namespace) return hashFunction(key);
        const separator = cacheOptions.namespaceSeparator || defaultNamespaceSeparator;
        return `${cacheOptions.namespace}${separator}${hashFunction(key)}`;
    };
}
function wrapWithKeyTransformation(resolveCache, makeKey) {
    return {
        get: (key)=>{
            return resolveCache().get(makeKey(key));
        },
        set: (key, value, options)=>{
            return resolveCache().set(makeKey(key), value, options);
        },
        delete: (key)=>{
            return resolveCache().delete(makeKey(key));
        },
        expireTag: (tag)=>{
            return resolveCache().expireTag(tag);
        }
    };
}
let warnedCacheUnavailable = false;
function getCacheImplementation(debug) {
    if (!inMemoryCacheInstance) {
        inMemoryCacheInstance = new import_in_memory_cache.InMemoryCache();
    }
    if (process.env.RUNTIME_CACHE_DISABLE_BUILD_CACHE === "true") {
        debug && console.log("Using InMemoryCache as build cache is disabled");
        return inMemoryCacheInstance;
    }
    const { RUNTIME_CACHE_ENDPOINT, RUNTIME_CACHE_HEADERS } = process.env;
    if (debug) {
        console.log("Runtime cache environment variables:", {
            RUNTIME_CACHE_ENDPOINT,
            RUNTIME_CACHE_HEADERS
        });
    }
    if (!RUNTIME_CACHE_ENDPOINT || !RUNTIME_CACHE_HEADERS) {
        if (!warnedCacheUnavailable) {
            console.warn("Runtime Cache unavailable in this environment. Falling back to in-memory cache.");
            warnedCacheUnavailable = true;
        }
        return inMemoryCacheInstance;
    }
    if (!buildCacheInstance) {
        let parsedHeaders = {};
        try {
            parsedHeaders = JSON.parse(RUNTIME_CACHE_HEADERS);
        } catch (e) {
            console.error("Failed to parse RUNTIME_CACHE_HEADERS:", e);
            return inMemoryCacheInstance;
        }
        let timeout = 500;
        if (process.env.RUNTIME_CACHE_TIMEOUT) {
            const parsed = parseInt(process.env.RUNTIME_CACHE_TIMEOUT, 10);
            if (!isNaN(parsed) && parsed > 0) {
                timeout = parsed;
            } else {
                console.warn(`Invalid RUNTIME_CACHE_TIMEOUT value: "${process.env.RUNTIME_CACHE_TIMEOUT}". Using default: ${timeout}ms`);
            }
        }
        buildCacheInstance = new import_build_client.BuildCache({
            endpoint: RUNTIME_CACHE_ENDPOINT,
            headers: parsedHeaders,
            onError: (error)=>console.error(error),
            timeout
        });
    }
    return buildCacheInstance;
}
var PkgCacheState = /* @__PURE__ */ ((PkgCacheState2)=>{
    PkgCacheState2["Fresh"] = "fresh";
    PkgCacheState2["Stale"] = "stale";
    PkgCacheState2["Expired"] = "expired";
    PkgCacheState2["NotFound"] = "notFound";
    PkgCacheState2["Error"] = "error";
    return PkgCacheState2;
})(PkgCacheState || {});
const HEADERS_VERCEL_CACHE_STATE = "x-vercel-cache-state";
const HEADERS_VERCEL_REVALIDATE = "x-vercel-revalidate";
const HEADERS_VERCEL_CACHE_TAGS = "x-vercel-cache-tags";
const HEADERS_VERCEL_CACHE_ITEM_NAME = "x-vercel-cache-item-name";
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    HEADERS_VERCEL_CACHE_ITEM_NAME,
    HEADERS_VERCEL_CACHE_STATE,
    HEADERS_VERCEL_CACHE_TAGS,
    HEADERS_VERCEL_REVALIDATE,
    PkgCacheState,
    getCache
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/db-connections/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var db_connections_exports = {};
__export(db_connections_exports, {
    attachDatabasePool: ()=>attachDatabasePool,
    experimental_attachDatabasePool: ()=>experimental_attachDatabasePool
});
module.exports = __toCommonJS(db_connections_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const DEBUG = !!process.env.DEBUG;
function getIdleTimeout(dbPool) {
    if ("options" in dbPool && dbPool.options) {
        if ("idleTimeoutMillis" in dbPool.options) {
            return typeof dbPool.options.idleTimeoutMillis === "number" ? dbPool.options.idleTimeoutMillis : 1e4;
        }
        if ("maxIdleTimeMS" in dbPool.options) {
            return typeof dbPool.options.maxIdleTimeMS === "number" ? dbPool.options.maxIdleTimeMS : 0;
        }
        if ("status" in dbPool) {
            return 5e3;
        }
        if ("connect" in dbPool && "execute" in dbPool) {
            return 3e4;
        }
    }
    if ("config" in dbPool && dbPool.config) {
        if ("connectionConfig" in dbPool.config && dbPool.config.connectionConfig) {
            return dbPool.config.connectionConfig.idleTimeout || 6e4;
        }
        if ("idleTimeout" in dbPool.config) {
            return typeof dbPool.config.idleTimeout === "number" ? dbPool.config.idleTimeout : 6e4;
        }
    }
    if ("poolTimeout" in dbPool) {
        return typeof dbPool.poolTimeout === "number" ? dbPool.poolTimeout : 6e4;
    }
    if ("idleTimeout" in dbPool) {
        return typeof dbPool.idleTimeout === "number" ? dbPool.idleTimeout : 0;
    }
    return 1e4;
}
let idleTimeout = null;
let idleTimeoutResolve = ()=>{};
const bootTime = Date.now();
const maximumDuration = 15 * 60 * 1e3 - 1e3;
function waitUntilIdleTimeout(dbPool) {
    if (!process.env.VERCEL_URL || // This is not set during builds where we don't need to wait for idle connections using the mechanism
    !process.env.VERCEL_REGION) {
        return;
    }
    if (idleTimeout) {
        clearTimeout(idleTimeout);
        idleTimeoutResolve();
    }
    const promise = new Promise((resolve)=>{
        idleTimeoutResolve = resolve;
    });
    const waitTime = Math.min(getIdleTimeout(dbPool) + 100, maximumDuration - (Date.now() - bootTime));
    idleTimeout = setTimeout(()=>{
        idleTimeoutResolve?.();
        if (DEBUG) {
            console.log("Database pool idle timeout reached. Releasing connections.");
        }
    }, waitTime);
    const requestContext = (0, import_get_context.getContext)();
    if (requestContext?.waitUntil) {
        requestContext.waitUntil(promise);
    } else {
        console.warn("Pool release event triggered outside of request scope.");
    }
}
function attachDatabasePool(dbPool) {
    if (idleTimeout) {
        idleTimeoutResolve?.();
        clearTimeout(idleTimeout);
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && "idleTimeoutMillis" in dbPool.options) {
        const pgPool = dbPool;
        pgPool.on("release", ()=>{
            if (DEBUG) {
                console.log("Client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    } else if ("on" in dbPool && dbPool.on && "config" in dbPool && dbPool.config && "connectionConfig" in dbPool.config) {
        const mysqlPool = dbPool;
        mysqlPool.on("release", ()=>{
            if (DEBUG) {
                console.log("MySQL client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    } else if ("on" in dbPool && dbPool.on && "config" in dbPool && dbPool.config && "idleTimeout" in dbPool.config) {
        const mysql2Pool = dbPool;
        mysql2Pool.on("release", ()=>{
            if (DEBUG) {
                console.log("MySQL2/MariaDB client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && dbPool.options && "maxIdleTimeMS" in dbPool.options) {
        const mongoPool = dbPool;
        mongoPool.on("connectionCheckedOut", ()=>{
            if (DEBUG) {
                console.log("MongoDB connection checked out");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && dbPool.options && "socket" in dbPool.options) {
        const redisPool = dbPool;
        redisPool.on("end", ()=>{
            if (DEBUG) {
                console.log("Redis connection ended");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    throw new Error("Unsupported database pool type");
}
const experimental_attachDatabasePool = attachDatabasePool;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    attachDatabasePool,
    experimental_attachDatabasePool
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/purge/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var purge_exports = {};
__export(purge_exports, {
    dangerouslyDeleteBySrcImage: ()=>dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag: ()=>dangerouslyDeleteByTag,
    invalidateBySrcImage: ()=>invalidateBySrcImage,
    invalidateByTag: ()=>invalidateByTag
});
module.exports = __toCommonJS(purge_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const invalidateByTag = (tag)=>{
    const api = (0, import_get_context.getContext)().purge;
    if (api) {
        return api.invalidateByTag(tag);
    }
    return Promise.resolve();
};
const dangerouslyDeleteByTag = (tag, options)=>{
    const api = (0, import_get_context.getContext)().purge;
    if (api) {
        return api.dangerouslyDeleteByTag(tag, options);
    }
    return Promise.resolve();
};
const invalidateBySrcImage = (src)=>{
    const api = (0, import_get_context.getContext)().purge;
    return api ? api.invalidateBySrcImage(src) : Promise.resolve();
};
const dangerouslyDeleteBySrcImage = (src, options)=>{
    const api = (0, import_get_context.getContext)().purge;
    return api ? api.dangerouslyDeleteBySrcImage(src, options) : Promise.resolve();
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag,
    invalidateBySrcImage,
    invalidateByTag
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/addcachetag/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var addcachetag_exports = {};
__export(addcachetag_exports, {
    addCacheTag: ()=>addCacheTag
});
module.exports = __toCommonJS(addcachetag_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const addCacheTag = (tag)=>{
    const addCacheTag2 = (0, import_get_context.getContext)().addCacheTag;
    if (addCacheTag2) {
        return addCacheTag2(tag);
    }
    return Promise.resolve();
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    addCacheTag
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var src_exports = {};
__export(src_exports, {
    addCacheTag: ()=>import_addcachetag.addCacheTag,
    attachDatabasePool: ()=>import_db_connections.attachDatabasePool,
    dangerouslyDeleteBySrcImage: ()=>import_purge.dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag: ()=>import_purge.dangerouslyDeleteByTag,
    experimental_attachDatabasePool: ()=>import_db_connections.experimental_attachDatabasePool,
    geolocation: ()=>import_headers.geolocation,
    getCache: ()=>import_cache.getCache,
    getEnv: ()=>import_get_env.getEnv,
    invalidateBySrcImage: ()=>import_purge.invalidateBySrcImage,
    invalidateByTag: ()=>import_purge.invalidateByTag,
    ipAddress: ()=>import_headers.ipAddress,
    next: ()=>import_middleware.next,
    rewrite: ()=>import_middleware.rewrite,
    waitUntil: ()=>import_wait_until.waitUntil
});
module.exports = __toCommonJS(src_exports);
var import_headers = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/headers.js [app-route] (ecmascript)");
var import_get_env = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-env.js [app-route] (ecmascript)");
var import_wait_until = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/wait-until.js [app-route] (ecmascript)");
var import_middleware = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/middleware.js [app-route] (ecmascript)");
var import_cache = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)");
var import_db_connections = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/db-connections/index.js [app-route] (ecmascript)");
var import_purge = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/purge/index.js [app-route] (ecmascript)");
var import_addcachetag = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/addcachetag/index.js [app-route] (ecmascript)");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    addCacheTag,
    attachDatabasePool,
    dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag,
    experimental_attachDatabasePool,
    geolocation,
    getCache,
    getEnv,
    invalidateBySrcImage,
    invalidateByTag,
    ipAddress,
    next,
    rewrite,
    waitUntil
});
}),
"[project]/frontend/node_modules/.pnpm/ms@2.1.3/node_modules/ms/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Helpers.
 */ var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var w = d * 7;
var y = d * 365.25;
/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} [options]
 * @throws {Error} throw an error if val is not a non-empty string or a number
 * @return {String|Number}
 * @api public
 */ module.exports = function(val, options) {
    options = options || {};
    var type = typeof val;
    if (type === 'string' && val.length > 0) {
        return parse(val);
    } else if (type === 'number' && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
    }
    throw new Error('val is not a non-empty string or a valid number. val=' + JSON.stringify(val));
};
/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */ function parse(str) {
    str = String(str);
    if (str.length > 100) {
        return;
    }
    var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(str);
    if (!match) {
        return;
    }
    var n = parseFloat(match[1]);
    var type = (match[2] || 'ms').toLowerCase();
    switch(type){
        case 'years':
        case 'year':
        case 'yrs':
        case 'yr':
        case 'y':
            return n * y;
        case 'weeks':
        case 'week':
        case 'w':
            return n * w;
        case 'days':
        case 'day':
        case 'd':
            return n * d;
        case 'hours':
        case 'hour':
        case 'hrs':
        case 'hr':
        case 'h':
            return n * h;
        case 'minutes':
        case 'minute':
        case 'mins':
        case 'min':
        case 'm':
            return n * m;
        case 'seconds':
        case 'second':
        case 'secs':
        case 'sec':
        case 's':
            return n * s;
        case 'milliseconds':
        case 'millisecond':
        case 'msecs':
        case 'msec':
        case 'ms':
            return n;
        default:
            return undefined;
    }
}
/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */ function fmtShort(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
        return Math.round(ms / d) + 'd';
    }
    if (msAbs >= h) {
        return Math.round(ms / h) + 'h';
    }
    if (msAbs >= m) {
        return Math.round(ms / m) + 'm';
    }
    if (msAbs >= s) {
        return Math.round(ms / s) + 's';
    }
    return ms + 'ms';
}
/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */ function fmtLong(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
        return plural(ms, msAbs, d, 'day');
    }
    if (msAbs >= h) {
        return plural(ms, msAbs, h, 'hour');
    }
    if (msAbs >= m) {
        return plural(ms, msAbs, m, 'minute');
    }
    if (msAbs >= s) {
        return plural(ms, msAbs, s, 'second');
    }
    return ms + ' ms';
}
/**
 * Pluralization helper.
 */ function plural(ms, msAbs, n, name) {
    var isPlural = msAbs >= n * 1.5;
    return Math.round(ms / n) + ' ' + name + (isPlural ? 's' : '');
}
}),
"[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "once",
    ()=>once,
    "parseDurationToDate",
    ()=>parseDurationToDate,
    "withResolvers",
    ()=>withResolvers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ms$40$2$2e$1$2e$3$2f$node_modules$2f$ms$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ms@2.1.3/node_modules/ms/index.js [app-route] (ecmascript)");
;
function withResolvers() {
    let resolve;
    let reject;
    const promise = new Promise((_resolve, _reject)=>{
        resolve = _resolve;
        reject = _reject;
    });
    return {
        promise,
        resolve,
        reject
    };
}
function once(fn) {
    const result = {
        get value () {
            const value = fn();
            Object.defineProperty(result, 'value', {
                value
            });
            return value;
        }
    };
    return result;
}
function parseDurationToDate(param) {
    if (typeof param === 'string') {
        const durationMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ms$40$2$2e$1$2e$3$2f$node_modules$2f$ms$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(param);
        if (typeof durationMs !== 'number' || durationMs < 0) {
            throw new Error(`Invalid duration: "${param}". Expected a valid duration string like "1s", "1m", "1h", etc.`);
        }
        return new Date(Date.now() + durationMs);
    } else if (typeof param === 'number') {
        if (param < 0 || !Number.isFinite(param)) {
            throw new Error(`Invalid duration: ${param}. Expected a non-negative finite number of milliseconds.`);
        }
        return new Date(Date.now() + param);
    } else if (param instanceof Date || param && typeof param === 'object' && typeof param.getTime === 'function') {
        // Handle both Date instances and date-like objects (from deserialization)
        return param instanceof Date ? param : new Date(param.getTime());
    } else {
        throw new Error(`Invalid duration parameter. Expected a duration string, number (milliseconds), or Date object.`);
    }
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/get-port.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPort",
    ()=>getPort
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$util__$5b$external$5d$__$28$node$3a$util$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:util [external] (node:util, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:child_process [external] (node:child_process, cjs)");
;
;
;
const execFileAsync = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$util__$5b$external$5d$__$28$node$3a$util$2c$__cjs$29$__["promisify"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__["execFile"]);
/**
 * Parses a port string and returns it if valid (0-65535), otherwise undefined.
 */ function parsePort(value, radix = 10) {
    const port = parseInt(value, radix);
    if (!Number.isNaN(port) && port >= 0 && port <= 65535) {
        return port;
    }
    return undefined;
}
// NOTE: We build /proc paths dynamically to prevent @vercel/nft from tracing them.
// NFT's static analysis tries to bundle any file path literal it finds (e.g., '/proc/net/tcp').
// Since /proc is a virtual Linux filesystem, this causes build failures in @sveltejs/adapter-vercel.
const join = (arr, sep)=>arr.join(sep);
const PROC_ROOT = join([
    '',
    'proc'
], '/');
/**
 * Gets listening ports for the current process on Linux by reading /proc filesystem.
 * This approach requires no external commands and works on all Linux systems.
 */ async function getLinuxPort(pid) {
    const listenState = '0A'; // TCP LISTEN state in /proc/net/tcp
    const tcpFiles = [
        `${PROC_ROOT}/net/tcp`,
        `${PROC_ROOT}/net/tcp6`
    ];
    // Step 1: Get socket inodes from /proc/<pid>/fd/ in order
    // We preserve order to maintain deterministic behavior (return first port)
    // Use both array (for order) and Set (for O(1) lookup)
    const socketInodes = [];
    const socketInodesSet = new Set();
    const fdPath = `${PROC_ROOT}/${pid}/fd`;
    try {
        const fds = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readdir"])(fdPath);
        // Sort FDs numerically to ensure deterministic order (FDs are always numeric strings)
        const sortedFds = fds.sort((a, b)=>{
            const numA = Number.parseInt(a, 10);
            const numB = Number.parseInt(b, 10);
            return numA - numB;
        });
        const results = await Promise.allSettled(sortedFds.map(async (fd)=>{
            const link = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readlink"])(`${fdPath}/${fd}`);
            // Socket links look like: socket:[12345]
            const match = link.match(/^socket:\[(\d+)\]$/);
            return match?.[1] ?? null;
        }));
        for (const result of results){
            if (result.status === 'fulfilled' && result.value) {
                socketInodes.push(result.value);
                socketInodesSet.add(result.value);
            }
        }
    } catch  {
        // Process might not exist or no permission
        return undefined;
    }
    if (socketInodes.length === 0) {
        return undefined;
    }
    // Step 2: Read /proc/net/tcp and /proc/net/tcp6 to find listening sockets
    // Format: sl local_address rem_address st ... inode
    // local_address is hex IP:port, st=0A means LISTEN
    // We iterate through socket inodes in order to maintain deterministic behavior
    for (const tcpFile of tcpFiles){
        try {
            const content = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(tcpFile, 'utf8');
            const lines = content.split('\n').slice(1); // Skip header
            // Build a map of inode -> port for quick lookup
            const inodeToPort = new Map();
            for (const line of lines){
                if (!line.trim()) continue; // Skip empty lines
                const parts = line.trim().split(/\s+/);
                if (parts.length < 10) continue;
                const localAddr = parts[1]; // e.g., "00000000:0BB8" (0.0.0.0:3000)
                const state = parts[3]; // "0A" = LISTEN
                const inode = parts[9];
                if (!localAddr || state !== listenState || !inode) continue;
                if (!socketInodesSet.has(inode)) continue;
                // Extract port from hex format (e.g., "0BB8" -> 3000)
                const colonIndex = localAddr.indexOf(':');
                if (colonIndex === -1) continue;
                const portHex = localAddr.slice(colonIndex + 1);
                if (!portHex) continue;
                const port = parsePort(portHex, 16);
                if (port !== undefined) {
                    inodeToPort.set(inode, port);
                }
            }
            // Return the first port matching our socket inodes in order
            for (const inode of socketInodes){
                const port = inodeToPort.get(inode);
                if (port !== undefined) {
                    return port;
                }
            }
        } catch  {
            continue;
        }
    }
    return undefined;
}
async function getPort() {
    const { pid, platform } = process;
    let port;
    try {
        switch(platform){
            case 'linux':
                {
                    port = await getLinuxPort(pid);
                    break;
                }
            case 'darwin':
                {
                    const { stdout } = await execFileAsync('lsof', [
                        '-a',
                        '-i',
                        '-P',
                        '-n',
                        '-p',
                        pid.toString()
                    ]);
                    // Parse lsof output in JS instead of piping to awk
                    // Find first LISTEN line and extract port from address (e.g., "*:3000" or "127.0.0.1:3000")
                    const lines = stdout.split('\n');
                    for (const line of lines){
                        if (line.includes('LISTEN')) {
                            // Column 9 (0-indexed: 8) contains the address like "*:3000" or "127.0.0.1:3000"
                            const parts = line.trim().split(/\s+/);
                            const addr = parts[8];
                            if (addr) {
                                const colonIndex = addr.lastIndexOf(':');
                                if (colonIndex !== -1) {
                                    port = parsePort(addr.slice(colonIndex + 1));
                                    if (port !== undefined) {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
            case 'win32':
                {
                    // Use cmd to run the piped command
                    const { stdout } = await execFileAsync('cmd', [
                        '/c',
                        `netstat -ano | findstr ${pid} | findstr LISTENING`
                    ]);
                    const trimmedOutput = stdout.trim();
                    if (trimmedOutput) {
                        const lines = trimmedOutput.split('\n');
                        for (const line of lines){
                            // Extract port from the local address column
                            // Matches both IPv4 (e.g., "127.0.0.1:3000") and IPv6 bracket notation (e.g., "[::1]:3000")
                            const match = line.trim().match(/^\s*TCP\s+(?:\[[\da-f:]+\]|[\d.]+):(\d+)\s+/i);
                            if (match) {
                                port = parsePort(match[1]);
                                if (port !== undefined) {
                                    break;
                                }
                            }
                        }
                    }
                    break;
                }
        }
    } catch (error) {
        // In dev, it's helpful to know why detection failed
        if ("TURBOPACK compile-time truthy", 1) {
            console.debug('[getPort] Detection failed:', error);
        }
        return undefined;
    }
    return Number.isNaN(port) ? undefined : port;
} //# sourceMappingURL=get-port.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ERROR_SLUGS",
    ()=>ERROR_SLUGS,
    "FatalError",
    ()=>FatalError,
    "RetryableError",
    ()=>RetryableError,
    "WorkflowAPIError",
    ()=>WorkflowAPIError,
    "WorkflowError",
    ()=>WorkflowError,
    "WorkflowRunCancelledError",
    ()=>WorkflowRunCancelledError,
    "WorkflowRunFailedError",
    ()=>WorkflowRunFailedError,
    "WorkflowRunNotCompletedError",
    ()=>WorkflowRunNotCompletedError,
    "WorkflowRunNotFoundError",
    ()=>WorkflowRunNotFoundError,
    "WorkflowRuntimeError",
    ()=>WorkflowRuntimeError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/index.js [app-route] (ecmascript)");
;
const BASE_URL = 'https://useworkflow.dev/err';
/**
 * @internal
 * Check if a value is an Error without relying on Node.js utilities.
 * This is needed for error classes that can be used in VM contexts where
 * Node.js imports are not available.
 */ function isError(value) {
    return typeof value === 'object' && value !== null && 'name' in value && 'message' in value;
}
const ERROR_SLUGS = {
    NODE_JS_MODULE_IN_WORKFLOW: 'node-js-module-in-workflow',
    START_INVALID_WORKFLOW_FUNCTION: 'start-invalid-workflow-function',
    SERIALIZATION_FAILED: 'serialization-failed',
    WEBHOOK_INVALID_RESPOND_WITH_VALUE: 'webhook-invalid-respond-with-value',
    WEBHOOK_RESPONSE_NOT_SENT: 'webhook-response-not-sent',
    FETCH_IN_WORKFLOW_FUNCTION: 'fetch-in-workflow'
};
class WorkflowError extends Error {
    cause;
    constructor(message, options){
        const msgDocs = options?.slug ? `${message}\n\nLearn more: ${BASE_URL}/${options.slug}` : message;
        super(msgDocs, {
            cause: options?.cause
        });
        this.cause = options?.cause;
        if (options?.cause instanceof Error) {
            this.stack = `${this.stack}\nCaused by: ${options.cause.stack}`;
        }
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowError';
    }
}
class WorkflowAPIError extends WorkflowError {
    status;
    code;
    url;
    constructor(message, options){
        super(message, {
            cause: options?.cause
        });
        this.name = 'WorkflowAPIError';
        this.status = options?.status;
        this.code = options?.code;
        this.url = options?.url;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowAPIError';
    }
}
class WorkflowRunFailedError extends WorkflowError {
    runId;
    constructor(runId, error){
        // Create a proper Error instance from the StructuredError to set as cause
        // NOTE: custom error types do not get serialized/deserialized. Everything is an Error
        const causeError = new Error(error.message);
        if (error.stack) {
            causeError.stack = error.stack;
        }
        if (error.code) {
            causeError.code = error.code;
        }
        super(`Workflow run "${runId}" failed: ${error.message}`, {
            cause: causeError
        });
        this.name = 'WorkflowRunFailedError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunFailedError';
    }
}
class WorkflowRunNotCompletedError extends WorkflowError {
    runId;
    status;
    constructor(runId, status){
        super(`Workflow run "${runId}" has not completed`, {});
        this.name = 'WorkflowRunNotCompletedError';
        this.runId = runId;
        this.status = status;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunNotCompletedError';
    }
}
class WorkflowRuntimeError extends WorkflowError {
    constructor(message, options){
        super(message, {
            ...options
        });
        this.name = 'WorkflowRuntimeError';
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRuntimeError';
    }
}
class WorkflowRunNotFoundError extends WorkflowError {
    runId;
    constructor(runId){
        super(`Workflow run "${runId}" not found`, {});
        this.name = 'WorkflowRunNotFoundError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunNotFoundError';
    }
}
class WorkflowRunCancelledError extends WorkflowError {
    runId;
    constructor(runId){
        super(`Workflow run "${runId}" cancelled`, {});
        this.name = 'WorkflowRunCancelledError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunCancelledError';
    }
}
class FatalError extends Error {
    fatal = true;
    constructor(message){
        super(message);
        this.name = 'FatalError';
    }
    static is(value) {
        return isError(value) && value.name === 'FatalError';
    }
}
class RetryableError extends Error {
    /**
     * The Date when the step should be retried.
     */ retryAfter;
    constructor(message, options = {}){
        super(message);
        this.name = 'RetryableError';
        if (options.retryAfter !== undefined) {
            this.retryAfter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseDurationToDate"])(options.retryAfter);
        } else {
            // Default to 1 second (1000 milliseconds)
            this.retryAfter = new Date(Date.now() + 1000);
        }
    }
    static is(value) {
        return isError(value) && value.name === 'RetryableError';
    }
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseEventSchema",
    ()=>BaseEventSchema,
    "CreateEventSchema",
    ()=>CreateEventSchema,
    "EventSchema",
    ()=>EventSchema,
    "EventTypeSchema",
    ()=>EventTypeSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const EventTypeSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'step_completed',
    'step_failed',
    'step_retrying',
    'step_started',
    'hook_created',
    'hook_received',
    'hook_disposed',
    'wait_created',
    'wait_completed',
    'workflow_completed',
    'workflow_failed',
    'workflow_started'
]);
const BaseEventSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    eventType: EventTypeSchema,
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
});
// Event schemas (shared between creation requests and server responses)
const StepCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_completed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        result: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
const StepFailedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_failed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
        stack: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
        fatal: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().optional()
    })
});
// TODO: this is not actually used anywhere yet, we could remove it
// on client and server if needed
const StepRetryingEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_retrying'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        attempt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().min(1)
    })
});
const StepStartedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_started'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const HookCreatedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_created'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const HookReceivedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_received'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        payload: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
const HookDisposedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_disposed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const WaitCreatedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('wait_created'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        resumeAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    })
});
const WaitCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('wait_completed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
// TODO: not used yet
const WorkflowCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_completed')
});
// TODO: not used yet
const WorkflowFailedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_failed'),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
// TODO: not used yet
const WorkflowStartedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_started')
});
const CreateEventSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].discriminatedUnion('eventType', [
    StepCompletedEventSchema,
    StepFailedEventSchema,
    StepRetryingEventSchema,
    StepStartedEventSchema,
    HookCreatedEventSchema,
    HookReceivedEventSchema,
    HookDisposedEventSchema,
    WaitCreatedEventSchema,
    WaitCompletedEventSchema,
    WorkflowCompletedEventSchema,
    WorkflowFailedEventSchema,
    WorkflowStartedEventSchema
]);
const EventSchema = CreateEventSchema.and(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
})); //# sourceMappingURL=events.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PaginatedResponseSchema",
    ()=>PaginatedResponseSchema,
    "StructuredErrorSchema",
    ()=>StructuredErrorSchema,
    "zodJsonSchema",
    ()=>zodJsonSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const zodJsonSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].lazy(()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].null(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(zodJsonSchema),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(), zodJsonSchema)
    ]);
});
const PaginatedResponseSchema = (dataSchema)=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        data: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(dataSchema),
        cursor: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        hasMore: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
    });
const StructuredErrorSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    message: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stack: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
    code: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
}); //# sourceMappingURL=shared.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HookSchema",
    ()=>HookSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const HookSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    hookId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    token: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    ownerId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    projectId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    environment: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    metadata: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["zodJsonSchema"].optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
}); //# sourceMappingURL=hooks.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageId",
    ()=>MessageId,
    "QueuePayloadSchema",
    ()=>QueuePayloadSchema,
    "QueuePrefix",
    ()=>QueuePrefix,
    "StepInvokePayloadSchema",
    ()=>StepInvokePayloadSchema,
    "TraceCarrierSchema",
    ()=>TraceCarrierSchema,
    "ValidQueueName",
    ()=>ValidQueueName,
    "WorkflowInvokePayloadSchema",
    ()=>WorkflowInvokePayloadSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/index.js [app-route] (ecmascript)");
;
const QueuePrefix = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal('__wkf_step_'),
    __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal('__wkf_workflow_')
]);
const ValidQueueName = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].templateLiteral([
    QueuePrefix,
    __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
]);
const MessageId = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().brand().describe('A stored queue message ID');
const TraceCarrierSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string());
const WorkflowInvokePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    traceCarrier: TraceCarrierSchema.optional(),
    requestedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].coerce.date().optional()
});
const StepInvokePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    workflowName: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    workflowRunId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    workflowStartedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number(),
    stepId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    traceCarrier: TraceCarrierSchema.optional(),
    requestedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].coerce.date().optional()
});
const QueuePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    WorkflowInvokePayloadSchema,
    StepInvokePayloadSchema
]); //# sourceMappingURL=queue.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkflowRunBaseSchema",
    ()=>WorkflowRunBaseSchema,
    "WorkflowRunSchema",
    ()=>WorkflowRunSchema,
    "WorkflowRunStatusSchema",
    ()=>WorkflowRunStatusSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const WorkflowRunStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'pending',
    'running',
    'completed',
    'failed',
    'paused',
    'cancelled'
]);
const WorkflowRunBaseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: WorkflowRunStatusSchema,
    deploymentId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    workflowName: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    executionContext: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()).optional(),
    input: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"].optional(),
    expiredAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    startedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    updatedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
});
const WorkflowRunSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].discriminatedUnion('status', [
    // Non-final states
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
            'pending',
            'running',
            'paused'
        ]),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined()
    }),
    // Cancelled state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('cancelled'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    }),
    // Completed state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('completed'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    }),
    // Failed state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('failed'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"],
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    })
]); //# sourceMappingURL=runs.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepSchema",
    ()=>StepSchema,
    "StepStatusSchema",
    ()=>StepStatusSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const StepStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'pending',
    'running',
    'completed',
    'failed',
    'cancelled'
]);
const StepSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stepId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stepName: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: StepStatusSchema,
    input: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"].optional(),
    attempt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    startedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    updatedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    retryAfter: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional()
}); //# sourceMappingURL=steps.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)"); //# sourceMappingURL=index.js.map
;
;
;
;
;
;
}),
"[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/common.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * This is the common logic for both the Node.js and web browser
 * implementations of `debug()`.
 */ function setup(env) {
    createDebug.debug = createDebug;
    createDebug.default = createDebug;
    createDebug.coerce = coerce;
    createDebug.disable = disable;
    createDebug.enable = enable;
    createDebug.enabled = enabled;
    createDebug.humanize = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/ms@2.1.3/node_modules/ms/index.js [app-route] (ecmascript)");
    createDebug.destroy = destroy;
    Object.keys(env).forEach((key)=>{
        createDebug[key] = env[key];
    });
    /**
	* The currently active debug mode names, and names to skip.
	*/ createDebug.names = [];
    createDebug.skips = [];
    /**
	* Map of special "%n" handling functions, for the debug "format" argument.
	*
	* Valid key names are a single, lower or upper-case letter, i.e. "n" and "N".
	*/ createDebug.formatters = {};
    /**
	* Selects a color for a debug namespace
	* @param {String} namespace The namespace string for the debug instance to be colored
	* @return {Number|String} An ANSI color code for the given namespace
	* @api private
	*/ function selectColor(namespace) {
        let hash = 0;
        for(let i = 0; i < namespace.length; i++){
            hash = (hash << 5) - hash + namespace.charCodeAt(i);
            hash |= 0; // Convert to 32bit integer
        }
        return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
    }
    createDebug.selectColor = selectColor;
    /**
	* Create a debugger with the given `namespace`.
	*
	* @param {String} namespace
	* @return {Function}
	* @api public
	*/ function createDebug(namespace) {
        let prevTime;
        let enableOverride = null;
        let namespacesCache;
        let enabledCache;
        function debug(...args) {
            // Disabled?
            if (!debug.enabled) {
                return;
            }
            const self = debug;
            // Set `diff` timestamp
            const curr = Number(new Date());
            const ms = curr - (prevTime || curr);
            self.diff = ms;
            self.prev = prevTime;
            self.curr = curr;
            prevTime = curr;
            args[0] = createDebug.coerce(args[0]);
            if (typeof args[0] !== 'string') {
                // Anything else let's inspect with %O
                args.unshift('%O');
            }
            // Apply any `formatters` transformations
            let index = 0;
            args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format)=>{
                // If we encounter an escaped % then don't increase the array index
                if (match === '%%') {
                    return '%';
                }
                index++;
                const formatter = createDebug.formatters[format];
                if (typeof formatter === 'function') {
                    const val = args[index];
                    match = formatter.call(self, val);
                    // Now we need to remove `args[index]` since it's inlined in the `format`
                    args.splice(index, 1);
                    index--;
                }
                return match;
            });
            // Apply env-specific formatting (colors, etc.)
            createDebug.formatArgs.call(self, args);
            const logFn = self.log || createDebug.log;
            logFn.apply(self, args);
        }
        debug.namespace = namespace;
        debug.useColors = createDebug.useColors();
        debug.color = createDebug.selectColor(namespace);
        debug.extend = extend;
        debug.destroy = createDebug.destroy; // XXX Temporary. Will be removed in the next major release.
        Object.defineProperty(debug, 'enabled', {
            enumerable: true,
            configurable: false,
            get: ()=>{
                if (enableOverride !== null) {
                    return enableOverride;
                }
                if (namespacesCache !== createDebug.namespaces) {
                    namespacesCache = createDebug.namespaces;
                    enabledCache = createDebug.enabled(namespace);
                }
                return enabledCache;
            },
            set: (v)=>{
                enableOverride = v;
            }
        });
        // Env-specific initialization logic for debug instances
        if (typeof createDebug.init === 'function') {
            createDebug.init(debug);
        }
        return debug;
    }
    function extend(namespace, delimiter) {
        const newDebug = createDebug(this.namespace + (typeof delimiter === 'undefined' ? ':' : delimiter) + namespace);
        newDebug.log = this.log;
        return newDebug;
    }
    /**
	* Enables a debug mode by namespaces. This can include modes
	* separated by a colon and wildcards.
	*
	* @param {String} namespaces
	* @api public
	*/ function enable(namespaces) {
        createDebug.save(namespaces);
        createDebug.namespaces = namespaces;
        createDebug.names = [];
        createDebug.skips = [];
        const split = (typeof namespaces === 'string' ? namespaces : '').trim().replace(/\s+/g, ',').split(',').filter(Boolean);
        for (const ns of split){
            if (ns[0] === '-') {
                createDebug.skips.push(ns.slice(1));
            } else {
                createDebug.names.push(ns);
            }
        }
    }
    /**
	 * Checks if the given string matches a namespace template, honoring
	 * asterisks as wildcards.
	 *
	 * @param {String} search
	 * @param {String} template
	 * @return {Boolean}
	 */ function matchesTemplate(search, template) {
        let searchIndex = 0;
        let templateIndex = 0;
        let starIndex = -1;
        let matchIndex = 0;
        while(searchIndex < search.length){
            if (templateIndex < template.length && (template[templateIndex] === search[searchIndex] || template[templateIndex] === '*')) {
                // Match character or proceed with wildcard
                if (template[templateIndex] === '*') {
                    starIndex = templateIndex;
                    matchIndex = searchIndex;
                    templateIndex++; // Skip the '*'
                } else {
                    searchIndex++;
                    templateIndex++;
                }
            } else if (starIndex !== -1) {
                // Backtrack to the last '*' and try to match more characters
                templateIndex = starIndex + 1;
                matchIndex++;
                searchIndex = matchIndex;
            } else {
                return false; // No match
            }
        }
        // Handle trailing '*' in template
        while(templateIndex < template.length && template[templateIndex] === '*'){
            templateIndex++;
        }
        return templateIndex === template.length;
    }
    /**
	* Disable debug output.
	*
	* @return {String} namespaces
	* @api public
	*/ function disable() {
        const namespaces = [
            ...createDebug.names,
            ...createDebug.skips.map((namespace)=>'-' + namespace)
        ].join(',');
        createDebug.enable('');
        return namespaces;
    }
    /**
	* Returns true if the given mode name is enabled, false otherwise.
	*
	* @param {String} name
	* @return {Boolean}
	* @api public
	*/ function enabled(name) {
        for (const skip of createDebug.skips){
            if (matchesTemplate(name, skip)) {
                return false;
            }
        }
        for (const ns of createDebug.names){
            if (matchesTemplate(name, ns)) {
                return true;
            }
        }
        return false;
    }
    /**
	* Coerce `val`.
	*
	* @param {Mixed} val
	* @return {Mixed}
	* @api private
	*/ function coerce(val) {
        if (val instanceof Error) {
            return val.stack || val.message;
        }
        return val;
    }
    /**
	* XXX DO NOT USE. This is a temporary stub function.
	* XXX It WILL be removed in the next major release.
	*/ function destroy() {
        console.warn('Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.');
    }
    createDebug.enable(createDebug.load());
    return createDebug;
}
module.exports = setup;
}),
"[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/node.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Module dependencies.
 */ const tty = __turbopack_context__.r("[externals]/tty [external] (tty, cjs)");
const util = __turbopack_context__.r("[externals]/util [external] (util, cjs)");
/**
 * This is the Node.js implementation of `debug()`.
 */ exports.init = init;
exports.log = log;
exports.formatArgs = formatArgs;
exports.save = save;
exports.load = load;
exports.useColors = useColors;
exports.destroy = util.deprecate(()=>{}, 'Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.');
/**
 * Colors.
 */ exports.colors = [
    6,
    2,
    3,
    4,
    5,
    1
];
try {
    // Optional dependency (as in, doesn't need to be installed, NOT like optionalDependencies in package.json)
    // eslint-disable-next-line import/no-extraneous-dependencies
    const supportsColor = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/supports-color@8.1.1/node_modules/supports-color/index.js [app-route] (ecmascript)");
    if (supportsColor && (supportsColor.stderr || supportsColor).level >= 2) {
        exports.colors = [
            20,
            21,
            26,
            27,
            32,
            33,
            38,
            39,
            40,
            41,
            42,
            43,
            44,
            45,
            56,
            57,
            62,
            63,
            68,
            69,
            74,
            75,
            76,
            77,
            78,
            79,
            80,
            81,
            92,
            93,
            98,
            99,
            112,
            113,
            128,
            129,
            134,
            135,
            148,
            149,
            160,
            161,
            162,
            163,
            164,
            165,
            166,
            167,
            168,
            169,
            170,
            171,
            172,
            173,
            178,
            179,
            184,
            185,
            196,
            197,
            198,
            199,
            200,
            201,
            202,
            203,
            204,
            205,
            206,
            207,
            208,
            209,
            214,
            215,
            220,
            221
        ];
    }
} catch (error) {
// Swallow - we only care if `supports-color` is available; it doesn't have to be.
}
/**
 * Build up the default `inspectOpts` object from the environment variables.
 *
 *   $ DEBUG_COLORS=no DEBUG_DEPTH=10 DEBUG_SHOW_HIDDEN=enabled node script.js
 */ exports.inspectOpts = Object.keys(process.env).filter((key)=>{
    return /^debug_/i.test(key);
}).reduce((obj, key)=>{
    // Camel-case
    const prop = key.substring(6).toLowerCase().replace(/_([a-z])/g, (_, k)=>{
        return k.toUpperCase();
    });
    // Coerce string value into JS value
    let val = process.env[key];
    if (/^(yes|on|true|enabled)$/i.test(val)) {
        val = true;
    } else if (/^(no|off|false|disabled)$/i.test(val)) {
        val = false;
    } else if (val === 'null') {
        val = null;
    } else {
        val = Number(val);
    }
    obj[prop] = val;
    return obj;
}, {});
/**
 * Is stdout a TTY? Colored output is enabled when `true`.
 */ function useColors() {
    return 'colors' in exports.inspectOpts ? Boolean(exports.inspectOpts.colors) : tty.isatty(process.stderr.fd);
}
/**
 * Adds ANSI color escape codes if enabled.
 *
 * @api public
 */ function formatArgs(args) {
    const { namespace: name, useColors } = this;
    if (useColors) {
        const c = this.color;
        const colorCode = '\u001B[3' + (c < 8 ? c : '8;5;' + c);
        const prefix = `  ${colorCode};1m${name} \u001B[0m`;
        args[0] = prefix + args[0].split('\n').join('\n' + prefix);
        args.push(colorCode + 'm+' + module.exports.humanize(this.diff) + '\u001B[0m');
    } else {
        args[0] = getDate() + name + ' ' + args[0];
    }
}
function getDate() {
    if (exports.inspectOpts.hideDate) {
        return '';
    }
    return new Date().toISOString() + ' ';
}
/**
 * Invokes `util.formatWithOptions()` with the specified arguments and writes to stderr.
 */ function log(...args) {
    return process.stderr.write(util.formatWithOptions(exports.inspectOpts, ...args) + '\n');
}
/**
 * Save `namespaces`.
 *
 * @param {String} namespaces
 * @api private
 */ function save(namespaces) {
    if (namespaces) {
        process.env.DEBUG = namespaces;
    } else {
        // If you set a process.env field to null or undefined, it gets cast to the
        // string 'null' or 'undefined'. Just delete instead.
        delete process.env.DEBUG;
    }
}
/**
 * Load `namespaces`.
 *
 * @return {String} returns the previously persisted debug modes
 * @api private
 */ function load() {
    return process.env.DEBUG;
}
/**
 * Init logic for `debug` instances.
 *
 * Create a new `inspectOpts` object in case `useColors` is set
 * differently for a particular `debug` instance.
 */ function init(debug) {
    debug.inspectOpts = {};
    const keys = Object.keys(exports.inspectOpts);
    for(let i = 0; i < keys.length; i++){
        debug.inspectOpts[keys[i]] = exports.inspectOpts[keys[i]];
    }
}
module.exports = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/common.js [app-route] (ecmascript)")(exports);
const { formatters } = module.exports;
/**
 * Map %o to `util.inspect()`, all on a single line.
 */ formatters.o = function(v) {
    this.inspectOpts.colors = this.useColors;
    return util.inspect(v, this.inspectOpts).split('\n').map((str)=>str.trim()).join(' ');
};
/**
 * Map %O to `util.inspect()`, allowing multiple lines if needed.
 */ formatters.O = function(v) {
    this.inspectOpts.colors = this.useColors;
    return util.inspect(v, this.inspectOpts);
};
}),
"[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/browser.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/* eslint-env browser */ /**
 * This is the web browser implementation of `debug()`.
 */ exports.formatArgs = formatArgs;
exports.save = save;
exports.load = load;
exports.useColors = useColors;
exports.storage = localstorage();
exports.destroy = (()=>{
    let warned = false;
    return ()=>{
        if (!warned) {
            warned = true;
            console.warn('Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.');
        }
    };
})();
/**
 * Colors.
 */ exports.colors = [
    '#0000CC',
    '#0000FF',
    '#0033CC',
    '#0033FF',
    '#0066CC',
    '#0066FF',
    '#0099CC',
    '#0099FF',
    '#00CC00',
    '#00CC33',
    '#00CC66',
    '#00CC99',
    '#00CCCC',
    '#00CCFF',
    '#3300CC',
    '#3300FF',
    '#3333CC',
    '#3333FF',
    '#3366CC',
    '#3366FF',
    '#3399CC',
    '#3399FF',
    '#33CC00',
    '#33CC33',
    '#33CC66',
    '#33CC99',
    '#33CCCC',
    '#33CCFF',
    '#6600CC',
    '#6600FF',
    '#6633CC',
    '#6633FF',
    '#66CC00',
    '#66CC33',
    '#9900CC',
    '#9900FF',
    '#9933CC',
    '#9933FF',
    '#99CC00',
    '#99CC33',
    '#CC0000',
    '#CC0033',
    '#CC0066',
    '#CC0099',
    '#CC00CC',
    '#CC00FF',
    '#CC3300',
    '#CC3333',
    '#CC3366',
    '#CC3399',
    '#CC33CC',
    '#CC33FF',
    '#CC6600',
    '#CC6633',
    '#CC9900',
    '#CC9933',
    '#CCCC00',
    '#CCCC33',
    '#FF0000',
    '#FF0033',
    '#FF0066',
    '#FF0099',
    '#FF00CC',
    '#FF00FF',
    '#FF3300',
    '#FF3333',
    '#FF3366',
    '#FF3399',
    '#FF33CC',
    '#FF33FF',
    '#FF6600',
    '#FF6633',
    '#FF9900',
    '#FF9933',
    '#FFCC00',
    '#FFCC33'
];
/**
 * Currently only WebKit-based Web Inspectors, Firefox >= v31,
 * and the Firebug extension (any Firefox version) are known
 * to support "%c" CSS customizations.
 *
 * TODO: add a `localStorage` variable to explicitly enable/disable colors
 */ // eslint-disable-next-line complexity
function useColors() {
    // NB: In an Electron preload script, document will be defined but not fully
    // initialized. Since we know we're in Chrome, we'll just detect this case
    // explicitly
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    // Internet Explorer and Edge do not support colors.
    if (typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
        return false;
    }
    let m;
    // Is webkit? http://stackoverflow.com/a/16459606/376773
    // document is undefined in react-native: https://github.com/facebook/react-native/pull/1632
    // eslint-disable-next-line no-return-assign
    return typeof document !== 'undefined' && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || ("TURBOPACK compile-time value", "undefined") !== 'undefined' && window.console && (window.console.firebug || window.console.exception && window.console.table) || typeof navigator !== 'undefined' && navigator.userAgent && (m = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(m[1], 10) >= 31 || typeof navigator !== 'undefined' && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
}
/**
 * Colorize log arguments if enabled.
 *
 * @api public
 */ function formatArgs(args) {
    args[0] = (this.useColors ? '%c' : '') + this.namespace + (this.useColors ? ' %c' : ' ') + args[0] + (this.useColors ? '%c ' : ' ') + '+' + module.exports.humanize(this.diff);
    if (!this.useColors) {
        return;
    }
    const c = 'color: ' + this.color;
    args.splice(1, 0, c, 'color: inherit');
    // The final "%c" is somewhat tricky, because there could be other
    // arguments passed either before or after the %c, so we need to
    // figure out the correct index to insert the CSS into
    let index = 0;
    let lastC = 0;
    args[0].replace(/%[a-zA-Z%]/g, (match)=>{
        if (match === '%%') {
            return;
        }
        index++;
        if (match === '%c') {
            // We only are interested in the *last* %c
            // (the user may have provided their own)
            lastC = index;
        }
    });
    args.splice(lastC, 0, c);
}
/**
 * Invokes `console.debug()` when available.
 * No-op when `console.debug` is not a "function".
 * If `console.debug` is not available, falls back
 * to `console.log`.
 *
 * @api public
 */ exports.log = console.debug || console.log || (()=>{});
/**
 * Save `namespaces`.
 *
 * @param {String} namespaces
 * @api private
 */ function save(namespaces) {
    try {
        if (namespaces) {
            exports.storage.setItem('debug', namespaces);
        } else {
            exports.storage.removeItem('debug');
        }
    } catch (error) {
    // Swallow
    // XXX (@Qix-) should we be logging these?
    }
}
/**
 * Load `namespaces`.
 *
 * @return {String} returns the previously persisted debug modes
 * @api private
 */ function load() {
    let r;
    try {
        r = exports.storage.getItem('debug') || exports.storage.getItem('DEBUG');
    } catch (error) {
    // Swallow
    // XXX (@Qix-) should we be logging these?
    }
    // If debug isn't set in LS, and we're in Electron, try to load $DEBUG
    if (!r && typeof process !== 'undefined' && 'env' in process) {
        r = process.env.DEBUG;
    }
    return r;
}
/**
 * Localstorage attempts to return the localstorage.
 *
 * This is necessary because safari throws
 * when a user disables cookies/localstorage
 * and you attempt to access it.
 *
 * @return {LocalStorage}
 * @api private
 */ function localstorage() {
    try {
        // TVMLKit (Apple TV JS Runtime) does not have a window object, just localStorage in the global context
        // The Browser also has localStorage in the global context.
        return localStorage;
    } catch (error) {
    // Swallow
    // XXX (@Qix-) should we be logging these?
    }
}
module.exports = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/common.js [app-route] (ecmascript)")(exports);
const { formatters } = module.exports;
/**
 * Map %j to `JSON.stringify()`, since no Web Inspectors do that by default.
 */ formatters.j = function(v) {
    try {
        return JSON.stringify(v);
    } catch (error) {
        return '[UnexpectedJSONParseError]: ' + error.message;
    }
};
}),
"[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Detect Electron renderer / nwjs process, which is node, but we should
 * treat as a browser.
 */ if (typeof process === 'undefined' || process.type === 'renderer' || ("TURBOPACK compile-time value", false) === true || process.__nwjs) {
    module.exports = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/browser.js [app-route] (ecmascript)");
} else {
    module.exports = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/debug@4.4.3_supports-color@8.1.1/node_modules/debug/src/node.js [app-route] (ecmascript)");
}
}),
"[project]/frontend/node_modules/.pnpm/has-flag@4.0.0/node_modules/has-flag/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

module.exports = (flag, argv = process.argv)=>{
    const prefix = flag.startsWith('-') ? '' : flag.length === 1 ? '-' : '--';
    const position = argv.indexOf(prefix + flag);
    const terminatorPosition = argv.indexOf('--');
    return position !== -1 && (terminatorPosition === -1 || position < terminatorPosition);
};
}),
"[project]/frontend/node_modules/.pnpm/supports-color@8.1.1/node_modules/supports-color/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

const os = __turbopack_context__.r("[externals]/os [external] (os, cjs)");
const tty = __turbopack_context__.r("[externals]/tty [external] (tty, cjs)");
const hasFlag = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/has-flag@4.0.0/node_modules/has-flag/index.js [app-route] (ecmascript)");
const { env } = process;
let flagForceColor;
if (hasFlag('no-color') || hasFlag('no-colors') || hasFlag('color=false') || hasFlag('color=never')) {
    flagForceColor = 0;
} else if (hasFlag('color') || hasFlag('colors') || hasFlag('color=true') || hasFlag('color=always')) {
    flagForceColor = 1;
}
function envForceColor() {
    if ('FORCE_COLOR' in env) {
        if (env.FORCE_COLOR === 'true') {
            return 1;
        }
        if (env.FORCE_COLOR === 'false') {
            return 0;
        }
        return env.FORCE_COLOR.length === 0 ? 1 : Math.min(Number.parseInt(env.FORCE_COLOR, 10), 3);
    }
}
function translateLevel(level) {
    if (level === 0) {
        return false;
    }
    return {
        level,
        hasBasic: true,
        has256: level >= 2,
        has16m: level >= 3
    };
}
function supportsColor(haveStream, { streamIsTTY, sniffFlags = true } = {}) {
    const noFlagForceColor = envForceColor();
    if (noFlagForceColor !== undefined) {
        flagForceColor = noFlagForceColor;
    }
    const forceColor = sniffFlags ? flagForceColor : noFlagForceColor;
    if (forceColor === 0) {
        return 0;
    }
    if (sniffFlags) {
        if (hasFlag('color=16m') || hasFlag('color=full') || hasFlag('color=truecolor')) {
            return 3;
        }
        if (hasFlag('color=256')) {
            return 2;
        }
    }
    if (haveStream && !streamIsTTY && forceColor === undefined) {
        return 0;
    }
    const min = forceColor || 0;
    if (env.TERM === 'dumb') {
        return min;
    }
    if ("TURBOPACK compile-time truthy", 1) {
        // Windows 10 build 10586 is the first Windows release that supports 256 colors.
        // Windows 10 build 14931 is the first release that supports 16m/TrueColor.
        const osRelease = os.release().split('.');
        if (Number(osRelease[0]) >= 10 && Number(osRelease[2]) >= 10586) {
            return Number(osRelease[2]) >= 14931 ? 3 : 2;
        }
        return 1;
    }
    //TURBOPACK unreachable
    ;
}
function getSupportLevel(stream, options = {}) {
    const level = supportsColor(stream, {
        streamIsTTY: stream && stream.isTTY,
        ...options
    });
    return translateLevel(level);
}
module.exports = {
    supportsColor: getSupportLevel,
    stdout: getSupportLevel({
        isTTY: tty.isatty(1)
    }),
    stderr: getSupportLevel({
        isTTY: tty.isatty(2)
    })
};
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/util.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Creates a lazily-evaluated, memoized version of the provided function.
 *
 * The returned object exposes a `value` getter that calls `fn` only once,
 * caches its result, and returns the cached value on subsequent accesses.
 *
 * @typeParam T - The return type of the provided function.
 * @param fn - The function to be called once and whose result will be cached.
 * @returns An object with a `value` property that returns the memoized result of `fn`.
 */ __turbopack_context__.s([
    "once",
    ()=>once
]);
function once(fn) {
    const result = {
        get value () {
            const value = fn();
            Object.defineProperty(result, 'value', {
                value
            });
            return value;
        }
    };
    return result;
} //# sourceMappingURL=util.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_RESOLVE_DATA_OPTION",
    ()=>DEFAULT_RESOLVE_DATA_OPTION,
    "config",
    ()=>config,
    "resolveBaseUrl",
    ()=>resolveBaseUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$get$2d$port$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/get-port.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/util.js [app-route] (ecmascript)");
;
;
const getDataDirFromEnv = ()=>{
    return process.env.WORKFLOW_LOCAL_DATA_DIR || '.workflow-data';
};
const DEFAULT_RESOLVE_DATA_OPTION = 'all';
const getBaseUrlFromEnv = ()=>{
    return process.env.WORKFLOW_LOCAL_BASE_URL;
};
const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["once"])(()=>{
    const dataDir = getDataDirFromEnv();
    const baseUrl = getBaseUrlFromEnv();
    return {
        dataDir,
        baseUrl
    };
});
async function resolveBaseUrl(config) {
    if (config.baseUrl) {
        return config.baseUrl;
    }
    if (typeof config.port === 'number') {
        return `http://localhost:${config.port}`;
    }
    if (process.env.PORT) {
        return `http://localhost:${process.env.PORT}`;
    }
    const detectedPort = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$get$2d$port$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getPort"])();
    if (detectedPort) {
        return `http://localhost:${detectedPort}`;
    }
    throw new Error('Unable to resolve base URL for workflow queue.');
} //# sourceMappingURL=config.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/queue.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createQueue",
    ()=>createQueue
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$timers$2f$promises__$5b$external$5d$__$28$node$3a$timers$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:timers/promises [external] (node:timers/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+queue@0.0.0-alpha.33/node_modules/@vercel/queue/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$async$2d$sema$40$3$2e$1$2e$1$2f$node_modules$2f$async$2d$sema$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/async-sema@3.1.1/node_modules/async-sema/lib/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$undici$40$6$2e$22$2e$0$2f$node_modules$2f$undici$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/undici@6.22.0/node_modules/undici/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
// For local queue, there is no technical limit on the message visibility lifespan,
// but the environment variable can be used for testing purposes to set a max visibility limit.
const LOCAL_QUEUE_MAX_VISIBILITY = parseInt(process.env.WORKFLOW_LOCAL_QUEUE_MAX_VISIBILITY ?? '0', 10) || Infinity;
// The local workers share the same Node.js process and event loop,
// so we need to limit concurrency to avoid overwhelming the system.
const DEFAULT_CONCURRENCY_LIMIT = 100;
const WORKFLOW_LOCAL_QUEUE_CONCURRENCY = parseInt(process.env.WORKFLOW_LOCAL_QUEUE_CONCURRENCY ?? '0', 10) || DEFAULT_CONCURRENCY_LIMIT;
// Create a custom agent optimized for high-concurrency local workflows:
// - headersTimeout: 0 allows long-running steps
// - connections: 100 allows many parallel connections to the same host
// - pipelining: 1 (default) for HTTP/1.1 compatibility
// - keepAliveTimeout: 30s keeps connections warm for rapid step execution
const httpAgent = new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$undici$40$6$2e$22$2e$0$2f$node_modules$2f$undici$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Agent"]({
    headersTimeout: 0,
    connections: 100,
    keepAliveTimeout: 30_000
});
function createQueue(config) {
    const transport = new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["JsonTransport"]();
    const generateId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])();
    const semaphore = new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$async$2d$sema$40$3$2e$1$2e$1$2f$node_modules$2f$async$2d$sema$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Sema"](WORKFLOW_LOCAL_QUEUE_CONCURRENCY);
    /**
     * holds inflight messages by idempotency key to ensure
     * that we don't queue the same message multiple times
     */ const inflightMessages = new Map();
    const queue = async (queueName, message, opts)=>{
        const cleanup = [];
        if (opts?.idempotencyKey) {
            const existing = inflightMessages.get(opts.idempotencyKey);
            if (existing) {
                return {
                    messageId: existing
                };
            }
        }
        const body = transport.serialize(message);
        let pathname;
        if (queueName.startsWith('__wkf_step_')) {
            pathname = `step`;
        } else if (queueName.startsWith('__wkf_workflow_')) {
            pathname = `flow`;
        } else {
            throw new Error('Unknown queue name prefix');
        }
        const messageId = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"].parse(`msg_${generateId()}`);
        if (opts?.idempotencyKey) {
            const key = opts.idempotencyKey;
            inflightMessages.set(key, messageId);
            cleanup.push(()=>{
                inflightMessages.delete(key);
            });
        }
        (async ()=>{
            const token = semaphore.tryAcquire();
            if (!token) {
                console.warn(`[world-local]: concurrency limit (${WORKFLOW_LOCAL_QUEUE_CONCURRENCY}) reached, waiting for queue to free up`);
                await semaphore.acquire();
            }
            try {
                let defaultRetriesLeft = 3;
                const baseUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resolveBaseUrl"])(config);
                for(let attempt = 0; defaultRetriesLeft > 0; attempt++){
                    defaultRetriesLeft--;
                    const response = await fetch(`${baseUrl}/.well-known/workflow/v1/${pathname}`, {
                        method: 'POST',
                        duplex: 'half',
                        dispatcher: httpAgent,
                        headers: {
                            'content-type': 'application/json',
                            'x-vqs-queue-name': queueName,
                            'x-vqs-message-id': messageId,
                            'x-vqs-message-attempt': String(attempt + 1)
                        },
                        body
                    });
                    if (response.ok) {
                        return;
                    }
                    const text = await response.text();
                    if (response.status === 503) {
                        try {
                            const timeoutSeconds = Number(JSON.parse(text).timeoutSeconds);
                            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$timers$2f$promises__$5b$external$5d$__$28$node$3a$timers$2f$promises$2c$__cjs$29$__["setTimeout"])(timeoutSeconds * 1000);
                            defaultRetriesLeft++;
                            continue;
                        } catch  {}
                    }
                    console.error(`[local world] Failed to queue message`, {
                        queueName,
                        text,
                        status: response.status,
                        headers: Object.fromEntries(response.headers.entries()),
                        body: body.toString()
                    });
                }
                console.error(`[local world] Reached max retries of local world queue implementation`);
            } finally{
                semaphore.release();
            }
        })().catch((err)=>{
            // Silently ignore client disconnect errors (e.g., browser refresh during streaming)
            // These are expected and should not cause unhandled rejection warnings
            const isAbortError = err?.name === 'AbortError' || err?.name === 'ResponseAborted';
            if (!isAbortError) {
                console.error('[local world] Queue operation failed:', err);
            }
        }).finally(()=>{
            for (const fn of cleanup){
                fn();
            }
        });
        return {
            messageId
        };
    };
    const HeaderParser = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].object({
        'x-vqs-queue-name': __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ValidQueueName"],
        'x-vqs-message-id': __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"],
        'x-vqs-message-attempt': __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].coerce.number()
    });
    const createQueueHandler = (prefix, handler)=>{
        return async (req)=>{
            const headers = HeaderParser.safeParse(Object.fromEntries(req.headers));
            if (!headers.success || !req.body) {
                return Response.json({
                    error: !req.body ? 'Missing request body' : 'Missing required headers'
                }, {
                    status: 400
                });
            }
            const queueName = headers.data['x-vqs-queue-name'];
            const messageId = headers.data['x-vqs-message-id'];
            const attempt = headers.data['x-vqs-message-attempt'];
            if (!queueName.startsWith(prefix)) {
                return Response.json({
                    error: 'Unhandled queue'
                }, {
                    status: 400
                });
            }
            const body = await new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["JsonTransport"]().deserialize(req.body);
            try {
                const result = await handler(body, {
                    attempt,
                    queueName,
                    messageId
                });
                let timeoutSeconds = null;
                if (typeof result?.timeoutSeconds === 'number') {
                    timeoutSeconds = Math.min(result.timeoutSeconds, LOCAL_QUEUE_MAX_VISIBILITY);
                }
                if (timeoutSeconds) {
                    return Response.json({
                        timeoutSeconds
                    }, {
                        status: 503
                    });
                }
                return Response.json({
                    ok: true
                });
            } catch (error) {
                return Response.json(String(error), {
                    status: 500
                });
            }
        };
    };
    const getDeploymentId = async ()=>{
        return 'dpl_local';
    };
    return {
        queue,
        createQueueHandler,
        getDeploymentId
    };
} //# sourceMappingURL=queue.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearCreatedFilesCache",
    ()=>clearCreatedFilesCache,
    "deleteJSON",
    ()=>deleteJSON,
    "ensureDir",
    ()=>ensureDir,
    "listJSONFiles",
    ()=>listJSONFiles,
    "paginatedFileSystemQuery",
    ()=>paginatedFileSystemQuery,
    "readBuffer",
    ()=>readBuffer,
    "readJSON",
    ()=>readJSON,
    "ulidToDate",
    ()=>ulidToDate,
    "write",
    ()=>write,
    "writeJSON",
    ()=>writeJSON
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
;
;
;
;
const ulid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
const Ulid = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().ulid();
// In-memory cache of created files to avoid expensive fs.access() calls
// This is safe because we only write once per file path (no overwrites without explicit flag)
const createdFilesCache = new Set();
function clearCreatedFilesCache() {
    createdFilesCache.clear();
}
function ulidToDate(maybeUlid) {
    const ulid = Ulid.safeParse(maybeUlid);
    if (!ulid.success) {
        return null;
    }
    return new Date((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decodeTime"])(ulid.data));
}
async function ensureDir(dirPath) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].mkdir(dirPath, {
            recursive: true
        });
    } catch (_error) {
    // Ignore if already exists
    }
}
async function writeJSON(filePath, data, opts) {
    return write(filePath, JSON.stringify(data, null, 2), opts);
}
async function write(filePath, data, opts) {
    if (!opts?.overwrite) {
        // Fast path: check in-memory cache first to avoid expensive fs.access() calls
        // This provides significant performance improvement when creating many files
        if (createdFilesCache.has(filePath)) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`File ${filePath} already exists and 'overwrite' is false`, {
                status: 409
            });
        }
        // Slow path: check filesystem for files created before this process started
        try {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].access(filePath);
            // File exists on disk, add to cache for future checks
            createdFilesCache.add(filePath);
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`File ${filePath} already exists and 'overwrite' is false`, {
                status: 409
            });
        } catch (error) {
            // If file doesn't exist (ENOENT), continue with write
            if (error.code !== 'ENOENT') {
                throw error;
            }
        }
    }
    const tempPath = `${filePath}.tmp.${ulid()}`;
    let tempFileCreated = false;
    try {
        await ensureDir(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].dirname(filePath));
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].writeFile(tempPath, data);
        tempFileCreated = true;
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].rename(tempPath, filePath);
        // Track this file in cache so future writes know it exists
        createdFilesCache.add(filePath);
    } catch (error) {
        // Only try to clean up temp file if it was actually created
        if (tempFileCreated) {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].unlink(tempPath).catch(()=>{});
        }
        throw error;
    }
}
async function readJSON(filePath, decoder) {
    try {
        const content = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readFile(filePath, 'utf-8');
        return decoder.parse(JSON.parse(content));
    } catch (error) {
        if (error.code === 'ENOENT') return null;
        throw error;
    }
}
async function readBuffer(filePath) {
    const content = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readFile(filePath);
    return content;
}
async function deleteJSON(filePath) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].unlink(filePath);
    } catch (error) {
        if (error.code !== 'ENOENT') throw error;
    }
}
async function listJSONFiles(dirPath) {
    try {
        const files = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readdir(dirPath);
        return files.filter((f)=>f.endsWith('.json')).map((f)=>f.replace('.json', ''));
    } catch (error) {
        if (error.code === 'ENOENT') return [];
        throw error;
    }
}
function parseCursor(cursor) {
    if (!cursor) return null;
    const parts = cursor.split('|');
    return {
        timestamp: new Date(parts[0]),
        id: parts[1] || null
    };
}
function createCursor(timestamp, id) {
    return id ? `${timestamp.toISOString()}|${id}` : timestamp.toISOString();
}
async function paginatedFileSystemQuery(config) {
    const { directory, schema, filePrefix, filter, sortOrder = 'desc', limit = 20, cursor, getCreatedAt, getId } = config;
    // 1. Get all JSON files in directory
    const fileIds = await listJSONFiles(directory);
    // 2. Filter by prefix if provided
    const relevantFileIds = filePrefix ? fileIds.filter((fileId)=>fileId.startsWith(filePrefix)) : fileIds;
    // 3. ULID Optimization: Filter by cursor using filename timestamps before loading JSON
    const parsedCursor = parseCursor(cursor);
    let candidateFileIds = relevantFileIds;
    if (parsedCursor) {
        candidateFileIds = relevantFileIds.filter((fileId)=>{
            const filenameDate = getCreatedAt(`${fileId}.json`);
            if (filenameDate) {
                // Use filename timestamp for cursor filtering
                // We need to be careful here: if parsedCursor has an ID (for tie-breaking),
                // we need to include items with the same timestamp for later ID-based filtering.
                // If no ID, we can use strict inequality for optimization.
                const cursorTime = parsedCursor.timestamp.getTime();
                const fileTime = filenameDate.getTime();
                if (parsedCursor.id) {
                    // Tie-breaking mode: include items at or near cursor timestamp
                    return sortOrder === 'desc' ? fileTime <= cursorTime : fileTime >= cursorTime;
                } else {
                    // No tie-breaking: strict inequality
                    return sortOrder === 'desc' ? fileTime < cursorTime : fileTime > cursorTime;
                }
            }
            // Skip files where we can't extract timestamp - no optimization benefit
            return false;
        });
    } else {
        // Even without cursor, skip files where getCreatedAt returns null for consistency
        candidateFileIds = relevantFileIds.filter((fileId)=>{
            return getCreatedAt(`${fileId}.json`) !== null;
        });
    }
    // 4. Load files individually and collect valid items
    const validItems = [];
    for (const fileId of candidateFileIds){
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(directory, `${fileId}.json`);
        const item = await readJSON(filePath, schema);
        if (item) {
            // Apply custom filter early if provided
            if (filter && !filter(item)) continue;
            // Double-check cursor filtering with actual createdAt from JSON
            // (in case ULID timestamp differs from stored createdAt)
            if (parsedCursor) {
                const itemTime = item.createdAt.getTime();
                const cursorTime = parsedCursor.timestamp.getTime();
                if (sortOrder === 'desc') {
                    // For descending order, skip items >= cursor
                    if (itemTime > cursorTime) continue;
                    // If timestamps are equal, use ID for tie-breaking (skip if ID >= cursorId)
                    if (itemTime === cursorTime && parsedCursor.id && getId) {
                        const itemId = getId(item);
                        if (itemId >= parsedCursor.id) continue;
                    }
                } else {
                    // For ascending order, skip items <= cursor
                    if (itemTime < cursorTime) continue;
                    // If timestamps are equal, use ID for tie-breaking (skip if ID <= cursorId)
                    if (itemTime === cursorTime && parsedCursor.id && getId) {
                        const itemId = getId(item);
                        if (itemId <= parsedCursor.id) continue;
                    }
                }
            }
            validItems.push(item);
        }
    }
    // 5. Sort by createdAt (and by ID for tie-breaking if getId is provided)
    validItems.sort((a, b)=>{
        const aTime = a.createdAt.getTime();
        const bTime = b.createdAt.getTime();
        const timeComparison = sortOrder === 'asc' ? aTime - bTime : bTime - aTime;
        // If timestamps are equal and we have getId, use ID for stable sorting
        if (timeComparison === 0 && getId) {
            const aId = getId(a);
            const bId = getId(b);
            return sortOrder === 'asc' ? aId.localeCompare(bId) : bId.localeCompare(aId);
        }
        return timeComparison;
    });
    // 6. Apply pagination
    const hasMore = validItems.length > limit;
    const items = hasMore ? validItems.slice(0, limit) : validItems;
    const nextCursor = items.length > 0 ? createCursor(items[items.length - 1].createdAt, getId?.(items[items.length - 1])) : null;
    return {
        data: items,
        cursor: nextCursor,
        hasMore
    };
} //# sourceMappingURL=fs.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/storage.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStorage",
    ()=>createStorage
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)");
;
;
;
;
;
;
// Create a monotonic ULID factory that ensures ULIDs are always increasing
// even when generated within the same millisecond
const monotonicUlid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
// Helper functions to filter data based on resolveData setting
function filterRunData(run, resolveData) {
    if (resolveData === 'none') {
        return {
            ...run,
            input: [],
            output: undefined
        };
    }
    return run;
}
function filterStepData(step, resolveData) {
    if (resolveData === 'none') {
        return {
            ...step,
            input: [],
            output: undefined
        };
    }
    return step;
}
function filterEventData(event, resolveData) {
    if (resolveData === 'none') {
        const { eventData: _eventData, ...rest } = event;
        return rest;
    }
    return event;
}
function filterHookData(hook, resolveData) {
    if (resolveData === 'none') {
        const { metadata: _metadata, ...rest } = hook;
        return rest;
    }
    return hook;
}
const getObjectCreatedAt = (idPrefix)=>(filename)=>{
        const replaceRegex = new RegExp(`^${idPrefix}_`, 'g');
        const dashIndex = filename.indexOf('-');
        if (dashIndex === -1) {
            // No dash - extract ULID from the filename (e.g., wrun_ULID.json, evnt_ULID.json)
            const ulid = filename.replace(/\.json$/, '').replace(replaceRegex, '');
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
        }
        // For composite keys like {runId}-{stepId}, extract from the appropriate part
        if (idPrefix === 'step') {
            // For steps: wrun_ULID-step_123.json - extract from the runId part
            const runId = filename.substring(0, dashIndex);
            const ulid = runId.replace(/^wrun_/, '');
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
        }
        // For events: wrun_ULID-evnt_ULID.json - extract from the eventId part
        const id = filename.substring(dashIndex + 1).replace(/\.json$/, '');
        const ulid = id.replace(replaceRegex, '');
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
    };
/**
 * Creates a hooks storage implementation using the filesystem.
 * Implements the Storage['hooks'] interface with hook CRUD operations.
 */ function createHooksStorage(basedir) {
    // Helper function to find a hook by token (shared between create and getByToken)
    async function findHookByToken(token) {
        const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
        const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(hooksDir);
        for (const file of files){
            const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(hooksDir, `${file}.json`);
            const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
            if (hook && hook.token === token) {
                return hook;
            }
        }
        return null;
    }
    async function create(runId, data) {
        // Check if a hook with the same token already exists
        // Token uniqueness is enforced globally per local environment
        const existingHook = await findHookByToken(data.token);
        if (existingHook) {
            throw new Error(`Hook with token ${data.token} already exists for this project`);
        }
        const now = new Date();
        const result = {
            runId,
            hookId: data.hookId,
            token: data.token,
            metadata: data.metadata,
            ownerId: 'local-owner',
            projectId: 'local-project',
            environment: 'local',
            createdAt: now
        };
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${data.hookId}.json`);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(hookPath, result);
        return result;
    }
    async function get(hookId, params) {
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${hookId}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (!hook) {
            throw new Error(`Hook ${hookId} not found`);
        }
        const resolveData = params?.resolveData || __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
        return filterHookData(hook, resolveData);
    }
    async function getByToken(token) {
        const hook = await findHookByToken(token);
        if (!hook) {
            throw new Error(`Hook with token ${token} not found`);
        }
        return hook;
    }
    async function list(params) {
        const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
        const resolveData = params.resolveData || __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
            directory: hooksDir,
            schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"],
            sortOrder: params.pagination?.sortOrder,
            limit: params.pagination?.limit,
            cursor: params.pagination?.cursor,
            filePrefix: undefined,
            filter: (hook)=>{
                // Filter by runId if provided
                if (params.runId && hook.runId !== params.runId) {
                    return false;
                }
                return true;
            },
            getCreatedAt: ()=>{
                // Hook files don't have ULID timestamps in filename
                // We need to read the file to get createdAt, but that's inefficient
                // So we return the hook's createdAt directly (item.createdAt will be used for sorting)
                // Return a dummy date to pass the null check, actual sorting uses item.createdAt
                return new Date(0);
            },
            getId: (hook)=>hook.hookId
        });
        // Transform the data after pagination
        return {
            ...result,
            data: result.data.map((hook)=>filterHookData(hook, resolveData))
        };
    }
    async function dispose(hookId) {
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${hookId}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (!hook) {
            throw new Error(`Hook ${hookId} not found`);
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deleteJSON"])(hookPath);
        return hook;
    }
    return {
        create,
        get,
        getByToken,
        list,
        dispose
    };
}
/**
 * Helper function to delete all hooks associated with a workflow run
 */ async function deleteAllHooksForRun(basedir, runId) {
    const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
    const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(hooksDir);
    for (const file of files){
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(hooksDir, `${file}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (hook && hook.runId === runId) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deleteJSON"])(hookPath);
        }
    }
}
function createStorage(basedir) {
    return {
        runs: {
            async create (data) {
                const runId = `wrun_${monotonicUlid()}`;
                const now = new Date();
                const result = {
                    runId,
                    deploymentId: data.deploymentId,
                    status: 'pending',
                    workflowName: data.workflowName,
                    executionContext: data.executionContext,
                    input: data.input || [],
                    output: undefined,
                    error: undefined,
                    startedAt: undefined,
                    completedAt: undefined,
                    createdAt: now,
                    updatedAt: now
                };
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${runId}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(runPath, result);
                return result;
            },
            async get (id, params) {
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${id}.json`);
                const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(runPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"]);
                if (!run) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
                }
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            /**
             * Updates a workflow run.
             *
             * Note: This operation is not atomic. Concurrent updates from multiple
             * processes may result in lost updates (last writer wins). This is an
             * inherent limitation of filesystem-based storage without locking.
             * For the local world, this is acceptable as it's typically
             * used in single-process scenarios.
             */ async update (id, data) {
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${id}.json`);
                const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(runPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"]);
                if (!run) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
                }
                const now = new Date();
                const updatedRun = {
                    ...run,
                    ...data,
                    updatedAt: now
                };
                // Only set startedAt the first time the run transitions to 'running'
                if (data.status === 'running' && !updatedRun.startedAt) {
                    updatedRun.startedAt = now;
                }
                const isBecomingTerminal = data.status === 'completed' || data.status === 'failed' || data.status === 'cancelled';
                if (isBecomingTerminal) {
                    updatedRun.completedAt = now;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(runPath, updatedRun, {
                    overwrite: true
                });
                // If transitioning to a terminal status, clean up all hooks for this run
                if (isBecomingTerminal) {
                    await deleteAllHooksForRun(basedir, id);
                }
                return updatedRun;
            },
            async list (params) {
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"],
                    filter: (run)=>{
                        if (params?.workflowName && run.workflowName !== params.workflowName) {
                            return false;
                        }
                        if (params?.status && run.status !== params.status) {
                            return false;
                        }
                        return true;
                    },
                    sortOrder: params?.pagination?.sortOrder ?? 'desc',
                    limit: params?.pagination?.limit,
                    cursor: params?.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('wrun'),
                    getId: (run)=>run.runId
                });
                // If resolveData is "none", replace input/output with empty data
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((run)=>({
                                ...run,
                                input: [],
                                output: undefined
                            }))
                    };
                }
                return result;
            },
            async cancel (id, params) {
                // This will call update which triggers hook cleanup automatically
                const run = await this.update(id, {
                    status: 'cancelled'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            async pause (id, params) {
                const run = await this.update(id, {
                    status: 'paused'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            async resume (id, params) {
                const run = await this.update(id, {
                    status: 'running'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            }
        },
        steps: {
            async create (runId, data) {
                const now = new Date();
                const result = {
                    runId,
                    stepId: data.stepId,
                    stepName: data.stepName,
                    status: 'pending',
                    input: data.input,
                    output: undefined,
                    error: undefined,
                    attempt: 0,
                    startedAt: undefined,
                    completedAt: undefined,
                    createdAt: now,
                    updatedAt: now
                };
                const compositeKey = `${runId}-${data.stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(stepPath, result);
                return result;
            },
            async get (runId, stepId, params) {
                if (!runId) {
                    const fileIds = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps'));
                    const fileId = fileIds.find((fileId)=>fileId.endsWith(`-${stepId}`));
                    if (!fileId) {
                        throw new Error(`Step ${stepId} not found`);
                    }
                    runId = fileId.split('-')[0];
                }
                const compositeKey = `${runId}-${stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(stepPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"]);
                if (!step) {
                    throw new Error(`Step ${stepId} in run ${runId} not found`);
                }
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterStepData(step, resolveData);
            },
            /**
             * Updates a step.
             *
             * Note: This operation is not atomic. Concurrent updates from multiple
             * processes may result in lost updates (last writer wins). This is an
             * inherent limitation of filesystem-based storage without locking.
             */ async update (runId, stepId, data) {
                const compositeKey = `${runId}-${stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(stepPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"]);
                if (!step) {
                    throw new Error(`Step ${stepId} in run ${runId} not found`);
                }
                const now = new Date();
                const updatedStep = {
                    ...step,
                    ...data,
                    updatedAt: now
                };
                // Only set startedAt the first time the step transitions to 'running'
                if (data.status === 'running' && !updatedStep.startedAt) {
                    updatedStep.startedAt = now;
                }
                if (data.status === 'completed' || data.status === 'failed') {
                    updatedStep.completedAt = now;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(stepPath, updatedStep, {
                    overwrite: true
                });
                return updatedStep;
            },
            async list (params) {
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"],
                    filePrefix: `${params.runId}-`,
                    sortOrder: params.pagination?.sortOrder ?? 'desc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('step'),
                    getId: (step)=>step.stepId
                });
                // If resolveData is "none", replace input/output with empty data
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((step)=>({
                                ...step,
                                input: [],
                                output: undefined
                            }))
                    };
                }
                return result;
            }
        },
        // Events - filesystem-backed storage
        events: {
            async create (runId, data, params) {
                const eventId = `evnt_${monotonicUlid()}`;
                const now = new Date();
                const result = {
                    ...data,
                    runId,
                    eventId,
                    createdAt: now
                };
                // Store event using composite key {runId}-{eventId}
                const compositeKey = `${runId}-${eventId}`;
                const eventPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events', `${compositeKey}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(eventPath, result);
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterEventData(result, resolveData);
            },
            async list (params) {
                const { runId } = params;
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"],
                    filePrefix: `${runId}-`,
                    // Events in chronological order (oldest first) by default,
                    // different from the default for other list calls.
                    sortOrder: params.pagination?.sortOrder ?? 'asc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('evnt'),
                    getId: (event)=>event.eventId
                });
                // If resolveData is "none", remove eventData from events
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((event)=>{
                            const { eventData: _eventData, ...rest } = event;
                            return rest;
                        })
                    };
                }
                return result;
            },
            async listByCorrelationId (params) {
                const correlationId = params.correlationId;
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"],
                    // No filePrefix - search all events
                    filter: (event)=>event.correlationId === correlationId,
                    // Events in chronological order (oldest first) by default,
                    // different from the default for other list calls.
                    sortOrder: params.pagination?.sortOrder ?? 'asc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('evnt'),
                    getId: (event)=>event.eventId
                });
                // If resolveData is "none", remove eventData from events
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((event)=>{
                            const { eventData: _eventData, ...rest } = event;
                            return rest;
                        })
                    };
                }
                return result;
            }
        },
        // Hooks
        hooks: createHooksStorage(basedir)
    };
} //# sourceMappingURL=storage.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/streamer.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStreamer",
    ()=>createStreamer,
    "deserializeChunk",
    ()=>deserializeChunk,
    "serializeChunk",
    ()=>serializeChunk
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$events__$5b$external$5d$__$28$node$3a$events$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:events [external] (node:events, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)");
;
;
;
;
// Create a monotonic ULID factory that ensures ULIDs are always increasing
// even when generated within the same millisecond
const monotonicUlid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
function serializeChunk(chunk) {
    const eofByte = Buffer.from([
        chunk.eof ? 1 : 0
    ]);
    return Buffer.concat([
        eofByte,
        chunk.chunk
    ]);
}
function deserializeChunk(serialized) {
    const eof = serialized[0] === 1;
    // Create a copy instead of a view to prevent ArrayBuffer detachment
    const chunk = Buffer.from(serialized.subarray(1));
    return {
        eof,
        chunk
    };
}
function createStreamer(basedir) {
    const streamEmitter = new __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$events__$5b$external$5d$__$28$node$3a$events$2c$__cjs$29$__["EventEmitter"]();
    return {
        async writeToStream (name, _runId, chunk) {
            // Await runId if it's a promise to ensure proper flushing
            await _runId;
            const chunkId = `strm_${monotonicUlid()}`;
            // Convert chunk to buffer for serialization
            let chunkBuffer;
            if (typeof chunk === 'string') {
                chunkBuffer = Buffer.from(new TextEncoder().encode(chunk));
            } else if (chunk instanceof Buffer) {
                chunkBuffer = chunk;
            } else {
                chunkBuffer = Buffer.from(chunk);
            }
            const serialized = serializeChunk({
                chunk: chunkBuffer,
                eof: false
            });
            const chunkPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks', `${name}-${chunkId}.json`);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["write"])(chunkPath, serialized);
            // Emit real-time event with Uint8Array (create copy to prevent ArrayBuffer detachment)
            const chunkData = Uint8Array.from(chunkBuffer);
            streamEmitter.emit(`chunk:${name}`, {
                streamName: name,
                chunkData,
                chunkId
            });
        },
        async closeStream (name, _runId) {
            // Await runId if it's a promise to ensure proper flushing
            await _runId;
            const chunkId = `strm_${monotonicUlid()}`;
            const chunkPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks', `${name}-${chunkId}.json`);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["write"])(chunkPath, serializeChunk({
                chunk: Buffer.from([]),
                eof: true
            }));
            streamEmitter.emit(`close:${name}`, {
                streamName: name
            });
        },
        async listStreamsByRunId (runId) {
            const chunksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks');
            const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(chunksDir);
            // Convert runId (wrun_{ULID}) to stream prefix (strm_{ULID}_user)
            const streamPrefix = runId.replace('wrun_', 'strm_') + '_user';
            // Extract unique stream names that match the run's prefix
            const streamNames = new Set();
            for (const file of files){
                // Files are named: {streamName}-{chunkId}
                // Find the last occurrence of '-strm_' to split correctly
                const lastDashIndex = file.lastIndexOf('-strm_');
                if (lastDashIndex === -1) {
                    // Try splitting at the last dash for legacy format
                    const parts = file.split('-');
                    if (parts.length >= 2) {
                        parts.pop(); // Remove chunkId
                        const streamName = parts.join('-');
                        if (streamName.startsWith(streamPrefix)) {
                            streamNames.add(streamName);
                        }
                    }
                } else {
                    const streamName = file.substring(0, lastDashIndex);
                    if (streamName.startsWith(streamPrefix)) {
                        streamNames.add(streamName);
                    }
                }
            }
            return Array.from(streamNames);
        },
        async readFromStream (name, startIndex = 0) {
            const chunksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks');
            let removeListeners = ()=>{};
            return new ReadableStream({
                async start (controller) {
                    // Track chunks delivered via events to prevent duplicates and maintain order.
                    const deliveredChunkIds = new Set();
                    // Buffer for chunks that arrive via events during disk reading
                    const bufferedEventChunks = [];
                    let isReadingFromDisk = true;
                    const chunkListener = (event)=>{
                        deliveredChunkIds.add(event.chunkId);
                        // Skip empty chunks to maintain consistency with disk reading behavior
                        // Empty chunks are not enqueued when read from disk (see line 184-186)
                        if (event.chunkData.byteLength === 0) {
                            return;
                        }
                        if (isReadingFromDisk) {
                            // Buffer chunks that arrive during disk reading to maintain order
                            // Create a copy to prevent ArrayBuffer detachment when enqueued later
                            bufferedEventChunks.push({
                                chunkId: event.chunkId,
                                chunkData: Uint8Array.from(event.chunkData)
                            });
                        } else {
                            // After disk reading is complete, deliver chunks immediately
                            // Create a copy to prevent ArrayBuffer detachment
                            controller.enqueue(Uint8Array.from(event.chunkData));
                        }
                    };
                    const closeListener = ()=>{
                        // Remove listeners before closing
                        streamEmitter.off(`chunk:${name}`, chunkListener);
                        streamEmitter.off(`close:${name}`, closeListener);
                        try {
                            controller.close();
                        } catch  {
                        // Ignore if controller is already closed (e.g., from cancel() or EOF)
                        }
                    };
                    removeListeners = closeListener;
                    // Set up listeners FIRST to avoid missing events
                    streamEmitter.on(`chunk:${name}`, chunkListener);
                    streamEmitter.on(`close:${name}`, closeListener);
                    // Now load existing chunks from disk
                    const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(chunksDir);
                    const chunkFiles = files.filter((file)=>file.startsWith(`${name}-`)).sort(); // ULID lexicographic sort = chronological order
                    // Process existing chunks, skipping any already delivered via events
                    let isComplete = false;
                    for(let i = startIndex; i < chunkFiles.length; i++){
                        const file = chunkFiles[i];
                        // Extract chunk ID from filename: "streamName-chunkId"
                        const chunkId = file.substring(name.length + 1);
                        // Skip if already delivered via event
                        if (deliveredChunkIds.has(chunkId)) {
                            continue;
                        }
                        const chunk = deserializeChunk(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readBuffer"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(chunksDir, `${file}.json`)));
                        if (chunk?.eof === true) {
                            isComplete = true;
                            break;
                        }
                        if (chunk.chunk.byteLength) {
                            // Create a copy to prevent ArrayBuffer detachment
                            controller.enqueue(Uint8Array.from(chunk.chunk));
                        }
                    }
                    // Finished reading from disk - now deliver buffered event chunks in chronological order
                    isReadingFromDisk = false;
                    // Sort buffered chunks by ULID (chronological order)
                    bufferedEventChunks.sort((a, b)=>a.chunkId.localeCompare(b.chunkId));
                    for (const buffered of bufferedEventChunks){
                        // Create a copy for defense in depth (already copied at storage, but be extra safe)
                        controller.enqueue(Uint8Array.from(buffered.chunkData));
                    }
                    if (isComplete) {
                        removeListeners();
                        try {
                            controller.close();
                        } catch  {
                        // Ignore if controller is already closed (e.g., from closeListener event)
                        }
                        return;
                    }
                },
                cancel () {
                    removeListeners();
                }
            });
        }
    };
} //# sourceMappingURL=streamer.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createLocalWorld",
    ()=>createLocalWorld
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/storage.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/streamer.js [app-route] (ecmascript)");
;
;
;
;
function createLocalWorld(args) {
    const definedArgs = args ? Object.fromEntries(Object.entries(args).filter(([, value])=>value !== undefined)) : {};
    const mergedConfig = {
        ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].value,
        ...definedArgs
    };
    return {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createQueue"])(mergedConfig),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStorage"])(mergedConfig.dataDir),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStreamer"])(mergedConfig.dataDir)
    };
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/.pnpm/mixpart@0.0.5-alpha.1/node_modules/mixpart/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/parser.ts
__turbopack_context__.s([
    "MultipartParseError",
    ()=>MultipartParseError,
    "extractBoundary",
    ()=>extractBoundary,
    "parseMultipartStream",
    ()=>parseMultipartStream
]);
var MultipartParseError = class extends Error {
    constructor(message){
        super(message);
        this.name = "MultipartParseError";
    }
};
function createSearch(pattern) {
    const needle = new TextEncoder().encode(pattern);
    return (haystack, start = 0)=>Buffer.prototype.indexOf.call(haystack, needle, start);
}
function createPartialTailSearch(pattern) {
    const needle = new TextEncoder().encode(pattern);
    const byteIndexes = {};
    for(let i = 0; i < needle.length; ++i){
        const byte = needle[i];
        if (byteIndexes[byte] === void 0) byteIndexes[byte] = [];
        byteIndexes[byte].push(i);
    }
    return function(haystack) {
        const haystackEnd = haystack.length - 1;
        if (haystack[haystackEnd] in byteIndexes) {
            const indexes = byteIndexes[haystack[haystackEnd]];
            for(let i = indexes.length - 1; i >= 0; --i){
                for(let j = indexes[i], k = haystackEnd; j >= 0 && haystack[k] === needle[j]; --j, --k){
                    if (j === 0) return k;
                }
            }
        }
        return -1;
    };
}
function parseHeaders(headerBytes) {
    const headerText = new TextDecoder("iso-8859-1").decode(headerBytes);
    const lines = headerText.trim().split(/\r?\n/);
    const headerInit = [];
    for (const line of lines){
        const colonIndex = line.indexOf(":");
        if (colonIndex > 0) {
            const name = line.slice(0, colonIndex).trim();
            const value = line.slice(colonIndex + 1).trim();
            headerInit.push([
                name,
                value
            ]);
        }
    }
    return new Headers(headerInit);
}
function extractBoundary(contentType) {
    const boundaryMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
    if (!boundaryMatch) {
        throw new MultipartParseError("No boundary found in Content-Type header");
    }
    return boundaryMatch[1] ?? boundaryMatch[2];
}
var AsyncMessageQueue = class {
    queue = [];
    waiters = [];
    finished = false;
    cancelled = false;
    error = null;
    /**
   * Producer: Enqueue a message for consumption
   */ enqueue(message) {
        if (this.finished || this.cancelled) return;
        if (this.waiters.length > 0) {
            const waiter = this.waiters.shift();
            waiter.resolve(message);
        } else {
            this.queue.push(message);
        }
    }
    /**
   * Producer: Signal completion (with optional error)
   */ finish(error) {
        if (this.finished) return;
        this.finished = true;
        this.error = error || null;
        while(this.waiters.length > 0){
            const waiter = this.waiters.shift();
            if (error) {
                waiter.reject(error);
            } else {
                waiter.resolve(null);
            }
        }
    }
    /**
   * Consumer: Cancel the queue (stops accepting new messages and notifies waiters)
   */ cancel() {
        if (this.cancelled || this.finished) return;
        this.cancelled = true;
        while(this.waiters.length > 0){
            const waiter = this.waiters.shift();
            waiter.resolve(null);
        }
    }
    /**
   * Consumer: Dequeue next message (or null if finished/cancelled)
   */ async dequeue() {
        if (this.queue.length > 0) {
            return this.queue.shift();
        }
        if (this.finished || this.cancelled) {
            if (this.error) throw this.error;
            return null;
        }
        return new Promise((resolve, reject)=>{
            this.waiters.push({
                resolve,
                reject
            });
        });
    }
    /**
   * Check if the queue is in a terminal state
   */ get isTerminal() {
        return this.finished || this.cancelled;
    }
};
async function* parseMultipartStream(response, options) {
    if (!response.body) {
        throw new MultipartParseError("Response body is null");
    }
    const contentType = response.headers.get("content-type");
    if (!contentType) {
        throw new MultipartParseError("Missing Content-Type header");
    }
    const boundary = extractBoundary(contentType);
    const parser = new StreamingMultipartParser(boundary, options);
    yield* parser.parseStream(response.body);
}
var StreamingMultipartParser = class {
    boundary;
    findOpeningBoundary;
    openingBoundaryLength;
    findBoundary;
    findPartialTailBoundary;
    boundaryLength;
    findDoubleNewline;
    // Safety limits
    maxHeaderSize;
    maxBoundaryBuffer;
    state = 0 /* Start */ ;
    buffer = null;
    currentHeaders = new Headers();
    currentPayloadController = null;
    constructor(boundary, options = {}){
        this.boundary = boundary;
        this.findOpeningBoundary = createSearch(`--${boundary}`);
        this.openingBoundaryLength = 2 + boundary.length;
        this.findBoundary = createSearch(`\r
--${boundary}`);
        this.findPartialTailBoundary = createPartialTailSearch(`\r
--${boundary}`);
        this.boundaryLength = 4 + boundary.length;
        this.findDoubleNewline = createSearch("\r\n\r\n");
        this.maxHeaderSize = options.maxHeaderSize ?? 65536;
        this.maxBoundaryBuffer = options.maxBoundaryBuffer ?? 8192;
    }
    async *parseStream(stream) {
        const reader = stream.getReader();
        const messageQueue = new AsyncMessageQueue();
        const producer = this.startProducer(reader, messageQueue);
        try {
            yield* this.consumeMessages(messageQueue);
        } finally{
            messageQueue.cancel();
            this.closeCurrentPayload();
            try {
                await reader.cancel();
            } catch (error) {}
            await producer;
        }
    }
    /**
   * Producer: Continuously read chunks and parse messages
   */ async startProducer(reader, messageQueue) {
        try {
            while(!messageQueue.isTerminal){
                let result;
                try {
                    result = await reader.read();
                } catch (readError) {
                    if (readError instanceof Error && (readError.name === "AbortError" || readError.constructor.name === "AbortError" || readError.name === "TimeoutError" || readError.constructor.name === "TimeoutError")) {
                        break;
                    }
                    throw readError;
                }
                const { done, value } = result;
                if (done) {
                    if (this.buffer !== null && this.buffer.length > 0) {
                        const messages2 = this.write(new Uint8Array(0));
                        for (const message of messages2){
                            if (messageQueue.isTerminal) break;
                            messageQueue.enqueue(message);
                        }
                    }
                    if (this.state !== 4 /* Done */ ) {
                        if (this.state === 0 /* Start */ ) {
                            throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
                        }
                        throw new MultipartParseError("Unexpected end of stream");
                    }
                    break;
                }
                if (!(value instanceof Uint8Array)) {
                    throw new MultipartParseError(`Invalid chunk type: expected Uint8Array, got ${typeof value}`);
                }
                const messages = this.write(value);
                for (const message of messages){
                    if (messageQueue.isTerminal) break;
                    messageQueue.enqueue(message);
                }
            }
            if (!messageQueue.isTerminal) {
                messageQueue.finish();
            }
        } catch (error) {
            this.closeCurrentPayload(error);
            if (!messageQueue.isTerminal) {
                messageQueue.finish(error);
            }
        } finally{
            try {
                reader.releaseLock();
            } catch (error) {}
        }
    }
    /**
   * Consumer: Yield messages from the queue
   */ async *consumeMessages(messageQueue) {
        while(true){
            const message = await messageQueue.dequeue();
            if (message === null) {
                break;
            }
            yield message;
        }
    }
    /**
   * Process a chunk of data through the state machine and return any complete messages.
   *
   * Returns an array because a single chunk can contain multiple complete messages
   * when small messages with headers + body + boundary all fit in one network chunk.
   * All messages must be captured and queued to maintain proper message ordering.
   */ write(chunk) {
        const newMessages = [];
        if (this.state === 4 /* Done */ ) {
            throw new MultipartParseError("Unexpected data after end of stream");
        }
        let index = 0;
        let chunkLength = chunk.length;
        if (this.buffer !== null) {
            const newSize = this.buffer.length + chunkLength;
            const maxAllowedSize = this.state === 2 /* Header */  ? this.maxHeaderSize : this.maxBoundaryBuffer;
            if (newSize > maxAllowedSize) {
                throw new MultipartParseError(`Buffer size limit exceeded: ${newSize} bytes > ${maxAllowedSize} bytes. This may indicate malformed multipart data with ${this.state === 2 /* Header */  ? "oversized headers" : "invalid boundaries"}.`);
            }
            const newChunk = new Uint8Array(newSize);
            newChunk.set(this.buffer, 0);
            newChunk.set(chunk, this.buffer.length);
            chunk = newChunk;
            chunkLength = chunk.length;
            this.buffer = null;
        }
        if (chunkLength === 0 && this.state === 0 /* Start */ ) {
            throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
        }
        while(true){
            if (this.state === 3 /* Body */ ) {
                if (chunkLength - index < this.boundaryLength) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`Boundary buffer limit exceeded: ${remainingData.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                const boundaryIndex = this.findBoundary(chunk, index);
                if (boundaryIndex === -1) {
                    const partialTailIndex = this.findPartialTailBoundary(chunk);
                    if (partialTailIndex === -1) {
                        this.writeBody(index === 0 ? chunk : chunk.subarray(index));
                    } else {
                        this.writeBody(chunk.subarray(index, partialTailIndex));
                        const partialBoundary = chunk.subarray(partialTailIndex);
                        if (partialBoundary.length > this.maxBoundaryBuffer) {
                            throw new MultipartParseError(`Partial boundary too large: ${partialBoundary.length} > ${this.maxBoundaryBuffer}`);
                        }
                        this.buffer = partialBoundary;
                    }
                    break;
                }
                this.writeBody(chunk.subarray(index, boundaryIndex));
                this.finishMessage();
                index = boundaryIndex + this.boundaryLength;
                this.state = 1 /* AfterBoundary */ ;
            }
            if (this.state === 1 /* AfterBoundary */ ) {
                if (chunkLength - index < 2) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`After-boundary buffer limit exceeded: ${remainingData.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                if (chunk[index] === 45 && chunk[index + 1] === 45) {
                    this.state = 4 /* Done */ ;
                    break;
                }
                if (chunk[index] === 13 && chunk[index + 1] === 10) {
                    index += 2;
                } else if (chunk[index] === 10) {
                    index += 1;
                } else {
                    throw new MultipartParseError(`Invalid character after boundary: expected CRLF or LF, got 0x${chunk[index].toString(16)}`);
                }
                this.state = 2 /* Header */ ;
            }
            if (this.state === 2 /* Header */ ) {
                if (chunkLength - index < 4) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxHeaderSize) {
                        throw new MultipartParseError(`Header buffer limit exceeded: ${remainingData.length} > ${this.maxHeaderSize}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                let headerEndIndex = this.findDoubleNewline(chunk, index);
                let headerEndOffset = 4;
                if (headerEndIndex === -1) {
                    const lfDoubleNewline = createSearch("\n\n");
                    headerEndIndex = lfDoubleNewline(chunk, index);
                    headerEndOffset = 2;
                }
                if (headerEndIndex === -1) {
                    const headerData = chunk.subarray(index);
                    if (headerData.length > this.maxHeaderSize) {
                        throw new MultipartParseError(`Headers too large: ${headerData.length} > ${this.maxHeaderSize} bytes`);
                    }
                    this.buffer = headerData;
                    break;
                }
                const headerBytes = chunk.subarray(index, headerEndIndex);
                this.currentHeaders = parseHeaders(headerBytes);
                const message = this.createStreamingMessage();
                newMessages.push(message);
                index = headerEndIndex + headerEndOffset;
                this.state = 3 /* Body */ ;
                continue;
            }
            if (this.state === 0 /* Start */ ) {
                if (chunkLength < this.openingBoundaryLength) {
                    if (chunk.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`Initial chunk too large for boundary detection: ${chunk.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = chunk;
                    break;
                }
                const boundaryIndex = this.findOpeningBoundary(chunk);
                if (boundaryIndex !== 0) {
                    throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
                }
                index = this.openingBoundaryLength;
                this.state = 1 /* AfterBoundary */ ;
            }
        }
        return newMessages;
    }
    createStreamingMessage() {
        const headers = new Headers(this.currentHeaders);
        const payload = new ReadableStream({
            start: (controller)=>{
                this.currentPayloadController = controller;
            }
        });
        this.currentHeaders = new Headers();
        return {
            headers,
            payload
        };
    }
    writeBody(chunk) {
        if (this.currentPayloadController) {
            this.currentPayloadController.enqueue(chunk);
        }
    }
    finishMessage() {
        if (this.currentPayloadController) {
            this.currentPayloadController.close();
            this.currentPayloadController = null;
        }
    }
    /**
   * Close current payload controller if open (used during cleanup)
   * If an error is provided, forwards it to the payload consumer
   */ closeCurrentPayload(error) {
        if (this.currentPayloadController) {
            try {
                if (error) {
                    this.currentPayloadController.error(error);
                } else {
                    this.currentPayloadController.close();
                }
            } catch (controllerError) {}
            this.currentPayloadController = null;
        }
    }
};
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_context_exports = {};
__export(get_context_exports, {
    SYMBOL_FOR_REQ_CONTEXT: ()=>SYMBOL_FOR_REQ_CONTEXT,
    getContext: ()=>getContext
});
module.exports = __toCommonJS(get_context_exports);
const SYMBOL_FOR_REQ_CONTEXT = Symbol.for("@vercel/request-context");
function getContext() {
    const fromSymbol = globalThis;
    return fromSymbol[SYMBOL_FOR_REQ_CONTEXT]?.get?.() ?? {};
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    SYMBOL_FOR_REQ_CONTEXT,
    getContext
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token-error.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var token_error_exports = {};
__export(token_error_exports, {
    VercelOidcTokenError: ()=>VercelOidcTokenError
});
module.exports = __toCommonJS(token_error_exports);
class VercelOidcTokenError extends Error {
    constructor(message, cause){
        super(message);
        this.name = "VercelOidcTokenError";
        this.cause = cause;
    }
    toString() {
        if (this.cause) {
            return `${this.name}: ${this.message}: ${this.cause}`;
        }
        return `${this.name}: ${this.message}`;
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    VercelOidcTokenError
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-vercel-oidc-token.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toESM = (mod, isNodeMode, target)=>(target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(// If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
        value: mod,
        enumerable: true
    }) : target, mod));
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_vercel_oidc_token_exports = {};
__export(get_vercel_oidc_token_exports, {
    getVercelOidcToken: ()=>getVercelOidcToken,
    getVercelOidcTokenSync: ()=>getVercelOidcTokenSync
});
module.exports = __toCommonJS(get_vercel_oidc_token_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)");
var import_token_error = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token-error.js [app-route] (ecmascript)");
async function getVercelOidcToken() {
    let token = "";
    let err;
    try {
        token = getVercelOidcTokenSync();
    } catch (error) {
        err = error;
    }
    try {
        const [{ getTokenPayload, isExpired }, { refreshToken }] = await Promise.all([
            await __turbopack_context__.A("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token-util.js [app-route] (ecmascript, async loader)"),
            await __turbopack_context__.A("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token.js [app-route] (ecmascript, async loader)")
        ]);
        if (!token || isExpired(getTokenPayload(token))) {
            await refreshToken();
            token = getVercelOidcTokenSync();
        }
    } catch (error) {
        if (err?.message && error instanceof Error) {
            error.message = `${err.message}
${error.message}`;
        }
        throw new import_token_error.VercelOidcTokenError(`Failed to refresh OIDC token`, error);
    }
    return token;
}
function getVercelOidcTokenSync() {
    const token = (0, import_get_context.getContext)().headers?.["x-vercel-oidc-token"] ?? process.env.VERCEL_OIDC_TOKEN;
    if (!token) {
        throw new Error(`The 'x-vercel-oidc-token' header is missing from the request. Do you have the OIDC option enabled in the Vercel project settings?`);
    }
    return token;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getVercelOidcToken,
    getVercelOidcTokenSync
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var src_exports = {};
__export(src_exports, {
    getContext: ()=>import_get_context.getContext,
    getVercelOidcToken: ()=>import_get_vercel_oidc_token.getVercelOidcToken,
    getVercelOidcTokenSync: ()=>import_get_vercel_oidc_token.getVercelOidcTokenSync
});
module.exports = __toCommonJS(src_exports);
var import_get_vercel_oidc_token = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-vercel-oidc-token.js [app-route] (ecmascript)");
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getContext,
    getVercelOidcToken,
    getVercelOidcTokenSync
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+queue@0.0.0-alpha.33/node_modules/@vercel/queue/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/transports.ts
__turbopack_context__.s([
    "BadRequestError",
    ()=>BadRequestError,
    "BufferTransport",
    ()=>BufferTransport,
    "Client",
    ()=>Client,
    "ForbiddenError",
    ()=>ForbiddenError,
    "InternalServerError",
    ()=>InternalServerError,
    "InvalidLimitError",
    ()=>InvalidLimitError,
    "JsonTransport",
    ()=>JsonTransport,
    "MessageCorruptedError",
    ()=>MessageCorruptedError,
    "MessageLockedError",
    ()=>MessageLockedError,
    "MessageNotAvailableError",
    ()=>MessageNotAvailableError,
    "MessageNotFoundError",
    ()=>MessageNotFoundError,
    "QueueEmptyError",
    ()=>QueueEmptyError,
    "StreamTransport",
    ()=>StreamTransport,
    "UnauthorizedError",
    ()=>UnauthorizedError,
    "handleCallback",
    ()=>handleCallback,
    "parseCallback",
    ()=>parseCallback,
    "receive",
    ()=>receive,
    "send",
    ()=>send
]);
// src/client.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$mixpart$40$0$2e$0$2e$5$2d$alpha$2e$1$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/mixpart@0.0.5-alpha.1/node_modules/mixpart/dist/index.mjs [app-route] (ecmascript)");
// src/oidc.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$oidc$40$3$2e$0$2e$5$2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)");
async function streamToBuffer(stream) {
    let totalLength = 0;
    const reader = stream.getReader();
    const chunks = [];
    try {
        while(true){
            const { done, value } = await reader.read();
            if (done) break;
            chunks.push(value);
            totalLength += value.length;
        }
    } finally{
        reader.releaseLock();
    }
    return Buffer.concat(chunks, totalLength);
}
var JsonTransport = class {
    contentType = "application/json";
    replacer;
    reviver;
    constructor(options = {}){
        this.replacer = options.replacer;
        this.reviver = options.reviver;
    }
    serialize(value) {
        return Buffer.from(JSON.stringify(value, this.replacer), "utf8");
    }
    async deserialize(stream) {
        const buffer = await streamToBuffer(stream);
        return JSON.parse(buffer.toString("utf8"), this.reviver);
    }
};
var BufferTransport = class {
    contentType = "application/octet-stream";
    serialize(value) {
        return value;
    }
    async deserialize(stream) {
        return await streamToBuffer(stream);
    }
};
var StreamTransport = class {
    contentType = "application/octet-stream";
    serialize(value) {
        return value;
    }
    async deserialize(stream) {
        return stream;
    }
    async finalize(payload) {
        const reader = payload.getReader();
        try {
            while(true){
                const { done } = await reader.read();
                if (done) break;
            }
        } finally{
            reader.releaseLock();
        }
    }
};
;
;
// src/types.ts
var MessageNotFoundError = class extends Error {
    constructor(messageId){
        super(`Message ${messageId} not found`);
        this.name = "MessageNotFoundError";
    }
};
var MessageNotAvailableError = class extends Error {
    constructor(messageId, reason){
        super(`Message ${messageId} not available for processing${reason ? `: ${reason}` : ""}`);
        this.name = "MessageNotAvailableError";
    }
};
var MessageCorruptedError = class extends Error {
    constructor(messageId, reason){
        super(`Message ${messageId} is corrupted: ${reason}`);
        this.name = "MessageCorruptedError";
    }
};
var QueueEmptyError = class extends Error {
    constructor(queueName, consumerGroup){
        super(`No messages available in queue "${queueName}" for consumer group "${consumerGroup}"`);
        this.name = "QueueEmptyError";
    }
};
var MessageLockedError = class extends Error {
    retryAfter;
    constructor(messageId, retryAfter){
        const retryMessage = retryAfter ? ` Retry after ${retryAfter} seconds.` : " Try again later.";
        super(`Message ${messageId} is temporarily locked.${retryMessage}`);
        this.name = "MessageLockedError";
        this.retryAfter = retryAfter;
    }
};
var UnauthorizedError = class extends Error {
    constructor(message = "Missing or invalid authentication token"){
        super(message);
        this.name = "UnauthorizedError";
    }
};
var ForbiddenError = class extends Error {
    constructor(message = "Queue environment doesn't match token environment"){
        super(message);
        this.name = "ForbiddenError";
    }
};
var BadRequestError = class extends Error {
    constructor(message){
        super(message);
        this.name = "BadRequestError";
    }
};
var InternalServerError = class extends Error {
    constructor(message = "Unexpected server error"){
        super(message);
        this.name = "InternalServerError";
    }
};
var InvalidLimitError = class extends Error {
    constructor(limit, min = 1, max = 10){
        super(`Invalid limit: ${limit}. Limit must be between ${min} and ${max}.`);
        this.name = "InvalidLimitError";
    }
};
// src/client.ts
function isDebugEnabled() {
    return process.env.VERCEL_QUEUE_DEBUG === "1" || process.env.VERCEL_QUEUE_DEBUG === "true";
}
async function consumeStream(stream) {
    const reader = stream.getReader();
    try {
        while(true){
            const { done } = await reader.read();
            if (done) break;
        }
    } finally{
        reader.releaseLock();
    }
}
function parseRetryAfter(headers) {
    const retryAfterHeader = headers.get("Retry-After");
    if (retryAfterHeader) {
        const parsed = parseInt(retryAfterHeader, 10);
        return Number.isNaN(parsed) ? void 0 : parsed;
    }
    return void 0;
}
function throwCommonHttpError(status, statusText, errorText, operation, badRequestDefault = "Invalid parameters") {
    if (status === 400) {
        throw new BadRequestError(errorText || badRequestDefault);
    }
    if (status === 401) {
        throw new UnauthorizedError(errorText || void 0);
    }
    if (status === 403) {
        throw new ForbiddenError(errorText || void 0);
    }
    if (status >= 500) {
        throw new InternalServerError(errorText || `Server error: ${status} ${statusText}`);
    }
    throw new Error(`Failed to ${operation}: ${status} ${statusText}`);
}
function parseQueueHeaders(headers) {
    const messageId = headers.get("Vqs-Message-Id");
    const deliveryCountStr = headers.get("Vqs-Delivery-Count") || "0";
    const timestamp = headers.get("Vqs-Timestamp");
    const contentType = headers.get("Content-Type") || "application/octet-stream";
    const ticket = headers.get("Vqs-Ticket");
    if (!messageId || !timestamp || !ticket) {
        return null;
    }
    const deliveryCount = parseInt(deliveryCountStr, 10);
    if (Number.isNaN(deliveryCount)) {
        return null;
    }
    return {
        messageId,
        deliveryCount,
        createdAt: new Date(timestamp),
        contentType,
        ticket
    };
}
var QueueClient = class {
    baseUrl;
    basePath;
    customHeaders;
    providedToken;
    /**
   * Create a new Vercel Queue Service client
   * @param options QueueClient configuration options
   */ constructor(options = {}){
        this.baseUrl = options.baseUrl || process.env.VERCEL_QUEUE_BASE_URL || "https://vercel-queue.com";
        this.basePath = options.basePath || process.env.VERCEL_QUEUE_BASE_PATH || "/api/v2/messages";
        this.customHeaders = options.headers || {};
        this.providedToken = options.token;
    }
    async getToken() {
        if (this.providedToken) {
            return this.providedToken;
        }
        const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$oidc$40$3$2e$0$2e$5$2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVercelOidcToken"])();
        if (!token) {
            throw new Error("Failed to get OIDC token from Vercel Functions. Make sure you are running in a Vercel Function environment, or provide a token explicitly.\n\nTo set up your environment:\n1. Link your project: 'vercel link'\n2. Pull environment variables: 'vercel env pull'\n3. Run with environment: 'dotenv -e .env.local -- your-command'");
        }
        return token;
    }
    /**
   * Internal fetch wrapper that automatically handles debug logging
   * when VERCEL_QUEUE_DEBUG is enabled
   */ async fetch(url, init) {
        const method = init.method || "GET";
        if (isDebugEnabled()) {
            const logData = {
                method,
                url,
                headers: init.headers
            };
            const body = init.body;
            if (body !== void 0 && body !== null) {
                if (body instanceof ArrayBuffer) {
                    logData.bodySize = body.byteLength;
                } else if (body instanceof Uint8Array) {
                    logData.bodySize = body.byteLength;
                } else if (typeof body === "string") {
                    logData.bodySize = body.length;
                } else {
                    logData.bodyType = typeof body;
                }
            }
            console.debug("[VQS Debug] Request:", JSON.stringify(logData, null, 2));
        }
        const response = await fetch(url, init);
        if (isDebugEnabled()) {
            const logData = {
                method,
                url,
                status: response.status,
                statusText: response.statusText,
                headers: response.headers
            };
            console.debug("[VQS Debug] Response:", JSON.stringify(logData, null, 2));
        }
        return response;
    }
    /**
   * Send a message to a queue
   * @param options Send message options
   * @param transport Serializer/deserializer for the payload
   * @returns Promise with the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async sendMessage(options, transport) {
        const { queueName, payload, idempotencyKey, retentionSeconds } = options;
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Content-Type": transport.contentType,
            ...this.customHeaders
        });
        const deploymentId = options.deploymentId || process.env.VERCEL_DEPLOYMENT_ID;
        if (deploymentId) {
            headers.set("Vqs-Deployment-Id", deploymentId);
        }
        if (idempotencyKey) {
            headers.set("Vqs-Idempotency-Key", idempotencyKey);
        }
        if (retentionSeconds !== void 0) {
            headers.set("Vqs-Retention-Seconds", retentionSeconds.toString());
        }
        const body = transport.serialize(payload);
        const response = await this.fetch(`${this.baseUrl}${this.basePath}`, {
            method: "POST",
            body,
            headers
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 409) {
                throw new Error("Duplicate idempotency key detected");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "send message");
        }
        const responseData = await response.json();
        return responseData;
    }
    /**
   * Receive messages from a queue
   * @param options Receive messages options
   * @param transport Serializer/deserializer for the payload
   * @returns AsyncGenerator that yields messages as they arrive
   * @throws {InvalidLimitError} When limit parameter is not between 1 and 10
   * @throws {QueueEmptyError} When no messages are available (204)
   * @throws {MessageLockedError} When messages are temporarily locked (423)
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async *receiveMessages(options, transport) {
        const { queueName, consumerGroup, visibilityTimeoutSeconds, limit } = options;
        if (limit !== void 0 && (limit < 1 || limit > 10)) {
            throw new InvalidLimitError(limit);
        }
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Vqs-Consumer-Group": consumerGroup,
            Accept: "multipart/mixed",
            ...this.customHeaders
        });
        if (visibilityTimeoutSeconds !== void 0) {
            headers.set("Vqs-Visibility-Timeout", visibilityTimeoutSeconds.toString());
        }
        if (limit !== void 0) {
            headers.set("Vqs-Limit", limit.toString());
        }
        const response = await this.fetch(`${this.baseUrl}${this.basePath}`, {
            method: "GET",
            headers
        });
        if (response.status === 204) {
            throw new QueueEmptyError(queueName, consumerGroup);
        }
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 423) {
                throw new MessageLockedError("next message", parseRetryAfter(response.headers));
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "receive messages");
        }
        for await (const multipartMessage of (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$mixpart$40$0$2e$0$2e$5$2d$alpha$2e$1$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMultipartStream"])(response)){
            try {
                const parsedHeaders = parseQueueHeaders(multipartMessage.headers);
                if (!parsedHeaders) {
                    console.warn("Missing required queue headers in multipart part");
                    await consumeStream(multipartMessage.payload);
                    continue;
                }
                const deserializedPayload = await transport.deserialize(multipartMessage.payload);
                const message = {
                    ...parsedHeaders,
                    payload: deserializedPayload
                };
                yield message;
            } catch (error) {
                console.warn("Failed to process multipart message:", error);
                await consumeStream(multipartMessage.payload);
            }
        }
    }
    async receiveMessageById(options, transport) {
        const { queueName, consumerGroup, messageId, visibilityTimeoutSeconds, skipPayload } = options;
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Vqs-Consumer-Group": consumerGroup,
            Accept: "multipart/mixed",
            ...this.customHeaders
        });
        if (visibilityTimeoutSeconds !== void 0) {
            headers.set("Vqs-Visibility-Timeout", visibilityTimeoutSeconds.toString());
        }
        if (skipPayload) {
            headers.set("Vqs-Skip-Payload", "1");
        }
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "GET",
            headers
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId);
            }
            if (response.status === 423) {
                throw new MessageLockedError(messageId, parseRetryAfter(response.headers));
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "receive message by ID");
        }
        if (skipPayload && response.status === 204) {
            const parsedHeaders = parseQueueHeaders(response.headers);
            if (!parsedHeaders) {
                throw new MessageCorruptedError(messageId, "Missing required queue headers in 204 response");
            }
            const message = {
                ...parsedHeaders,
                payload: void 0
            };
            return {
                message
            };
        }
        if (!transport) {
            throw new Error("Transport is required when skipPayload is not true");
        }
        try {
            for await (const multipartMessage of (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$mixpart$40$0$2e$0$2e$5$2d$alpha$2e$1$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMultipartStream"])(response)){
                try {
                    const parsedHeaders = parseQueueHeaders(multipartMessage.headers);
                    if (!parsedHeaders) {
                        console.warn("Missing required queue headers in multipart part");
                        await consumeStream(multipartMessage.payload);
                        continue;
                    }
                    const deserializedPayload = await transport.deserialize(multipartMessage.payload);
                    const message = {
                        ...parsedHeaders,
                        payload: deserializedPayload
                    };
                    return {
                        message
                    };
                } catch (error) {
                    console.warn("Failed to deserialize message by ID:", error);
                    await consumeStream(multipartMessage.payload);
                    throw new MessageCorruptedError(messageId, `Failed to deserialize payload: ${error}`);
                }
            }
        } catch (error) {
            if (error instanceof MessageCorruptedError) {
                throw error;
            }
            throw new MessageCorruptedError(messageId, `Failed to parse multipart response: ${error}`);
        }
        throw new MessageNotFoundError(messageId);
    }
    /**
   * Delete a message (acknowledge processing)
   * @param options Delete message options
   * @returns Promise with delete status
   * @throws {MessageNotFoundError} When the message doesn't exist (404)
   * @throws {MessageNotAvailableError} When message can't be deleted (409)
   * @throws {BadRequestError} When ticket is missing or invalid (400)
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async deleteMessage(options) {
        const { queueName, consumerGroup, messageId, ticket } = options;
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "DELETE",
            headers: new Headers({
                Authorization: `Bearer ${await this.getToken()}`,
                "Vqs-Queue-Name": queueName,
                "Vqs-Consumer-Group": consumerGroup,
                "Vqs-Ticket": ticket,
                ...this.customHeaders
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId, errorText || "Invalid ticket, message not in correct state, or already processed");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "delete message", "Missing or invalid ticket");
        }
        return {
            deleted: true
        };
    }
    /**
   * Change the visibility timeout of a message
   * @param options Change visibility options
   * @returns Promise with update status
   * @throws {MessageNotFoundError} When the message doesn't exist (404)
   * @throws {MessageNotAvailableError} When message can't be updated (409)
   * @throws {BadRequestError} When ticket is missing or visibility timeout invalid (400)
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async changeVisibility(options) {
        const { queueName, consumerGroup, messageId, ticket, visibilityTimeoutSeconds } = options;
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "PATCH",
            headers: new Headers({
                Authorization: `Bearer ${await this.getToken()}`,
                "Vqs-Queue-Name": queueName,
                "Vqs-Consumer-Group": consumerGroup,
                "Vqs-Ticket": ticket,
                "Vqs-Visibility-Timeout": visibilityTimeoutSeconds.toString(),
                ...this.customHeaders
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId, errorText || "Invalid ticket, message not in correct state, or already processed");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "change visibility", "Missing ticket or invalid visibility timeout");
        }
        return {
            updated: true
        };
    }
};
// src/dev.ts
var GLOBAL_KEY = Symbol.for("@vercel/queue.devHandlers");
function getDevHandlerState() {
    const g = globalThis;
    if (!g[GLOBAL_KEY]) {
        g[GLOBAL_KEY] = {
            devRouteHandlers: /* @__PURE__ */ new Map(),
            wildcardRouteHandlers: /* @__PURE__ */ new Map()
        };
    }
    return g[GLOBAL_KEY];
}
var { devRouteHandlers, wildcardRouteHandlers } = getDevHandlerState();
function cleanupDeadRefs(key, refs) {
    const aliveRefs = refs.filter((ref)=>ref.deref() !== void 0);
    if (aliveRefs.length === 0) {
        wildcardRouteHandlers.delete(key);
    } else if (aliveRefs.length < refs.length) {
        wildcardRouteHandlers.set(key, aliveRefs);
    }
}
function isDevMode() {
    return ("TURBOPACK compile-time value", "development") === "development";
}
function registerDevRouteHandler(routeHandler, handlers) {
    for(const topicName in handlers){
        for(const consumerGroup in handlers[topicName]){
            const key = `${topicName}:${consumerGroup}`;
            if (topicName.includes("*")) {
                const existing = wildcardRouteHandlers.get(key) || [];
                cleanupDeadRefs(key, existing);
                const cleanedRefs = wildcardRouteHandlers.get(key) || [];
                const weakRef = new WeakRef(routeHandler);
                cleanedRefs.push(weakRef);
                wildcardRouteHandlers.set(key, cleanedRefs);
            } else {
                devRouteHandlers.set(key, {
                    routeHandler,
                    topicPattern: topicName
                });
            }
        }
    }
}
function findRouteHandlersForTopic(topicName) {
    const handlersMap = /* @__PURE__ */ new Map();
    for (const [key, { routeHandler, topicPattern }] of devRouteHandlers.entries()){
        const [_, consumerGroup] = key.split(":");
        if (topicPattern === topicName) {
            if (!handlersMap.has(routeHandler)) {
                handlersMap.set(routeHandler, /* @__PURE__ */ new Set());
            }
            handlersMap.get(routeHandler).add(consumerGroup);
        }
    }
    for (const [key, refs] of wildcardRouteHandlers.entries()){
        const [pattern, consumerGroup] = key.split(":");
        if (matchesWildcardPattern(topicName, pattern)) {
            cleanupDeadRefs(key, refs);
            const cleanedRefs = wildcardRouteHandlers.get(key) || [];
            for (const ref of cleanedRefs){
                const routeHandler = ref.deref();
                if (routeHandler) {
                    if (!handlersMap.has(routeHandler)) {
                        handlersMap.set(routeHandler, /* @__PURE__ */ new Set());
                    }
                    handlersMap.get(routeHandler).add(consumerGroup);
                }
            }
        }
    }
    return handlersMap;
}
function createMockCloudEventRequest(topicName, consumerGroup, messageId) {
    const cloudEvent = {
        type: "com.vercel.queue.v1beta",
        source: `/topic/${topicName}/consumer/${consumerGroup}`,
        id: messageId,
        datacontenttype: "application/json",
        data: {
            messageId,
            queueName: topicName,
            consumerGroup
        },
        time: /* @__PURE__ */ new Date().toISOString(),
        specversion: "1.0"
    };
    return new Request("https://localhost/api/queue/callback", {
        method: "POST",
        headers: {
            "Content-Type": "application/cloudevents+json"
        },
        body: JSON.stringify(cloudEvent)
    });
}
var DEV_CALLBACK_DELAY = 1e3;
function scheduleDevTimeout(topicName, messageId, timeoutSeconds) {
    console.log(`[Dev Mode] Message ${messageId} timed out for ${timeoutSeconds}s, will re-trigger`);
    setTimeout(()=>{
        console.log(`[Dev Mode] Re-triggering callback for timed-out message ${messageId}`);
        triggerDevCallbacks(topicName, messageId);
    }, timeoutSeconds * 1e3 + DEV_CALLBACK_DELAY);
}
function triggerDevCallbacks(topicName, messageId) {
    const handlersMap = findRouteHandlersForTopic(topicName);
    if (handlersMap.size === 0) {
        return;
    }
    const consumerGroups = Array.from(new Set(Array.from(handlersMap.values()).flatMap((groups)=>Array.from(groups))));
    console.log(`[Dev Mode] Triggering local callbacks for topic "${topicName}" \u2192 consumers: ${consumerGroups.join(", ")}`);
    setTimeout(async ()=>{
        for (const [routeHandler, consumerGroups2] of handlersMap.entries()){
            for (const consumerGroup of consumerGroups2){
                try {
                    const request = createMockCloudEventRequest(topicName, consumerGroup, messageId);
                    const response = await routeHandler(request);
                    if (response.ok) {
                        try {
                            const responseData = await response.json();
                            if (responseData.status === "success") {
                                console.log(`[Dev Mode] Message processed for ${topicName}/${consumerGroup}`);
                            }
                        } catch (jsonError) {
                            console.error(`[Dev Mode] Failed to parse success response for ${topicName}/${consumerGroup}:`, jsonError);
                        }
                    } else {
                        try {
                            const errorData = await response.json();
                            console.error(`[Dev Mode] Failed to process message for ${topicName}/${consumerGroup}:`, errorData.error || response.statusText);
                        } catch (jsonError) {
                            console.error(`[Dev Mode] Failed to process message for ${topicName}/${consumerGroup}:`, response.statusText);
                        }
                    }
                } catch (error) {
                    console.error(`[Dev Mode] Error triggering callback for ${topicName}/${consumerGroup}:`, error);
                }
            }
        }
    }, DEV_CALLBACK_DELAY);
}
function clearDevHandlers() {
    devRouteHandlers.clear();
    wildcardRouteHandlers.clear();
}
if (("TURBOPACK compile-time value", "development") === "test" || process.env.VITEST) {
    globalThis.__clearDevHandlers = clearDevHandlers;
}
// src/consumer-group.ts
var ConsumerGroup = class {
    client;
    topicName;
    consumerGroupName;
    visibilityTimeout;
    refreshInterval;
    transport;
    /**
   * Create a new ConsumerGroup instance
   * @param client QueueClient instance to use for API calls
   * @param topicName Name of the topic to consume from
   * @param consumerGroupName Name of the consumer group
   * @param options Optional configuration
   */ constructor(client, topicName, consumerGroupName, options = {}){
        this.client = client;
        this.topicName = topicName;
        this.consumerGroupName = consumerGroupName;
        this.visibilityTimeout = options.visibilityTimeoutSeconds || 30;
        this.refreshInterval = options.refreshInterval || 10;
        this.transport = options.transport || new JsonTransport();
    }
    /**
   * Starts a background loop that periodically extends the visibility timeout for a message.
   * This prevents the message from becoming visible to other consumers while it's being processed.
   *
   * The extension loop runs every `refreshInterval` seconds and updates the message's
   * visibility timeout to `visibilityTimeout` seconds from the current time.
   *
   * @param messageId - The unique identifier of the message to extend visibility for
   * @param ticket - The receipt ticket that proves ownership of the message
   * @returns A function that when called will stop the extension loop
   *
   * @remarks
   * - The first extension attempt occurs after `refreshInterval` seconds, not immediately
   * - If an extension fails, the loop terminates with an error logged to console
   * - The returned stop function is idempotent - calling it multiple times is safe
   * - By default, the stop function returns immediately without waiting for in-flight
   * - Pass `true` to the stop function to wait for any in-flight extension to complete
   */ startVisibilityExtension(messageId, ticket) {
        let isRunning = true;
        let resolveLifecycle;
        let timeoutId = null;
        const lifecyclePromise = new Promise((resolve)=>{
            resolveLifecycle = resolve;
        });
        const extend = async ()=>{
            if (!isRunning) {
                resolveLifecycle();
                return;
            }
            try {
                await this.client.changeVisibility({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId,
                    ticket,
                    visibilityTimeoutSeconds: this.visibilityTimeout
                });
                if (isRunning) {
                    timeoutId = setTimeout(()=>extend(), this.refreshInterval * 1e3);
                } else {
                    resolveLifecycle();
                }
            } catch (error) {
                console.error(`Failed to extend visibility for message ${messageId}:`, error);
                resolveLifecycle();
            }
        };
        timeoutId = setTimeout(()=>extend(), this.refreshInterval * 1e3);
        return async (waitForCompletion = false)=>{
            isRunning = false;
            if (timeoutId) {
                clearTimeout(timeoutId);
                timeoutId = null;
            }
            if (waitForCompletion) {
                await lifecyclePromise;
            } else {
                resolveLifecycle();
            }
        };
    }
    /**
   * Process a single message with the given handler
   * @param message The message to process
   * @param handler Function to process the message
   */ async processMessage(message, handler) {
        const stopExtension = this.startVisibilityExtension(message.messageId, message.ticket);
        try {
            const result = await handler(message.payload, {
                messageId: message.messageId,
                deliveryCount: message.deliveryCount,
                createdAt: message.createdAt,
                topicName: this.topicName,
                consumerGroup: this.consumerGroupName
            });
            await stopExtension();
            if (result && "timeoutSeconds" in result) {
                await this.client.changeVisibility({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: message.messageId,
                    ticket: message.ticket,
                    visibilityTimeoutSeconds: result.timeoutSeconds
                });
                if (isDevMode()) {
                    scheduleDevTimeout(this.topicName, message.messageId, result.timeoutSeconds);
                }
            } else {
                await this.client.deleteMessage({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: message.messageId,
                    ticket: message.ticket
                });
            }
        } catch (error) {
            await stopExtension();
            if (this.transport.finalize && message.payload !== void 0 && message.payload !== null) {
                try {
                    await this.transport.finalize(message.payload);
                } catch (finalizeError) {
                    console.warn("Failed to finalize message payload:", finalizeError);
                }
            }
            throw error;
        }
    }
    async consume(handler, options) {
        if (options?.messageId) {
            if (options.skipPayload) {
                const response = await this.client.receiveMessageById({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: options.messageId,
                    visibilityTimeoutSeconds: this.visibilityTimeout,
                    skipPayload: true
                }, this.transport);
                await this.processMessage(response.message, handler);
            } else {
                const response = await this.client.receiveMessageById({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: options.messageId,
                    visibilityTimeoutSeconds: this.visibilityTimeout
                }, this.transport);
                await this.processMessage(response.message, handler);
            }
        } else {
            let messageFound = false;
            for await (const message of this.client.receiveMessages({
                queueName: this.topicName,
                consumerGroup: this.consumerGroupName,
                visibilityTimeoutSeconds: this.visibilityTimeout,
                limit: 1
            }, this.transport)){
                messageFound = true;
                await this.processMessage(message, handler);
                break;
            }
            if (!messageFound) {
                throw new Error("No messages available");
            }
        }
    }
    /**
   * Get the consumer group name
   */ get name() {
        return this.consumerGroupName;
    }
    /**
   * Get the topic name this consumer group is subscribed to
   */ get topic() {
        return this.topicName;
    }
};
// src/topic.ts
var Topic = class {
    client;
    topicName;
    transport;
    /**
   * Create a new Topic instance
   * @param client QueueClient instance to use for API calls
   * @param topicName Name of the topic to work with
   * @param transport Optional serializer/deserializer for the payload (defaults to JSON)
   */ constructor(client, topicName, transport){
        this.client = client;
        this.topicName = topicName;
        this.transport = transport || new JsonTransport();
    }
    /**
   * Publish a message to the topic
   * @param payload The data to publish
   * @param options Optional publish options
   * @returns An object containing the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async publish(payload, options) {
        const result = await this.client.sendMessage({
            queueName: this.topicName,
            payload,
            idempotencyKey: options?.idempotencyKey,
            retentionSeconds: options?.retentionSeconds,
            deploymentId: options?.deploymentId
        }, this.transport);
        if (isDevMode()) {
            triggerDevCallbacks(this.topicName, result.messageId);
        }
        return {
            messageId: result.messageId
        };
    }
    /**
   * Create a consumer group for this topic
   * @param consumerGroupName Name of the consumer group
   * @param options Optional configuration for the consumer group
   * @returns A ConsumerGroup instance
   */ consumerGroup(consumerGroupName, options) {
        const consumerOptions = {
            ...options,
            transport: options?.transport || this.transport
        };
        return new ConsumerGroup(this.client, this.topicName, consumerGroupName, consumerOptions);
    }
    /**
   * Get the topic name
   */ get name() {
        return this.topicName;
    }
    /**
   * Get the transport used by this topic
   */ get serializer() {
        return this.transport;
    }
};
// src/callback.ts
function validateWildcardPattern(pattern) {
    const firstIndex = pattern.indexOf("*");
    const lastIndex = pattern.lastIndexOf("*");
    if (firstIndex !== lastIndex) {
        return false;
    }
    if (firstIndex === -1) {
        return false;
    }
    if (firstIndex !== pattern.length - 1) {
        return false;
    }
    return true;
}
function matchesWildcardPattern(topicName, pattern) {
    const prefix = pattern.slice(0, -1);
    return topicName.startsWith(prefix);
}
function findTopicHandler(queueName, handlers) {
    const exactHandler = handlers[queueName];
    if (exactHandler) {
        return exactHandler;
    }
    for(const pattern in handlers){
        if (pattern.includes("*") && matchesWildcardPattern(queueName, pattern)) {
            return handlers[pattern];
        }
    }
    return null;
}
async function parseCallback(request) {
    const contentType = request.headers.get("content-type");
    if (!contentType || !contentType.includes("application/cloudevents+json")) {
        throw new Error("Invalid content type: expected 'application/cloudevents+json'");
    }
    let cloudEvent;
    try {
        cloudEvent = await request.json();
    } catch (error) {
        throw new Error("Failed to parse CloudEvent from request body");
    }
    if (!cloudEvent.type || !cloudEvent.source || !cloudEvent.id || typeof cloudEvent.data !== "object" || cloudEvent.data == null) {
        throw new Error("Invalid CloudEvent: missing required fields");
    }
    if (cloudEvent.type !== "com.vercel.queue.v1beta") {
        throw new Error(`Invalid CloudEvent type: expected 'com.vercel.queue.v1beta', got '${cloudEvent.type}'`);
    }
    const missingFields = [];
    if (!("queueName" in cloudEvent.data)) missingFields.push("queueName");
    if (!("consumerGroup" in cloudEvent.data)) missingFields.push("consumerGroup");
    if (!("messageId" in cloudEvent.data)) missingFields.push("messageId");
    if (missingFields.length > 0) {
        throw new Error(`Missing required CloudEvent data fields: ${missingFields.join(", ")}`);
    }
    const { messageId, queueName, consumerGroup } = cloudEvent.data;
    return {
        queueName,
        consumerGroup,
        messageId
    };
}
function createCallbackHandler(handlers, client) {
    for(const topicPattern in handlers){
        if (topicPattern.includes("*")) {
            if (!validateWildcardPattern(topicPattern)) {
                throw new Error(`Invalid wildcard pattern "${topicPattern}": * may only appear once and must be at the end of the topic name`);
            }
        }
    }
    const routeHandler = async (request)=>{
        try {
            const { queueName, consumerGroup, messageId } = await parseCallback(request);
            const topicHandler = findTopicHandler(queueName, handlers);
            if (!topicHandler) {
                const availableTopics = Object.keys(handlers).join(", ");
                return Response.json({
                    error: `No handler found for topic: ${queueName}`,
                    availableTopics
                }, {
                    status: 404
                });
            }
            const consumerGroupHandler = topicHandler[consumerGroup];
            if (!consumerGroupHandler) {
                const availableGroups = Object.keys(topicHandler).join(", ");
                return Response.json({
                    error: `No handler found for consumer group "${consumerGroup}" in topic "${queueName}".`,
                    availableGroups
                }, {
                    status: 404
                });
            }
            const topic = new Topic(client, queueName);
            const cg = topic.consumerGroup(consumerGroup);
            await cg.consume(consumerGroupHandler, {
                messageId
            });
            return Response.json({
                status: "success"
            });
        } catch (error) {
            console.error("Queue callback error:", error);
            if (error instanceof Error && (error.message.includes("Missing required CloudEvent data fields") || error.message.includes("Invalid CloudEvent") || error.message.includes("Invalid CloudEvent type") || error.message.includes("Invalid content type") || error.message.includes("Failed to parse CloudEvent"))) {
                return Response.json({
                    error: error.message
                }, {
                    status: 400
                });
            }
            return Response.json({
                error: "Failed to process queue message"
            }, {
                status: 500
            });
        }
    };
    if (isDevMode()) {
        registerDevRouteHandler(routeHandler, handlers);
    }
    return routeHandler;
}
function handleCallback(handlers, client) {
    return createCallbackHandler(handlers, client || new QueueClient());
}
// src/factory.ts
async function send(topicName, payload, options) {
    const transport = options?.transport || new JsonTransport();
    const client = options?.client || new QueueClient();
    const result = await client.sendMessage({
        queueName: topicName,
        payload,
        idempotencyKey: options?.idempotencyKey,
        retentionSeconds: options?.retentionSeconds,
        deploymentId: options?.deploymentId
    }, transport);
    if (isDevMode()) {
        triggerDevCallbacks(topicName, result.messageId);
    }
    return {
        messageId: result.messageId
    };
}
async function receive(topicName, consumerGroup, handler, options) {
    const transport = options?.transport || new JsonTransport();
    const client = options?.client || new QueueClient();
    const topic = new Topic(client, topicName, transport);
    const { messageId, skipPayload, client: _, ...consumerGroupOptions } = options || {};
    const consumer = topic.consumerGroup(consumerGroup, consumerGroupOptions);
    if (messageId) {
        if (skipPayload) {
            return consumer.consume(handler, {
                messageId,
                skipPayload: true
            });
        } else {
            return consumer.consume(handler, {
                messageId
            });
        }
    } else {
        return consumer.consume(handler);
    }
}
// src/queue-client.ts
var Client = class {
    client;
    /**
   * Create a new Client
   * @param options QueueClient configuration options
   */ constructor(options = {}){
        this.client = new QueueClient(options);
    }
    /**
   * Send a message to a topic
   * @param topicName Name of the topic to send to
   * @param payload The data to send
   * @param options Optional publish options and transport
   * @returns Promise with the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async send(topicName, payload, options) {
        return send(topicName, payload, {
            ...options,
            client: this.client
        });
    }
    /**
   * Create a callback handler for processing queue messages
   * Returns a Next.js route handler function that routes messages to appropriate handlers
   * @param handlers Object with topic-specific handlers organized by consumer groups
   * @returns A Next.js route handler function
   *
   * @example
   * ```typescript
   * export const POST = client.handleCallback({
   *   "user-events": {
   *     "welcome": (user, metadata) => console.log("Welcoming user", user),
   *     "analytics": (user, metadata) => console.log("Tracking user", user),
   *   },
   * });
   * ```
   */ handleCallback(handlers) {
        return handleCallback(handlers, this.client);
    }
};
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/frontend/node_modules/.pnpm/async-sema@3.1.1/node_modules/async-sema/lib/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RateLimit = exports.Sema = void 0;
const events_1 = __importDefault(__turbopack_context__.r("[externals]/events [external] (events, cjs)"));
function arrayMove(src, srcIndex, dst, dstIndex, len) {
    for(let j = 0; j < len; ++j){
        dst[j + dstIndex] = src[j + srcIndex];
        src[j + srcIndex] = void 0;
    }
}
function pow2AtLeast(n) {
    n = n >>> 0;
    n = n - 1;
    n = n | n >> 1;
    n = n | n >> 2;
    n = n | n >> 4;
    n = n | n >> 8;
    n = n | n >> 16;
    return n + 1;
}
function getCapacity(capacity) {
    return pow2AtLeast(Math.min(Math.max(16, capacity), 1073741824));
}
// Deque is based on https://github.com/petkaantonov/deque/blob/master/js/deque.js
// Released under the MIT License: https://github.com/petkaantonov/deque/blob/6ef4b6400ad3ba82853fdcc6531a38eb4f78c18c/LICENSE
class Deque {
    constructor(capacity){
        this._capacity = getCapacity(capacity);
        this._length = 0;
        this._front = 0;
        this.arr = [];
    }
    push(item) {
        const length = this._length;
        this.checkCapacity(length + 1);
        const i = this._front + length & this._capacity - 1;
        this.arr[i] = item;
        this._length = length + 1;
        return length + 1;
    }
    pop() {
        const length = this._length;
        if (length === 0) {
            return void 0;
        }
        const i = this._front + length - 1 & this._capacity - 1;
        const ret = this.arr[i];
        this.arr[i] = void 0;
        this._length = length - 1;
        return ret;
    }
    shift() {
        const length = this._length;
        if (length === 0) {
            return void 0;
        }
        const front = this._front;
        const ret = this.arr[front];
        this.arr[front] = void 0;
        this._front = front + 1 & this._capacity - 1;
        this._length = length - 1;
        return ret;
    }
    get length() {
        return this._length;
    }
    checkCapacity(size) {
        if (this._capacity < size) {
            this.resizeTo(getCapacity(this._capacity * 1.5 + 16));
        }
    }
    resizeTo(capacity) {
        const oldCapacity = this._capacity;
        this._capacity = capacity;
        const front = this._front;
        const length = this._length;
        if (front + length > oldCapacity) {
            const moveItemsCount = front + length & oldCapacity - 1;
            arrayMove(this.arr, 0, this.arr, oldCapacity, moveItemsCount);
        }
    }
}
class ReleaseEmitter extends events_1.default {
}
function isFn(x) {
    return typeof x === 'function';
}
function defaultInit() {
    return '1';
}
class Sema {
    constructor(nr, { initFn = defaultInit, pauseFn, resumeFn, capacity = 10 } = {}){
        if (isFn(pauseFn) !== isFn(resumeFn)) {
            throw new Error('pauseFn and resumeFn must be both set for pausing');
        }
        this.nrTokens = nr;
        this.free = new Deque(nr);
        this.waiting = new Deque(capacity);
        this.releaseEmitter = new ReleaseEmitter();
        this.noTokens = initFn === defaultInit;
        this.pauseFn = pauseFn;
        this.resumeFn = resumeFn;
        this.paused = false;
        this.releaseEmitter.on('release', (token)=>{
            const p = this.waiting.shift();
            if (p) {
                p.resolve(token);
            } else {
                if (this.resumeFn && this.paused) {
                    this.paused = false;
                    this.resumeFn();
                }
                this.free.push(token);
            }
        });
        for(let i = 0; i < nr; i++){
            this.free.push(initFn());
        }
    }
    tryAcquire() {
        return this.free.pop();
    }
    async acquire() {
        let token = this.tryAcquire();
        if (token !== void 0) {
            return token;
        }
        return new Promise((resolve, reject)=>{
            if (this.pauseFn && !this.paused) {
                this.paused = true;
                this.pauseFn();
            }
            this.waiting.push({
                resolve,
                reject
            });
        });
    }
    release(token) {
        this.releaseEmitter.emit('release', this.noTokens ? '1' : token);
    }
    drain() {
        const a = new Array(this.nrTokens);
        for(let i = 0; i < this.nrTokens; i++){
            a[i] = this.acquire();
        }
        return Promise.all(a);
    }
    nrWaiting() {
        return this.waiting.length;
    }
}
exports.Sema = Sema;
function RateLimit(rps, { timeUnit = 1000, uniformDistribution = false } = {}) {
    const sema = new Sema(uniformDistribution ? 1 : rps);
    const delay = uniformDistribution ? timeUnit / rps : timeUnit;
    return async function rl() {
        await sema.acquire();
        setTimeout(()=>sema.release(), delay);
    };
}
exports.RateLimit = RateLimit;
}),
"[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_ULID",
    ()=>MAX_ULID,
    "MIN_ULID",
    ()=>MIN_ULID,
    "TIME_LEN",
    ()=>TIME_LEN,
    "TIME_MAX",
    ()=>TIME_MAX,
    "ULIDError",
    ()=>ULIDError,
    "ULIDErrorCode",
    ()=>ULIDErrorCode,
    "decodeTime",
    ()=>decodeTime,
    "encodeTime",
    ()=>encodeTime,
    "fixULIDBase32",
    ()=>fixULIDBase32,
    "incrementBase32",
    ()=>incrementBase32,
    "isValid",
    ()=>isValid,
    "monotonicFactory",
    ()=>monotonicFactory,
    "ulid",
    ()=>ulid,
    "ulidToUUID",
    ()=>ulidToUUID,
    "uuidToULID",
    ()=>uuidToULID
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:crypto [external] (node:crypto, cjs)");
;
// These values should NEVER change. The values are precisely for
// generating ULIDs.
const B32_CHARACTERS = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
const ENCODING = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; // Crockford's Base32
const ENCODING_LEN = 32; // from ENCODING.length;
const MAX_ULID = "7ZZZZZZZZZZZZZZZZZZZZZZZZZ";
const MIN_ULID = "00000000000000000000000000";
const RANDOM_LEN = 16;
const TIME_LEN = 10;
const TIME_MAX = 281474976710655; // from Math.pow(2, 48) - 1;
const ULID_REGEX = /^[0-7][0-9a-hjkmnp-tv-zA-HJKMNP-TV-Z]{25}$/;
const UUID_REGEX = /^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$/;
var ULIDErrorCode;
(function(ULIDErrorCode) {
    ULIDErrorCode["Base32IncorrectEncoding"] = "B32_ENC_INVALID";
    ULIDErrorCode["DecodeTimeInvalidCharacter"] = "DEC_TIME_CHAR";
    ULIDErrorCode["DecodeTimeValueMalformed"] = "DEC_TIME_MALFORMED";
    ULIDErrorCode["EncodeTimeNegative"] = "ENC_TIME_NEG";
    ULIDErrorCode["EncodeTimeSizeExceeded"] = "ENC_TIME_SIZE_EXCEED";
    ULIDErrorCode["EncodeTimeValueMalformed"] = "ENC_TIME_MALFORMED";
    ULIDErrorCode["PRNGDetectFailure"] = "PRNG_DETECT";
    ULIDErrorCode["ULIDInvalid"] = "ULID_INVALID";
    ULIDErrorCode["Unexpected"] = "UNEXPECTED";
    ULIDErrorCode["UUIDInvalid"] = "UUID_INVALID";
})(ULIDErrorCode || (ULIDErrorCode = {}));
class ULIDError extends Error {
    constructor(errorCode, message){
        super(`${message} (${errorCode})`);
        this.name = "ULIDError";
        this.code = errorCode;
    }
}
function randomChar(prng) {
    // Currently PRNGs generate fractions from 0 to _less than_ 1, so no "%" is necessary.
    // However, just in case a future PRNG can generate 1,
    // we are applying "% ENCODING LEN" to wrap back to the first character
    const randomPosition = Math.floor(prng() * ENCODING_LEN) % ENCODING_LEN;
    return ENCODING.charAt(randomPosition);
}
function replaceCharAt(str, index, char) {
    if (index > str.length - 1) {
        return str;
    }
    return str.substr(0, index) + char + str.substr(index + 1);
}
// Code from https://github.com/devbanana/crockford-base32/blob/develop/src/index.ts
function crockfordEncode(input) {
    const output = [];
    let bitsRead = 0;
    let buffer = 0;
    const reversedInput = new Uint8Array(input.slice().reverse());
    for (const byte of reversedInput){
        buffer |= byte << bitsRead;
        bitsRead += 8;
        while(bitsRead >= 5){
            output.unshift(buffer & 0x1f);
            buffer >>>= 5;
            bitsRead -= 5;
        }
    }
    if (bitsRead > 0) {
        output.unshift(buffer & 0x1f);
    }
    return output.map((byte)=>B32_CHARACTERS.charAt(byte)).join("");
}
function crockfordDecode(input) {
    const sanitizedInput = input.toUpperCase().split("").reverse().join("");
    const output = [];
    let bitsRead = 0;
    let buffer = 0;
    for (const character of sanitizedInput){
        const byte = B32_CHARACTERS.indexOf(character);
        if (byte === -1) {
            throw new Error(`Invalid base 32 character found in string: ${character}`);
        }
        buffer |= byte << bitsRead;
        bitsRead += 5;
        while(bitsRead >= 8){
            output.unshift(buffer & 0xff);
            buffer >>>= 8;
            bitsRead -= 8;
        }
    }
    if (bitsRead >= 5 || buffer > 0) {
        output.unshift(buffer & 0xff);
    }
    return new Uint8Array(output);
}
/**
 * Fix a ULID's Base32 encoding -
 * i and l (case-insensitive) will be treated as 1 and o (case-insensitive) will be treated as 0.
 * hyphens are ignored during decoding.
 * @param id The ULID
 * @returns The cleaned up ULID
 */ function fixULIDBase32(id) {
    return id.replace(/i/gi, "1").replace(/l/gi, "1").replace(/o/gi, "0").replace(/-/g, "");
}
function incrementBase32(str) {
    let done = undefined, index = str.length, char, charIndex, output = str;
    const maxCharIndex = ENCODING_LEN - 1;
    while(!done && index-- >= 0){
        char = output[index];
        charIndex = ENCODING.indexOf(char);
        if (charIndex === -1) {
            throw new ULIDError(ULIDErrorCode.Base32IncorrectEncoding, "Incorrectly encoded string");
        }
        if (charIndex === maxCharIndex) {
            output = replaceCharAt(output, index, ENCODING[0]);
            continue;
        }
        done = replaceCharAt(output, index, ENCODING[charIndex + 1]);
    }
    if (typeof done === "string") {
        return done;
    }
    throw new ULIDError(ULIDErrorCode.Base32IncorrectEncoding, "Failed incrementing string");
}
/**
 * Decode time from a ULID
 * @param id The ULID
 * @returns The decoded timestamp
 */ function decodeTime(id) {
    if (id.length !== TIME_LEN + RANDOM_LEN) {
        throw new ULIDError(ULIDErrorCode.DecodeTimeValueMalformed, "Malformed ULID");
    }
    const time = id.substr(0, TIME_LEN).toUpperCase().split("").reverse().reduce((carry, char, index)=>{
        const encodingIndex = ENCODING.indexOf(char);
        if (encodingIndex === -1) {
            throw new ULIDError(ULIDErrorCode.DecodeTimeInvalidCharacter, `Time decode error: Invalid character: ${char}`);
        }
        return carry += encodingIndex * Math.pow(ENCODING_LEN, index);
    }, 0);
    if (time > TIME_MAX) {
        throw new ULIDError(ULIDErrorCode.DecodeTimeValueMalformed, `Malformed ULID: timestamp too large: ${time}`);
    }
    return time;
}
/**
 * Detect the best PRNG (pseudo-random number generator)
 * @param root The root to check from (global/window)
 * @returns The PRNG function
 */ function detectPRNG(root) {
    const rootLookup = detectRoot();
    const globalCrypto = rootLookup && (rootLookup.crypto || rootLookup.msCrypto) || (typeof __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"] !== "undefined" ? __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"] : null);
    if (typeof globalCrypto?.getRandomValues === "function") {
        return ()=>{
            const buffer = new Uint8Array(1);
            globalCrypto.getRandomValues(buffer);
            return buffer[0] / 0xff;
        };
    } else if (typeof globalCrypto?.randomBytes === "function") {
        return ()=>globalCrypto.randomBytes(1).readUInt8() / 0xff;
    } else if (__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"]?.randomBytes) {
        return ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"].randomBytes(1).readUInt8() / 0xff;
    }
    throw new ULIDError(ULIDErrorCode.PRNGDetectFailure, "Failed to find a reliable PRNG");
}
function detectRoot() {
    if (inWebWorker()) return self;
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if ("TURBOPACK compile-time truthy", 1) {
        return /*TURBOPACK member replacement*/ __turbopack_context__.g;
    }
    //TURBOPACK unreachable
    ;
}
function encodeRandom(len, prng) {
    let str = "";
    for(; len > 0; len--){
        str = randomChar(prng) + str;
    }
    return str;
}
/**
 * Encode the time portion of a ULID
 * @param now The current timestamp
 * @param len Length to generate
 * @returns The encoded time
 */ function encodeTime(now, len = TIME_LEN) {
    if (isNaN(now)) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeValueMalformed, `Time must be a number: ${now}`);
    } else if (now > TIME_MAX) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeSizeExceeded, `Cannot encode a time larger than ${TIME_MAX}: ${now}`);
    } else if (now < 0) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeNegative, `Time must be positive: ${now}`);
    } else if (Number.isInteger(now) === false) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeValueMalformed, `Time must be an integer: ${now}`);
    }
    let mod, str = "";
    for(let currentLen = len; currentLen > 0; currentLen--){
        mod = now % ENCODING_LEN;
        str = ENCODING.charAt(mod) + str;
        now = (now - mod) / ENCODING_LEN;
    }
    return str;
}
function inWebWorker() {
    // @ts-ignore
    return typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
}
/**
 * Check if a ULID is valid
 * @param id The ULID to test
 * @returns True if valid, false otherwise
 * @example
 *   isValid("01HNZX8JGFACFA36RBXDHEQN6E"); // true
 *   isValid(""); // false
 */ function isValid(id) {
    return typeof id === "string" && id.length === TIME_LEN + RANDOM_LEN && id.toUpperCase().split("").every((char)=>ENCODING.indexOf(char) !== -1);
}
/**
 * Create a ULID factory to generate monotonically-increasing
 *  ULIDs
 * @param prng The PRNG to use
 * @returns A ulid factory
 * @example
 *  const ulid = monotonicFactory();
 *  ulid(); // "01HNZXD07M5CEN5XA66EMZSRZW"
 */ function monotonicFactory(prng) {
    const currentPRNG = prng || detectPRNG();
    let lastTime = 0, lastRandom;
    return function _ulid(seedTime) {
        const seed = !seedTime || isNaN(seedTime) ? Date.now() : seedTime;
        if (seed <= lastTime) {
            const incrementedRandom = lastRandom = incrementBase32(lastRandom);
            return encodeTime(lastTime, TIME_LEN) + incrementedRandom;
        }
        lastTime = seed;
        const newRandom = lastRandom = encodeRandom(RANDOM_LEN, currentPRNG);
        return encodeTime(seed, TIME_LEN) + newRandom;
    };
}
/**
 * Generate a ULID
 * @param seedTime Optional time seed
 * @param prng Optional PRNG function
 * @returns A ULID string
 * @example
 *  ulid(); // "01HNZXD07M5CEN5XA66EMZSRZW"
 */ function ulid(seedTime, prng) {
    const currentPRNG = prng || detectPRNG();
    const seed = !seedTime || isNaN(seedTime) ? Date.now() : seedTime;
    return encodeTime(seed, TIME_LEN) + encodeRandom(RANDOM_LEN, currentPRNG);
}
/**
 * Convert a ULID to a UUID
 * @param ulid The ULID to convert
 * @returns A UUID string
 */ function ulidToUUID(ulid) {
    const isValid = ULID_REGEX.test(ulid);
    if (!isValid) {
        throw new ULIDError(ULIDErrorCode.ULIDInvalid, `Invalid ULID: ${ulid}`);
    }
    const uint8Array = crockfordDecode(ulid);
    let uuid = Array.from(uint8Array).map((byte)=>byte.toString(16).padStart(2, "0")).join("");
    uuid = uuid.substring(0, 8) + "-" + uuid.substring(8, 12) + "-" + uuid.substring(12, 16) + "-" + uuid.substring(16, 20) + "-" + uuid.substring(20);
    return uuid.toUpperCase();
}
/**
 * Convert a UUID to a ULID
 * @param uuid The UUID to convert
 * @returns A ULID string
 */ function uuidToULID(uuid) {
    const isValid = UUID_REGEX.test(uuid);
    if (!isValid) {
        throw new ULIDError(ULIDErrorCode.UUIDInvalid, `Invalid UUID: ${uuid}`);
    }
    const bytes = uuid.replace(/-/g, "").match(/.{1,2}/g);
    if (!bytes) {
        throw new ULIDError(ULIDErrorCode.Unexpected, `Failed parsing UUID bytes: ${uuid}`);
    }
    const uint8Array = new Uint8Array(bytes.map((byte)=>parseInt(byte, 16)));
    return crockfordEncode(uint8Array);
}
;
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/version.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Generated by genversion.
__turbopack_context__.s([
    "version",
    ()=>version
]);
const version = '4.0.1-beta.18'; //# sourceMappingURL=version.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/utils.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_RESOLVE_DATA_OPTION",
    ()=>DEFAULT_RESOLVE_DATA_OPTION,
    "dateToStringReplacer",
    ()=>dateToStringReplacer,
    "deserializeError",
    ()=>deserializeError,
    "getHeaders",
    ()=>getHeaders,
    "getHttpConfig",
    ()=>getHttpConfig,
    "getHttpUrl",
    ()=>getHttpUrl,
    "makeRequest",
    ()=>makeRequest,
    "serializeError",
    ()=>serializeError
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$os__$5b$external$5d$__$28$node$3a$os$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:os [external] (node:os, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$oidc$40$3$2e$0$2e$5$2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/errors.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$version$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/version.js [app-route] (ecmascript)");
;
;
;
;
;
;
const DEFAULT_RESOLVE_DATA_OPTION = 'all';
function dateToStringReplacer(_key, value) {
    if (value instanceof Date) {
        return value.toISOString();
    }
    return value;
}
function serializeError(data) {
    const { error, ...rest } = data;
    // If we have an error, serialize as JSON string
    if (error !== undefined) {
        return {
            ...rest,
            error: JSON.stringify({
                message: error.message,
                stack: error.stack,
                code: error.code
            })
        };
    }
    return data;
}
function deserializeError(obj) {
    const { error, ...rest } = obj;
    if (!error) {
        return obj;
    }
    // Try to parse as structured error JSON
    try {
        const parsed = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"].parse(JSON.parse(error));
        return {
            ...rest,
            error: {
                message: parsed.message,
                stack: parsed.stack,
                code: parsed.code
            }
        };
    } catch  {
        // Backwards compatibility: error is just a plain string
        return {
            ...rest,
            error: {
                message: error
            }
        };
    }
}
const getUserAgent = ()=>{
    return `@workflow/world-vercel/${__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$version$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["version"]} node-${process.version} ${__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$os__$5b$external$5d$__$28$node$3a$os$2c$__cjs$29$__["default"].platform()} (${__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$os__$5b$external$5d$__$28$node$3a$os$2c$__cjs$29$__["default"].arch()})`;
};
const getHttpUrl = (config)=>{
    const projectConfig = config?.projectConfig;
    const defaultUrl = 'https://vercel-workflow.com/api';
    const defaultProxyUrl = 'https://api.vercel.com/v1/workflow';
    const usingProxy = Boolean(config?.baseUrl || projectConfig?.projectId && projectConfig?.teamId);
    const baseUrl = config?.baseUrl || (usingProxy ? defaultProxyUrl : defaultUrl);
    return {
        baseUrl,
        usingProxy
    };
};
const getHeaders = (config)=>{
    const projectConfig = config?.projectConfig;
    const headers = new Headers(config?.headers);
    headers.set('User-Agent', getUserAgent());
    if (projectConfig) {
        headers.set('x-vercel-environment', projectConfig.environment || 'production');
        if (projectConfig.projectId) {
            headers.set('x-vercel-project-id', projectConfig.projectId);
        }
        if (projectConfig.teamId) {
            headers.set('x-vercel-team-id', projectConfig.teamId);
        }
    }
    return headers;
};
async function getHttpConfig(config) {
    const headers = getHeaders(config);
    const token = config?.token ?? await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$oidc$40$3$2e$0$2e$5$2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVercelOidcToken"])();
    if (token) {
        headers.set('Authorization', `Bearer ${token}`);
    }
    const { baseUrl, usingProxy } = getHttpUrl(config);
    return {
        baseUrl,
        headers,
        usingProxy
    };
}
async function makeRequest({ endpoint, options = {}, config = {}, schema }) {
    const { baseUrl, headers } = await getHttpConfig(config);
    headers.set('Content-Type', 'application/json');
    const url = `${baseUrl}${endpoint}`;
    const response = await fetch(url, {
        ...options,
        headers
    });
    if (!response.ok) {
        const errorData = await response.json().catch(()=>({}));
        if (process.env.DEBUG === '1') {
            const stringifiedHeaders = Array.from(headers.entries()).map(([key, value])=>`-H "${key}: ${value}"`).join(' ');
            console.error(`Failed to fetch, reproduce with:\ncurl -X ${options.method} ${stringifiedHeaders} "${url}"`);
        }
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](errorData.message || `${options.method ?? 'GET'} ${endpoint} -> HTTP ${response.status}: ${response.statusText}`, {
            url,
            status: response.status,
            code: errorData.code
        });
    }
    try {
        const text = await response.text();
        return schema.parse(JSON.parse(text));
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$errors$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ZodError"]) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`Failed to parse server response for ${options.method ?? 'GET'} ${endpoint}: ${error.message}`, {
                url,
                cause: error
            });
        }
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`Failed to parse server response for ${options.method ?? 'GET'} ${endpoint}`, {
            url,
            cause: error
        });
    }
} //# sourceMappingURL=utils.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/queue.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createQueue",
    ()=>createQueue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+queue@0.0.0-alpha.33/node_modules/@vercel/queue/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$schemas$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/schemas.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/utils.js [app-route] (ecmascript)");
;
;
;
;
const MessageWrapper = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$schemas$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["object"]({
    payload: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["QueuePayloadSchema"],
    queueName: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ValidQueueName"]
});
const VERCEL_QUEUE_MAX_VISIBILITY = 39600; // 11 hours in seconds
function createQueue(config) {
    const { baseUrl, usingProxy } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHttpUrl"])(config);
    const headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHeaders"])(config);
    const queueClient = new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Client"]({
        baseUrl: usingProxy ? baseUrl : undefined,
        basePath: usingProxy ? '/queues/v2/messages' : undefined,
        token: usingProxy ? config?.token : undefined,
        headers: Object.fromEntries(headers.entries())
    });
    const queue = async (queueName, x, opts)=>{
        // zod v3 doesn't have the `encode` method. We only support zod v4 officially,
        // but codebases that pin zod v3 are still common.
        const hasEncoder = typeof MessageWrapper.encode === 'function';
        if (!hasEncoder) {
            console.warn('Using zod v3 compatibility mode for queue() calls - this may not work as expected');
        }
        const encoder = hasEncoder ? MessageWrapper.encode : (data)=>data;
        const encoded = encoder({
            payload: x,
            queueName
        });
        const sanitizedQueueName = queueName.replace(/[^A-Za-z0-9-_]/g, '-');
        const { messageId } = await queueClient.send(sanitizedQueueName, encoded, opts);
        return {
            messageId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"].parse(messageId)
        };
    };
    const createQueueHandler = (prefix, handler)=>{
        return queueClient.handleCallback({
            [`${prefix}*`]: {
                default: async (body, meta)=>{
                    const { payload, queueName } = MessageWrapper.parse(body);
                    const result = await handler(payload, {
                        queueName,
                        messageId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"].parse(meta.messageId),
                        attempt: meta.deliveryCount
                    });
                    if (typeof result?.timeoutSeconds === 'number') {
                        // For Vercel Queue, enforce the max visibility limit:
                        //   - When a step function throws a `RetryableError`, the retryAfter timestamp is updated and stored on the Step document
                        const adjustedTimeoutSeconds = Math.min(result.timeoutSeconds, VERCEL_QUEUE_MAX_VISIBILITY);
                        if (adjustedTimeoutSeconds !== result.timeoutSeconds) {
                            result.timeoutSeconds = adjustedTimeoutSeconds;
                        }
                    }
                    return result;
                }
            }
        });
    };
    const getDeploymentId = async ()=>{
        const deploymentId = process.env.VERCEL_DEPLOYMENT_ID;
        if (!deploymentId) {
            throw new Error('VERCEL_DEPLOYMENT_ID environment variable is not set');
        }
        return deploymentId;
    };
    return {
        queue,
        createQueueHandler,
        getDeploymentId
    };
} //# sourceMappingURL=queue.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/events.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createWorkflowRunEvent",
    ()=>createWorkflowRunEvent,
    "getWorkflowRunEvents",
    ()=>getWorkflowRunEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/utils.js [app-route] (ecmascript)");
;
;
;
// Helper to filter event data based on resolveData setting
function filterEventData(event, resolveData) {
    if (resolveData === 'none') {
        const { eventData: _eventData, ...rest } = event;
        return rest;
    }
    return event;
}
// Would usually "EventSchema.omit({ eventData: true })" but that doesn't work
// on zod unions. Re-creating the schema manually.
const EventWithRefsSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].object({
    eventId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].string(),
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].string(),
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventTypeSchema"],
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].string().optional(),
    eventDataRef: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].any().optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].coerce.date()
});
async function getWorkflowRunEvents(params, config) {
    const searchParams = new URLSearchParams();
    const { pagination, resolveData = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"] } = params;
    let runId;
    let correlationId;
    if ('runId' in params) {
        runId = params.runId;
    } else {
        correlationId = params.correlationId;
    }
    if (!runId && !correlationId) {
        throw new Error('Either runId or correlationId must be provided');
    }
    if (pagination?.limit) searchParams.set('limit', pagination.limit.toString());
    if (pagination?.cursor) searchParams.set('cursor', pagination.cursor);
    if (pagination?.sortOrder) searchParams.set('sortOrder', pagination.sortOrder);
    if (correlationId) searchParams.set('correlationId', correlationId);
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const query = queryString ? `?${queryString}` : '';
    const endpoint = correlationId ? `/v1/events${query}` : `/v1/runs/${runId}/events${query}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint,
        options: {
            method: 'GET'
        },
        config,
        schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PaginatedResponseSchema"])(remoteRefBehavior === 'lazy' ? EventWithRefsSchema : __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"])
    });
    return {
        ...response,
        data: response.data.map((event)=>filterEventData(event, resolveData))
    };
}
async function createWorkflowRunEvent(id, data, params, config) {
    const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
    const event = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint: `/v1/runs/${id}/events`,
        options: {
            method: 'POST',
            body: JSON.stringify(data, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dateToStringReplacer"])
        },
        config,
        schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"]
    });
    return filterEventData(event, resolveData);
} //# sourceMappingURL=events.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/hooks.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createHook",
    ()=>createHook,
    "disposeHook",
    ()=>disposeHook,
    "getHook",
    ()=>getHook,
    "getHookByToken",
    ()=>getHookByToken,
    "listHooks",
    ()=>listHooks
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/utils.js [app-route] (ecmascript)");
;
;
;
// Helper to filter hook data based on resolveData setting
function filterHookData(hook, resolveData) {
    if (resolveData === 'none') {
        const { metadataRef: _metadataRef, ...rest } = hook;
        return rest;
    }
    return hook;
}
const HookWithRefsSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"].omit({
    metadata: true
}).extend({
    metadataRef: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].any().optional()
});
async function listHooks(params, config) {
    const { runId, pagination, resolveData = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"] } = params;
    const searchParams = new URLSearchParams();
    if (pagination?.limit) searchParams.set('limit', pagination.limit.toString());
    if (pagination?.cursor) searchParams.set('cursor', pagination.cursor);
    if (pagination?.sortOrder) searchParams.set('sortOrder', pagination.sortOrder);
    // Map resolveData to internal RemoteRefBehavior
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    if (runId) searchParams.set('runId', runId);
    const queryString = searchParams.toString();
    const endpoint = `/v1/hooks${queryString ? `?${queryString}` : ''}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint,
        options: {
            method: 'GET'
        },
        config,
        schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PaginatedResponseSchema"])(remoteRefBehavior === 'lazy' ? HookWithRefsSchema : __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"])
    });
    return {
        ...response,
        data: response.data.map((hook)=>filterHookData(hook, resolveData))
    };
}
async function getHook(hookId, params, config) {
    const resolveData = params?.resolveData || 'all';
    const endpoint = `/v1/hooks/${hookId}`;
    const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint,
        options: {
            method: 'GET'
        },
        config,
        schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]
    });
    return filterHookData(hook, resolveData);
}
async function createHook(runId, data, config) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint: `/v1/hooks/create`,
        options: {
            method: 'POST',
            body: JSON.stringify({
                runId,
                ...data
            }, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dateToStringReplacer"])
        },
        config,
        schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]
    });
}
async function getHookByToken(token, config) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint: `/v1/hooks/by-token?token=${encodeURIComponent(token)}`,
        options: {
            method: 'GET'
        },
        config,
        schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]
    });
}
async function disposeHook(hookId, config) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint: `/v1/hooks/${hookId}`,
        options: {
            method: 'DELETE'
        },
        config,
        schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]
    });
} //# sourceMappingURL=hooks.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/runs.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cancelWorkflowRun",
    ()=>cancelWorkflowRun,
    "createWorkflowRun",
    ()=>createWorkflowRun,
    "getWorkflowRun",
    ()=>getWorkflowRun,
    "listWorkflowRuns",
    ()=>listWorkflowRuns,
    "pauseWorkflowRun",
    ()=>pauseWorkflowRun,
    "resumeWorkflowRun",
    ()=>resumeWorkflowRun,
    "updateWorkflowRun",
    ()=>updateWorkflowRun
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/utils.js [app-route] (ecmascript)");
;
;
;
;
/**
 * Wire format schema for workflow runs coming from the backend.
 * The backend returns error as a JSON string, not an object, so we need
 * a schema that accepts the wire format before deserialization.
 *
 * This is used for validation in makeRequest(), then deserializeError()
 * transforms the string into the expected StructuredError object.
 */ const WorkflowRunWireBaseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunBaseSchema"].omit({
    error: true
}).extend({
    // Backend returns error as a JSON string, not an object
    error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
});
// Wire schema for resolved data (full input/output)
const WorkflowRunWireSchema = WorkflowRunWireBaseSchema;
// Wire schema for lazy mode with refs instead of data
const WorkflowRunWireWithRefsSchema = WorkflowRunWireBaseSchema.omit({
    input: true,
    output: true
}).extend({
    // We discard the results of the refs, so we don't care about the type here
    inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    outputRef: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    input: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()).optional(),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    blobStorageBytes: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional(),
    streamStorageBytes: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional()
});
// Helper to filter run data based on resolveData setting
function filterRunData(run, resolveData) {
    if (resolveData === 'none') {
        const { inputRef: _inputRef, outputRef: _outputRef, ...rest } = run;
        const deserialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(rest);
        return {
            ...deserialized,
            input: [],
            output: undefined
        };
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(run);
}
async function listWorkflowRuns(params = {}, config) {
    const { workflowName, status, pagination, resolveData = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"] } = params;
    const searchParams = new URLSearchParams();
    if (workflowName) searchParams.set('workflowName', workflowName);
    if (status) searchParams.set('status', status);
    if (pagination?.limit) searchParams.set('limit', pagination.limit.toString());
    if (pagination?.cursor) searchParams.set('cursor', pagination.cursor);
    if (pagination?.sortOrder) searchParams.set('sortOrder', pagination.sortOrder);
    // Map resolveData to internal RemoteRefBehavior
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const endpoint = `/v1/runs${queryString ? `?${queryString}` : ''}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint,
        options: {
            method: 'GET'
        },
        config,
        schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PaginatedResponseSchema"])(remoteRefBehavior === 'lazy' ? WorkflowRunWireWithRefsSchema : WorkflowRunWireSchema)
    });
    return {
        ...response,
        data: response.data.map((run)=>filterRunData(run, resolveData))
    };
}
async function createWorkflowRun(data, config) {
    const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint: '/v1/runs/create',
        options: {
            method: 'POST',
            body: JSON.stringify(data, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dateToStringReplacer"])
        },
        config,
        schema: WorkflowRunWireSchema
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(run);
}
async function getWorkflowRun(id, params, config) {
    const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    const searchParams = new URLSearchParams();
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const endpoint = `/v1/runs/${id}${queryString ? `?${queryString}` : ''}`;
    try {
        const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
            endpoint,
            options: {
                method: 'GET'
            },
            config,
            schema: remoteRefBehavior === 'lazy' ? WorkflowRunWireWithRefsSchema : WorkflowRunWireSchema
        });
        return filterRunData(run, resolveData);
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"] && error.status === 404) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
        }
        throw error;
    }
}
async function updateWorkflowRun(id, data, config) {
    try {
        const serialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["serializeError"])(data);
        const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
            endpoint: `/v1/runs/${id}`,
            options: {
                method: 'PUT',
                body: JSON.stringify(serialized, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dateToStringReplacer"])
            },
            config,
            schema: WorkflowRunWireSchema
        });
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(run);
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"] && error.status === 404) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
        }
        throw error;
    }
}
async function cancelWorkflowRun(id, params, config) {
    const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    const searchParams = new URLSearchParams();
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const endpoint = `/v1/runs/${id}/cancel${queryString ? `?${queryString}` : ''}`;
    try {
        const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
            endpoint,
            options: {
                method: 'PUT'
            },
            config,
            schema: remoteRefBehavior === 'lazy' ? WorkflowRunWireWithRefsSchema : WorkflowRunWireSchema
        });
        return filterRunData(run, resolveData);
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"] && error.status === 404) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
        }
        throw error;
    }
}
async function pauseWorkflowRun(id, params, config) {
    const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    const searchParams = new URLSearchParams();
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const endpoint = `/v1/runs/${id}/pause${queryString ? `?${queryString}` : ''}`;
    try {
        const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
            endpoint,
            options: {
                method: 'PUT'
            },
            config,
            schema: remoteRefBehavior === 'lazy' ? WorkflowRunWireWithRefsSchema : WorkflowRunWireSchema
        });
        return filterRunData(run, resolveData);
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"] && error.status === 404) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
        }
        throw error;
    }
}
async function resumeWorkflowRun(id, params, config) {
    const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    const searchParams = new URLSearchParams();
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const endpoint = `/v1/runs/${id}/resume${queryString ? `?${queryString}` : ''}`;
    try {
        const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
            endpoint,
            options: {
                method: 'PUT'
            },
            config,
            schema: remoteRefBehavior === 'lazy' ? WorkflowRunWireWithRefsSchema : WorkflowRunWireSchema
        });
        return filterRunData(run, resolveData);
    } catch (error) {
        if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"] && error.status === 404) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
        }
        throw error;
    }
} //# sourceMappingURL=runs.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/steps.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStep",
    ()=>createStep,
    "getStep",
    ()=>getStep,
    "listWorkflowRunSteps",
    ()=>listWorkflowRunSteps,
    "updateStep",
    ()=>updateStep
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/utils.js [app-route] (ecmascript)");
;
;
;
/**
 * Wire format schema for steps coming from the backend.
 * The backend returns error as a JSON string, not an object, so we need
 * a schema that accepts the wire format before deserialization.
 *
 * This is used for validation in makeRequest(), then deserializeStepError()
 * transforms the string into the expected StructuredError object.
 */ const StepWireSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"].omit({
    error: true
}).extend({
    // Backend returns error as a JSON string, not an object
    error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
});
// Wire schema for lazy mode with refs instead of data
const StepWireWithRefsSchema = StepWireSchema.omit({
    input: true,
    output: true
}).extend({
    // We discard the results of the refs, so we don't care about the type here
    inputRef: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    outputRef: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    input: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()).optional(),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional()
});
// Helper to filter step data based on resolveData setting
function filterStepData(step, resolveData) {
    if (resolveData === 'none') {
        const { inputRef: _inputRef, outputRef: _outputRef, ...rest } = step;
        const deserialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(rest);
        return {
            ...deserialized,
            input: [],
            output: undefined
        };
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(step);
}
async function listWorkflowRunSteps(params, config) {
    const { runId, pagination, resolveData = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"] } = params;
    const searchParams = new URLSearchParams();
    if (pagination?.cursor) searchParams.set('cursor', pagination.cursor);
    if (pagination?.limit) searchParams.set('limit', pagination.limit.toString());
    if (pagination?.sortOrder) searchParams.set('sortOrder', pagination.sortOrder);
    // Map resolveData to internal RemoteRefBehavior
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const endpoint = `/v1/runs/${runId}/steps${queryString ? `?${queryString}` : ''}`;
    const response = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint,
        options: {
            method: 'GET'
        },
        config,
        schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["PaginatedResponseSchema"])(remoteRefBehavior === 'lazy' ? StepWireWithRefsSchema : StepWireSchema)
    });
    return {
        ...response,
        data: response.data.map((step)=>filterStepData(step, resolveData))
    };
}
async function createStep(runId, data, config) {
    const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint: `/v1/runs/${runId}/steps`,
        options: {
            method: 'POST',
            body: JSON.stringify(data, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dateToStringReplacer"])
        },
        config,
        schema: StepWireSchema
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(step);
}
async function updateStep(runId, stepId, data, config) {
    const serialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["serializeError"])(data);
    const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint: `/v1/runs/${runId}/steps/${stepId}`,
        options: {
            method: 'PUT',
            body: JSON.stringify(serialized, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dateToStringReplacer"])
        },
        config,
        schema: StepWireSchema
    });
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deserializeError"])(step);
}
async function getStep(runId, stepId, params, config) {
    const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
    const remoteRefBehavior = resolveData === 'none' ? 'lazy' : 'resolve';
    const searchParams = new URLSearchParams();
    searchParams.set('remoteRefBehavior', remoteRefBehavior);
    const queryString = searchParams.toString();
    const endpoint = runId ? `/v1/runs/${runId}/steps/${stepId}${queryString ? `?${queryString}` : ''}` : `/v1/steps/${stepId}${queryString ? `?${queryString}` : ''}`;
    const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["makeRequest"])({
        endpoint,
        options: {
            method: 'GET'
        },
        config,
        schema: remoteRefBehavior === 'lazy' ? StepWireWithRefsSchema : StepWireSchema
    });
    return filterStepData(step, resolveData);
} //# sourceMappingURL=steps.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/storage.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStorage",
    ()=>createStorage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/steps.js [app-route] (ecmascript)");
;
;
;
;
function createStorage(config) {
    return {
        // Storage interface with namespaced methods
        runs: {
            create: (data)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createWorkflowRun"])(data, config),
            get: (id, params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorkflowRun"])(id, params, config),
            update: (id, data)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["updateWorkflowRun"])(id, data, config),
            list: (params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listWorkflowRuns"])(params, config),
            cancel: (id, params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["cancelWorkflowRun"])(id, params, config),
            pause: (id, params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["pauseWorkflowRun"])(id, params, config),
            resume: (id, params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resumeWorkflowRun"])(id, params, config)
        },
        steps: {
            create: (runId, data)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStep"])(runId, data, config),
            get: (runId, stepId, params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getStep"])(runId, stepId, params, config),
            update: (runId, stepId, data)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["updateStep"])(runId, stepId, data, config),
            list: (params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listWorkflowRunSteps"])(params, config)
        },
        events: {
            create: (runId, data, params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createWorkflowRunEvent"])(runId, data, params, config),
            list: (params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorkflowRunEvents"])(params, config),
            listByCorrelationId: (params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorkflowRunEvents"])(params, config)
        },
        hooks: {
            create: (runId, data)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createHook"])(runId, data, config),
            get: (hookId, params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHook"])(hookId, params, config),
            getByToken: (token)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHookByToken"])(token, config),
            list: (params)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listHooks"])(params, config),
            dispose: (hookId)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["disposeHook"])(hookId, config)
        }
    };
} //# sourceMappingURL=storage.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/streamer.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStreamer",
    ()=>createStreamer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/utils.js [app-route] (ecmascript)");
;
function getStreamUrl(name, runId, httpConfig) {
    if (runId) {
        return new URL(`${httpConfig.baseUrl}/v1/runs/${runId}/stream/${encodeURIComponent(name)}`);
    }
    return new URL(`${httpConfig.baseUrl}/v1/stream/${encodeURIComponent(name)}`);
}
function createStreamer(config) {
    return {
        async writeToStream (name, runId, chunk) {
            // Await runId if it's a promise to ensure proper flushing
            const resolvedRunId = await runId;
            const httpConfig = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHttpConfig"])(config);
            await fetch(getStreamUrl(name, resolvedRunId, httpConfig), {
                method: 'PUT',
                body: chunk,
                headers: httpConfig.headers,
                duplex: 'half'
            });
        },
        async closeStream (name, runId) {
            // Await runId if it's a promise to ensure proper flushing
            const resolvedRunId = await runId;
            const httpConfig = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHttpConfig"])(config);
            httpConfig.headers.set('X-Stream-Done', 'true');
            await fetch(getStreamUrl(name, resolvedRunId, httpConfig), {
                method: 'PUT',
                headers: httpConfig.headers
            });
        },
        async readFromStream (name, startIndex) {
            const httpConfig = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHttpConfig"])(config);
            const url = getStreamUrl(name, undefined, httpConfig);
            if (typeof startIndex === 'number') {
                url.searchParams.set('startIndex', String(startIndex));
            }
            const res = await fetch(url, {
                headers: httpConfig.headers
            });
            if (!res.ok) throw new Error(`Failed to fetch stream: ${res.status}`);
            return res.body;
        },
        async listStreamsByRunId (runId) {
            const httpConfig = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getHttpConfig"])(config);
            const url = new URL(`${httpConfig.baseUrl}/v1/runs/${runId}/streams`);
            const res = await fetch(url, {
                headers: httpConfig.headers
            });
            if (!res.ok) throw new Error(`Failed to list streams: ${res.status}`);
            return await res.json();
        }
    };
} //# sourceMappingURL=streamer.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createVercelWorld",
    ()=>createVercelWorld
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/storage.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/streamer.js [app-route] (ecmascript)");
;
;
;
;
;
;
function createVercelWorld(config) {
    return {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createQueue"])(config),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStorage"])(config),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStreamer"])(config)
    };
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/utils.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** @type {Record<string, string>} */ __turbopack_context__.s([
    "DevalueError",
    ()=>DevalueError,
    "enumerable_symbols",
    ()=>enumerable_symbols,
    "escaped",
    ()=>escaped,
    "get_type",
    ()=>get_type,
    "is_plain_object",
    ()=>is_plain_object,
    "is_primitive",
    ()=>is_primitive,
    "stringify_key",
    ()=>stringify_key,
    "stringify_string",
    ()=>stringify_string
]);
const escaped = {
    '<': '\\u003C',
    '\\': '\\\\',
    '\b': '\\b',
    '\f': '\\f',
    '\n': '\\n',
    '\r': '\\r',
    '\t': '\\t',
    '\u2028': '\\u2028',
    '\u2029': '\\u2029'
};
class DevalueError extends Error {
    /**
	 * @param {string} message
	 * @param {string[]} keys
	 * @param {any} [value] - The value that failed to be serialized
	 * @param {any} [root] - The root value being serialized
	 */ constructor(message, keys, value, root){
        super(message);
        this.name = 'DevalueError';
        this.path = keys.join('');
        this.value = value;
        this.root = root;
    }
}
function is_primitive(thing) {
    return Object(thing) !== thing;
}
const object_proto_names = /* @__PURE__ */ Object.getOwnPropertyNames(Object.prototype).sort().join('\0');
function is_plain_object(thing) {
    const proto = Object.getPrototypeOf(thing);
    return proto === Object.prototype || proto === null || Object.getPrototypeOf(proto) === null || Object.getOwnPropertyNames(proto).sort().join('\0') === object_proto_names;
}
function get_type(thing) {
    return Object.prototype.toString.call(thing).slice(8, -1);
}
/** @param {string} char */ function get_escaped_char(char) {
    switch(char){
        case '"':
            return '\\"';
        case '<':
            return '\\u003C';
        case '\\':
            return '\\\\';
        case '\n':
            return '\\n';
        case '\r':
            return '\\r';
        case '\t':
            return '\\t';
        case '\b':
            return '\\b';
        case '\f':
            return '\\f';
        case '\u2028':
            return '\\u2028';
        case '\u2029':
            return '\\u2029';
        default:
            return char < ' ' ? `\\u${char.charCodeAt(0).toString(16).padStart(4, '0')}` : '';
    }
}
function stringify_string(str) {
    let result = '';
    let last_pos = 0;
    const len = str.length;
    for(let i = 0; i < len; i += 1){
        const char = str[i];
        const replacement = get_escaped_char(char);
        if (replacement) {
            result += str.slice(last_pos, i) + replacement;
            last_pos = i + 1;
        }
    }
    return `"${last_pos === 0 ? str : result + str.slice(last_pos)}"`;
}
function enumerable_symbols(object) {
    return Object.getOwnPropertySymbols(object).filter((symbol)=>Object.getOwnPropertyDescriptor(object, symbol).enumerable);
}
const is_identifier = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;
function stringify_key(key) {
    return is_identifier.test(key) ? '.' + key : '[' + JSON.stringify(key) + ']';
}
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/base64.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Base64 Encodes an arraybuffer
 * @param {ArrayBuffer} arraybuffer
 * @returns {string}
 */ __turbopack_context__.s([
    "decode64",
    ()=>decode64,
    "encode64",
    ()=>encode64
]);
function encode64(arraybuffer) {
    const dv = new DataView(arraybuffer);
    let binaryString = "";
    for(let i = 0; i < arraybuffer.byteLength; i++){
        binaryString += String.fromCharCode(dv.getUint8(i));
    }
    return binaryToAscii(binaryString);
}
function decode64(string) {
    const binaryString = asciiToBinary(string);
    const arraybuffer = new ArrayBuffer(binaryString.length);
    const dv = new DataView(arraybuffer);
    for(let i = 0; i < arraybuffer.byteLength; i++){
        dv.setUint8(i, binaryString.charCodeAt(i));
    }
    return arraybuffer;
}
const KEY_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
/**
 * Substitute for atob since it's deprecated in node.
 * Does not do any input validation.
 *
 * @see https://github.com/jsdom/abab/blob/master/lib/atob.js
 *
 * @param {string} data
 * @returns {string}
 */ function asciiToBinary(data) {
    if (data.length % 4 === 0) {
        data = data.replace(/==?$/, "");
    }
    let output = "";
    let buffer = 0;
    let accumulatedBits = 0;
    for(let i = 0; i < data.length; i++){
        buffer <<= 6;
        buffer |= KEY_STRING.indexOf(data[i]);
        accumulatedBits += 6;
        if (accumulatedBits === 24) {
            output += String.fromCharCode((buffer & 0xff0000) >> 16);
            output += String.fromCharCode((buffer & 0xff00) >> 8);
            output += String.fromCharCode(buffer & 0xff);
            buffer = accumulatedBits = 0;
        }
    }
    if (accumulatedBits === 12) {
        buffer >>= 4;
        output += String.fromCharCode(buffer);
    } else if (accumulatedBits === 18) {
        buffer >>= 2;
        output += String.fromCharCode((buffer & 0xff00) >> 8);
        output += String.fromCharCode(buffer & 0xff);
    }
    return output;
}
/**
 * Substitute for btoa since it's deprecated in node.
 * Does not do any input validation.
 *
 * @see https://github.com/jsdom/abab/blob/master/lib/btoa.js
 *
 * @param {string} str
 * @returns {string}
 */ function binaryToAscii(str) {
    let out = "";
    for(let i = 0; i < str.length; i += 3){
        /** @type {[number, number, number, number]} */ const groupsOfSix = [
            undefined,
            undefined,
            undefined,
            undefined
        ];
        groupsOfSix[0] = str.charCodeAt(i) >> 2;
        groupsOfSix[1] = (str.charCodeAt(i) & 0x03) << 4;
        if (str.length > i + 1) {
            groupsOfSix[1] |= str.charCodeAt(i + 1) >> 4;
            groupsOfSix[2] = (str.charCodeAt(i + 1) & 0x0f) << 2;
        }
        if (str.length > i + 2) {
            groupsOfSix[2] |= str.charCodeAt(i + 2) >> 6;
            groupsOfSix[3] = str.charCodeAt(i + 2) & 0x3f;
        }
        for(let j = 0; j < groupsOfSix.length; j++){
            if (typeof groupsOfSix[j] === "undefined") {
                out += "=";
            } else {
                out += KEY_STRING[groupsOfSix[j]];
            }
        }
    }
    return out;
}
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/constants.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HOLE",
    ()=>HOLE,
    "NAN",
    ()=>NAN,
    "NEGATIVE_INFINITY",
    ()=>NEGATIVE_INFINITY,
    "NEGATIVE_ZERO",
    ()=>NEGATIVE_ZERO,
    "POSITIVE_INFINITY",
    ()=>POSITIVE_INFINITY,
    "UNDEFINED",
    ()=>UNDEFINED
]);
const UNDEFINED = -1;
const HOLE = -2;
const NAN = -3;
const POSITIVE_INFINITY = -4;
const NEGATIVE_INFINITY = -5;
const NEGATIVE_ZERO = -6;
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/parse.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parse",
    ()=>parse,
    "unflatten",
    ()=>unflatten
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/base64.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/constants.js [app-route] (ecmascript)");
;
;
function parse(serialized, revivers) {
    return unflatten(JSON.parse(serialized), revivers);
}
function unflatten(parsed, revivers) {
    if (typeof parsed === 'number') return hydrate(parsed, true);
    if (!Array.isArray(parsed) || parsed.length === 0) {
        throw new Error('Invalid input');
    }
    const values = parsed;
    const hydrated = Array(values.length);
    /**
	 * @param {number} index
	 * @returns {any}
	 */ function hydrate(index, standalone = false) {
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"]) return undefined;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NAN"]) return NaN;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["POSITIVE_INFINITY"]) return Infinity;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_INFINITY"]) return -Infinity;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"]) return -0;
        if (standalone || typeof index !== 'number') {
            throw new Error(`Invalid input`);
        }
        if (index in hydrated) return hydrated[index];
        const value = values[index];
        if (!value || typeof value !== 'object') {
            hydrated[index] = value;
        } else if (Array.isArray(value)) {
            if (typeof value[0] === 'string') {
                const type = value[0];
                const reviver = revivers?.[type];
                if (reviver) {
                    let i = value[1];
                    if (typeof i !== 'number') {
                        // if it's not a number, it was serialized by a builtin reviver
                        // so we need to munge it into the format expected by a custom reviver
                        i = values.push(value[1]) - 1;
                    }
                    return hydrated[index] = reviver(hydrate(i));
                }
                switch(type){
                    case 'Date':
                        hydrated[index] = new Date(value[1]);
                        break;
                    case 'Set':
                        const set = new Set();
                        hydrated[index] = set;
                        for(let i = 1; i < value.length; i += 1){
                            set.add(hydrate(value[i]));
                        }
                        break;
                    case 'Map':
                        const map = new Map();
                        hydrated[index] = map;
                        for(let i = 1; i < value.length; i += 2){
                            map.set(hydrate(value[i]), hydrate(value[i + 1]));
                        }
                        break;
                    case 'RegExp':
                        hydrated[index] = new RegExp(value[1], value[2]);
                        break;
                    case 'Object':
                        hydrated[index] = Object(value[1]);
                        break;
                    case 'BigInt':
                        hydrated[index] = BigInt(value[1]);
                        break;
                    case 'null':
                        const obj = Object.create(null);
                        hydrated[index] = obj;
                        for(let i = 1; i < value.length; i += 2){
                            obj[value[i]] = hydrate(value[i + 1]);
                        }
                        break;
                    case 'Int8Array':
                    case 'Uint8Array':
                    case 'Uint8ClampedArray':
                    case 'Int16Array':
                    case 'Uint16Array':
                    case 'Int32Array':
                    case 'Uint32Array':
                    case 'Float32Array':
                    case 'Float64Array':
                    case 'BigInt64Array':
                    case 'BigUint64Array':
                        {
                            const TypedArrayConstructor = globalThis[type];
                            const typedArray = new TypedArrayConstructor(hydrate(value[1]));
                            hydrated[index] = value[2] !== undefined ? typedArray.subarray(value[2], value[3]) : typedArray;
                            break;
                        }
                    case 'ArrayBuffer':
                        {
                            const base64 = value[1];
                            const arraybuffer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decode64"])(base64);
                            hydrated[index] = arraybuffer;
                            break;
                        }
                    case 'Temporal.Duration':
                    case 'Temporal.Instant':
                    case 'Temporal.PlainDate':
                    case 'Temporal.PlainTime':
                    case 'Temporal.PlainDateTime':
                    case 'Temporal.PlainMonthDay':
                    case 'Temporal.PlainYearMonth':
                    case 'Temporal.ZonedDateTime':
                        {
                            const temporalName = type.slice(9);
                            // @ts-expect-error TS doesn't know about Temporal yet
                            hydrated[index] = Temporal[temporalName].from(value[1]);
                            break;
                        }
                    case 'URL':
                        {
                            const url = new URL(value[1]);
                            hydrated[index] = url;
                            break;
                        }
                    case 'URLSearchParams':
                        {
                            const url = new URLSearchParams(value[1]);
                            hydrated[index] = url;
                            break;
                        }
                    default:
                        throw new Error(`Unknown type ${type}`);
                }
            } else {
                const array = new Array(value.length);
                hydrated[index] = array;
                for(let i = 0; i < value.length; i += 1){
                    const n = value[i];
                    if (n === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HOLE"]) continue;
                    array[i] = hydrate(n);
                }
            }
        } else {
            /** @type {Record<string, any>} */ const object = {};
            hydrated[index] = object;
            for(const key in value){
                if (key === '__proto__') {
                    throw new Error('Cannot parse an object with a `__proto__` property');
                }
                const n = value[key];
                object[key] = hydrate(n);
            }
        }
        return hydrated[index];
    }
    return hydrate(0);
}
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/stringify.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stringify",
    ()=>stringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/constants.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/base64.js [app-route] (ecmascript)");
;
;
;
function stringify(value, reducers) {
    /** @type {any[]} */ const stringified = [];
    /** @type {Map<any, number>} */ const indexes = new Map();
    /** @type {Array<{ key: string, fn: (value: any) => any }>} */ const custom = [];
    if (reducers) {
        for (const key of Object.getOwnPropertyNames(reducers)){
            custom.push({
                key,
                fn: reducers[key]
            });
        }
    }
    /** @type {string[]} */ const keys = [];
    let p = 0;
    /** @param {any} thing */ function flatten(thing) {
        if (thing === undefined) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"];
        if (Number.isNaN(thing)) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NAN"];
        if (thing === Infinity) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["POSITIVE_INFINITY"];
        if (thing === -Infinity) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_INFINITY"];
        if (thing === 0 && 1 / thing < 0) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"];
        if (indexes.has(thing)) return indexes.get(thing);
        const index = p++;
        indexes.set(thing, index);
        for (const { key, fn } of custom){
            const value = fn(thing);
            if (value) {
                stringified[index] = `["${key}",${flatten(value)}]`;
                return index;
            }
        }
        if (typeof thing === 'function') {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify a function`, keys, thing, value);
        }
        let str = '';
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_primitive"])(thing)) {
            str = stringify_primitive(thing);
        } else {
            const type = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["get_type"])(thing);
            switch(type){
                case 'Number':
                case 'String':
                case 'Boolean':
                    str = `["Object",${stringify_primitive(thing)}]`;
                    break;
                case 'BigInt':
                    str = `["BigInt",${thing}]`;
                    break;
                case 'Date':
                    const valid = !isNaN(thing.getDate());
                    str = `["Date","${valid ? thing.toISOString() : ''}"]`;
                    break;
                case 'URL':
                    str = `["URL",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                case 'URLSearchParams':
                    str = `["URLSearchParams",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                case 'RegExp':
                    const { source, flags } = thing;
                    str = flags ? `["RegExp",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(source)},"${flags}"]` : `["RegExp",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(source)}]`;
                    break;
                case 'Array':
                    str = '[';
                    for(let i = 0; i < thing.length; i += 1){
                        if (i > 0) str += ',';
                        if (i in thing) {
                            keys.push(`[${i}]`);
                            str += flatten(thing[i]);
                            keys.pop();
                        } else {
                            str += __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HOLE"];
                        }
                    }
                    str += ']';
                    break;
                case 'Set':
                    str = '["Set"';
                    for (const value of thing){
                        str += `,${flatten(value)}`;
                    }
                    str += ']';
                    break;
                case 'Map':
                    str = '["Map"';
                    for (const [key, value] of thing){
                        keys.push(`.get(${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_primitive"])(key) ? stringify_primitive(key) : '...'})`);
                        str += `,${flatten(key)},${flatten(value)}`;
                        keys.pop();
                    }
                    str += ']';
                    break;
                case 'Int8Array':
                case 'Uint8Array':
                case 'Uint8ClampedArray':
                case 'Int16Array':
                case 'Uint16Array':
                case 'Int32Array':
                case 'Uint32Array':
                case 'Float32Array':
                case 'Float64Array':
                case 'BigInt64Array':
                case 'BigUint64Array':
                    {
                        /** @type {import("./types.js").TypedArray} */ const typedArray = thing;
                        str = '["' + type + '",' + flatten(typedArray.buffer);
                        const a = thing.byteOffset;
                        const b = a + thing.byteLength;
                        // handle subarrays
                        if (a > 0 || b !== typedArray.buffer.byteLength) {
                            const m = +/(\d+)/.exec(type)[1] / 8;
                            str += `,${a / m},${b / m}`;
                        }
                        str += ']';
                        break;
                    }
                case 'ArrayBuffer':
                    {
                        /** @type {ArrayBuffer} */ const arraybuffer = thing;
                        const base64 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["encode64"])(arraybuffer);
                        str = `["ArrayBuffer","${base64}"]`;
                        break;
                    }
                case 'Temporal.Duration':
                case 'Temporal.Instant':
                case 'Temporal.PlainDate':
                case 'Temporal.PlainTime':
                case 'Temporal.PlainDateTime':
                case 'Temporal.PlainMonthDay':
                case 'Temporal.PlainYearMonth':
                case 'Temporal.ZonedDateTime':
                    str = `["${type}",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                default:
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_plain_object"])(thing)) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify arbitrary non-POJOs`, keys, thing, value);
                    }
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["enumerable_symbols"])(thing).length > 0) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify POJOs with symbolic keys`, keys, thing, value);
                    }
                    if (Object.getPrototypeOf(thing) === null) {
                        str = '["null"';
                        for(const key in thing){
                            keys.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_key"])(key));
                            str += `,${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(key)},${flatten(thing[key])}`;
                            keys.pop();
                        }
                        str += ']';
                    } else {
                        str = '{';
                        let started = false;
                        for(const key in thing){
                            if (started) str += ',';
                            started = true;
                            keys.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_key"])(key));
                            str += `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(key)}:${flatten(thing[key])}`;
                            keys.pop();
                        }
                        str += '}';
                    }
            }
        }
        stringified[index] = str;
        return index;
    }
    const index = flatten(value);
    // special case — value is represented as a negative index
    if (index < 0) return `${index}`;
    return `[${stringified.join(',')}]`;
}
/**
 * @param {any} thing
 * @returns {string}
 */ function stringify_primitive(thing) {
    const type = typeof thing;
    if (type === 'string') return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing);
    if (thing instanceof String) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString());
    if (thing === void 0) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"].toString();
    if (thing === 0 && 1 / thing < 0) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"].toString();
    if (type === 'bigint') return `["BigInt","${thing}"]`;
    return String(thing);
}
}),
"[project]/frontend/node_modules/.pnpm/@jridgewell+sourcemap-codec@1.5.5/node_modules/@jridgewell/sourcemap-codec/dist/sourcemap-codec.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/vlq.ts
__turbopack_context__.s([
    "decode",
    ()=>decode,
    "decodeGeneratedRanges",
    ()=>decodeGeneratedRanges,
    "decodeOriginalScopes",
    ()=>decodeOriginalScopes,
    "encode",
    ()=>encode,
    "encodeGeneratedRanges",
    ()=>encodeGeneratedRanges,
    "encodeOriginalScopes",
    ()=>encodeOriginalScopes
]);
var comma = ",".charCodeAt(0);
var semicolon = ";".charCodeAt(0);
var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var intToChar = new Uint8Array(64);
var charToInt = new Uint8Array(128);
for(let i = 0; i < chars.length; i++){
    const c = chars.charCodeAt(i);
    intToChar[i] = c;
    charToInt[c] = i;
}
function decodeInteger(reader, relative) {
    let value = 0;
    let shift = 0;
    let integer = 0;
    do {
        const c = reader.next();
        integer = charToInt[c];
        value |= (integer & 31) << shift;
        shift += 5;
    }while (integer & 32)
    const shouldNegate = value & 1;
    value >>>= 1;
    if (shouldNegate) {
        value = -2147483648 | -value;
    }
    return relative + value;
}
function encodeInteger(builder, num, relative) {
    let delta = num - relative;
    delta = delta < 0 ? -delta << 1 | 1 : delta << 1;
    do {
        let clamped = delta & 31;
        delta >>>= 5;
        if (delta > 0) clamped |= 32;
        builder.write(intToChar[clamped]);
    }while (delta > 0)
    return num;
}
function hasMoreVlq(reader, max) {
    if (reader.pos >= max) return false;
    return reader.peek() !== comma;
}
// src/strings.ts
var bufLength = 1024 * 16;
var td = typeof TextDecoder !== "undefined" ? /* @__PURE__ */ new TextDecoder() : typeof Buffer !== "undefined" ? {
    decode (buf) {
        const out = Buffer.from(buf.buffer, buf.byteOffset, buf.byteLength);
        return out.toString();
    }
} : {
    decode (buf) {
        let out = "";
        for(let i = 0; i < buf.length; i++){
            out += String.fromCharCode(buf[i]);
        }
        return out;
    }
};
var StringWriter = class {
    constructor(){
        this.pos = 0;
        this.out = "";
        this.buffer = new Uint8Array(bufLength);
    }
    write(v) {
        const { buffer } = this;
        buffer[this.pos++] = v;
        if (this.pos === bufLength) {
            this.out += td.decode(buffer);
            this.pos = 0;
        }
    }
    flush() {
        const { buffer, out, pos } = this;
        return pos > 0 ? out + td.decode(buffer.subarray(0, pos)) : out;
    }
};
var StringReader = class {
    constructor(buffer){
        this.pos = 0;
        this.buffer = buffer;
    }
    next() {
        return this.buffer.charCodeAt(this.pos++);
    }
    peek() {
        return this.buffer.charCodeAt(this.pos);
    }
    indexOf(char) {
        const { buffer, pos } = this;
        const idx = buffer.indexOf(char, pos);
        return idx === -1 ? buffer.length : idx;
    }
};
// src/scopes.ts
var EMPTY = [];
function decodeOriginalScopes(input) {
    const { length } = input;
    const reader = new StringReader(input);
    const scopes = [];
    const stack = [];
    let line = 0;
    for(; reader.pos < length; reader.pos++){
        line = decodeInteger(reader, line);
        const column = decodeInteger(reader, 0);
        if (!hasMoreVlq(reader, length)) {
            const last = stack.pop();
            last[2] = line;
            last[3] = column;
            continue;
        }
        const kind = decodeInteger(reader, 0);
        const fields = decodeInteger(reader, 0);
        const hasName = fields & 1;
        const scope = hasName ? [
            line,
            column,
            0,
            0,
            kind,
            decodeInteger(reader, 0)
        ] : [
            line,
            column,
            0,
            0,
            kind
        ];
        let vars = EMPTY;
        if (hasMoreVlq(reader, length)) {
            vars = [];
            do {
                const varsIndex = decodeInteger(reader, 0);
                vars.push(varsIndex);
            }while (hasMoreVlq(reader, length))
        }
        scope.vars = vars;
        scopes.push(scope);
        stack.push(scope);
    }
    return scopes;
}
function encodeOriginalScopes(scopes) {
    const writer = new StringWriter();
    for(let i = 0; i < scopes.length;){
        i = _encodeOriginalScopes(scopes, i, writer, [
            0
        ]);
    }
    return writer.flush();
}
function _encodeOriginalScopes(scopes, index, writer, state) {
    const scope = scopes[index];
    const { 0: startLine, 1: startColumn, 2: endLine, 3: endColumn, 4: kind, vars } = scope;
    if (index > 0) writer.write(comma);
    state[0] = encodeInteger(writer, startLine, state[0]);
    encodeInteger(writer, startColumn, 0);
    encodeInteger(writer, kind, 0);
    const fields = scope.length === 6 ? 1 : 0;
    encodeInteger(writer, fields, 0);
    if (scope.length === 6) encodeInteger(writer, scope[5], 0);
    for (const v of vars){
        encodeInteger(writer, v, 0);
    }
    for(index++; index < scopes.length;){
        const next = scopes[index];
        const { 0: l, 1: c } = next;
        if (l > endLine || l === endLine && c >= endColumn) {
            break;
        }
        index = _encodeOriginalScopes(scopes, index, writer, state);
    }
    writer.write(comma);
    state[0] = encodeInteger(writer, endLine, state[0]);
    encodeInteger(writer, endColumn, 0);
    return index;
}
function decodeGeneratedRanges(input) {
    const { length } = input;
    const reader = new StringReader(input);
    const ranges = [];
    const stack = [];
    let genLine = 0;
    let definitionSourcesIndex = 0;
    let definitionScopeIndex = 0;
    let callsiteSourcesIndex = 0;
    let callsiteLine = 0;
    let callsiteColumn = 0;
    let bindingLine = 0;
    let bindingColumn = 0;
    do {
        const semi = reader.indexOf(";");
        let genColumn = 0;
        for(; reader.pos < semi; reader.pos++){
            genColumn = decodeInteger(reader, genColumn);
            if (!hasMoreVlq(reader, semi)) {
                const last = stack.pop();
                last[2] = genLine;
                last[3] = genColumn;
                continue;
            }
            const fields = decodeInteger(reader, 0);
            const hasDefinition = fields & 1;
            const hasCallsite = fields & 2;
            const hasScope = fields & 4;
            let callsite = null;
            let bindings = EMPTY;
            let range;
            if (hasDefinition) {
                const defSourcesIndex = decodeInteger(reader, definitionSourcesIndex);
                definitionScopeIndex = decodeInteger(reader, definitionSourcesIndex === defSourcesIndex ? definitionScopeIndex : 0);
                definitionSourcesIndex = defSourcesIndex;
                range = [
                    genLine,
                    genColumn,
                    0,
                    0,
                    defSourcesIndex,
                    definitionScopeIndex
                ];
            } else {
                range = [
                    genLine,
                    genColumn,
                    0,
                    0
                ];
            }
            range.isScope = !!hasScope;
            if (hasCallsite) {
                const prevCsi = callsiteSourcesIndex;
                const prevLine = callsiteLine;
                callsiteSourcesIndex = decodeInteger(reader, callsiteSourcesIndex);
                const sameSource = prevCsi === callsiteSourcesIndex;
                callsiteLine = decodeInteger(reader, sameSource ? callsiteLine : 0);
                callsiteColumn = decodeInteger(reader, sameSource && prevLine === callsiteLine ? callsiteColumn : 0);
                callsite = [
                    callsiteSourcesIndex,
                    callsiteLine,
                    callsiteColumn
                ];
            }
            range.callsite = callsite;
            if (hasMoreVlq(reader, semi)) {
                bindings = [];
                do {
                    bindingLine = genLine;
                    bindingColumn = genColumn;
                    const expressionsCount = decodeInteger(reader, 0);
                    let expressionRanges;
                    if (expressionsCount < -1) {
                        expressionRanges = [
                            [
                                decodeInteger(reader, 0)
                            ]
                        ];
                        for(let i = -1; i > expressionsCount; i--){
                            const prevBl = bindingLine;
                            bindingLine = decodeInteger(reader, bindingLine);
                            bindingColumn = decodeInteger(reader, bindingLine === prevBl ? bindingColumn : 0);
                            const expression = decodeInteger(reader, 0);
                            expressionRanges.push([
                                expression,
                                bindingLine,
                                bindingColumn
                            ]);
                        }
                    } else {
                        expressionRanges = [
                            [
                                expressionsCount
                            ]
                        ];
                    }
                    bindings.push(expressionRanges);
                }while (hasMoreVlq(reader, semi))
            }
            range.bindings = bindings;
            ranges.push(range);
            stack.push(range);
        }
        genLine++;
        reader.pos = semi + 1;
    }while (reader.pos < length)
    return ranges;
}
function encodeGeneratedRanges(ranges) {
    if (ranges.length === 0) return "";
    const writer = new StringWriter();
    for(let i = 0; i < ranges.length;){
        i = _encodeGeneratedRanges(ranges, i, writer, [
            0,
            0,
            0,
            0,
            0,
            0,
            0
        ]);
    }
    return writer.flush();
}
function _encodeGeneratedRanges(ranges, index, writer, state) {
    const range = ranges[index];
    const { 0: startLine, 1: startColumn, 2: endLine, 3: endColumn, isScope, callsite, bindings } = range;
    if (state[0] < startLine) {
        catchupLine(writer, state[0], startLine);
        state[0] = startLine;
        state[1] = 0;
    } else if (index > 0) {
        writer.write(comma);
    }
    state[1] = encodeInteger(writer, range[1], state[1]);
    const fields = (range.length === 6 ? 1 : 0) | (callsite ? 2 : 0) | (isScope ? 4 : 0);
    encodeInteger(writer, fields, 0);
    if (range.length === 6) {
        const { 4: sourcesIndex, 5: scopesIndex } = range;
        if (sourcesIndex !== state[2]) {
            state[3] = 0;
        }
        state[2] = encodeInteger(writer, sourcesIndex, state[2]);
        state[3] = encodeInteger(writer, scopesIndex, state[3]);
    }
    if (callsite) {
        const { 0: sourcesIndex, 1: callLine, 2: callColumn } = range.callsite;
        if (sourcesIndex !== state[4]) {
            state[5] = 0;
            state[6] = 0;
        } else if (callLine !== state[5]) {
            state[6] = 0;
        }
        state[4] = encodeInteger(writer, sourcesIndex, state[4]);
        state[5] = encodeInteger(writer, callLine, state[5]);
        state[6] = encodeInteger(writer, callColumn, state[6]);
    }
    if (bindings) {
        for (const binding of bindings){
            if (binding.length > 1) encodeInteger(writer, -binding.length, 0);
            const expression = binding[0][0];
            encodeInteger(writer, expression, 0);
            let bindingStartLine = startLine;
            let bindingStartColumn = startColumn;
            for(let i = 1; i < binding.length; i++){
                const expRange = binding[i];
                bindingStartLine = encodeInteger(writer, expRange[1], bindingStartLine);
                bindingStartColumn = encodeInteger(writer, expRange[2], bindingStartColumn);
                encodeInteger(writer, expRange[0], 0);
            }
        }
    }
    for(index++; index < ranges.length;){
        const next = ranges[index];
        const { 0: l, 1: c } = next;
        if (l > endLine || l === endLine && c >= endColumn) {
            break;
        }
        index = _encodeGeneratedRanges(ranges, index, writer, state);
    }
    if (state[0] < endLine) {
        catchupLine(writer, state[0], endLine);
        state[0] = endLine;
        state[1] = 0;
    } else {
        writer.write(comma);
    }
    state[1] = encodeInteger(writer, endColumn, state[1]);
    return index;
}
function catchupLine(writer, lastLine, line) {
    do {
        writer.write(semicolon);
    }while (++lastLine < line)
}
// src/sourcemap-codec.ts
function decode(mappings) {
    const { length } = mappings;
    const reader = new StringReader(mappings);
    const decoded = [];
    let genColumn = 0;
    let sourcesIndex = 0;
    let sourceLine = 0;
    let sourceColumn = 0;
    let namesIndex = 0;
    do {
        const semi = reader.indexOf(";");
        const line = [];
        let sorted = true;
        let lastCol = 0;
        genColumn = 0;
        while(reader.pos < semi){
            let seg;
            genColumn = decodeInteger(reader, genColumn);
            if (genColumn < lastCol) sorted = false;
            lastCol = genColumn;
            if (hasMoreVlq(reader, semi)) {
                sourcesIndex = decodeInteger(reader, sourcesIndex);
                sourceLine = decodeInteger(reader, sourceLine);
                sourceColumn = decodeInteger(reader, sourceColumn);
                if (hasMoreVlq(reader, semi)) {
                    namesIndex = decodeInteger(reader, namesIndex);
                    seg = [
                        genColumn,
                        sourcesIndex,
                        sourceLine,
                        sourceColumn,
                        namesIndex
                    ];
                } else {
                    seg = [
                        genColumn,
                        sourcesIndex,
                        sourceLine,
                        sourceColumn
                    ];
                }
            } else {
                seg = [
                    genColumn
                ];
            }
            line.push(seg);
            reader.pos++;
        }
        if (!sorted) sort(line);
        decoded.push(line);
        reader.pos = semi + 1;
    }while (reader.pos <= length)
    return decoded;
}
function sort(line) {
    line.sort(sortComparator);
}
function sortComparator(a, b) {
    return a[0] - b[0];
}
function encode(decoded) {
    const writer = new StringWriter();
    let sourcesIndex = 0;
    let sourceLine = 0;
    let sourceColumn = 0;
    let namesIndex = 0;
    for(let i = 0; i < decoded.length; i++){
        const line = decoded[i];
        if (i > 0) writer.write(semicolon);
        if (line.length === 0) continue;
        let genColumn = 0;
        for(let j = 0; j < line.length; j++){
            const segment = line[j];
            if (j > 0) writer.write(comma);
            genColumn = encodeInteger(writer, segment[0], genColumn);
            if (segment.length === 1) continue;
            sourcesIndex = encodeInteger(writer, segment[1], sourcesIndex);
            sourceLine = encodeInteger(writer, segment[2], sourceLine);
            sourceColumn = encodeInteger(writer, segment[3], sourceColumn);
            if (segment.length === 4) continue;
            namesIndex = encodeInteger(writer, segment[4], namesIndex);
        }
    }
    return writer.flush();
}
;
 //# sourceMappingURL=sourcemap-codec.mjs.map
}),
"[project]/frontend/node_modules/.pnpm/@jridgewell+resolve-uri@3.1.2/node_modules/@jridgewell/resolve-uri/dist/resolve-uri.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// Matches the scheme of a URL, eg "http://"
__turbopack_context__.s([
    "default",
    ()=>resolve
]);
const schemeRegex = /^[\w+.-]+:\/\//;
/**
 * Matches the parts of a URL:
 * 1. Scheme, including ":", guaranteed.
 * 2. User/password, including "@", optional.
 * 3. Host, guaranteed.
 * 4. Port, including ":", optional.
 * 5. Path, including "/", optional.
 * 6. Query, including "?", optional.
 * 7. Hash, including "#", optional.
 */ const urlRegex = /^([\w+.-]+:)\/\/([^@/#?]*@)?([^:/#?]*)(:\d+)?(\/[^#?]*)?(\?[^#]*)?(#.*)?/;
/**
 * File URLs are weird. They dont' need the regular `//` in the scheme, they may or may not start
 * with a leading `/`, they can have a domain (but only if they don't start with a Windows drive).
 *
 * 1. Host, optional.
 * 2. Path, which may include "/", guaranteed.
 * 3. Query, including "?", optional.
 * 4. Hash, including "#", optional.
 */ const fileRegex = /^file:(?:\/\/((?![a-z]:)[^/#?]*)?)?(\/?[^#?]*)(\?[^#]*)?(#.*)?/i;
function isAbsoluteUrl(input) {
    return schemeRegex.test(input);
}
function isSchemeRelativeUrl(input) {
    return input.startsWith('//');
}
function isAbsolutePath(input) {
    return input.startsWith('/');
}
function isFileUrl(input) {
    return input.startsWith('file:');
}
function isRelative(input) {
    return /^[.?#]/.test(input);
}
function parseAbsoluteUrl(input) {
    const match = urlRegex.exec(input);
    return makeUrl(match[1], match[2] || '', match[3], match[4] || '', match[5] || '/', match[6] || '', match[7] || '');
}
function parseFileUrl(input) {
    const match = fileRegex.exec(input);
    const path = match[2];
    return makeUrl('file:', '', match[1] || '', '', isAbsolutePath(path) ? path : '/' + path, match[3] || '', match[4] || '');
}
function makeUrl(scheme, user, host, port, path, query, hash) {
    return {
        scheme,
        user,
        host,
        port,
        path,
        query,
        hash,
        type: 7 /* Absolute */ 
    };
}
function parseUrl(input) {
    if (isSchemeRelativeUrl(input)) {
        const url = parseAbsoluteUrl('http:' + input);
        url.scheme = '';
        url.type = 6 /* SchemeRelative */ ;
        return url;
    }
    if (isAbsolutePath(input)) {
        const url = parseAbsoluteUrl('http://foo.com' + input);
        url.scheme = '';
        url.host = '';
        url.type = 5 /* AbsolutePath */ ;
        return url;
    }
    if (isFileUrl(input)) return parseFileUrl(input);
    if (isAbsoluteUrl(input)) return parseAbsoluteUrl(input);
    const url = parseAbsoluteUrl('http://foo.com/' + input);
    url.scheme = '';
    url.host = '';
    url.type = input ? input.startsWith('?') ? 3 /* Query */  : input.startsWith('#') ? 2 /* Hash */  : 4 /* RelativePath */  : 1 /* Empty */ ;
    return url;
}
function stripPathFilename(path) {
    // If a path ends with a parent directory "..", then it's a relative path with excess parent
    // paths. It's not a file, so we can't strip it.
    if (path.endsWith('/..')) return path;
    const index = path.lastIndexOf('/');
    return path.slice(0, index + 1);
}
function mergePaths(url, base) {
    normalizePath(base, base.type);
    // If the path is just a "/", then it was an empty path to begin with (remember, we're a relative
    // path).
    if (url.path === '/') {
        url.path = base.path;
    } else {
        // Resolution happens relative to the base path's directory, not the file.
        url.path = stripPathFilename(base.path) + url.path;
    }
}
/**
 * The path can have empty directories "//", unneeded parents "foo/..", or current directory
 * "foo/.". We need to normalize to a standard representation.
 */ function normalizePath(url, type) {
    const rel = type <= 4 /* RelativePath */ ;
    const pieces = url.path.split('/');
    // We need to preserve the first piece always, so that we output a leading slash. The item at
    // pieces[0] is an empty string.
    let pointer = 1;
    // Positive is the number of real directories we've output, used for popping a parent directory.
    // Eg, "foo/bar/.." will have a positive 2, and we can decrement to be left with just "foo".
    let positive = 0;
    // We need to keep a trailing slash if we encounter an empty directory (eg, splitting "foo/" will
    // generate `["foo", ""]` pieces). And, if we pop a parent directory. But once we encounter a
    // real directory, we won't need to append, unless the other conditions happen again.
    let addTrailingSlash = false;
    for(let i = 1; i < pieces.length; i++){
        const piece = pieces[i];
        // An empty directory, could be a trailing slash, or just a double "//" in the path.
        if (!piece) {
            addTrailingSlash = true;
            continue;
        }
        // If we encounter a real directory, then we don't need to append anymore.
        addTrailingSlash = false;
        // A current directory, which we can always drop.
        if (piece === '.') continue;
        // A parent directory, we need to see if there are any real directories we can pop. Else, we
        // have an excess of parents, and we'll need to keep the "..".
        if (piece === '..') {
            if (positive) {
                addTrailingSlash = true;
                positive--;
                pointer--;
            } else if (rel) {
                // If we're in a relativePath, then we need to keep the excess parents. Else, in an absolute
                // URL, protocol relative URL, or an absolute path, we don't need to keep excess.
                pieces[pointer++] = piece;
            }
            continue;
        }
        // We've encountered a real directory. Move it to the next insertion pointer, which accounts for
        // any popped or dropped directories.
        pieces[pointer++] = piece;
        positive++;
    }
    let path = '';
    for(let i = 1; i < pointer; i++){
        path += '/' + pieces[i];
    }
    if (!path || addTrailingSlash && !path.endsWith('/..')) {
        path += '/';
    }
    url.path = path;
}
/**
 * Attempts to resolve `input` URL/path relative to `base`.
 */ function resolve(input, base) {
    if (!input && !base) return '';
    const url = parseUrl(input);
    let inputType = url.type;
    if (base && inputType !== 7 /* Absolute */ ) {
        const baseUrl = parseUrl(base);
        const baseType = baseUrl.type;
        switch(inputType){
            case 1 /* Empty */ :
                url.hash = baseUrl.hash;
            // fall through
            case 2 /* Hash */ :
                url.query = baseUrl.query;
            // fall through
            case 3 /* Query */ :
            case 4 /* RelativePath */ :
                mergePaths(url, baseUrl);
            // fall through
            case 5 /* AbsolutePath */ :
                // The host, user, and port are joined, you can't copy one without the others.
                url.user = baseUrl.user;
                url.host = baseUrl.host;
                url.port = baseUrl.port;
            // fall through
            case 6 /* SchemeRelative */ :
                // The input doesn't have a schema at least, so we need to copy at least that over.
                url.scheme = baseUrl.scheme;
        }
        if (baseType > inputType) inputType = baseType;
    }
    normalizePath(url, inputType);
    const queryHash = url.query + url.hash;
    switch(inputType){
        // This is impossible, because of the empty checks at the start of the function.
        // case UrlType.Empty:
        case 2 /* Hash */ :
        case 3 /* Query */ :
            return queryHash;
        case 4 /* RelativePath */ :
            {
                // The first char is always a "/", and we need it to be relative.
                const path = url.path.slice(1);
                if (!path) return queryHash || '.';
                if (isRelative(base || input) && !isRelative(path)) {
                    // If base started with a leading ".", or there is no base and input started with a ".",
                    // then we need to ensure that the relative path starts with a ".". We don't know if
                    // relative starts with a "..", though, so check before prepending.
                    return './' + path + queryHash;
                }
                return path + queryHash;
            }
        case 5 /* AbsolutePath */ :
            return url.path + queryHash;
        default:
            return url.scheme + '//' + url.user + url.host + url.port + url.path + queryHash;
    }
}
;
 //# sourceMappingURL=resolve-uri.mjs.map
}),
"[project]/frontend/node_modules/.pnpm/@jridgewell+trace-mapping@0.3.31/node_modules/@jridgewell/trace-mapping/dist/trace-mapping.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/trace-mapping.ts
__turbopack_context__.s([
    "AnyMap",
    ()=>FlattenMap,
    "FlattenMap",
    ()=>FlattenMap,
    "GREATEST_LOWER_BOUND",
    ()=>GREATEST_LOWER_BOUND,
    "LEAST_UPPER_BOUND",
    ()=>LEAST_UPPER_BOUND,
    "TraceMap",
    ()=>TraceMap,
    "allGeneratedPositionsFor",
    ()=>allGeneratedPositionsFor,
    "decodedMap",
    ()=>decodedMap,
    "decodedMappings",
    ()=>decodedMappings,
    "eachMapping",
    ()=>eachMapping,
    "encodedMap",
    ()=>encodedMap,
    "encodedMappings",
    ()=>encodedMappings,
    "generatedPositionFor",
    ()=>generatedPositionFor,
    "isIgnored",
    ()=>isIgnored,
    "originalPositionFor",
    ()=>originalPositionFor,
    "presortedDecodedMap",
    ()=>presortedDecodedMap,
    "sourceContentFor",
    ()=>sourceContentFor,
    "traceSegment",
    ()=>traceSegment
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$jridgewell$2b$sourcemap$2d$codec$40$1$2e$5$2e$5$2f$node_modules$2f40$jridgewell$2f$sourcemap$2d$codec$2f$dist$2f$sourcemap$2d$codec$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@jridgewell+sourcemap-codec@1.5.5/node_modules/@jridgewell/sourcemap-codec/dist/sourcemap-codec.mjs [app-route] (ecmascript)");
// src/resolve.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$jridgewell$2b$resolve$2d$uri$40$3$2e$1$2e$2$2f$node_modules$2f40$jridgewell$2f$resolve$2d$uri$2f$dist$2f$resolve$2d$uri$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@jridgewell+resolve-uri@3.1.2/node_modules/@jridgewell/resolve-uri/dist/resolve-uri.mjs [app-route] (ecmascript)");
;
;
// src/strip-filename.ts
function stripFilename(path) {
    if (!path) return "";
    const index = path.lastIndexOf("/");
    return path.slice(0, index + 1);
}
// src/resolve.ts
function resolver(mapUrl, sourceRoot) {
    const from = stripFilename(mapUrl);
    const prefix = sourceRoot ? sourceRoot + "/" : "";
    return (source)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$jridgewell$2b$resolve$2d$uri$40$3$2e$1$2e$2$2f$node_modules$2f40$jridgewell$2f$resolve$2d$uri$2f$dist$2f$resolve$2d$uri$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(prefix + (source || ""), from);
}
// src/sourcemap-segment.ts
var COLUMN = 0;
var SOURCES_INDEX = 1;
var SOURCE_LINE = 2;
var SOURCE_COLUMN = 3;
var NAMES_INDEX = 4;
var REV_GENERATED_LINE = 1;
var REV_GENERATED_COLUMN = 2;
// src/sort.ts
function maybeSort(mappings, owned) {
    const unsortedIndex = nextUnsortedSegmentLine(mappings, 0);
    if (unsortedIndex === mappings.length) return mappings;
    if (!owned) mappings = mappings.slice();
    for(let i = unsortedIndex; i < mappings.length; i = nextUnsortedSegmentLine(mappings, i + 1)){
        mappings[i] = sortSegments(mappings[i], owned);
    }
    return mappings;
}
function nextUnsortedSegmentLine(mappings, start) {
    for(let i = start; i < mappings.length; i++){
        if (!isSorted(mappings[i])) return i;
    }
    return mappings.length;
}
function isSorted(line) {
    for(let j = 1; j < line.length; j++){
        if (line[j][COLUMN] < line[j - 1][COLUMN]) {
            return false;
        }
    }
    return true;
}
function sortSegments(line, owned) {
    if (!owned) line = line.slice();
    return line.sort(sortComparator);
}
function sortComparator(a, b) {
    return a[COLUMN] - b[COLUMN];
}
// src/by-source.ts
function buildBySources(decoded, memos) {
    const sources = memos.map(()=>[]);
    for(let i = 0; i < decoded.length; i++){
        const line = decoded[i];
        for(let j = 0; j < line.length; j++){
            const seg = line[j];
            if (seg.length === 1) continue;
            const sourceIndex2 = seg[SOURCES_INDEX];
            const sourceLine = seg[SOURCE_LINE];
            const sourceColumn = seg[SOURCE_COLUMN];
            const source = sources[sourceIndex2];
            const segs = source[sourceLine] || (source[sourceLine] = []);
            segs.push([
                sourceColumn,
                i,
                seg[COLUMN]
            ]);
        }
    }
    for(let i = 0; i < sources.length; i++){
        const source = sources[i];
        for(let j = 0; j < source.length; j++){
            const line = source[j];
            if (line) line.sort(sortComparator);
        }
    }
    return sources;
}
// src/binary-search.ts
var found = false;
function binarySearch(haystack, needle, low, high) {
    while(low <= high){
        const mid = low + (high - low >> 1);
        const cmp = haystack[mid][COLUMN] - needle;
        if (cmp === 0) {
            found = true;
            return mid;
        }
        if (cmp < 0) {
            low = mid + 1;
        } else {
            high = mid - 1;
        }
    }
    found = false;
    return low - 1;
}
function upperBound(haystack, needle, index) {
    for(let i = index + 1; i < haystack.length; index = i++){
        if (haystack[i][COLUMN] !== needle) break;
    }
    return index;
}
function lowerBound(haystack, needle, index) {
    for(let i = index - 1; i >= 0; index = i--){
        if (haystack[i][COLUMN] !== needle) break;
    }
    return index;
}
function memoizedState() {
    return {
        lastKey: -1,
        lastNeedle: -1,
        lastIndex: -1
    };
}
function memoizedBinarySearch(haystack, needle, state, key) {
    const { lastKey, lastNeedle, lastIndex } = state;
    let low = 0;
    let high = haystack.length - 1;
    if (key === lastKey) {
        if (needle === lastNeedle) {
            found = lastIndex !== -1 && haystack[lastIndex][COLUMN] === needle;
            return lastIndex;
        }
        if (needle >= lastNeedle) {
            low = lastIndex === -1 ? 0 : lastIndex;
        } else {
            high = lastIndex;
        }
    }
    state.lastKey = key;
    state.lastNeedle = needle;
    return state.lastIndex = binarySearch(haystack, needle, low, high);
}
// src/types.ts
function parse(map) {
    return typeof map === "string" ? JSON.parse(map) : map;
}
// src/flatten-map.ts
var FlattenMap = function(map, mapUrl) {
    const parsed = parse(map);
    if (!("sections" in parsed)) {
        return new TraceMap(parsed, mapUrl);
    }
    const mappings = [];
    const sources = [];
    const sourcesContent = [];
    const names = [];
    const ignoreList = [];
    recurse(parsed, mapUrl, mappings, sources, sourcesContent, names, ignoreList, 0, 0, Infinity, Infinity);
    const joined = {
        version: 3,
        file: parsed.file,
        names,
        sources,
        sourcesContent,
        mappings,
        ignoreList
    };
    return presortedDecodedMap(joined);
};
function recurse(input, mapUrl, mappings, sources, sourcesContent, names, ignoreList, lineOffset, columnOffset, stopLine, stopColumn) {
    const { sections } = input;
    for(let i = 0; i < sections.length; i++){
        const { map, offset } = sections[i];
        let sl = stopLine;
        let sc = stopColumn;
        if (i + 1 < sections.length) {
            const nextOffset = sections[i + 1].offset;
            sl = Math.min(stopLine, lineOffset + nextOffset.line);
            if (sl === stopLine) {
                sc = Math.min(stopColumn, columnOffset + nextOffset.column);
            } else if (sl < stopLine) {
                sc = columnOffset + nextOffset.column;
            }
        }
        addSection(map, mapUrl, mappings, sources, sourcesContent, names, ignoreList, lineOffset + offset.line, columnOffset + offset.column, sl, sc);
    }
}
function addSection(input, mapUrl, mappings, sources, sourcesContent, names, ignoreList, lineOffset, columnOffset, stopLine, stopColumn) {
    const parsed = parse(input);
    if ("sections" in parsed) return recurse(...arguments);
    const map = new TraceMap(parsed, mapUrl);
    const sourcesOffset = sources.length;
    const namesOffset = names.length;
    const decoded = decodedMappings(map);
    const { resolvedSources, sourcesContent: contents, ignoreList: ignores } = map;
    append(sources, resolvedSources);
    append(names, map.names);
    if (contents) append(sourcesContent, contents);
    else for(let i = 0; i < resolvedSources.length; i++)sourcesContent.push(null);
    if (ignores) for(let i = 0; i < ignores.length; i++)ignoreList.push(ignores[i] + sourcesOffset);
    for(let i = 0; i < decoded.length; i++){
        const lineI = lineOffset + i;
        if (lineI > stopLine) return;
        const out = getLine(mappings, lineI);
        const cOffset = i === 0 ? columnOffset : 0;
        const line = decoded[i];
        for(let j = 0; j < line.length; j++){
            const seg = line[j];
            const column = cOffset + seg[COLUMN];
            if (lineI === stopLine && column >= stopColumn) return;
            if (seg.length === 1) {
                out.push([
                    column
                ]);
                continue;
            }
            const sourcesIndex = sourcesOffset + seg[SOURCES_INDEX];
            const sourceLine = seg[SOURCE_LINE];
            const sourceColumn = seg[SOURCE_COLUMN];
            out.push(seg.length === 4 ? [
                column,
                sourcesIndex,
                sourceLine,
                sourceColumn
            ] : [
                column,
                sourcesIndex,
                sourceLine,
                sourceColumn,
                namesOffset + seg[NAMES_INDEX]
            ]);
        }
    }
}
function append(arr, other) {
    for(let i = 0; i < other.length; i++)arr.push(other[i]);
}
function getLine(arr, index) {
    for(let i = arr.length; i <= index; i++)arr[i] = [];
    return arr[index];
}
// src/trace-mapping.ts
var LINE_GTR_ZERO = "`line` must be greater than 0 (lines start at line 1)";
var COL_GTR_EQ_ZERO = "`column` must be greater than or equal to 0 (columns start at column 0)";
var LEAST_UPPER_BOUND = -1;
var GREATEST_LOWER_BOUND = 1;
var TraceMap = class {
    constructor(map, mapUrl){
        const isString = typeof map === "string";
        if (!isString && map._decodedMemo) return map;
        const parsed = parse(map);
        const { version, file, names, sourceRoot, sources, sourcesContent } = parsed;
        this.version = version;
        this.file = file;
        this.names = names || [];
        this.sourceRoot = sourceRoot;
        this.sources = sources;
        this.sourcesContent = sourcesContent;
        this.ignoreList = parsed.ignoreList || parsed.x_google_ignoreList || void 0;
        const resolve = resolver(mapUrl, sourceRoot);
        this.resolvedSources = sources.map(resolve);
        const { mappings } = parsed;
        if (typeof mappings === "string") {
            this._encoded = mappings;
            this._decoded = void 0;
        } else if (Array.isArray(mappings)) {
            this._encoded = void 0;
            this._decoded = maybeSort(mappings, isString);
        } else if (parsed.sections) {
            throw new Error(`TraceMap passed sectioned source map, please use FlattenMap export instead`);
        } else {
            throw new Error(`invalid source map: ${JSON.stringify(parsed)}`);
        }
        this._decodedMemo = memoizedState();
        this._bySources = void 0;
        this._bySourceMemos = void 0;
    }
};
function cast(map) {
    return map;
}
function encodedMappings(map) {
    var _a, _b;
    return (_b = (_a = cast(map))._encoded) != null ? _b : _a._encoded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$jridgewell$2b$sourcemap$2d$codec$40$1$2e$5$2e$5$2f$node_modules$2f40$jridgewell$2f$sourcemap$2d$codec$2f$dist$2f$sourcemap$2d$codec$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["encode"])(cast(map)._decoded);
}
function decodedMappings(map) {
    var _a;
    return (_a = cast(map))._decoded || (_a._decoded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$jridgewell$2b$sourcemap$2d$codec$40$1$2e$5$2e$5$2f$node_modules$2f40$jridgewell$2f$sourcemap$2d$codec$2f$dist$2f$sourcemap$2d$codec$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decode"])(cast(map)._encoded));
}
function traceSegment(map, line, column) {
    const decoded = decodedMappings(map);
    if (line >= decoded.length) return null;
    const segments = decoded[line];
    const index = traceSegmentInternal(segments, cast(map)._decodedMemo, line, column, GREATEST_LOWER_BOUND);
    return index === -1 ? null : segments[index];
}
function originalPositionFor(map, needle) {
    let { line, column, bias } = needle;
    line--;
    if (line < 0) throw new Error(LINE_GTR_ZERO);
    if (column < 0) throw new Error(COL_GTR_EQ_ZERO);
    const decoded = decodedMappings(map);
    if (line >= decoded.length) return OMapping(null, null, null, null);
    const segments = decoded[line];
    const index = traceSegmentInternal(segments, cast(map)._decodedMemo, line, column, bias || GREATEST_LOWER_BOUND);
    if (index === -1) return OMapping(null, null, null, null);
    const segment = segments[index];
    if (segment.length === 1) return OMapping(null, null, null, null);
    const { names, resolvedSources } = map;
    return OMapping(resolvedSources[segment[SOURCES_INDEX]], segment[SOURCE_LINE] + 1, segment[SOURCE_COLUMN], segment.length === 5 ? names[segment[NAMES_INDEX]] : null);
}
function generatedPositionFor(map, needle) {
    const { source, line, column, bias } = needle;
    return generatedPosition(map, source, line, column, bias || GREATEST_LOWER_BOUND, false);
}
function allGeneratedPositionsFor(map, needle) {
    const { source, line, column, bias } = needle;
    return generatedPosition(map, source, line, column, bias || LEAST_UPPER_BOUND, true);
}
function eachMapping(map, cb) {
    const decoded = decodedMappings(map);
    const { names, resolvedSources } = map;
    for(let i = 0; i < decoded.length; i++){
        const line = decoded[i];
        for(let j = 0; j < line.length; j++){
            const seg = line[j];
            const generatedLine = i + 1;
            const generatedColumn = seg[0];
            let source = null;
            let originalLine = null;
            let originalColumn = null;
            let name = null;
            if (seg.length !== 1) {
                source = resolvedSources[seg[1]];
                originalLine = seg[2] + 1;
                originalColumn = seg[3];
            }
            if (seg.length === 5) name = names[seg[4]];
            cb({
                generatedLine,
                generatedColumn,
                source,
                originalLine,
                originalColumn,
                name
            });
        }
    }
}
function sourceIndex(map, source) {
    const { sources, resolvedSources } = map;
    let index = sources.indexOf(source);
    if (index === -1) index = resolvedSources.indexOf(source);
    return index;
}
function sourceContentFor(map, source) {
    const { sourcesContent } = map;
    if (sourcesContent == null) return null;
    const index = sourceIndex(map, source);
    return index === -1 ? null : sourcesContent[index];
}
function isIgnored(map, source) {
    const { ignoreList } = map;
    if (ignoreList == null) return false;
    const index = sourceIndex(map, source);
    return index === -1 ? false : ignoreList.includes(index);
}
function presortedDecodedMap(map, mapUrl) {
    const tracer = new TraceMap(clone(map, []), mapUrl);
    cast(tracer)._decoded = map.mappings;
    return tracer;
}
function decodedMap(map) {
    return clone(map, decodedMappings(map));
}
function encodedMap(map) {
    return clone(map, encodedMappings(map));
}
function clone(map, mappings) {
    return {
        version: map.version,
        file: map.file,
        names: map.names,
        sourceRoot: map.sourceRoot,
        sources: map.sources,
        sourcesContent: map.sourcesContent,
        mappings,
        ignoreList: map.ignoreList || map.x_google_ignoreList
    };
}
function OMapping(source, line, column, name) {
    return {
        source,
        line,
        column,
        name
    };
}
function GMapping(line, column) {
    return {
        line,
        column
    };
}
function traceSegmentInternal(segments, memo, line, column, bias) {
    let index = memoizedBinarySearch(segments, column, memo, line);
    if (found) {
        index = (bias === LEAST_UPPER_BOUND ? upperBound : lowerBound)(segments, column, index);
    } else if (bias === LEAST_UPPER_BOUND) index++;
    if (index === -1 || index === segments.length) return -1;
    return index;
}
function sliceGeneratedPositions(segments, memo, line, column, bias) {
    let min = traceSegmentInternal(segments, memo, line, column, GREATEST_LOWER_BOUND);
    if (!found && bias === LEAST_UPPER_BOUND) min++;
    if (min === -1 || min === segments.length) return [];
    const matchedColumn = found ? column : segments[min][COLUMN];
    if (!found) min = lowerBound(segments, matchedColumn, min);
    const max = upperBound(segments, matchedColumn, min);
    const result = [];
    for(; min <= max; min++){
        const segment = segments[min];
        result.push(GMapping(segment[REV_GENERATED_LINE] + 1, segment[REV_GENERATED_COLUMN]));
    }
    return result;
}
function generatedPosition(map, source, line, column, bias, all) {
    var _a, _b;
    line--;
    if (line < 0) throw new Error(LINE_GTR_ZERO);
    if (column < 0) throw new Error(COL_GTR_EQ_ZERO);
    const { sources, resolvedSources } = map;
    let sourceIndex2 = sources.indexOf(source);
    if (sourceIndex2 === -1) sourceIndex2 = resolvedSources.indexOf(source);
    if (sourceIndex2 === -1) return all ? [] : GMapping(null, null);
    const bySourceMemos = (_a = cast(map))._bySourceMemos || (_a._bySourceMemos = sources.map(memoizedState));
    const generated = (_b = cast(map))._bySources || (_b._bySources = buildBySources(decodedMappings(map), bySourceMemos));
    const segments = generated[sourceIndex2][line];
    if (segments == null) return all ? [] : GMapping(null, null);
    const memo = bySourceMemos[sourceIndex2];
    if (all) return sliceGeneratedPositions(segments, memo, line, column, bias);
    const index = traceSegmentInternal(segments, memo, line, column, bias);
    if (index === -1) return GMapping(null, null);
    const segment = segments[index];
    return GMapping(segment[REV_GENERATED_LINE] + 1, segment[REV_GENERATED_COLUMN]);
}
;
 //# sourceMappingURL=trace-mapping.mjs.map
}),
"[project]/frontend/node_modules/.pnpm/nanoid@5.1.6/node_modules/nanoid/url-alphabet/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "urlAlphabet",
    ()=>urlAlphabet
]);
const urlAlphabet = 'useandom-26T198340PX75pxJACKVERYMINDBUSHWOLF_GQZbfghjklqvwyzrict';
}),
"[project]/frontend/node_modules/.pnpm/nanoid@5.1.6/node_modules/nanoid/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "customAlphabet",
    ()=>customAlphabet,
    "customRandom",
    ()=>customRandom,
    "nanoid",
    ()=>nanoid,
    "random",
    ()=>random
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:crypto [external] (node:crypto, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$nanoid$40$5$2e$1$2e$6$2f$node_modules$2f$nanoid$2f$url$2d$alphabet$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/nanoid@5.1.6/node_modules/nanoid/url-alphabet/index.js [app-route] (ecmascript)");
;
;
;
const POOL_SIZE_MULTIPLIER = 128;
let pool, poolOffset;
function fillPool(bytes) {
    if (!pool || pool.length < bytes) {
        pool = Buffer.allocUnsafe(bytes * POOL_SIZE_MULTIPLIER);
        __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["webcrypto"].getRandomValues(pool);
        poolOffset = 0;
    } else if (poolOffset + bytes > pool.length) {
        __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["webcrypto"].getRandomValues(pool);
        poolOffset = 0;
    }
    poolOffset += bytes;
}
function random(bytes) {
    fillPool(bytes |= 0);
    return pool.subarray(poolOffset - bytes, poolOffset);
}
function customRandom(alphabet, defaultSize, getRandom) {
    let mask = (2 << 31 - Math.clz32(alphabet.length - 1 | 1)) - 1;
    let step = Math.ceil(1.6 * mask * defaultSize / alphabet.length);
    return (size = defaultSize)=>{
        if (!size) return '';
        let id = '';
        while(true){
            let bytes = getRandom(step);
            let i = step;
            while(i--){
                id += alphabet[bytes[i] & mask] || '';
                if (id.length >= size) return id;
            }
        }
    };
}
function customAlphabet(alphabet, size = 21) {
    return customRandom(alphabet, size, random);
}
function nanoid(size = 21) {
    fillPool(size |= 0);
    let id = '';
    for(let i = poolOffset - size; i < poolOffset; i++){
        id += __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$nanoid$40$5$2e$1$2e$6$2f$node_modules$2f$nanoid$2f$url$2d$alphabet$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["urlAlphabet"][pool[i] & 63];
    }
    return id;
}
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/alea.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A port of an algorithm by Johannes Baagøe <baagoe@baagoe.com>, 2010
// http://baagoe.com/en/RandomMusings/javascript/
// https://github.com/nquinlan/better-random-numbers-for-javascript-mirror
// Original work is under MIT license -
// Copyright (C) 2010 by Johannes Baagøe <baagoe@baagoe.org>
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
(function(global, module1, define1) {
    function Alea(seed) {
        var me = this, mash = Mash();
        me.next = function() {
            var t = 2091639 * me.s0 + me.c * 2.3283064365386963e-10; // 2^-32
            me.s0 = me.s1;
            me.s1 = me.s2;
            return me.s2 = t - (me.c = t | 0);
        };
        // Apply the seeding algorithm from Baagoe.
        me.c = 1;
        me.s0 = mash(' ');
        me.s1 = mash(' ');
        me.s2 = mash(' ');
        me.s0 -= mash(seed);
        if (me.s0 < 0) {
            me.s0 += 1;
        }
        me.s1 -= mash(seed);
        if (me.s1 < 0) {
            me.s1 += 1;
        }
        me.s2 -= mash(seed);
        if (me.s2 < 0) {
            me.s2 += 1;
        }
        mash = null;
    }
    function copy(f, t) {
        t.c = f.c;
        t.s0 = f.s0;
        t.s1 = f.s1;
        t.s2 = f.s2;
        return t;
    }
    function impl(seed, opts) {
        var xg = new Alea(seed), state = opts && opts.state, prng = xg.next;
        prng.int32 = function() {
            return xg.next() * 0x100000000 | 0;
        };
        prng.double = function() {
            return prng() + (prng() * 0x200000 | 0) * 1.1102230246251565e-16; // 2^-53
        };
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    function Mash() {
        var n = 0xefc8249d;
        var mash = function(data) {
            data = String(data);
            for(var i = 0; i < data.length; i++){
                n += data.charCodeAt(i);
                var h = 0.02519603282416938 * n;
                n = h >>> 0;
                h -= n;
                h *= n;
                n = h >>> 0;
                h -= n;
                n += h * 0x100000000; // 2^32
            }
            return (n >>> 0) * 2.3283064365386963e-10; // 2^-32
        };
        return mash;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.alea = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xor128.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "xor128" prng algorithm by
// George Marsaglia.  See http://www.jstatsoft.org/v08/i14/paper
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this, strseed = '';
        me.x = 0;
        me.y = 0;
        me.z = 0;
        me.w = 0;
        // Set up generator function.
        me.next = function() {
            var t = me.x ^ me.x << 11;
            me.x = me.y;
            me.y = me.z;
            me.z = me.w;
            return me.w ^= me.w >>> 19 ^ t ^ t >>> 8;
        };
        if (seed === (seed | 0)) {
            // Integer seed.
            me.x = seed;
        } else {
            // String seed.
            strseed += seed;
        }
        // Mix in string seed, then discard an initial batch of 64 values.
        for(var k = 0; k < strseed.length + 64; k++){
            me.x ^= strseed.charCodeAt(k) | 0;
            me.next();
        }
    }
    function copy(f, t) {
        t.x = f.x;
        t.y = f.y;
        t.z = f.z;
        t.w = f.w;
        return t;
    }
    function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xor128 = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xorwow.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "xorwow" prng algorithm by
// George Marsaglia.  See http://www.jstatsoft.org/v08/i14/paper
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this, strseed = '';
        // Set up generator function.
        me.next = function() {
            var t = me.x ^ me.x >>> 2;
            me.x = me.y;
            me.y = me.z;
            me.z = me.w;
            me.w = me.v;
            return (me.d = me.d + 362437 | 0) + (me.v = me.v ^ me.v << 4 ^ (t ^ t << 1)) | 0;
        };
        me.x = 0;
        me.y = 0;
        me.z = 0;
        me.w = 0;
        me.v = 0;
        if (seed === (seed | 0)) {
            // Integer seed.
            me.x = seed;
        } else {
            // String seed.
            strseed += seed;
        }
        // Mix in string seed, then discard an initial batch of 64 values.
        for(var k = 0; k < strseed.length + 64; k++){
            me.x ^= strseed.charCodeAt(k) | 0;
            if (k == strseed.length) {
                me.d = me.x << 10 ^ me.x >>> 4;
            }
            me.next();
        }
    }
    function copy(f, t) {
        t.x = f.x;
        t.y = f.y;
        t.z = f.z;
        t.w = f.w;
        t.v = f.v;
        t.d = f.d;
        return t;
    }
    function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xorwow = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xorshift7.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "xorshift7" algorithm by
// François Panneton and Pierre L'ecuyer:
// "On the Xorgshift Random Number Generators"
// http://saluc.engr.uconn.edu/refs/crypto/rng/panneton05onthexorshift.pdf
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this;
        // Set up generator function.
        me.next = function() {
            // Update xor generator.
            var X = me.x, i = me.i, t, v, w;
            t = X[i];
            t ^= t >>> 7;
            v = t ^ t << 24;
            t = X[i + 1 & 7];
            v ^= t ^ t >>> 10;
            t = X[i + 3 & 7];
            v ^= t ^ t >>> 3;
            t = X[i + 4 & 7];
            v ^= t ^ t << 7;
            t = X[i + 7 & 7];
            t = t ^ t << 13;
            v ^= t ^ t << 9;
            X[i] = v;
            me.i = i + 1 & 7;
            return v;
        };
        function init(me, seed) {
            var j, w, X = [];
            if (seed === (seed | 0)) {
                // Seed state array using a 32-bit integer.
                w = X[0] = seed;
            } else {
                // Seed state using a string.
                seed = '' + seed;
                for(j = 0; j < seed.length; ++j){
                    X[j & 7] = X[j & 7] << 15 ^ seed.charCodeAt(j) + X[j + 1 & 7] << 13;
                }
            }
            // Enforce an array length of 8, not all zeroes.
            while(X.length < 8)X.push(0);
            for(j = 0; j < 8 && X[j] === 0; ++j);
            if (j == 8) w = X[7] = -1;
            else w = X[j];
            me.x = X;
            me.i = 0;
            // Discard an initial 256 values.
            for(j = 256; j > 0; --j){
                me.next();
            }
        }
        init(me, seed);
    }
    function copy(f, t) {
        t.x = f.x.slice();
        t.i = f.i;
        return t;
    }
    function impl(seed, opts) {
        if (seed == null) seed = +new Date;
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (state.x) copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xorshift7 = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xor4096.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of Richard Brent's Xorgens xor4096 algorithm.
//
// This fast non-cryptographic random number generator is designed for
// use in Monte-Carlo algorithms. It combines a long-period xorshift
// generator with a Weyl generator, and it passes all common batteries
// of stasticial tests for randomness while consuming only a few nanoseconds
// for each prng generated.  For background on the generator, see Brent's
// paper: "Some long-period random number generators using shifts and xors."
// http://arxiv.org/pdf/1004.3115v1.pdf
//
// Usage:
//
// var xor4096 = require('xor4096');
// random = xor4096(1);                        // Seed with int32 or string.
// assert.equal(random(), 0.1520436450538547); // (0, 1) range, 53 bits.
// assert.equal(random.int32(), 1806534897);   // signed int32, 32 bits.
//
// For nonzero numeric keys, this impelementation provides a sequence
// identical to that by Brent's xorgens 3 implementaion in C.  This
// implementation also provides for initalizing the generator with
// string seeds, or for saving and restoring the state of the generator.
//
// On Chrome, this prng benchmarks about 2.1 times slower than
// Javascript's built-in Math.random().
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this;
        // Set up generator function.
        me.next = function() {
            var w = me.w, X = me.X, i = me.i, t, v;
            // Update Weyl generator.
            me.w = w = w + 0x61c88647 | 0;
            // Update xor generator.
            v = X[i + 34 & 127];
            t = X[i = i + 1 & 127];
            v ^= v << 13;
            t ^= t << 17;
            v ^= v >>> 15;
            t ^= t >>> 12;
            // Update Xor generator array state.
            v = X[i] = v ^ t;
            me.i = i;
            // Result is the combination.
            return v + (w ^ w >>> 16) | 0;
        };
        function init(me, seed) {
            var t, v, i, j, w, X = [], limit = 128;
            if (seed === (seed | 0)) {
                // Numeric seeds initialize v, which is used to generates X.
                v = seed;
                seed = null;
            } else {
                // String seeds are mixed into v and X one character at a time.
                seed = seed + '\0';
                v = 0;
                limit = Math.max(limit, seed.length);
            }
            // Initialize circular array and weyl value.
            for(i = 0, j = -32; j < limit; ++j){
                // Put the unicode characters into the array, and shuffle them.
                if (seed) v ^= seed.charCodeAt((j + 32) % seed.length);
                // After 32 shuffles, take v as the starting w value.
                if (j === 0) w = v;
                v ^= v << 10;
                v ^= v >>> 15;
                v ^= v << 4;
                v ^= v >>> 13;
                if (j >= 0) {
                    w = w + 0x61c88647 | 0; // Weyl.
                    t = X[j & 127] ^= v + w; // Combine xor and weyl to init array.
                    i = 0 == t ? i + 1 : 0; // Count zeroes.
                }
            }
            // We have detected all zeroes; make the key nonzero.
            if (i >= 128) {
                X[(seed && seed.length || 0) & 127] = -1;
            }
            // Run the generator 512 times to further mix the state before using it.
            // Factoring this as a function slows the main generator, so it is just
            // unrolled here.  The weyl generator is not advanced while warming up.
            i = 127;
            for(j = 4 * 128; j > 0; --j){
                v = X[i + 34 & 127];
                t = X[i = i + 1 & 127];
                v ^= v << 13;
                t ^= t << 17;
                v ^= v >>> 15;
                t ^= t >>> 12;
                X[i] = v ^ t;
            }
            // Storing state as object members is faster than using closure variables.
            me.w = w;
            me.X = X;
            me.i = i;
        }
        init(me, seed);
    }
    function copy(f, t) {
        t.i = f.i;
        t.w = f.w;
        t.X = f.X.slice();
        return t;
    }
    ;
    function impl(seed, opts) {
        if (seed == null) seed = +new Date;
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (state.X) copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.xor4096 = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/tychei.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A Javascript implementaion of the "Tyche-i" prng algorithm by
// Samuel Neves and Filipe Araujo.
// See https://eden.dei.uc.pt/~sneves/pubs/2011-snfa2.pdf
(function(global, module1, define1) {
    function XorGen(seed) {
        var me = this, strseed = '';
        // Set up generator function.
        me.next = function() {
            var b = me.b, c = me.c, d = me.d, a = me.a;
            b = b << 25 ^ b >>> 7 ^ c;
            c = c - d | 0;
            d = d << 24 ^ d >>> 8 ^ a;
            a = a - b | 0;
            me.b = b = b << 20 ^ b >>> 12 ^ c;
            me.c = c = c - d | 0;
            me.d = d << 16 ^ c >>> 16 ^ a;
            return me.a = a - b | 0;
        };
        /* The following is non-inverted tyche, which has better internal
   * bit diffusion, but which is about 25% slower than tyche-i in JS.
  me.next = function() {
    var a = me.a, b = me.b, c = me.c, d = me.d;
    a = (me.a + me.b | 0) >>> 0;
    d = me.d ^ a; d = d << 16 ^ d >>> 16;
    c = me.c + d | 0;
    b = me.b ^ c; b = b << 12 ^ d >>> 20;
    me.a = a = a + b | 0;
    d = d ^ a; me.d = d = d << 8 ^ d >>> 24;
    me.c = c = c + d | 0;
    b = b ^ c;
    return me.b = (b << 7 ^ b >>> 25);
  }
  */ me.a = 0;
        me.b = 0;
        me.c = 2654435769 | 0;
        me.d = 1367130551;
        if (seed === Math.floor(seed)) {
            // Integer seed.
            me.a = seed / 0x100000000 | 0;
            me.b = seed | 0;
        } else {
            // String seed.
            strseed += seed;
        }
        // Mix in string seed, then discard an initial batch of 64 values.
        for(var k = 0; k < strseed.length + 20; k++){
            me.b ^= strseed.charCodeAt(k) | 0;
            me.next();
        }
    }
    function copy(f, t) {
        t.a = f.a;
        t.b = f.b;
        t.c = f.c;
        t.d = f.d;
        return t;
    }
    ;
    function impl(seed, opts) {
        var xg = new XorGen(seed), state = opts && opts.state, prng = function() {
            return (xg.next() >>> 0) / 0x100000000;
        };
        prng.double = function() {
            do {
                var top = xg.next() >>> 11, bot = (xg.next() >>> 0) / 0x100000000, result = (top + bot) / (1 << 21);
            }while (result === 0)
            return result;
        };
        prng.int32 = xg.next;
        prng.quick = prng;
        if (state) {
            if (typeof state == 'object') copy(state, xg);
            prng.state = function() {
                return copy(xg, {});
            };
        }
        return prng;
    }
    if (module1 && module1.exports) {
        module1.exports = impl;
    } else if (define1 && define1.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return impl;
        }(__turbopack_context__.r, exports, module));
    } else {
        this.tychei = impl;
    }
})(/*TURBOPACK member replacement*/ __turbopack_context__.e, ("TURBOPACK compile-time value", "object") == 'object' && module, typeof define == 'function' && define // present with an AMD loader
);
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/seedrandom.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/*
Copyright 2019 David Bau.

Permission is hereby granted, free of charge, to any person obtaining
a copy of this software and associated documentation files (the
"Software"), to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to
permit persons to whom the Software is furnished to do so, subject to
the following conditions:

The above copyright notice and this permission notice shall be
included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY
CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/ (function(global, pool, math) {
    //
    // The following constants are related to IEEE 754 limits.
    //
    var width = 256, chunks = 6, digits = 52, rngname = 'random', startdenom = math.pow(width, chunks), significance = math.pow(2, digits), overflow = significance * 2, mask = width - 1, nodecrypto; // node.js crypto module, initialized at the bottom.
    //
    // seedrandom()
    // This is the seedrandom function described above.
    //
    function seedrandom(seed, options, callback) {
        var key = [];
        options = options == true ? {
            entropy: true
        } : options || {};
        // Flatten the seed string or build one from local entropy if needed.
        var shortseed = mixkey(flatten(options.entropy ? [
            seed,
            tostring(pool)
        ] : seed == null ? autoseed() : seed, 3), key);
        // Use the seed to initialize an ARC4 generator.
        var arc4 = new ARC4(key);
        // This function returns a random double in [0, 1) that contains
        // randomness in every bit of the mantissa of the IEEE 754 value.
        var prng = function() {
            var n = arc4.g(chunks), d = startdenom, x = 0; //   and no 'extra last byte'.
            while(n < significance){
                n = (n + x) * width; //   shifting numerator and
                d *= width; //   denominator and generating a
                x = arc4.g(1); //   new least-significant-byte.
            }
            while(n >= overflow){
                n /= 2; //   last byte, shift everything
                d /= 2; //   right using integer math until
                x >>>= 1; //   we have exactly the desired bits.
            }
            return (n + x) / d; // Form the number within [0, 1).
        };
        prng.int32 = function() {
            return arc4.g(4) | 0;
        };
        prng.quick = function() {
            return arc4.g(4) / 0x100000000;
        };
        prng.double = prng;
        // Mix the randomness into accumulated entropy.
        mixkey(tostring(arc4.S), pool);
        // Calling convention: what to return as a function of prng, seed, is_math.
        return (options.pass || callback || function(prng, seed, is_math_call, state) {
            if (state) {
                // Load the arc4 state from the given state if it has an S array.
                if (state.S) {
                    copy(state, arc4);
                }
                // Only provide the .state method if requested via options.state.
                prng.state = function() {
                    return copy(arc4, {});
                };
            }
            // If called as a method of Math (Math.seedrandom()), mutate
            // Math.random because that is how seedrandom.js has worked since v1.0.
            if (is_math_call) {
                math[rngname] = prng;
                return seed;
            } else return prng;
        })(prng, shortseed, 'global' in options ? options.global : this == math, options.state);
    }
    //
    // ARC4
    //
    // An ARC4 implementation.  The constructor takes a key in the form of
    // an array of at most (width) integers that should be 0 <= x < (width).
    //
    // The g(count) method returns a pseudorandom integer that concatenates
    // the next (count) outputs from ARC4.  Its return value is a number x
    // that is in the range 0 <= x < (width ^ count).
    //
    function ARC4(key) {
        var t, keylen = key.length, me = this, i = 0, j = me.i = me.j = 0, s = me.S = [];
        // The empty key [] is treated as [0].
        if (!keylen) {
            key = [
                keylen++
            ];
        }
        // Set up S using the standard key scheduling algorithm.
        while(i < width){
            s[i] = i++;
        }
        for(i = 0; i < width; i++){
            s[i] = s[j = mask & j + key[i % keylen] + (t = s[i])];
            s[j] = t;
        }
        // The "g" method returns the next (count) outputs as one number.
        (me.g = function(count) {
            // Using instance members instead of closure state nearly doubles speed.
            var t, r = 0, i = me.i, j = me.j, s = me.S;
            while(count--){
                t = s[i = mask & i + 1];
                r = r * width + s[mask & (s[i] = s[j = mask & j + t]) + (s[j] = t)];
            }
            me.i = i;
            me.j = j;
            return r;
        // For robust unpredictability, the function call below automatically
        // discards an initial batch of values.  This is called RC4-drop[256].
        // See http://google.com/search?q=rsa+fluhrer+response&btnI
        })(width);
    }
    //
    // copy()
    // Copies internal state of ARC4 to or from a plain object.
    //
    function copy(f, t) {
        t.i = f.i;
        t.j = f.j;
        t.S = f.S.slice();
        return t;
    }
    ;
    //
    // flatten()
    // Converts an object tree to nested arrays of strings.
    //
    function flatten(obj, depth) {
        var result = [], typ = typeof obj, prop;
        if (depth && typ == 'object') {
            for(prop in obj){
                try {
                    result.push(flatten(obj[prop], depth - 1));
                } catch (e) {}
            }
        }
        return result.length ? result : typ == 'string' ? obj : obj + '\0';
    }
    //
    // mixkey()
    // Mixes a string seed into a key that is an array of integers, and
    // returns a shortened string seed that is equivalent to the result key.
    //
    function mixkey(seed, key) {
        var stringseed = seed + '', smear, j = 0;
        while(j < stringseed.length){
            key[mask & j] = mask & (smear ^= key[mask & j] * 19) + stringseed.charCodeAt(j++);
        }
        return tostring(key);
    }
    //
    // autoseed()
    // Returns an object for autoseeding, using window.crypto and Node crypto
    // module if available.
    //
    function autoseed() {
        try {
            var out;
            if (nodecrypto && (out = nodecrypto.randomBytes)) {
                // The use of 'out' to remember randomBytes makes tight minified code.
                out = out(width);
            } else {
                out = new Uint8Array(width);
                (global.crypto || global.msCrypto).getRandomValues(out);
            }
            return tostring(out);
        } catch (e) {
            var browser = global.navigator, plugins = browser && browser.plugins;
            return [
                +new Date,
                global,
                plugins,
                global.screen,
                tostring(pool)
            ];
        }
    }
    //
    // tostring()
    // Converts an array of charcodes to a string
    //
    function tostring(a) {
        return String.fromCharCode.apply(0, a);
    }
    //
    // When seedrandom.js is loaded, we immediately mix a few bits
    // from the built-in RNG into the entropy pool.  Because we do
    // not want to interfere with deterministic PRNG state later,
    // seedrandom will not call math.random on its own again after
    // initialization.
    //
    mixkey(math.random(), pool);
    //
    // Nodejs and AMD support: export the implementation as a module using
    // either convention.
    //
    if (("TURBOPACK compile-time value", "object") == 'object' && module.exports) {
        module.exports = seedrandom;
        // When in node.js, try using crypto package for autoseeding.
        try {
            nodecrypto = __turbopack_context__.r("[externals]/crypto [external] (crypto, cjs)");
        } catch (ex) {}
    } else if (typeof define == 'function' && define.amd) {
        ((r)=>r !== undefined && __turbopack_context__.v(r))(function() {
            return seedrandom;
        }(__turbopack_context__.r, exports, module));
    } else {
        // When included as a plain script, set up Math.seedrandom global.
        math['seed' + rngname] = seedrandom;
    }
// End anonymous scope, and pass initial values.
})(// global: `self` in browsers (including strict mode and web workers),
// otherwise `this` in Node and other environments
typeof self !== 'undefined' ? self : /*TURBOPACK member replacement*/ __turbopack_context__.e, [], Math // math: package containing random, pow, and seedrandom
);
}),
"[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

// A library of seedable RNGs implemented in Javascript.
//
// Usage:
//
// var seedrandom = require('seedrandom');
// var random = seedrandom(1); // or any seed.
// var x = random();       // 0 <= x < 1.  Every bit is random.
// var x = random.quick(); // 0 <= x < 1.  32 bits of randomness.
// alea, a 53-bit multiply-with-carry generator by Johannes Baagøe.
// Period: ~2^116
// Reported to pass all BigCrush tests.
var alea = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/alea.js [app-route] (ecmascript)");
// xor128, a pure xor-shift generator by George Marsaglia.
// Period: 2^128-1.
// Reported to fail: MatrixRank and LinearComp.
var xor128 = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xor128.js [app-route] (ecmascript)");
// xorwow, George Marsaglia's 160-bit xor-shift combined plus weyl.
// Period: 2^192-2^32
// Reported to fail: CollisionOver, SimpPoker, and LinearComp.
var xorwow = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xorwow.js [app-route] (ecmascript)");
// xorshift7, by François Panneton and Pierre L'ecuyer, takes
// a different approach: it adds robustness by allowing more shifts
// than Marsaglia's original three.  It is a 7-shift generator
// with 256 bits, that passes BigCrush with no systmatic failures.
// Period 2^256-1.
// No systematic BigCrush failures reported.
var xorshift7 = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xorshift7.js [app-route] (ecmascript)");
// xor4096, by Richard Brent, is a 4096-bit xor-shift with a
// very long period that also adds a Weyl generator. It also passes
// BigCrush with no systematic failures.  Its long period may
// be useful if you have many generators and need to avoid
// collisions.
// Period: 2^4128-2^32.
// No systematic BigCrush failures reported.
var xor4096 = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/xor4096.js [app-route] (ecmascript)");
// Tyche-i, by Samuel Neves and Filipe Araujo, is a bit-shifting random
// number generator derived from ChaCha, a modern stream cipher.
// https://eden.dei.uc.pt/~sneves/pubs/2011-snfa2.pdf
// Period: ~2^127
// No systematic BigCrush failures reported.
var tychei = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/lib/tychei.js [app-route] (ecmascript)");
// The original ARC4-based prng included in this library.
// Period: ~2^1600
var sr = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/seedrandom@3.0.5/node_modules/seedrandom/seedrandom.js [app-route] (ecmascript)");
sr.alea = alea;
sr.xor128 = xor128;
sr.xorwow = xorwow;
sr.xorshift7 = xorshift7;
sr.xor4096 = xor4096;
sr.tychei = tychei;
module.exports = sr;
}),
"[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/api.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime.js [app-route] (ecmascript) <locals>"); //# sourceMappingURL=api.js.map
;
}),
];

//# sourceMappingURL=9e883__pnpm_196722ac._.js.map