module.exports = [
"[project]/node_modules/@ai-sdk/provider/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/errors/ai-sdk-error.ts
__turbopack_context__.s([
    "AISDKError",
    ()=>AISDKError,
    "APICallError",
    ()=>APICallError,
    "EmptyResponseBodyError",
    ()=>EmptyResponseBodyError,
    "InvalidArgumentError",
    ()=>InvalidArgumentError,
    "InvalidPromptError",
    ()=>InvalidPromptError,
    "InvalidResponseDataError",
    ()=>InvalidResponseDataError,
    "JSONParseError",
    ()=>JSONParseError,
    "LoadAPIKeyError",
    ()=>LoadAPIKeyError,
    "LoadSettingError",
    ()=>LoadSettingError,
    "NoContentGeneratedError",
    ()=>NoContentGeneratedError,
    "NoSuchModelError",
    ()=>NoSuchModelError,
    "TooManyEmbeddingValuesForCallError",
    ()=>TooManyEmbeddingValuesForCallError,
    "TypeValidationError",
    ()=>TypeValidationError,
    "UnsupportedFunctionalityError",
    ()=>UnsupportedFunctionalityError,
    "getErrorMessage",
    ()=>getErrorMessage,
    "isJSONArray",
    ()=>isJSONArray,
    "isJSONObject",
    ()=>isJSONObject,
    "isJSONValue",
    ()=>isJSONValue
]);
var marker = "vercel.ai.error";
var symbol = Symbol.for(marker);
var _a;
var _AISDKError = class _AISDKError extends Error {
    /**
   * Creates an AI SDK Error.
   *
   * @param {Object} params - The parameters for creating the error.
   * @param {string} params.name - The name of the error.
   * @param {string} params.message - The error message.
   * @param {unknown} [params.cause] - The underlying cause of the error.
   */ constructor({ name: name14, message, cause }){
        super(message);
        this[_a] = true;
        this.name = name14;
        this.cause = cause;
    }
    /**
   * Checks if the given error is an AI SDK Error.
   * @param {unknown} error - The error to check.
   * @returns {boolean} True if the error is an AI SDK Error, false otherwise.
   */ static isInstance(error) {
        return _AISDKError.hasMarker(error, marker);
    }
    static hasMarker(error, marker15) {
        const markerSymbol = Symbol.for(marker15);
        return error != null && typeof error === "object" && markerSymbol in error && typeof error[markerSymbol] === "boolean" && error[markerSymbol] === true;
    }
};
_a = symbol;
var AISDKError = _AISDKError;
// src/errors/api-call-error.ts
var name = "AI_APICallError";
var marker2 = `vercel.ai.error.${name}`;
var symbol2 = Symbol.for(marker2);
var _a2;
var APICallError = class extends AISDKError {
    constructor({ message, url, requestBodyValues, statusCode, responseHeaders, responseBody, cause, isRetryable = statusCode != null && (statusCode === 408 || // request timeout
    statusCode === 409 || // conflict
    statusCode === 429 || // too many requests
    statusCode >= 500), // server error
    data }){
        super({
            name,
            message,
            cause
        });
        this[_a2] = true;
        this.url = url;
        this.requestBodyValues = requestBodyValues;
        this.statusCode = statusCode;
        this.responseHeaders = responseHeaders;
        this.responseBody = responseBody;
        this.isRetryable = isRetryable;
        this.data = data;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker2);
    }
};
_a2 = symbol2;
// src/errors/empty-response-body-error.ts
var name2 = "AI_EmptyResponseBodyError";
var marker3 = `vercel.ai.error.${name2}`;
var symbol3 = Symbol.for(marker3);
var _a3;
var EmptyResponseBodyError = class extends AISDKError {
    // used in isInstance
    constructor({ message = "Empty response body" } = {}){
        super({
            name: name2,
            message
        });
        this[_a3] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker3);
    }
};
_a3 = symbol3;
// src/errors/get-error-message.ts
function getErrorMessage(error) {
    if (error == null) {
        return "unknown error";
    }
    if (typeof error === "string") {
        return error;
    }
    if (error instanceof Error) {
        return error.message;
    }
    return JSON.stringify(error);
}
// src/errors/invalid-argument-error.ts
var name3 = "AI_InvalidArgumentError";
var marker4 = `vercel.ai.error.${name3}`;
var symbol4 = Symbol.for(marker4);
var _a4;
var InvalidArgumentError = class extends AISDKError {
    constructor({ message, cause, argument }){
        super({
            name: name3,
            message,
            cause
        });
        this[_a4] = true;
        this.argument = argument;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker4);
    }
};
_a4 = symbol4;
// src/errors/invalid-prompt-error.ts
var name4 = "AI_InvalidPromptError";
var marker5 = `vercel.ai.error.${name4}`;
var symbol5 = Symbol.for(marker5);
var _a5;
var InvalidPromptError = class extends AISDKError {
    constructor({ prompt, message, cause }){
        super({
            name: name4,
            message: `Invalid prompt: ${message}`,
            cause
        });
        this[_a5] = true;
        this.prompt = prompt;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker5);
    }
};
_a5 = symbol5;
// src/errors/invalid-response-data-error.ts
var name5 = "AI_InvalidResponseDataError";
var marker6 = `vercel.ai.error.${name5}`;
var symbol6 = Symbol.for(marker6);
var _a6;
var InvalidResponseDataError = class extends AISDKError {
    constructor({ data, message = `Invalid response data: ${JSON.stringify(data)}.` }){
        super({
            name: name5,
            message
        });
        this[_a6] = true;
        this.data = data;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker6);
    }
};
_a6 = symbol6;
// src/errors/json-parse-error.ts
var name6 = "AI_JSONParseError";
var marker7 = `vercel.ai.error.${name6}`;
var symbol7 = Symbol.for(marker7);
var _a7;
var JSONParseError = class extends AISDKError {
    constructor({ text, cause }){
        super({
            name: name6,
            message: `JSON parsing failed: Text: ${text}.
Error message: ${getErrorMessage(cause)}`,
            cause
        });
        this[_a7] = true;
        this.text = text;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker7);
    }
};
_a7 = symbol7;
// src/errors/load-api-key-error.ts
var name7 = "AI_LoadAPIKeyError";
var marker8 = `vercel.ai.error.${name7}`;
var symbol8 = Symbol.for(marker8);
var _a8;
var LoadAPIKeyError = class extends AISDKError {
    // used in isInstance
    constructor({ message }){
        super({
            name: name7,
            message
        });
        this[_a8] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker8);
    }
};
_a8 = symbol8;
// src/errors/load-setting-error.ts
var name8 = "AI_LoadSettingError";
var marker9 = `vercel.ai.error.${name8}`;
var symbol9 = Symbol.for(marker9);
var _a9;
var LoadSettingError = class extends AISDKError {
    // used in isInstance
    constructor({ message }){
        super({
            name: name8,
            message
        });
        this[_a9] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker9);
    }
};
_a9 = symbol9;
// src/errors/no-content-generated-error.ts
var name9 = "AI_NoContentGeneratedError";
var marker10 = `vercel.ai.error.${name9}`;
var symbol10 = Symbol.for(marker10);
var _a10;
var NoContentGeneratedError = class extends AISDKError {
    // used in isInstance
    constructor({ message = "No content generated." } = {}){
        super({
            name: name9,
            message
        });
        this[_a10] = true;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker10);
    }
};
_a10 = symbol10;
// src/errors/no-such-model-error.ts
var name10 = "AI_NoSuchModelError";
var marker11 = `vercel.ai.error.${name10}`;
var symbol11 = Symbol.for(marker11);
var _a11;
var NoSuchModelError = class extends AISDKError {
    constructor({ errorName = name10, modelId, modelType, message = `No such ${modelType}: ${modelId}` }){
        super({
            name: errorName,
            message
        });
        this[_a11] = true;
        this.modelId = modelId;
        this.modelType = modelType;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker11);
    }
};
_a11 = symbol11;
// src/errors/too-many-embedding-values-for-call-error.ts
var name11 = "AI_TooManyEmbeddingValuesForCallError";
var marker12 = `vercel.ai.error.${name11}`;
var symbol12 = Symbol.for(marker12);
var _a12;
var TooManyEmbeddingValuesForCallError = class extends AISDKError {
    constructor(options){
        super({
            name: name11,
            message: `Too many values for a single embedding call. The ${options.provider} model "${options.modelId}" can only embed up to ${options.maxEmbeddingsPerCall} values per call, but ${options.values.length} values were provided.`
        });
        this[_a12] = true;
        this.provider = options.provider;
        this.modelId = options.modelId;
        this.maxEmbeddingsPerCall = options.maxEmbeddingsPerCall;
        this.values = options.values;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker12);
    }
};
_a12 = symbol12;
// src/errors/type-validation-error.ts
var name12 = "AI_TypeValidationError";
var marker13 = `vercel.ai.error.${name12}`;
var symbol13 = Symbol.for(marker13);
var _a13;
var _TypeValidationError = class _TypeValidationError extends AISDKError {
    constructor({ value, cause }){
        super({
            name: name12,
            message: `Type validation failed: Value: ${JSON.stringify(value)}.
Error message: ${getErrorMessage(cause)}`,
            cause
        });
        this[_a13] = true;
        this.value = value;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker13);
    }
    /**
   * Wraps an error into a TypeValidationError.
   * If the cause is already a TypeValidationError with the same value, it returns the cause.
   * Otherwise, it creates a new TypeValidationError.
   *
   * @param {Object} params - The parameters for wrapping the error.
   * @param {unknown} params.value - The value that failed validation.
   * @param {unknown} params.cause - The original error or cause of the validation failure.
   * @returns {TypeValidationError} A TypeValidationError instance.
   */ static wrap({ value, cause }) {
        return _TypeValidationError.isInstance(cause) && cause.value === value ? cause : new _TypeValidationError({
            value,
            cause
        });
    }
};
_a13 = symbol13;
var TypeValidationError = _TypeValidationError;
// src/errors/unsupported-functionality-error.ts
var name13 = "AI_UnsupportedFunctionalityError";
var marker14 = `vercel.ai.error.${name13}`;
var symbol14 = Symbol.for(marker14);
var _a14;
var UnsupportedFunctionalityError = class extends AISDKError {
    constructor({ functionality, message = `'${functionality}' functionality not supported.` }){
        super({
            name: name13,
            message
        });
        this[_a14] = true;
        this.functionality = functionality;
    }
    static isInstance(error) {
        return AISDKError.hasMarker(error, marker14);
    }
};
_a14 = symbol14;
// src/json-value/is-json.ts
function isJSONValue(value) {
    if (value === null || typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        return true;
    }
    if (Array.isArray(value)) {
        return value.every(isJSONValue);
    }
    if (typeof value === "object") {
        return Object.entries(value).every(([key, val])=>typeof key === "string" && isJSONValue(val));
    }
    return false;
}
function isJSONArray(value) {
    return Array.isArray(value) && value.every(isJSONValue);
}
function isJSONObject(value) {
    return value != null && typeof value === "object" && Object.entries(value).every(([key, val])=>typeof key === "string" && isJSONValue(val));
}
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/node_modules/eventsource-parser/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ParseError",
    ()=>ParseError,
    "createParser",
    ()=>createParser
]);
class ParseError extends Error {
    constructor(message, options){
        super(message), this.name = "ParseError", this.type = options.type, this.field = options.field, this.value = options.value, this.line = options.line;
    }
}
function noop(_arg) {}
function createParser(callbacks) {
    if (typeof callbacks == "function") throw new TypeError("`callbacks` must be an object, got a function instead. Did you mean `{onEvent: fn}`?");
    const { onEvent = noop, onError = noop, onRetry = noop, onComment } = callbacks;
    let incompleteLine = "", isFirstChunk = !0, id, data = "", eventType = "";
    function feed(newChunk) {
        const chunk = isFirstChunk ? newChunk.replace(/^\xEF\xBB\xBF/, "") : newChunk, [complete, incomplete] = splitLines(`${incompleteLine}${chunk}`);
        for (const line of complete)parseLine(line);
        incompleteLine = incomplete, isFirstChunk = !1;
    }
    function parseLine(line) {
        if (line === "") {
            dispatchEvent();
            return;
        }
        if (line.startsWith(":")) {
            onComment && onComment(line.slice(line.startsWith(": ") ? 2 : 1));
            return;
        }
        const fieldSeparatorIndex = line.indexOf(":");
        if (fieldSeparatorIndex !== -1) {
            const field = line.slice(0, fieldSeparatorIndex), offset = line[fieldSeparatorIndex + 1] === " " ? 2 : 1, value = line.slice(fieldSeparatorIndex + offset);
            processField(field, value, line);
            return;
        }
        processField(line, "", line);
    }
    function processField(field, value, line) {
        switch(field){
            case "event":
                eventType = value;
                break;
            case "data":
                data = `${data}${value}
`;
                break;
            case "id":
                id = value.includes("\0") ? void 0 : value;
                break;
            case "retry":
                /^\d+$/.test(value) ? onRetry(parseInt(value, 10)) : onError(new ParseError(`Invalid \`retry\` value: "${value}"`, {
                    type: "invalid-retry",
                    value,
                    line
                }));
                break;
            default:
                onError(new ParseError(`Unknown field "${field.length > 20 ? `${field.slice(0, 20)}\u2026` : field}"`, {
                    type: "unknown-field",
                    field,
                    value,
                    line
                }));
                break;
        }
    }
    function dispatchEvent() {
        data.length > 0 && onEvent({
            id,
            event: eventType || void 0,
            // If the data buffer's last character is a U+000A LINE FEED (LF) character,
            // then remove the last character from the data buffer.
            data: data.endsWith(`
`) ? data.slice(0, -1) : data
        }), id = void 0, data = "", eventType = "";
    }
    function reset(options = {}) {
        incompleteLine && options.consume && parseLine(incompleteLine), isFirstChunk = !0, id = void 0, data = "", eventType = "", incompleteLine = "";
    }
    return {
        feed,
        reset
    };
}
function splitLines(chunk) {
    const lines = [];
    let incompleteLine = "", searchIndex = 0;
    for(; searchIndex < chunk.length;){
        const crIndex = chunk.indexOf("\r", searchIndex), lfIndex = chunk.indexOf(`
`, searchIndex);
        let lineEnd = -1;
        if (crIndex !== -1 && lfIndex !== -1 ? lineEnd = Math.min(crIndex, lfIndex) : crIndex !== -1 ? crIndex === chunk.length - 1 ? lineEnd = -1 : lineEnd = crIndex : lfIndex !== -1 && (lineEnd = lfIndex), lineEnd === -1) {
            incompleteLine = chunk.slice(searchIndex);
            break;
        } else {
            const line = chunk.slice(searchIndex, lineEnd);
            lines.push(line), searchIndex = lineEnd + 1, chunk[searchIndex - 1] === "\r" && chunk[searchIndex] === `
` && searchIndex++;
        }
    }
    return [
        lines,
        incompleteLine
    ];
}
;
 //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/eventsource-parser/dist/stream.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "EventSourceParserStream",
    ()=>EventSourceParserStream
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/eventsource-parser/dist/index.js [app-route] (ecmascript)");
;
;
class EventSourceParserStream extends TransformStream {
    constructor({ onError, onRetry, onComment } = {}){
        let parser;
        super({
            start (controller) {
                parser = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$eventsource$2d$parser$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createParser"])({
                    onEvent: (event)=>{
                        controller.enqueue(event);
                    },
                    onError (error) {
                        onError === "terminate" ? controller.error(error) : typeof onError == "function" && onError(error);
                    },
                    onRetry,
                    onComment
                });
            },
            transform (chunk) {
                parser.feed(chunk);
            }
        });
    }
}
;
 //# sourceMappingURL=stream.js.map
}),
"[project]/node_modules/ai/dist/internal/index.mjs [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// internal/index.ts
__turbopack_context__.s([
    "convertToLanguageModelPrompt",
    ()=>convertToLanguageModelPrompt,
    "prepareCallSettings",
    ()=>prepareCallSettings,
    "prepareRetries",
    ()=>prepareRetries,
    "prepareToolsAndToolChoice",
    ()=>prepareToolsAndToolChoice,
    "standardizePrompt",
    ()=>standardizePrompt
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-route] (ecmascript) <locals>");
// src/util/download/download-error.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/provider/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/index.js [app-route] (ecmascript)");
;
;
;
var imageMediaTypeSignatures = [
    {
        mediaType: "image/gif",
        bytesPrefix: [
            71,
            73,
            70
        ]
    },
    {
        mediaType: "image/png",
        bytesPrefix: [
            137,
            80,
            78,
            71
        ]
    },
    {
        mediaType: "image/jpeg",
        bytesPrefix: [
            255,
            216
        ]
    },
    {
        mediaType: "image/webp",
        bytesPrefix: [
            82,
            73,
            70,
            70,
            // "RIFF"
            null,
            null,
            null,
            null,
            // file size (variable)
            87,
            69,
            66,
            80
        ]
    },
    {
        mediaType: "image/bmp",
        bytesPrefix: [
            66,
            77
        ]
    },
    {
        mediaType: "image/tiff",
        bytesPrefix: [
            73,
            73,
            42,
            0
        ]
    },
    {
        mediaType: "image/tiff",
        bytesPrefix: [
            77,
            77,
            0,
            42
        ]
    },
    {
        mediaType: "image/avif",
        bytesPrefix: [
            0,
            0,
            0,
            32,
            102,
            116,
            121,
            112,
            97,
            118,
            105,
            102
        ]
    },
    {
        mediaType: "image/heic",
        bytesPrefix: [
            0,
            0,
            0,
            32,
            102,
            116,
            121,
            112,
            104,
            101,
            105,
            99
        ]
    }
];
var stripID3 = (data)=>{
    const bytes = typeof data === "string" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["convertBase64ToUint8Array"])(data) : data;
    const id3Size = (bytes[6] & 127) << 21 | (bytes[7] & 127) << 14 | (bytes[8] & 127) << 7 | bytes[9] & 127;
    return bytes.slice(id3Size + 10);
};
function stripID3TagsIfPresent(data) {
    const hasId3 = typeof data === "string" && data.startsWith("SUQz") || typeof data !== "string" && data.length > 10 && data[0] === 73 && // 'I'
    data[1] === 68 && // 'D'
    data[2] === 51;
    return hasId3 ? stripID3(data) : data;
}
function detectMediaType({ data, signatures }) {
    const processedData = stripID3TagsIfPresent(data);
    const bytes = typeof processedData === "string" ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["convertBase64ToUint8Array"])(processedData.substring(0, Math.min(processedData.length, 24))) : processedData;
    for (const signature of signatures){
        if (bytes.length >= signature.bytesPrefix.length && signature.bytesPrefix.every((byte, index)=>byte === null || bytes[index] === byte)) {
            return signature.mediaType;
        }
    }
    return void 0;
}
;
var name = "AI_DownloadError";
var marker = `vercel.ai.error.${name}`;
var symbol = Symbol.for(marker);
var _a;
var DownloadError = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"] {
    constructor({ url, statusCode, statusText, cause, message = cause == null ? `Failed to download ${url}: ${statusCode} ${statusText}` : `Failed to download ${url}: ${cause}` }){
        super({
            name,
            message,
            cause
        });
        this[_a] = true;
        this.url = url;
        this.statusCode = statusCode;
        this.statusText = statusText;
    }
    static isInstance(error) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"].hasMarker(error, marker);
    }
};
_a = symbol;
;
// src/version.ts
var VERSION = ("TURBOPACK compile-time truthy", 1) ? "5.0.109" : "TURBOPACK unreachable";
// src/util/download/download.ts
var download = async ({ url })=>{
    var _a5;
    const urlText = url.toString();
    try {
        const response = await fetch(urlText, {
            headers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["withUserAgentSuffix"])({}, `ai-sdk/${VERSION}`, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getRuntimeEnvironmentUserAgent"])())
        });
        if (!response.ok) {
            throw new DownloadError({
                url: urlText,
                statusCode: response.status,
                statusText: response.statusText
            });
        }
        return {
            data: new Uint8Array(await response.arrayBuffer()),
            mediaType: (_a5 = response.headers.get("content-type")) != null ? _a5 : void 0
        };
    } catch (error) {
        if (DownloadError.isInstance(error)) {
            throw error;
        }
        throw new DownloadError({
            url: urlText,
            cause: error
        });
    }
};
// src/util/download/download-function.ts
var createDefaultDownloadFunction = (download2 = download)=>(requestedDownloads)=>Promise.all(requestedDownloads.map(async (requestedDownload)=>requestedDownload.isUrlSupportedByModel ? null : download2(requestedDownload)));
;
;
;
// src/prompt/split-data-url.ts
function splitDataUrl(dataUrl) {
    try {
        const [header, base64Content] = dataUrl.split(",");
        return {
            mediaType: header.split(";")[0].split(":")[1],
            base64Content
        };
    } catch (error) {
        return {
            mediaType: void 0,
            base64Content: void 0
        };
    }
}
// src/prompt/data-content.ts
var dataContentSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].instanceof(Uint8Array),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].instanceof(ArrayBuffer),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].custom(// Buffer might not be available in some environments such as CloudFlare:
    (value)=>{
        var _a5, _b;
        return (_b = (_a5 = globalThis.Buffer) == null ? void 0 : _a5.isBuffer(value)) != null ? _b : false;
    }, {
        message: "Must be a Buffer"
    })
]);
function convertToLanguageModelV2DataContent(content) {
    if (content instanceof Uint8Array) {
        return {
            data: content,
            mediaType: void 0
        };
    }
    if (content instanceof ArrayBuffer) {
        return {
            data: new Uint8Array(content),
            mediaType: void 0
        };
    }
    if (typeof content === "string") {
        try {
            content = new URL(content);
        } catch (error) {}
    }
    if (content instanceof URL && content.protocol === "data:") {
        const { mediaType: dataUrlMediaType, base64Content } = splitDataUrl(content.toString());
        if (dataUrlMediaType == null || base64Content == null) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"]({
                name: "InvalidDataContentError",
                message: `Invalid data URL format in content ${content.toString()}`
            });
        }
        return {
            data: base64Content,
            mediaType: dataUrlMediaType
        };
    }
    return {
        data: content,
        mediaType: void 0
    };
}
;
var name2 = "AI_InvalidMessageRoleError";
var marker2 = `vercel.ai.error.${name2}`;
var symbol2 = Symbol.for(marker2);
var _a2;
var InvalidMessageRoleError = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"] {
    constructor({ role, message = `Invalid message role: '${role}'. Must be one of: "system", "user", "assistant", "tool".` }){
        super({
            name: name2,
            message
        });
        this[_a2] = true;
        this.role = role;
    }
    static isInstance(error) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"].hasMarker(error, marker2);
    }
};
_a2 = symbol2;
// src/prompt/convert-to-language-model-prompt.ts
async function convertToLanguageModelPrompt({ prompt, supportedUrls, download: download2 = createDefaultDownloadFunction() }) {
    const downloadedAssets = await downloadAssets(prompt.messages, download2, supportedUrls);
    return [
        ...prompt.system != null ? [
            {
                role: "system",
                content: prompt.system
            }
        ] : [],
        ...prompt.messages.map((message)=>convertToLanguageModelMessage({
                message,
                downloadedAssets
            }))
    ];
}
function convertToLanguageModelMessage({ message, downloadedAssets }) {
    const role = message.role;
    switch(role){
        case "system":
            {
                return {
                    role: "system",
                    content: message.content,
                    providerOptions: message.providerOptions
                };
            }
        case "user":
            {
                if (typeof message.content === "string") {
                    return {
                        role: "user",
                        content: [
                            {
                                type: "text",
                                text: message.content
                            }
                        ],
                        providerOptions: message.providerOptions
                    };
                }
                return {
                    role: "user",
                    content: message.content.map((part)=>convertPartToLanguageModelPart(part, downloadedAssets)).filter((part)=>part.type !== "text" || part.text !== ""),
                    providerOptions: message.providerOptions
                };
            }
        case "assistant":
            {
                if (typeof message.content === "string") {
                    return {
                        role: "assistant",
                        content: [
                            {
                                type: "text",
                                text: message.content
                            }
                        ],
                        providerOptions: message.providerOptions
                    };
                }
                return {
                    role: "assistant",
                    content: message.content.filter(// remove empty text parts (no text, and no provider options):
                    (part)=>part.type !== "text" || part.text !== "" || part.providerOptions != null).map((part)=>{
                        const providerOptions = part.providerOptions;
                        switch(part.type){
                            case "file":
                                {
                                    const { data, mediaType } = convertToLanguageModelV2DataContent(part.data);
                                    return {
                                        type: "file",
                                        data,
                                        filename: part.filename,
                                        mediaType: mediaType != null ? mediaType : part.mediaType,
                                        providerOptions
                                    };
                                }
                            case "reasoning":
                                {
                                    return {
                                        type: "reasoning",
                                        text: part.text,
                                        providerOptions
                                    };
                                }
                            case "text":
                                {
                                    return {
                                        type: "text",
                                        text: part.text,
                                        providerOptions
                                    };
                                }
                            case "tool-call":
                                {
                                    return {
                                        type: "tool-call",
                                        toolCallId: part.toolCallId,
                                        toolName: part.toolName,
                                        input: part.input,
                                        providerExecuted: part.providerExecuted,
                                        providerOptions
                                    };
                                }
                            case "tool-result":
                                {
                                    return {
                                        type: "tool-result",
                                        toolCallId: part.toolCallId,
                                        toolName: part.toolName,
                                        output: part.output,
                                        providerOptions
                                    };
                                }
                        }
                    }),
                    providerOptions: message.providerOptions
                };
            }
        case "tool":
            {
                return {
                    role: "tool",
                    content: message.content.map((part)=>({
                            type: "tool-result",
                            toolCallId: part.toolCallId,
                            toolName: part.toolName,
                            output: part.output,
                            providerOptions: part.providerOptions
                        })),
                    providerOptions: message.providerOptions
                };
            }
        default:
            {
                const _exhaustiveCheck = role;
                throw new InvalidMessageRoleError({
                    role: _exhaustiveCheck
                });
            }
    }
}
async function downloadAssets(messages, download2, supportedUrls) {
    const plannedDownloads = messages.filter((message)=>message.role === "user").map((message)=>message.content).filter((content)=>Array.isArray(content)).flat().filter((part)=>part.type === "image" || part.type === "file").map((part)=>{
        var _a5;
        const mediaType = (_a5 = part.mediaType) != null ? _a5 : part.type === "image" ? "image/*" : void 0;
        let data = part.type === "image" ? part.image : part.data;
        if (typeof data === "string") {
            try {
                data = new URL(data);
            } catch (ignored) {}
        }
        return {
            mediaType,
            data
        };
    }).filter((part)=>part.data instanceof URL).map((part)=>({
            url: part.data,
            isUrlSupportedByModel: part.mediaType != null && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isUrlSupported"])({
                url: part.data.toString(),
                mediaType: part.mediaType,
                supportedUrls
            })
        }));
    const downloadedFiles = await download2(plannedDownloads);
    return Object.fromEntries(downloadedFiles.map((file, index)=>file == null ? null : [
            plannedDownloads[index].url.toString(),
            {
                data: file.data,
                mediaType: file.mediaType
            }
        ]).filter((file)=>file != null));
}
function convertPartToLanguageModelPart(part, downloadedAssets) {
    var _a5;
    if (part.type === "text") {
        return {
            type: "text",
            text: part.text,
            providerOptions: part.providerOptions
        };
    }
    let originalData;
    const type = part.type;
    switch(type){
        case "image":
            originalData = part.image;
            break;
        case "file":
            originalData = part.data;
            break;
        default:
            throw new Error(`Unsupported part type: ${type}`);
    }
    const { data: convertedData, mediaType: convertedMediaType } = convertToLanguageModelV2DataContent(originalData);
    let mediaType = convertedMediaType != null ? convertedMediaType : part.mediaType;
    let data = convertedData;
    if (data instanceof URL) {
        const downloadedFile = downloadedAssets[data.toString()];
        if (downloadedFile) {
            data = downloadedFile.data;
            mediaType != null ? mediaType : mediaType = downloadedFile.mediaType;
        }
    }
    switch(type){
        case "image":
            {
                if (data instanceof Uint8Array || typeof data === "string") {
                    mediaType = (_a5 = detectMediaType({
                        data,
                        signatures: imageMediaTypeSignatures
                    })) != null ? _a5 : mediaType;
                }
                return {
                    type: "file",
                    mediaType: mediaType != null ? mediaType : "image/*",
                    // any image
                    filename: void 0,
                    data,
                    providerOptions: part.providerOptions
                };
            }
        case "file":
            {
                if (mediaType == null) {
                    throw new Error(`Media type is missing for file part`);
                }
                return {
                    type: "file",
                    mediaType,
                    filename: part.filename,
                    data,
                    providerOptions: part.providerOptions
                };
            }
    }
}
;
// src/util/is-non-empty-object.ts
function isNonEmptyObject(object) {
    return object != null && Object.keys(object).length > 0;
}
// src/prompt/prepare-tools-and-tool-choice.ts
function prepareToolsAndToolChoice({ tools, toolChoice, activeTools }) {
    if (!isNonEmptyObject(tools)) {
        return {
            tools: void 0,
            toolChoice: void 0
        };
    }
    const filteredTools = activeTools != null ? Object.entries(tools).filter(([name5])=>activeTools.includes(name5)) : Object.entries(tools);
    return {
        tools: filteredTools.map(([name5, tool])=>{
            const toolType = tool.type;
            switch(toolType){
                case void 0:
                case "dynamic":
                case "function":
                    return {
                        type: "function",
                        name: name5,
                        description: tool.description,
                        inputSchema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["asSchema"])(tool.inputSchema).jsonSchema,
                        providerOptions: tool.providerOptions
                    };
                case "provider-defined":
                    return {
                        type: "provider-defined",
                        name: name5,
                        id: tool.id,
                        args: tool.args
                    };
                default:
                    {
                        const exhaustiveCheck = toolType;
                        throw new Error(`Unsupported tool type: ${exhaustiveCheck}`);
                    }
            }
        }),
        toolChoice: toolChoice == null ? {
            type: "auto"
        } : typeof toolChoice === "string" ? {
            type: toolChoice
        } : {
            type: "tool",
            toolName: toolChoice.toolName
        }
    };
}
;
;
;
;
;
;
var jsonValueSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].lazy(()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].null(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].boolean(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), jsonValueSchema),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(jsonValueSchema)
    ]));
// src/types/provider-metadata.ts
var providerMetadataSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), jsonValueSchema));
;
var textPartSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("text"),
    text: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    providerOptions: providerMetadataSchema.optional()
});
var imagePartSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("image"),
    image: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
        dataContentSchema,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].instanceof(URL)
    ]),
    mediaType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().optional(),
    providerOptions: providerMetadataSchema.optional()
});
var filePartSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("file"),
    data: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
        dataContentSchema,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].instanceof(URL)
    ]),
    filename: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().optional(),
    mediaType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    providerOptions: providerMetadataSchema.optional()
});
var reasoningPartSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("reasoning"),
    text: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    providerOptions: providerMetadataSchema.optional()
});
var toolCallPartSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("tool-call"),
    toolCallId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    toolName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    input: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].unknown(),
    providerOptions: providerMetadataSchema.optional(),
    providerExecuted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].boolean().optional()
});
var outputSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].discriminatedUnion("type", [
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("text"),
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("json"),
        value: jsonValueSchema
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("error-text"),
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("error-json"),
        value: jsonValueSchema
    }),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("content"),
        value: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("text"),
                text: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("media"),
                data: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                mediaType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
            })
        ]))
    })
]);
var toolResultPartSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("tool-result"),
    toolCallId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    toolName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    output: outputSchema,
    providerOptions: providerMetadataSchema.optional()
});
// src/prompt/message.ts
var systemModelMessageSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    role: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("system"),
    content: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    providerOptions: providerMetadataSchema.optional()
});
var userModelMessageSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    role: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("user"),
    content: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
            textPartSchema,
            imagePartSchema,
            filePartSchema
        ]))
    ]),
    providerOptions: providerMetadataSchema.optional()
});
var assistantModelMessageSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    role: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("assistant"),
    content: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
            textPartSchema,
            filePartSchema,
            reasoningPartSchema,
            toolCallPartSchema,
            toolResultPartSchema
        ]))
    ]),
    providerOptions: providerMetadataSchema.optional()
});
var toolModelMessageSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    role: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("tool"),
    content: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(toolResultPartSchema),
    providerOptions: providerMetadataSchema.optional()
});
var modelMessageSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    systemModelMessageSchema,
    userModelMessageSchema,
    assistantModelMessageSchema,
    toolModelMessageSchema
]);
// src/prompt/standardize-prompt.ts
async function standardizePrompt(prompt) {
    if (prompt.prompt == null && prompt.messages == null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "prompt or messages must be defined"
        });
    }
    if (prompt.prompt != null && prompt.messages != null) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "prompt and messages cannot be defined at the same time"
        });
    }
    if (prompt.system != null && typeof prompt.system !== "string") {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "system must be a string"
        });
    }
    let messages;
    if (prompt.prompt != null && typeof prompt.prompt === "string") {
        messages = [
            {
                role: "user",
                content: prompt.prompt
            }
        ];
    } else if (prompt.prompt != null && Array.isArray(prompt.prompt)) {
        messages = prompt.prompt;
    } else if (prompt.messages != null) {
        messages = prompt.messages;
    } else {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "prompt or messages must be defined"
        });
    }
    if (messages.length === 0) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "messages must not be empty"
        });
    }
    const validationResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["safeValidateTypes"])({
        value: messages,
        schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(modelMessageSchema)
    });
    if (!validationResult.success) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["InvalidPromptError"]({
            prompt,
            message: "The messages must be a ModelMessage[]. If you have passed a UIMessage[], you can use convertToModelMessages to convert them.",
            cause: validationResult.error
        });
    }
    return {
        messages,
        system: prompt.system
    };
}
;
var name3 = "AI_InvalidArgumentError";
var marker3 = `vercel.ai.error.${name3}`;
var symbol3 = Symbol.for(marker3);
var _a3;
var InvalidArgumentError = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"] {
    constructor({ parameter, value, message }){
        super({
            name: name3,
            message: `Invalid argument for parameter ${parameter}: ${message}`
        });
        this[_a3] = true;
        this.parameter = parameter;
        this.value = value;
    }
    static isInstance(error) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"].hasMarker(error, marker3);
    }
};
_a3 = symbol3;
// src/prompt/prepare-call-settings.ts
function prepareCallSettings({ maxOutputTokens, temperature, topP, topK, presencePenalty, frequencyPenalty, seed, stopSequences }) {
    if (maxOutputTokens != null) {
        if (!Number.isInteger(maxOutputTokens)) {
            throw new InvalidArgumentError({
                parameter: "maxOutputTokens",
                value: maxOutputTokens,
                message: "maxOutputTokens must be an integer"
            });
        }
        if (maxOutputTokens < 1) {
            throw new InvalidArgumentError({
                parameter: "maxOutputTokens",
                value: maxOutputTokens,
                message: "maxOutputTokens must be >= 1"
            });
        }
    }
    if (temperature != null) {
        if (typeof temperature !== "number") {
            throw new InvalidArgumentError({
                parameter: "temperature",
                value: temperature,
                message: "temperature must be a number"
            });
        }
    }
    if (topP != null) {
        if (typeof topP !== "number") {
            throw new InvalidArgumentError({
                parameter: "topP",
                value: topP,
                message: "topP must be a number"
            });
        }
    }
    if (topK != null) {
        if (typeof topK !== "number") {
            throw new InvalidArgumentError({
                parameter: "topK",
                value: topK,
                message: "topK must be a number"
            });
        }
    }
    if (presencePenalty != null) {
        if (typeof presencePenalty !== "number") {
            throw new InvalidArgumentError({
                parameter: "presencePenalty",
                value: presencePenalty,
                message: "presencePenalty must be a number"
            });
        }
    }
    if (frequencyPenalty != null) {
        if (typeof frequencyPenalty !== "number") {
            throw new InvalidArgumentError({
                parameter: "frequencyPenalty",
                value: frequencyPenalty,
                message: "frequencyPenalty must be a number"
            });
        }
    }
    if (seed != null) {
        if (!Number.isInteger(seed)) {
            throw new InvalidArgumentError({
                parameter: "seed",
                value: seed,
                message: "seed must be an integer"
            });
        }
    }
    return {
        maxOutputTokens,
        temperature,
        topP,
        topK,
        presencePenalty,
        frequencyPenalty,
        stopSequences,
        seed
    };
}
;
;
;
var name4 = "AI_RetryError";
var marker4 = `vercel.ai.error.${name4}`;
var symbol4 = Symbol.for(marker4);
var _a4;
var RetryError = class extends __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"] {
    constructor({ message, reason, errors }){
        super({
            name: name4,
            message
        });
        this[_a4] = true;
        this.reason = reason;
        this.errors = errors;
        this.lastError = errors[errors.length - 1];
    }
    static isInstance(error) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["AISDKError"].hasMarker(error, marker4);
    }
};
_a4 = symbol4;
// src/util/retry-with-exponential-backoff.ts
function getRetryDelayInMs({ error, exponentialBackoffDelay }) {
    const headers = error.responseHeaders;
    if (!headers) return exponentialBackoffDelay;
    let ms;
    const retryAfterMs = headers["retry-after-ms"];
    if (retryAfterMs) {
        const timeoutMs = parseFloat(retryAfterMs);
        if (!Number.isNaN(timeoutMs)) {
            ms = timeoutMs;
        }
    }
    const retryAfter = headers["retry-after"];
    if (retryAfter && ms === void 0) {
        const timeoutSeconds = parseFloat(retryAfter);
        if (!Number.isNaN(timeoutSeconds)) {
            ms = timeoutSeconds * 1e3;
        } else {
            ms = Date.parse(retryAfter) - Date.now();
        }
    }
    if (ms != null && !Number.isNaN(ms) && 0 <= ms && (ms < 60 * 1e3 || ms < exponentialBackoffDelay)) {
        return ms;
    }
    return exponentialBackoffDelay;
}
var retryWithExponentialBackoffRespectingRetryHeaders = ({ maxRetries = 2, initialDelayInMs = 2e3, backoffFactor = 2, abortSignal } = {})=>async (f)=>_retryWithExponentialBackoff(f, {
            maxRetries,
            delayInMs: initialDelayInMs,
            backoffFactor,
            abortSignal
        });
async function _retryWithExponentialBackoff(f, { maxRetries, delayInMs, backoffFactor, abortSignal }, errors = []) {
    try {
        return await f();
    } catch (error) {
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["isAbortError"])(error)) {
            throw error;
        }
        if (maxRetries === 0) {
            throw error;
        }
        const errorMessage = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getErrorMessage"])(error);
        const newErrors = [
            ...errors,
            error
        ];
        const tryNumber = newErrors.length;
        if (tryNumber > maxRetries) {
            throw new RetryError({
                message: `Failed after ${tryNumber} attempts. Last error: ${errorMessage}`,
                reason: "maxRetriesExceeded",
                errors: newErrors
            });
        }
        if (error instanceof Error && __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["APICallError"].isInstance(error) && error.isRetryable === true && tryNumber <= maxRetries) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["delay"])(getRetryDelayInMs({
                error,
                exponentialBackoffDelay: delayInMs
            }), {
                abortSignal
            });
            return _retryWithExponentialBackoff(f, {
                maxRetries,
                delayInMs: backoffFactor * delayInMs,
                backoffFactor,
                abortSignal
            }, newErrors);
        }
        if (tryNumber === 1) {
            throw error;
        }
        throw new RetryError({
            message: `Failed after ${tryNumber} attempts with non-retryable error: '${errorMessage}'`,
            reason: "errorNotRetryable",
            errors: newErrors
        });
    }
}
// src/util/prepare-retries.ts
function prepareRetries({ maxRetries, abortSignal }) {
    if (maxRetries != null) {
        if (!Number.isInteger(maxRetries)) {
            throw new InvalidArgumentError({
                parameter: "maxRetries",
                value: maxRetries,
                message: "maxRetries must be an integer"
            });
        }
        if (maxRetries < 0) {
            throw new InvalidArgumentError({
                parameter: "maxRetries",
                value: maxRetries,
                message: "maxRetries must be >= 0"
            });
        }
    }
    const maxRetriesResult = maxRetries != null ? maxRetries : 2;
    return {
        maxRetries: maxRetriesResult,
        retry: retryWithExponentialBackoffRespectingRetryHeaders({
            maxRetries: maxRetriesResult,
            abortSignal
        })
    };
}
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/node_modules/ms/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Helpers.
 */ var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var w = d * 7;
var y = d * 365.25;
/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} [options]
 * @throws {Error} throw an error if val is not a non-empty string or a number
 * @return {String|Number}
 * @api public
 */ module.exports = function(val, options) {
    options = options || {};
    var type = typeof val;
    if (type === 'string' && val.length > 0) {
        return parse(val);
    } else if (type === 'number' && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
    }
    throw new Error('val is not a non-empty string or a valid number. val=' + JSON.stringify(val));
};
/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */ function parse(str) {
    str = String(str);
    if (str.length > 100) {
        return;
    }
    var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(str);
    if (!match) {
        return;
    }
    var n = parseFloat(match[1]);
    var type = (match[2] || 'ms').toLowerCase();
    switch(type){
        case 'years':
        case 'year':
        case 'yrs':
        case 'yr':
        case 'y':
            return n * y;
        case 'weeks':
        case 'week':
        case 'w':
            return n * w;
        case 'days':
        case 'day':
        case 'd':
            return n * d;
        case 'hours':
        case 'hour':
        case 'hrs':
        case 'hr':
        case 'h':
            return n * h;
        case 'minutes':
        case 'minute':
        case 'mins':
        case 'min':
        case 'm':
            return n * m;
        case 'seconds':
        case 'second':
        case 'secs':
        case 'sec':
        case 's':
            return n * s;
        case 'milliseconds':
        case 'millisecond':
        case 'msecs':
        case 'msec':
        case 'ms':
            return n;
        default:
            return undefined;
    }
}
/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */ function fmtShort(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
        return Math.round(ms / d) + 'd';
    }
    if (msAbs >= h) {
        return Math.round(ms / h) + 'h';
    }
    if (msAbs >= m) {
        return Math.round(ms / m) + 'm';
    }
    if (msAbs >= s) {
        return Math.round(ms / s) + 's';
    }
    return ms + 'ms';
}
/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */ function fmtLong(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
        return plural(ms, msAbs, d, 'day');
    }
    if (msAbs >= h) {
        return plural(ms, msAbs, h, 'hour');
    }
    if (msAbs >= m) {
        return plural(ms, msAbs, m, 'minute');
    }
    if (msAbs >= s) {
        return plural(ms, msAbs, s, 'second');
    }
    return ms + ' ms';
}
/**
 * Pluralization helper.
 */ function plural(ms, msAbs, n, name) {
    var isPlural = msAbs >= n * 1.5;
    return Math.round(ms / n) + ' ' + name + (isPlural ? 's' : '');
}
}),
"[project]/frontend/node_modules/.pnpm/ms@2.1.3/node_modules/ms/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {

/**
 * Helpers.
 */ var s = 1000;
var m = s * 60;
var h = m * 60;
var d = h * 24;
var w = d * 7;
var y = d * 365.25;
/**
 * Parse or format the given `val`.
 *
 * Options:
 *
 *  - `long` verbose formatting [false]
 *
 * @param {String|Number} val
 * @param {Object} [options]
 * @throws {Error} throw an error if val is not a non-empty string or a number
 * @return {String|Number}
 * @api public
 */ module.exports = function(val, options) {
    options = options || {};
    var type = typeof val;
    if (type === 'string' && val.length > 0) {
        return parse(val);
    } else if (type === 'number' && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
    }
    throw new Error('val is not a non-empty string or a valid number. val=' + JSON.stringify(val));
};
/**
 * Parse the given `str` and return milliseconds.
 *
 * @param {String} str
 * @return {Number}
 * @api private
 */ function parse(str) {
    str = String(str);
    if (str.length > 100) {
        return;
    }
    var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(str);
    if (!match) {
        return;
    }
    var n = parseFloat(match[1]);
    var type = (match[2] || 'ms').toLowerCase();
    switch(type){
        case 'years':
        case 'year':
        case 'yrs':
        case 'yr':
        case 'y':
            return n * y;
        case 'weeks':
        case 'week':
        case 'w':
            return n * w;
        case 'days':
        case 'day':
        case 'd':
            return n * d;
        case 'hours':
        case 'hour':
        case 'hrs':
        case 'hr':
        case 'h':
            return n * h;
        case 'minutes':
        case 'minute':
        case 'mins':
        case 'min':
        case 'm':
            return n * m;
        case 'seconds':
        case 'second':
        case 'secs':
        case 'sec':
        case 's':
            return n * s;
        case 'milliseconds':
        case 'millisecond':
        case 'msecs':
        case 'msec':
        case 'ms':
            return n;
        default:
            return undefined;
    }
}
/**
 * Short format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */ function fmtShort(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
        return Math.round(ms / d) + 'd';
    }
    if (msAbs >= h) {
        return Math.round(ms / h) + 'h';
    }
    if (msAbs >= m) {
        return Math.round(ms / m) + 'm';
    }
    if (msAbs >= s) {
        return Math.round(ms / s) + 's';
    }
    return ms + 'ms';
}
/**
 * Long format for `ms`.
 *
 * @param {Number} ms
 * @return {String}
 * @api private
 */ function fmtLong(ms) {
    var msAbs = Math.abs(ms);
    if (msAbs >= d) {
        return plural(ms, msAbs, d, 'day');
    }
    if (msAbs >= h) {
        return plural(ms, msAbs, h, 'hour');
    }
    if (msAbs >= m) {
        return plural(ms, msAbs, m, 'minute');
    }
    if (msAbs >= s) {
        return plural(ms, msAbs, s, 'second');
    }
    return ms + ' ms';
}
/**
 * Pluralization helper.
 */ function plural(ms, msAbs, n, name) {
    var isPlural = msAbs >= n * 1.5;
    return Math.round(ms / n) + ' ' + name + (isPlural ? 's' : '');
}
}),
"[project]/node_modules/@workflow/utils/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "once",
    ()=>once,
    "parseDurationToDate",
    ()=>parseDurationToDate,
    "withResolvers",
    ()=>withResolvers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ms$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ms/index.js [app-route] (ecmascript)");
;
function withResolvers() {
    let resolve;
    let reject;
    const promise = new Promise((_resolve, _reject)=>{
        resolve = _resolve;
        reject = _reject;
    });
    return {
        promise,
        resolve,
        reject
    };
}
function once(fn) {
    const result = {
        get value () {
            const value = fn();
            Object.defineProperty(result, 'value', {
                value
            });
            return value;
        }
    };
    return result;
}
function parseDurationToDate(param) {
    if (typeof param === 'string') {
        const durationMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ms$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(param);
        if (typeof durationMs !== 'number' || durationMs < 0) {
            throw new Error(`Invalid duration: "${param}". Expected a valid duration string like "1s", "1m", "1h", etc.`);
        }
        return new Date(Date.now() + durationMs);
    } else if (typeof param === 'number') {
        if (param < 0 || !Number.isFinite(param)) {
            throw new Error(`Invalid duration: ${param}. Expected a non-negative finite number of milliseconds.`);
        }
        return new Date(Date.now() + param);
    } else if (param instanceof Date || param && typeof param === 'object' && typeof param.getTime === 'function') {
        // Handle both Date instances and date-like objects (from deserialization)
        return param instanceof Date ? param : new Date(param.getTime());
    } else {
        throw new Error(`Invalid duration parameter. Expected a duration string, number (milliseconds), or Date object.`);
    }
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/@workflow/utils/dist/get-port.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPort",
    ()=>getPort
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$util__$5b$external$5d$__$28$node$3a$util$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:util [external] (node:util, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:child_process [external] (node:child_process, cjs)");
;
;
;
const execFileAsync = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$util__$5b$external$5d$__$28$node$3a$util$2c$__cjs$29$__["promisify"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__["execFile"]);
/**
 * Parses a port string and returns it if valid (0-65535), otherwise undefined.
 */ function parsePort(value, radix = 10) {
    const port = parseInt(value, radix);
    if (!Number.isNaN(port) && port >= 0 && port <= 65535) {
        return port;
    }
    return undefined;
}
// NOTE: We build /proc paths dynamically to prevent @vercel/nft from tracing them.
// NFT's static analysis tries to bundle any file path literal it finds (e.g., '/proc/net/tcp').
// Since /proc is a virtual Linux filesystem, this causes build failures in @sveltejs/adapter-vercel.
const join = (arr, sep)=>arr.join(sep);
const PROC_ROOT = join([
    '',
    'proc'
], '/');
/**
 * Gets listening ports for the current process on Linux by reading /proc filesystem.
 * This approach requires no external commands and works on all Linux systems.
 */ async function getLinuxPort(pid) {
    const listenState = '0A'; // TCP LISTEN state in /proc/net/tcp
    const tcpFiles = [
        `${PROC_ROOT}/net/tcp`,
        `${PROC_ROOT}/net/tcp6`
    ];
    // Step 1: Get socket inodes from /proc/<pid>/fd/ in order
    // We preserve order to maintain deterministic behavior (return first port)
    // Use both array (for order) and Set (for O(1) lookup)
    const socketInodes = [];
    const socketInodesSet = new Set();
    const fdPath = `${PROC_ROOT}/${pid}/fd`;
    try {
        const fds = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readdir"])(fdPath);
        // Sort FDs numerically to ensure deterministic order (FDs are always numeric strings)
        const sortedFds = fds.sort((a, b)=>{
            const numA = Number.parseInt(a, 10);
            const numB = Number.parseInt(b, 10);
            return numA - numB;
        });
        const results = await Promise.allSettled(sortedFds.map(async (fd)=>{
            const link = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readlink"])(`${fdPath}/${fd}`);
            // Socket links look like: socket:[12345]
            const match = link.match(/^socket:\[(\d+)\]$/);
            return match?.[1] ?? null;
        }));
        for (const result of results){
            if (result.status === 'fulfilled' && result.value) {
                socketInodes.push(result.value);
                socketInodesSet.add(result.value);
            }
        }
    } catch  {
        // Process might not exist or no permission
        return undefined;
    }
    if (socketInodes.length === 0) {
        return undefined;
    }
    // Step 2: Read /proc/net/tcp and /proc/net/tcp6 to find listening sockets
    // Format: sl local_address rem_address st ... inode
    // local_address is hex IP:port, st=0A means LISTEN
    // We iterate through socket inodes in order to maintain deterministic behavior
    for (const tcpFile of tcpFiles){
        try {
            const content = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(tcpFile, 'utf8');
            const lines = content.split('\n').slice(1); // Skip header
            // Build a map of inode -> port for quick lookup
            const inodeToPort = new Map();
            for (const line of lines){
                if (!line.trim()) continue; // Skip empty lines
                const parts = line.trim().split(/\s+/);
                if (parts.length < 10) continue;
                const localAddr = parts[1]; // e.g., "00000000:0BB8" (0.0.0.0:3000)
                const state = parts[3]; // "0A" = LISTEN
                const inode = parts[9];
                if (!localAddr || state !== listenState || !inode) continue;
                if (!socketInodesSet.has(inode)) continue;
                // Extract port from hex format (e.g., "0BB8" -> 3000)
                const colonIndex = localAddr.indexOf(':');
                if (colonIndex === -1) continue;
                const portHex = localAddr.slice(colonIndex + 1);
                if (!portHex) continue;
                const port = parsePort(portHex, 16);
                if (port !== undefined) {
                    inodeToPort.set(inode, port);
                }
            }
            // Return the first port matching our socket inodes in order
            for (const inode of socketInodes){
                const port = inodeToPort.get(inode);
                if (port !== undefined) {
                    return port;
                }
            }
        } catch  {
            continue;
        }
    }
    return undefined;
}
async function getPort() {
    const { pid, platform } = process;
    let port;
    try {
        switch(platform){
            case 'linux':
                {
                    port = await getLinuxPort(pid);
                    break;
                }
            case 'darwin':
                {
                    const { stdout } = await execFileAsync('lsof', [
                        '-a',
                        '-i',
                        '-P',
                        '-n',
                        '-p',
                        pid.toString()
                    ]);
                    // Parse lsof output in JS instead of piping to awk
                    // Find first LISTEN line and extract port from address (e.g., "*:3000" or "127.0.0.1:3000")
                    const lines = stdout.split('\n');
                    for (const line of lines){
                        if (line.includes('LISTEN')) {
                            // Column 9 (0-indexed: 8) contains the address like "*:3000" or "127.0.0.1:3000"
                            const parts = line.trim().split(/\s+/);
                            const addr = parts[8];
                            if (addr) {
                                const colonIndex = addr.lastIndexOf(':');
                                if (colonIndex !== -1) {
                                    port = parsePort(addr.slice(colonIndex + 1));
                                    if (port !== undefined) {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
            case 'win32':
                {
                    // Use cmd to run the piped command
                    const { stdout } = await execFileAsync('cmd', [
                        '/c',
                        `netstat -ano | findstr ${pid} | findstr LISTENING`
                    ]);
                    const trimmedOutput = stdout.trim();
                    if (trimmedOutput) {
                        const lines = trimmedOutput.split('\n');
                        for (const line of lines){
                            // Extract port from the local address column
                            // Matches both IPv4 (e.g., "127.0.0.1:3000") and IPv6 bracket notation (e.g., "[::1]:3000")
                            const match = line.trim().match(/^\s*TCP\s+(?:\[[\da-f:]+\]|[\d.]+):(\d+)\s+/i);
                            if (match) {
                                port = parsePort(match[1]);
                                if (port !== undefined) {
                                    break;
                                }
                            }
                        }
                    }
                    break;
                }
        }
    } catch (error) {
        // In dev, it's helpful to know why detection failed
        if ("TURBOPACK compile-time truthy", 1) {
            console.debug('[getPort] Detection failed:', error);
        }
        return undefined;
    }
    return Number.isNaN(port) ? undefined : port;
} //# sourceMappingURL=get-port.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "once",
    ()=>once,
    "parseDurationToDate",
    ()=>parseDurationToDate,
    "withResolvers",
    ()=>withResolvers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ms$40$2$2e$1$2e$3$2f$node_modules$2f$ms$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ms@2.1.3/node_modules/ms/index.js [app-route] (ecmascript)");
;
function withResolvers() {
    let resolve;
    let reject;
    const promise = new Promise((_resolve, _reject)=>{
        resolve = _resolve;
        reject = _reject;
    });
    return {
        promise,
        resolve,
        reject
    };
}
function once(fn) {
    const result = {
        get value () {
            const value = fn();
            Object.defineProperty(result, 'value', {
                value
            });
            return value;
        }
    };
    return result;
}
function parseDurationToDate(param) {
    if (typeof param === 'string') {
        const durationMs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ms$40$2$2e$1$2e$3$2f$node_modules$2f$ms$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])(param);
        if (typeof durationMs !== 'number' || durationMs < 0) {
            throw new Error(`Invalid duration: "${param}". Expected a valid duration string like "1s", "1m", "1h", etc.`);
        }
        return new Date(Date.now() + durationMs);
    } else if (typeof param === 'number') {
        if (param < 0 || !Number.isFinite(param)) {
            throw new Error(`Invalid duration: ${param}. Expected a non-negative finite number of milliseconds.`);
        }
        return new Date(Date.now() + param);
    } else if (param instanceof Date || param && typeof param === 'object' && typeof param.getTime === 'function') {
        // Handle both Date instances and date-like objects (from deserialization)
        return param instanceof Date ? param : new Date(param.getTime());
    } else {
        throw new Error(`Invalid duration parameter. Expected a duration string, number (milliseconds), or Date object.`);
    }
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/get-port.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getPort",
    ()=>getPort
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs/promises [external] (node:fs/promises, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$util__$5b$external$5d$__$28$node$3a$util$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:util [external] (node:util, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:child_process [external] (node:child_process, cjs)");
;
;
;
const execFileAsync = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$util__$5b$external$5d$__$28$node$3a$util$2c$__cjs$29$__["promisify"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$child_process__$5b$external$5d$__$28$node$3a$child_process$2c$__cjs$29$__["execFile"]);
/**
 * Parses a port string and returns it if valid (0-65535), otherwise undefined.
 */ function parsePort(value, radix = 10) {
    const port = parseInt(value, radix);
    if (!Number.isNaN(port) && port >= 0 && port <= 65535) {
        return port;
    }
    return undefined;
}
// NOTE: We build /proc paths dynamically to prevent @vercel/nft from tracing them.
// NFT's static analysis tries to bundle any file path literal it finds (e.g., '/proc/net/tcp').
// Since /proc is a virtual Linux filesystem, this causes build failures in @sveltejs/adapter-vercel.
const join = (arr, sep)=>arr.join(sep);
const PROC_ROOT = join([
    '',
    'proc'
], '/');
/**
 * Gets listening ports for the current process on Linux by reading /proc filesystem.
 * This approach requires no external commands and works on all Linux systems.
 */ async function getLinuxPort(pid) {
    const listenState = '0A'; // TCP LISTEN state in /proc/net/tcp
    const tcpFiles = [
        `${PROC_ROOT}/net/tcp`,
        `${PROC_ROOT}/net/tcp6`
    ];
    // Step 1: Get socket inodes from /proc/<pid>/fd/ in order
    // We preserve order to maintain deterministic behavior (return first port)
    // Use both array (for order) and Set (for O(1) lookup)
    const socketInodes = [];
    const socketInodesSet = new Set();
    const fdPath = `${PROC_ROOT}/${pid}/fd`;
    try {
        const fds = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readdir"])(fdPath);
        // Sort FDs numerically to ensure deterministic order (FDs are always numeric strings)
        const sortedFds = fds.sort((a, b)=>{
            const numA = Number.parseInt(a, 10);
            const numB = Number.parseInt(b, 10);
            return numA - numB;
        });
        const results = await Promise.allSettled(sortedFds.map(async (fd)=>{
            const link = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readlink"])(`${fdPath}/${fd}`);
            // Socket links look like: socket:[12345]
            const match = link.match(/^socket:\[(\d+)\]$/);
            return match?.[1] ?? null;
        }));
        for (const result of results){
            if (result.status === 'fulfilled' && result.value) {
                socketInodes.push(result.value);
                socketInodesSet.add(result.value);
            }
        }
    } catch  {
        // Process might not exist or no permission
        return undefined;
    }
    if (socketInodes.length === 0) {
        return undefined;
    }
    // Step 2: Read /proc/net/tcp and /proc/net/tcp6 to find listening sockets
    // Format: sl local_address rem_address st ... inode
    // local_address is hex IP:port, st=0A means LISTEN
    // We iterate through socket inodes in order to maintain deterministic behavior
    for (const tcpFile of tcpFiles){
        try {
            const content = await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs$2f$promises__$5b$external$5d$__$28$node$3a$fs$2f$promises$2c$__cjs$29$__["readFile"])(tcpFile, 'utf8');
            const lines = content.split('\n').slice(1); // Skip header
            // Build a map of inode -> port for quick lookup
            const inodeToPort = new Map();
            for (const line of lines){
                if (!line.trim()) continue; // Skip empty lines
                const parts = line.trim().split(/\s+/);
                if (parts.length < 10) continue;
                const localAddr = parts[1]; // e.g., "00000000:0BB8" (0.0.0.0:3000)
                const state = parts[3]; // "0A" = LISTEN
                const inode = parts[9];
                if (!localAddr || state !== listenState || !inode) continue;
                if (!socketInodesSet.has(inode)) continue;
                // Extract port from hex format (e.g., "0BB8" -> 3000)
                const colonIndex = localAddr.indexOf(':');
                if (colonIndex === -1) continue;
                const portHex = localAddr.slice(colonIndex + 1);
                if (!portHex) continue;
                const port = parsePort(portHex, 16);
                if (port !== undefined) {
                    inodeToPort.set(inode, port);
                }
            }
            // Return the first port matching our socket inodes in order
            for (const inode of socketInodes){
                const port = inodeToPort.get(inode);
                if (port !== undefined) {
                    return port;
                }
            }
        } catch  {
            continue;
        }
    }
    return undefined;
}
async function getPort() {
    const { pid, platform } = process;
    let port;
    try {
        switch(platform){
            case 'linux':
                {
                    port = await getLinuxPort(pid);
                    break;
                }
            case 'darwin':
                {
                    const { stdout } = await execFileAsync('lsof', [
                        '-a',
                        '-i',
                        '-P',
                        '-n',
                        '-p',
                        pid.toString()
                    ]);
                    // Parse lsof output in JS instead of piping to awk
                    // Find first LISTEN line and extract port from address (e.g., "*:3000" or "127.0.0.1:3000")
                    const lines = stdout.split('\n');
                    for (const line of lines){
                        if (line.includes('LISTEN')) {
                            // Column 9 (0-indexed: 8) contains the address like "*:3000" or "127.0.0.1:3000"
                            const parts = line.trim().split(/\s+/);
                            const addr = parts[8];
                            if (addr) {
                                const colonIndex = addr.lastIndexOf(':');
                                if (colonIndex !== -1) {
                                    port = parsePort(addr.slice(colonIndex + 1));
                                    if (port !== undefined) {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    break;
                }
            case 'win32':
                {
                    // Use cmd to run the piped command
                    const { stdout } = await execFileAsync('cmd', [
                        '/c',
                        `netstat -ano | findstr ${pid} | findstr LISTENING`
                    ]);
                    const trimmedOutput = stdout.trim();
                    if (trimmedOutput) {
                        const lines = trimmedOutput.split('\n');
                        for (const line of lines){
                            // Extract port from the local address column
                            // Matches both IPv4 (e.g., "127.0.0.1:3000") and IPv6 bracket notation (e.g., "[::1]:3000")
                            const match = line.trim().match(/^\s*TCP\s+(?:\[[\da-f:]+\]|[\d.]+):(\d+)\s+/i);
                            if (match) {
                                port = parsePort(match[1]);
                                if (port !== undefined) {
                                    break;
                                }
                            }
                        }
                    }
                    break;
                }
        }
    } catch (error) {
        // In dev, it's helpful to know why detection failed
        if ("TURBOPACK compile-time truthy", 1) {
            console.debug('[getPort] Detection failed:', error);
        }
        return undefined;
    }
    return Number.isNaN(port) ? undefined : port;
} //# sourceMappingURL=get-port.js.map
}),
"[project]/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ERROR_SLUGS",
    ()=>ERROR_SLUGS,
    "FatalError",
    ()=>FatalError,
    "RetryableError",
    ()=>RetryableError,
    "WorkflowAPIError",
    ()=>WorkflowAPIError,
    "WorkflowError",
    ()=>WorkflowError,
    "WorkflowRunCancelledError",
    ()=>WorkflowRunCancelledError,
    "WorkflowRunFailedError",
    ()=>WorkflowRunFailedError,
    "WorkflowRunNotCompletedError",
    ()=>WorkflowRunNotCompletedError,
    "WorkflowRunNotFoundError",
    ()=>WorkflowRunNotFoundError,
    "WorkflowRuntimeError",
    ()=>WorkflowRuntimeError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/utils/dist/index.js [app-route] (ecmascript)");
;
const BASE_URL = 'https://useworkflow.dev/err';
/**
 * @internal
 * Check if a value is an Error without relying on Node.js utilities.
 * This is needed for error classes that can be used in VM contexts where
 * Node.js imports are not available.
 */ function isError(value) {
    return typeof value === 'object' && value !== null && 'name' in value && 'message' in value;
}
const ERROR_SLUGS = {
    NODE_JS_MODULE_IN_WORKFLOW: 'node-js-module-in-workflow',
    START_INVALID_WORKFLOW_FUNCTION: 'start-invalid-workflow-function',
    SERIALIZATION_FAILED: 'serialization-failed',
    WEBHOOK_INVALID_RESPOND_WITH_VALUE: 'webhook-invalid-respond-with-value',
    WEBHOOK_RESPONSE_NOT_SENT: 'webhook-response-not-sent',
    FETCH_IN_WORKFLOW_FUNCTION: 'fetch-in-workflow'
};
class WorkflowError extends Error {
    cause;
    constructor(message, options){
        const msgDocs = options?.slug ? `${message}\n\nLearn more: ${BASE_URL}/${options.slug}` : message;
        super(msgDocs, {
            cause: options?.cause
        });
        this.cause = options?.cause;
        if (options?.cause instanceof Error) {
            this.stack = `${this.stack}\nCaused by: ${options.cause.stack}`;
        }
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowError';
    }
}
class WorkflowAPIError extends WorkflowError {
    status;
    code;
    url;
    constructor(message, options){
        super(message, {
            cause: options?.cause
        });
        this.name = 'WorkflowAPIError';
        this.status = options?.status;
        this.code = options?.code;
        this.url = options?.url;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowAPIError';
    }
}
class WorkflowRunFailedError extends WorkflowError {
    runId;
    constructor(runId, error){
        // Create a proper Error instance from the StructuredError to set as cause
        // NOTE: custom error types do not get serialized/deserialized. Everything is an Error
        const causeError = new Error(error.message);
        if (error.stack) {
            causeError.stack = error.stack;
        }
        if (error.code) {
            causeError.code = error.code;
        }
        super(`Workflow run "${runId}" failed: ${error.message}`, {
            cause: causeError
        });
        this.name = 'WorkflowRunFailedError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunFailedError';
    }
}
class WorkflowRunNotCompletedError extends WorkflowError {
    runId;
    status;
    constructor(runId, status){
        super(`Workflow run "${runId}" has not completed`, {});
        this.name = 'WorkflowRunNotCompletedError';
        this.runId = runId;
        this.status = status;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunNotCompletedError';
    }
}
class WorkflowRuntimeError extends WorkflowError {
    constructor(message, options){
        super(message, {
            ...options
        });
        this.name = 'WorkflowRuntimeError';
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRuntimeError';
    }
}
class WorkflowRunNotFoundError extends WorkflowError {
    runId;
    constructor(runId){
        super(`Workflow run "${runId}" not found`, {});
        this.name = 'WorkflowRunNotFoundError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunNotFoundError';
    }
}
class WorkflowRunCancelledError extends WorkflowError {
    runId;
    constructor(runId){
        super(`Workflow run "${runId}" cancelled`, {});
        this.name = 'WorkflowRunCancelledError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunCancelledError';
    }
}
class FatalError extends Error {
    fatal = true;
    constructor(message){
        super(message);
        this.name = 'FatalError';
    }
    static is(value) {
        return isError(value) && value.name === 'FatalError';
    }
}
class RetryableError extends Error {
    /**
     * The Date when the step should be retried.
     */ retryAfter;
    constructor(message, options = {}){
        super(message);
        this.name = 'RetryableError';
        if (options.retryAfter !== undefined) {
            this.retryAfter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseDurationToDate"])(options.retryAfter);
        } else {
            // Default to 1 second (1000 milliseconds)
            this.retryAfter = new Date(Date.now() + 1000);
        }
    }
    static is(value) {
        return isError(value) && value.name === 'RetryableError';
    }
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ERROR_SLUGS",
    ()=>ERROR_SLUGS,
    "FatalError",
    ()=>FatalError,
    "RetryableError",
    ()=>RetryableError,
    "WorkflowAPIError",
    ()=>WorkflowAPIError,
    "WorkflowError",
    ()=>WorkflowError,
    "WorkflowRunCancelledError",
    ()=>WorkflowRunCancelledError,
    "WorkflowRunFailedError",
    ()=>WorkflowRunFailedError,
    "WorkflowRunNotCompletedError",
    ()=>WorkflowRunNotCompletedError,
    "WorkflowRunNotFoundError",
    ()=>WorkflowRunNotFoundError,
    "WorkflowRuntimeError",
    ()=>WorkflowRuntimeError
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/index.js [app-route] (ecmascript)");
;
const BASE_URL = 'https://useworkflow.dev/err';
/**
 * @internal
 * Check if a value is an Error without relying on Node.js utilities.
 * This is needed for error classes that can be used in VM contexts where
 * Node.js imports are not available.
 */ function isError(value) {
    return typeof value === 'object' && value !== null && 'name' in value && 'message' in value;
}
const ERROR_SLUGS = {
    NODE_JS_MODULE_IN_WORKFLOW: 'node-js-module-in-workflow',
    START_INVALID_WORKFLOW_FUNCTION: 'start-invalid-workflow-function',
    SERIALIZATION_FAILED: 'serialization-failed',
    WEBHOOK_INVALID_RESPOND_WITH_VALUE: 'webhook-invalid-respond-with-value',
    WEBHOOK_RESPONSE_NOT_SENT: 'webhook-response-not-sent',
    FETCH_IN_WORKFLOW_FUNCTION: 'fetch-in-workflow'
};
class WorkflowError extends Error {
    cause;
    constructor(message, options){
        const msgDocs = options?.slug ? `${message}\n\nLearn more: ${BASE_URL}/${options.slug}` : message;
        super(msgDocs, {
            cause: options?.cause
        });
        this.cause = options?.cause;
        if (options?.cause instanceof Error) {
            this.stack = `${this.stack}\nCaused by: ${options.cause.stack}`;
        }
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowError';
    }
}
class WorkflowAPIError extends WorkflowError {
    status;
    code;
    url;
    constructor(message, options){
        super(message, {
            cause: options?.cause
        });
        this.name = 'WorkflowAPIError';
        this.status = options?.status;
        this.code = options?.code;
        this.url = options?.url;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowAPIError';
    }
}
class WorkflowRunFailedError extends WorkflowError {
    runId;
    constructor(runId, error){
        // Create a proper Error instance from the StructuredError to set as cause
        // NOTE: custom error types do not get serialized/deserialized. Everything is an Error
        const causeError = new Error(error.message);
        if (error.stack) {
            causeError.stack = error.stack;
        }
        if (error.code) {
            causeError.code = error.code;
        }
        super(`Workflow run "${runId}" failed: ${error.message}`, {
            cause: causeError
        });
        this.name = 'WorkflowRunFailedError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunFailedError';
    }
}
class WorkflowRunNotCompletedError extends WorkflowError {
    runId;
    status;
    constructor(runId, status){
        super(`Workflow run "${runId}" has not completed`, {});
        this.name = 'WorkflowRunNotCompletedError';
        this.runId = runId;
        this.status = status;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunNotCompletedError';
    }
}
class WorkflowRuntimeError extends WorkflowError {
    constructor(message, options){
        super(message, {
            ...options
        });
        this.name = 'WorkflowRuntimeError';
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRuntimeError';
    }
}
class WorkflowRunNotFoundError extends WorkflowError {
    runId;
    constructor(runId){
        super(`Workflow run "${runId}" not found`, {});
        this.name = 'WorkflowRunNotFoundError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunNotFoundError';
    }
}
class WorkflowRunCancelledError extends WorkflowError {
    runId;
    constructor(runId){
        super(`Workflow run "${runId}" cancelled`, {});
        this.name = 'WorkflowRunCancelledError';
        this.runId = runId;
    }
    static is(value) {
        return isError(value) && value.name === 'WorkflowRunCancelledError';
    }
}
class FatalError extends Error {
    fatal = true;
    constructor(message){
        super(message);
        this.name = 'FatalError';
    }
    static is(value) {
        return isError(value) && value.name === 'FatalError';
    }
}
class RetryableError extends Error {
    /**
     * The Date when the step should be retried.
     */ retryAfter;
    constructor(message, options = {}){
        super(message);
        this.name = 'RetryableError';
        if (options.retryAfter !== undefined) {
            this.retryAfter = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseDurationToDate"])(options.retryAfter);
        } else {
            // Default to 1 second (1000 milliseconds)
            this.retryAfter = new Date(Date.now() + 1000);
        }
    }
    static is(value) {
        return isError(value) && value.name === 'RetryableError';
    }
} //# sourceMappingURL=index.js.map
}),
"[project]/node_modules/@vercel/functions/headers.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var headers_exports = {};
__export(headers_exports, {
    CITY_HEADER_NAME: ()=>CITY_HEADER_NAME,
    COUNTRY_HEADER_NAME: ()=>COUNTRY_HEADER_NAME,
    EMOJI_FLAG_UNICODE_STARTING_POSITION: ()=>EMOJI_FLAG_UNICODE_STARTING_POSITION,
    IP_HEADER_NAME: ()=>IP_HEADER_NAME,
    LATITUDE_HEADER_NAME: ()=>LATITUDE_HEADER_NAME,
    LONGITUDE_HEADER_NAME: ()=>LONGITUDE_HEADER_NAME,
    POSTAL_CODE_HEADER_NAME: ()=>POSTAL_CODE_HEADER_NAME,
    REGION_HEADER_NAME: ()=>REGION_HEADER_NAME,
    REQUEST_ID_HEADER_NAME: ()=>REQUEST_ID_HEADER_NAME,
    geolocation: ()=>geolocation,
    ipAddress: ()=>ipAddress
});
module.exports = __toCommonJS(headers_exports);
const CITY_HEADER_NAME = "x-vercel-ip-city";
const COUNTRY_HEADER_NAME = "x-vercel-ip-country";
const IP_HEADER_NAME = "x-real-ip";
const LATITUDE_HEADER_NAME = "x-vercel-ip-latitude";
const LONGITUDE_HEADER_NAME = "x-vercel-ip-longitude";
const REGION_HEADER_NAME = "x-vercel-ip-country-region";
const POSTAL_CODE_HEADER_NAME = "x-vercel-ip-postal-code";
const REQUEST_ID_HEADER_NAME = "x-vercel-id";
const EMOJI_FLAG_UNICODE_STARTING_POSITION = 127397;
function getHeader(headers, key) {
    return headers.get(key) ?? void 0;
}
function getHeaderWithDecode(request, key) {
    const header = getHeader(request.headers, key);
    return header ? decodeURIComponent(header) : void 0;
}
function getFlag(countryCode) {
    const regex = new RegExp("^[A-Z]{2}$").test(countryCode);
    if (!countryCode || !regex) return void 0;
    return String.fromCodePoint(...countryCode.split("").map((char)=>EMOJI_FLAG_UNICODE_STARTING_POSITION + char.charCodeAt(0)));
}
function ipAddress(input) {
    const headers = "headers" in input ? input.headers : input;
    return getHeader(headers, IP_HEADER_NAME);
}
function getRegionFromRequestId(requestId) {
    if (!requestId) {
        return "dev1";
    }
    return requestId.split(":")[0];
}
function geolocation(request) {
    return {
        // city name may be encoded to support multi-byte characters
        city: getHeaderWithDecode(request, CITY_HEADER_NAME),
        country: getHeader(request.headers, COUNTRY_HEADER_NAME),
        flag: getFlag(getHeader(request.headers, COUNTRY_HEADER_NAME)),
        countryRegion: getHeader(request.headers, REGION_HEADER_NAME),
        region: getRegionFromRequestId(getHeader(request.headers, REQUEST_ID_HEADER_NAME)),
        latitude: getHeader(request.headers, LATITUDE_HEADER_NAME),
        longitude: getHeader(request.headers, LONGITUDE_HEADER_NAME),
        postalCode: getHeader(request.headers, POSTAL_CODE_HEADER_NAME)
    };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    CITY_HEADER_NAME,
    COUNTRY_HEADER_NAME,
    EMOJI_FLAG_UNICODE_STARTING_POSITION,
    IP_HEADER_NAME,
    LATITUDE_HEADER_NAME,
    LONGITUDE_HEADER_NAME,
    POSTAL_CODE_HEADER_NAME,
    REGION_HEADER_NAME,
    REQUEST_ID_HEADER_NAME,
    geolocation,
    ipAddress
});
}),
"[project]/node_modules/@vercel/functions/get-env.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_env_exports = {};
__export(get_env_exports, {
    getEnv: ()=>getEnv
});
module.exports = __toCommonJS(get_env_exports);
const getEnv = (env = process.env)=>({
        /**
   * An indicator to show that System Environment Variables have been exposed to your project's Deployments.
   * @example "1"
   */ VERCEL: get(env, "VERCEL"),
        /**
   * An indicator that the code is running in a Continuous Integration environment.
   * @example "1"
   */ CI: get(env, "CI"),
        /**
   * The Environment that the app is deployed and running on.
   * @example "production"
   */ VERCEL_ENV: get(env, "VERCEL_ENV"),
        /**
   * The domain name of the generated deployment URL. The value does not include the protocol scheme https://.
   * NOTE: This Variable cannot be used in conjunction with Standard Deployment Protection.
   * @example "*.vercel.app"
   */ VERCEL_URL: get(env, "VERCEL_URL"),
        /**
   * The domain name of the generated Git branch URL. The value does not include the protocol scheme https://.
   * @example "*-git-*.vercel.app"
   */ VERCEL_BRANCH_URL: get(env, "VERCEL_BRANCH_URL"),
        /**
   * A production domain name of the project. This is useful to reliably generate links that point to production such as OG-image URLs.
   * The value does not include the protocol scheme https://.
   * @example "myproject.vercel.app"
   */ VERCEL_PROJECT_PRODUCTION_URL: get(env, "VERCEL_PROJECT_PRODUCTION_URL"),
        /**
   * The ID of the Region where the app is running.
   *
   * Possible values:
   * - arn1 (Stockholm, Sweden)
   * - bom1 (Mumbai, India)
   * - cdg1 (Paris, France)
   * - cle1 (Cleveland, USA)
   * - cpt1 (Cape Town, South Africa)
   * - dub1 (Dublin, Ireland)
   * - fra1 (Frankfurt, Germany)
   * - gru1 (São Paulo, Brazil)
   * - hkg1 (Hong Kong)
   * - hnd1 (Tokyo, Japan)
   * - iad1 (Washington, D.C., USA)
   * - icn1 (Seoul, South Korea)
   * - kix1 (Osaka, Japan)
   * - lhr1 (London, United Kingdom)
   * - pdx1 (Portland, USA)
   * - sfo1 (San Francisco, USA)
   * - sin1 (Singapore)
   * - syd1 (Sydney, Australia)
   * - dev1 (Development Region)
   *
   * @example "iad1"
   */ VERCEL_REGION: get(env, "VERCEL_REGION"),
        /**
   * The unique identifier for the deployment, which can be used to implement Skew Protection.
   * @example "dpl_7Gw5ZMBpQA8h9GF832KGp7nwbuh3"
   */ VERCEL_DEPLOYMENT_ID: get(env, "VERCEL_DEPLOYMENT_ID"),
        /**
   * When Skew Protection is enabled in Project Settings, this value is set to 1.
   * @example "1"
   */ VERCEL_SKEW_PROTECTION_ENABLED: get(env, "VERCEL_SKEW_PROTECTION_ENABLED"),
        /**
   * The Protection Bypass for Automation value, if the secret has been generated in the project's Deployment Protection settings.
   */ VERCEL_AUTOMATION_BYPASS_SECRET: get(env, "VERCEL_AUTOMATION_BYPASS_SECRET"),
        /**
   * The Git Provider the deployment is triggered from.
   * @example "github"
   */ VERCEL_GIT_PROVIDER: get(env, "VERCEL_GIT_PROVIDER"),
        /**
   * The origin repository the deployment is triggered from.
   * @example "my-site"
   */ VERCEL_GIT_REPO_SLUG: get(env, "VERCEL_GIT_REPO_SLUG"),
        /**
   * The account that owns the repository the deployment is triggered from.
   * @example "acme"
   */ VERCEL_GIT_REPO_OWNER: get(env, "VERCEL_GIT_REPO_OWNER"),
        /**
   * The ID of the repository the deployment is triggered from.
   * @example "117716146"
   */ VERCEL_GIT_REPO_ID: get(env, "VERCEL_GIT_REPO_ID"),
        /**
   * The git branch of the commit the deployment was triggered by.
   * @example "improve-about-page"
   */ VERCEL_GIT_COMMIT_REF: get(env, "VERCEL_GIT_COMMIT_REF"),
        /**
   * The git SHA of the commit the deployment was triggered by.
   * @example "fa1eade47b73733d6312d5abfad33ce9e4068081"
   */ VERCEL_GIT_COMMIT_SHA: get(env, "VERCEL_GIT_COMMIT_SHA"),
        /**
   * The message attached to the commit the deployment was triggered by.
   * @example "Update about page"
   */ VERCEL_GIT_COMMIT_MESSAGE: get(env, "VERCEL_GIT_COMMIT_MESSAGE"),
        /**
   * The username attached to the author of the commit that the project was deployed by.
   * @example "johndoe"
   */ VERCEL_GIT_COMMIT_AUTHOR_LOGIN: get(env, "VERCEL_GIT_COMMIT_AUTHOR_LOGIN"),
        /**
   * The name attached to the author of the commit that the project was deployed by.
   * @example "John Doe"
   */ VERCEL_GIT_COMMIT_AUTHOR_NAME: get(env, "VERCEL_GIT_COMMIT_AUTHOR_NAME"),
        /**
   * The git SHA of the last successful deployment for the project and branch.
   * NOTE: This Variable is only exposed when an Ignored Build Step is provided.
   * @example "fa1eade47b73733d6312d5abfad33ce9e4068080"
   */ VERCEL_GIT_PREVIOUS_SHA: get(env, "VERCEL_GIT_PREVIOUS_SHA"),
        /**
   * The pull request id the deployment was triggered by. If a deployment is created on a branch before a pull request is made, this value will be an empty string.
   * @example "23"
   */ VERCEL_GIT_PULL_REQUEST_ID: get(env, "VERCEL_GIT_PULL_REQUEST_ID")
    });
const get = (env, key)=>{
    const value = env[key];
    return value === "" ? void 0 : value;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getEnv
});
}),
"[project]/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_context_exports = {};
__export(get_context_exports, {
    SYMBOL_FOR_REQ_CONTEXT: ()=>SYMBOL_FOR_REQ_CONTEXT,
    getContext: ()=>getContext
});
module.exports = __toCommonJS(get_context_exports);
const SYMBOL_FOR_REQ_CONTEXT = Symbol.for("@vercel/request-context");
function getContext() {
    const fromSymbol = globalThis;
    return fromSymbol[SYMBOL_FOR_REQ_CONTEXT]?.get?.() ?? {};
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    SYMBOL_FOR_REQ_CONTEXT,
    getContext
});
}),
"[project]/node_modules/@vercel/functions/wait-until.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var wait_until_exports = {};
__export(wait_until_exports, {
    waitUntil: ()=>waitUntil
});
module.exports = __toCommonJS(wait_until_exports);
var import_get_context = __turbopack_context__.r("[project]/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const waitUntil = (promise)=>{
    if (promise === null || typeof promise !== "object" || typeof promise.then !== "function") {
        throw new TypeError(`waitUntil can only be called with a Promise, got ${typeof promise}`);
    }
    return (0, import_get_context.getContext)().waitUntil?.(promise);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    waitUntil
});
}),
"[project]/node_modules/@vercel/functions/middleware.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var middleware_exports = {};
__export(middleware_exports, {
    next: ()=>next,
    rewrite: ()=>rewrite
});
module.exports = __toCommonJS(middleware_exports);
function handleMiddlewareField(init, headers) {
    if (init?.request?.headers) {
        if (!(init.request.headers instanceof Headers)) {
            throw new Error("request.headers must be an instance of Headers");
        }
        const keys = [];
        for (const [key, value] of init.request.headers){
            headers.set("x-middleware-request-" + key, value);
            keys.push(key);
        }
        headers.set("x-middleware-override-headers", keys.join(","));
    }
}
function rewrite(destination, init) {
    const headers = new Headers(init?.headers ?? {});
    headers.set("x-middleware-rewrite", String(destination));
    handleMiddlewareField(init, headers);
    return new Response(null, {
        ...init,
        headers
    });
}
function next(init) {
    const headers = new Headers(init?.headers ?? {});
    headers.set("x-middleware-next", "1");
    handleMiddlewareField(init, headers);
    return new Response(null, {
        ...init,
        headers
    });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    next,
    rewrite
});
}),
"[project]/node_modules/@vercel/functions/cache/in-memory-cache.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var in_memory_cache_exports = {};
__export(in_memory_cache_exports, {
    InMemoryCache: ()=>InMemoryCache
});
module.exports = __toCommonJS(in_memory_cache_exports);
class InMemoryCache {
    constructor(){
        this.cache = {};
    }
    async get(key) {
        const entry = this.cache[key];
        if (entry) {
            if (entry.ttl && entry.lastModified + entry.ttl * 1e3 < Date.now()) {
                await this.delete(key);
                return null;
            }
            return entry.value;
        }
        return null;
    }
    async set(key, value, options) {
        this.cache[key] = {
            value,
            lastModified: Date.now(),
            ttl: options?.ttl,
            tags: new Set(options?.tags || [])
        };
    }
    async delete(key) {
        delete this.cache[key];
    }
    async expireTag(tag) {
        const tags = Array.isArray(tag) ? tag : [
            tag
        ];
        for(const key in this.cache){
            if (Object.prototype.hasOwnProperty.call(this.cache, key)) {
                const entry = this.cache[key];
                if (tags.some((t)=>entry.tags.has(t))) {
                    delete this.cache[key];
                }
            }
        }
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    InMemoryCache
});
}),
"[project]/node_modules/@vercel/functions/cache/build-client.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var build_client_exports = {};
__export(build_client_exports, {
    BuildCache: ()=>BuildCache
});
module.exports = __toCommonJS(build_client_exports);
var import_index = __turbopack_context__.r("[project]/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)");
class BuildCache {
    constructor({ endpoint, headers, onError, timeout = 500 }){
        this.get = async (key)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const res = await fetch(`${this.endpoint}${key}`, {
                    headers: this.headers,
                    method: "GET",
                    signal: controller.signal
                });
                if (res.status === 404) {
                    clearTimeout(timeoutId);
                    return null;
                }
                if (res.status === 200) {
                    const cacheState = res.headers.get(import_index.HEADERS_VERCEL_CACHE_STATE);
                    if (cacheState !== import_index.PkgCacheState.Fresh) {
                        res.body?.cancel?.();
                        clearTimeout(timeoutId);
                        return null;
                    }
                    const result = await res.json();
                    clearTimeout(timeoutId);
                    return result;
                } else {
                    clearTimeout(timeoutId);
                    throw new Error(`Failed to get cache: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
                return null;
            }
        };
        this.set = async (key, value, options)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const optionalHeaders = {};
                if (options?.ttl) {
                    optionalHeaders[import_index.HEADERS_VERCEL_REVALIDATE] = options.ttl.toString();
                }
                if (options?.tags && options.tags.length > 0) {
                    optionalHeaders[import_index.HEADERS_VERCEL_CACHE_TAGS] = options.tags.join(",");
                }
                if (options?.name) {
                    optionalHeaders[import_index.HEADERS_VERCEL_CACHE_ITEM_NAME] = options.name;
                }
                const res = await fetch(`${this.endpoint}${key}`, {
                    method: "POST",
                    headers: {
                        ...this.headers,
                        ...optionalHeaders
                    },
                    body: JSON.stringify(value),
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to set cache: ${res.status} ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.delete = async (key)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const res = await fetch(`${this.endpoint}${key}`, {
                    method: "DELETE",
                    headers: this.headers,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to delete cache: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.expireTag = async (tag)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                if (Array.isArray(tag)) {
                    tag = tag.join(",");
                }
                const res = await fetch(`${this.endpoint}revalidate?tags=${tag}`, {
                    method: "POST",
                    headers: this.headers,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to revalidate tag: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.endpoint = endpoint;
        this.headers = headers;
        this.onError = onError;
        this.timeout = timeout;
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    BuildCache
});
}),
"[project]/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var cache_exports = {};
__export(cache_exports, {
    HEADERS_VERCEL_CACHE_ITEM_NAME: ()=>HEADERS_VERCEL_CACHE_ITEM_NAME,
    HEADERS_VERCEL_CACHE_STATE: ()=>HEADERS_VERCEL_CACHE_STATE,
    HEADERS_VERCEL_CACHE_TAGS: ()=>HEADERS_VERCEL_CACHE_TAGS,
    HEADERS_VERCEL_REVALIDATE: ()=>HEADERS_VERCEL_REVALIDATE,
    PkgCacheState: ()=>PkgCacheState,
    getCache: ()=>getCache
});
module.exports = __toCommonJS(cache_exports);
var import_get_context = __turbopack_context__.r("[project]/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
var import_in_memory_cache = __turbopack_context__.r("[project]/node_modules/@vercel/functions/cache/in-memory-cache.js [app-route] (ecmascript)");
var import_build_client = __turbopack_context__.r("[project]/node_modules/@vercel/functions/cache/build-client.js [app-route] (ecmascript)");
const defaultKeyHashFunction = (key)=>{
    let hash = 5381;
    for(let i = 0; i < key.length; i++){
        hash = hash * 33 ^ key.charCodeAt(i);
    }
    return (hash >>> 0).toString(16);
};
const defaultNamespaceSeparator = "$";
let inMemoryCacheInstance = null;
let buildCacheInstance = null;
const getCache = (cacheOptions)=>{
    const resolveCache = ()=>{
        let cache;
        if ((0, import_get_context.getContext)().cache) {
            cache = (0, import_get_context.getContext)().cache;
        } else {
            cache = getCacheImplementation(process.env.SUSPENSE_CACHE_DEBUG === "true");
        }
        return cache;
    };
    return wrapWithKeyTransformation(resolveCache, createKeyTransformer(cacheOptions));
};
function createKeyTransformer(cacheOptions) {
    const hashFunction = cacheOptions?.keyHashFunction || defaultKeyHashFunction;
    return (key)=>{
        if (!cacheOptions?.namespace) return hashFunction(key);
        const separator = cacheOptions.namespaceSeparator || defaultNamespaceSeparator;
        return `${cacheOptions.namespace}${separator}${hashFunction(key)}`;
    };
}
function wrapWithKeyTransformation(resolveCache, makeKey) {
    return {
        get: (key)=>{
            return resolveCache().get(makeKey(key));
        },
        set: (key, value, options)=>{
            return resolveCache().set(makeKey(key), value, options);
        },
        delete: (key)=>{
            return resolveCache().delete(makeKey(key));
        },
        expireTag: (tag)=>{
            return resolveCache().expireTag(tag);
        }
    };
}
let warnedCacheUnavailable = false;
function getCacheImplementation(debug) {
    if (!inMemoryCacheInstance) {
        inMemoryCacheInstance = new import_in_memory_cache.InMemoryCache();
    }
    if (process.env.RUNTIME_CACHE_DISABLE_BUILD_CACHE === "true") {
        debug && console.log("Using InMemoryCache as build cache is disabled");
        return inMemoryCacheInstance;
    }
    const { RUNTIME_CACHE_ENDPOINT, RUNTIME_CACHE_HEADERS } = process.env;
    if (debug) {
        console.log("Runtime cache environment variables:", {
            RUNTIME_CACHE_ENDPOINT,
            RUNTIME_CACHE_HEADERS
        });
    }
    if (!RUNTIME_CACHE_ENDPOINT || !RUNTIME_CACHE_HEADERS) {
        if (!warnedCacheUnavailable) {
            console.warn("Runtime Cache unavailable in this environment. Falling back to in-memory cache.");
            warnedCacheUnavailable = true;
        }
        return inMemoryCacheInstance;
    }
    if (!buildCacheInstance) {
        let parsedHeaders = {};
        try {
            parsedHeaders = JSON.parse(RUNTIME_CACHE_HEADERS);
        } catch (e) {
            console.error("Failed to parse RUNTIME_CACHE_HEADERS:", e);
            return inMemoryCacheInstance;
        }
        let timeout = 500;
        if (process.env.RUNTIME_CACHE_TIMEOUT) {
            const parsed = parseInt(process.env.RUNTIME_CACHE_TIMEOUT, 10);
            if (!isNaN(parsed) && parsed > 0) {
                timeout = parsed;
            } else {
                console.warn(`Invalid RUNTIME_CACHE_TIMEOUT value: "${process.env.RUNTIME_CACHE_TIMEOUT}". Using default: ${timeout}ms`);
            }
        }
        buildCacheInstance = new import_build_client.BuildCache({
            endpoint: RUNTIME_CACHE_ENDPOINT,
            headers: parsedHeaders,
            onError: (error)=>console.error(error),
            timeout
        });
    }
    return buildCacheInstance;
}
var PkgCacheState = /* @__PURE__ */ ((PkgCacheState2)=>{
    PkgCacheState2["Fresh"] = "fresh";
    PkgCacheState2["Stale"] = "stale";
    PkgCacheState2["Expired"] = "expired";
    PkgCacheState2["NotFound"] = "notFound";
    PkgCacheState2["Error"] = "error";
    return PkgCacheState2;
})(PkgCacheState || {});
const HEADERS_VERCEL_CACHE_STATE = "x-vercel-cache-state";
const HEADERS_VERCEL_REVALIDATE = "x-vercel-revalidate";
const HEADERS_VERCEL_CACHE_TAGS = "x-vercel-cache-tags";
const HEADERS_VERCEL_CACHE_ITEM_NAME = "x-vercel-cache-item-name";
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    HEADERS_VERCEL_CACHE_ITEM_NAME,
    HEADERS_VERCEL_CACHE_STATE,
    HEADERS_VERCEL_CACHE_TAGS,
    HEADERS_VERCEL_REVALIDATE,
    PkgCacheState,
    getCache
});
}),
"[project]/node_modules/@vercel/functions/db-connections/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var db_connections_exports = {};
__export(db_connections_exports, {
    attachDatabasePool: ()=>attachDatabasePool,
    experimental_attachDatabasePool: ()=>experimental_attachDatabasePool
});
module.exports = __toCommonJS(db_connections_exports);
var import_get_context = __turbopack_context__.r("[project]/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const DEBUG = !!process.env.DEBUG;
function getIdleTimeout(dbPool) {
    if ("options" in dbPool && dbPool.options) {
        if ("idleTimeoutMillis" in dbPool.options) {
            return typeof dbPool.options.idleTimeoutMillis === "number" ? dbPool.options.idleTimeoutMillis : 1e4;
        }
        if ("maxIdleTimeMS" in dbPool.options) {
            return typeof dbPool.options.maxIdleTimeMS === "number" ? dbPool.options.maxIdleTimeMS : 0;
        }
        if ("status" in dbPool) {
            return 5e3;
        }
        if ("connect" in dbPool && "execute" in dbPool) {
            return 3e4;
        }
    }
    if ("config" in dbPool && dbPool.config) {
        if ("connectionConfig" in dbPool.config && dbPool.config.connectionConfig) {
            return dbPool.config.connectionConfig.idleTimeout || 6e4;
        }
        if ("idleTimeout" in dbPool.config) {
            return typeof dbPool.config.idleTimeout === "number" ? dbPool.config.idleTimeout : 6e4;
        }
    }
    if ("poolTimeout" in dbPool) {
        return typeof dbPool.poolTimeout === "number" ? dbPool.poolTimeout : 6e4;
    }
    if ("idleTimeout" in dbPool) {
        return typeof dbPool.idleTimeout === "number" ? dbPool.idleTimeout : 0;
    }
    return 1e4;
}
let idleTimeout = null;
let idleTimeoutResolve = ()=>{};
const bootTime = Date.now();
const maximumDuration = 15 * 60 * 1e3 - 1e3;
function waitUntilIdleTimeout(dbPool) {
    if (!process.env.VERCEL_URL || // This is not set during builds where we don't need to wait for idle connections using the mechanism
    !process.env.VERCEL_REGION) {
        return;
    }
    if (idleTimeout) {
        clearTimeout(idleTimeout);
        idleTimeoutResolve();
    }
    const promise = new Promise((resolve)=>{
        idleTimeoutResolve = resolve;
    });
    const waitTime = Math.min(getIdleTimeout(dbPool) + 100, maximumDuration - (Date.now() - bootTime));
    idleTimeout = setTimeout(()=>{
        idleTimeoutResolve?.();
        if (DEBUG) {
            console.log("Database pool idle timeout reached. Releasing connections.");
        }
    }, waitTime);
    const requestContext = (0, import_get_context.getContext)();
    if (requestContext?.waitUntil) {
        requestContext.waitUntil(promise);
    } else {
        console.warn("Pool release event triggered outside of request scope.");
    }
}
function attachDatabasePool(dbPool) {
    if (idleTimeout) {
        idleTimeoutResolve?.();
        clearTimeout(idleTimeout);
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && "idleTimeoutMillis" in dbPool.options) {
        const pgPool = dbPool;
        pgPool.on("release", ()=>{
            if (DEBUG) {
                console.log("Client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    } else if ("on" in dbPool && dbPool.on && "config" in dbPool && dbPool.config && "connectionConfig" in dbPool.config) {
        const mysqlPool = dbPool;
        mysqlPool.on("release", ()=>{
            if (DEBUG) {
                console.log("MySQL client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    } else if ("on" in dbPool && dbPool.on && "config" in dbPool && dbPool.config && "idleTimeout" in dbPool.config) {
        const mysql2Pool = dbPool;
        mysql2Pool.on("release", ()=>{
            if (DEBUG) {
                console.log("MySQL2/MariaDB client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && dbPool.options && "maxIdleTimeMS" in dbPool.options) {
        const mongoPool = dbPool;
        mongoPool.on("connectionCheckedOut", ()=>{
            if (DEBUG) {
                console.log("MongoDB connection checked out");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && dbPool.options && "socket" in dbPool.options) {
        const redisPool = dbPool;
        redisPool.on("end", ()=>{
            if (DEBUG) {
                console.log("Redis connection ended");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    throw new Error("Unsupported database pool type");
}
const experimental_attachDatabasePool = attachDatabasePool;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    attachDatabasePool,
    experimental_attachDatabasePool
});
}),
"[project]/node_modules/@vercel/functions/purge/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var purge_exports = {};
__export(purge_exports, {
    dangerouslyDeleteBySrcImage: ()=>dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag: ()=>dangerouslyDeleteByTag,
    invalidateBySrcImage: ()=>invalidateBySrcImage,
    invalidateByTag: ()=>invalidateByTag
});
module.exports = __toCommonJS(purge_exports);
var import_get_context = __turbopack_context__.r("[project]/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const invalidateByTag = (tag)=>{
    const api = (0, import_get_context.getContext)().purge;
    if (api) {
        return api.invalidateByTag(tag);
    }
    return Promise.resolve();
};
const dangerouslyDeleteByTag = (tag, options)=>{
    const api = (0, import_get_context.getContext)().purge;
    if (api) {
        return api.dangerouslyDeleteByTag(tag, options);
    }
    return Promise.resolve();
};
const invalidateBySrcImage = (src)=>{
    const api = (0, import_get_context.getContext)().purge;
    return api ? api.invalidateBySrcImage(src) : Promise.resolve();
};
const dangerouslyDeleteBySrcImage = (src, options)=>{
    const api = (0, import_get_context.getContext)().purge;
    return api ? api.dangerouslyDeleteBySrcImage(src, options) : Promise.resolve();
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag,
    invalidateBySrcImage,
    invalidateByTag
});
}),
"[project]/node_modules/@vercel/functions/addcachetag/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var addcachetag_exports = {};
__export(addcachetag_exports, {
    addCacheTag: ()=>addCacheTag
});
module.exports = __toCommonJS(addcachetag_exports);
var import_get_context = __turbopack_context__.r("[project]/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const addCacheTag = (tag)=>{
    const addCacheTag2 = (0, import_get_context.getContext)().addCacheTag;
    if (addCacheTag2) {
        return addCacheTag2(tag);
    }
    return Promise.resolve();
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    addCacheTag
});
}),
"[project]/node_modules/@vercel/functions/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var src_exports = {};
__export(src_exports, {
    addCacheTag: ()=>import_addcachetag.addCacheTag,
    attachDatabasePool: ()=>import_db_connections.attachDatabasePool,
    dangerouslyDeleteBySrcImage: ()=>import_purge.dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag: ()=>import_purge.dangerouslyDeleteByTag,
    experimental_attachDatabasePool: ()=>import_db_connections.experimental_attachDatabasePool,
    geolocation: ()=>import_headers.geolocation,
    getCache: ()=>import_cache.getCache,
    getEnv: ()=>import_get_env.getEnv,
    invalidateBySrcImage: ()=>import_purge.invalidateBySrcImage,
    invalidateByTag: ()=>import_purge.invalidateByTag,
    ipAddress: ()=>import_headers.ipAddress,
    next: ()=>import_middleware.next,
    rewrite: ()=>import_middleware.rewrite,
    waitUntil: ()=>import_wait_until.waitUntil
});
module.exports = __toCommonJS(src_exports);
var import_headers = __turbopack_context__.r("[project]/node_modules/@vercel/functions/headers.js [app-route] (ecmascript)");
var import_get_env = __turbopack_context__.r("[project]/node_modules/@vercel/functions/get-env.js [app-route] (ecmascript)");
var import_wait_until = __turbopack_context__.r("[project]/node_modules/@vercel/functions/wait-until.js [app-route] (ecmascript)");
var import_middleware = __turbopack_context__.r("[project]/node_modules/@vercel/functions/middleware.js [app-route] (ecmascript)");
var import_cache = __turbopack_context__.r("[project]/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)");
var import_db_connections = __turbopack_context__.r("[project]/node_modules/@vercel/functions/db-connections/index.js [app-route] (ecmascript)");
var import_purge = __turbopack_context__.r("[project]/node_modules/@vercel/functions/purge/index.js [app-route] (ecmascript)");
var import_addcachetag = __turbopack_context__.r("[project]/node_modules/@vercel/functions/addcachetag/index.js [app-route] (ecmascript)");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    addCacheTag,
    attachDatabasePool,
    dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag,
    experimental_attachDatabasePool,
    geolocation,
    getCache,
    getEnv,
    invalidateBySrcImage,
    invalidateByTag,
    ipAddress,
    next,
    rewrite,
    waitUntil
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/headers.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var headers_exports = {};
__export(headers_exports, {
    CITY_HEADER_NAME: ()=>CITY_HEADER_NAME,
    COUNTRY_HEADER_NAME: ()=>COUNTRY_HEADER_NAME,
    EMOJI_FLAG_UNICODE_STARTING_POSITION: ()=>EMOJI_FLAG_UNICODE_STARTING_POSITION,
    IP_HEADER_NAME: ()=>IP_HEADER_NAME,
    LATITUDE_HEADER_NAME: ()=>LATITUDE_HEADER_NAME,
    LONGITUDE_HEADER_NAME: ()=>LONGITUDE_HEADER_NAME,
    POSTAL_CODE_HEADER_NAME: ()=>POSTAL_CODE_HEADER_NAME,
    REGION_HEADER_NAME: ()=>REGION_HEADER_NAME,
    REQUEST_ID_HEADER_NAME: ()=>REQUEST_ID_HEADER_NAME,
    geolocation: ()=>geolocation,
    ipAddress: ()=>ipAddress
});
module.exports = __toCommonJS(headers_exports);
const CITY_HEADER_NAME = "x-vercel-ip-city";
const COUNTRY_HEADER_NAME = "x-vercel-ip-country";
const IP_HEADER_NAME = "x-real-ip";
const LATITUDE_HEADER_NAME = "x-vercel-ip-latitude";
const LONGITUDE_HEADER_NAME = "x-vercel-ip-longitude";
const REGION_HEADER_NAME = "x-vercel-ip-country-region";
const POSTAL_CODE_HEADER_NAME = "x-vercel-ip-postal-code";
const REQUEST_ID_HEADER_NAME = "x-vercel-id";
const EMOJI_FLAG_UNICODE_STARTING_POSITION = 127397;
function getHeader(headers, key) {
    return headers.get(key) ?? void 0;
}
function getHeaderWithDecode(request, key) {
    const header = getHeader(request.headers, key);
    return header ? decodeURIComponent(header) : void 0;
}
function getFlag(countryCode) {
    const regex = new RegExp("^[A-Z]{2}$").test(countryCode);
    if (!countryCode || !regex) return void 0;
    return String.fromCodePoint(...countryCode.split("").map((char)=>EMOJI_FLAG_UNICODE_STARTING_POSITION + char.charCodeAt(0)));
}
function ipAddress(input) {
    const headers = "headers" in input ? input.headers : input;
    return getHeader(headers, IP_HEADER_NAME);
}
function getRegionFromRequestId(requestId) {
    if (!requestId) {
        return "dev1";
    }
    return requestId.split(":")[0];
}
function geolocation(request) {
    return {
        // city name may be encoded to support multi-byte characters
        city: getHeaderWithDecode(request, CITY_HEADER_NAME),
        country: getHeader(request.headers, COUNTRY_HEADER_NAME),
        flag: getFlag(getHeader(request.headers, COUNTRY_HEADER_NAME)),
        countryRegion: getHeader(request.headers, REGION_HEADER_NAME),
        region: getRegionFromRequestId(getHeader(request.headers, REQUEST_ID_HEADER_NAME)),
        latitude: getHeader(request.headers, LATITUDE_HEADER_NAME),
        longitude: getHeader(request.headers, LONGITUDE_HEADER_NAME),
        postalCode: getHeader(request.headers, POSTAL_CODE_HEADER_NAME)
    };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    CITY_HEADER_NAME,
    COUNTRY_HEADER_NAME,
    EMOJI_FLAG_UNICODE_STARTING_POSITION,
    IP_HEADER_NAME,
    LATITUDE_HEADER_NAME,
    LONGITUDE_HEADER_NAME,
    POSTAL_CODE_HEADER_NAME,
    REGION_HEADER_NAME,
    REQUEST_ID_HEADER_NAME,
    geolocation,
    ipAddress
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-env.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_env_exports = {};
__export(get_env_exports, {
    getEnv: ()=>getEnv
});
module.exports = __toCommonJS(get_env_exports);
const getEnv = (env = process.env)=>({
        /**
   * An indicator to show that System Environment Variables have been exposed to your project's Deployments.
   * @example "1"
   */ VERCEL: get(env, "VERCEL"),
        /**
   * An indicator that the code is running in a Continuous Integration environment.
   * @example "1"
   */ CI: get(env, "CI"),
        /**
   * The Environment that the app is deployed and running on.
   * @example "production"
   */ VERCEL_ENV: get(env, "VERCEL_ENV"),
        /**
   * The domain name of the generated deployment URL. The value does not include the protocol scheme https://.
   * NOTE: This Variable cannot be used in conjunction with Standard Deployment Protection.
   * @example "*.vercel.app"
   */ VERCEL_URL: get(env, "VERCEL_URL"),
        /**
   * The domain name of the generated Git branch URL. The value does not include the protocol scheme https://.
   * @example "*-git-*.vercel.app"
   */ VERCEL_BRANCH_URL: get(env, "VERCEL_BRANCH_URL"),
        /**
   * A production domain name of the project. This is useful to reliably generate links that point to production such as OG-image URLs.
   * The value does not include the protocol scheme https://.
   * @example "myproject.vercel.app"
   */ VERCEL_PROJECT_PRODUCTION_URL: get(env, "VERCEL_PROJECT_PRODUCTION_URL"),
        /**
   * The ID of the Region where the app is running.
   *
   * Possible values:
   * - arn1 (Stockholm, Sweden)
   * - bom1 (Mumbai, India)
   * - cdg1 (Paris, France)
   * - cle1 (Cleveland, USA)
   * - cpt1 (Cape Town, South Africa)
   * - dub1 (Dublin, Ireland)
   * - fra1 (Frankfurt, Germany)
   * - gru1 (São Paulo, Brazil)
   * - hkg1 (Hong Kong)
   * - hnd1 (Tokyo, Japan)
   * - iad1 (Washington, D.C., USA)
   * - icn1 (Seoul, South Korea)
   * - kix1 (Osaka, Japan)
   * - lhr1 (London, United Kingdom)
   * - pdx1 (Portland, USA)
   * - sfo1 (San Francisco, USA)
   * - sin1 (Singapore)
   * - syd1 (Sydney, Australia)
   * - dev1 (Development Region)
   *
   * @example "iad1"
   */ VERCEL_REGION: get(env, "VERCEL_REGION"),
        /**
   * The unique identifier for the deployment, which can be used to implement Skew Protection.
   * @example "dpl_7Gw5ZMBpQA8h9GF832KGp7nwbuh3"
   */ VERCEL_DEPLOYMENT_ID: get(env, "VERCEL_DEPLOYMENT_ID"),
        /**
   * When Skew Protection is enabled in Project Settings, this value is set to 1.
   * @example "1"
   */ VERCEL_SKEW_PROTECTION_ENABLED: get(env, "VERCEL_SKEW_PROTECTION_ENABLED"),
        /**
   * The Protection Bypass for Automation value, if the secret has been generated in the project's Deployment Protection settings.
   */ VERCEL_AUTOMATION_BYPASS_SECRET: get(env, "VERCEL_AUTOMATION_BYPASS_SECRET"),
        /**
   * The Git Provider the deployment is triggered from.
   * @example "github"
   */ VERCEL_GIT_PROVIDER: get(env, "VERCEL_GIT_PROVIDER"),
        /**
   * The origin repository the deployment is triggered from.
   * @example "my-site"
   */ VERCEL_GIT_REPO_SLUG: get(env, "VERCEL_GIT_REPO_SLUG"),
        /**
   * The account that owns the repository the deployment is triggered from.
   * @example "acme"
   */ VERCEL_GIT_REPO_OWNER: get(env, "VERCEL_GIT_REPO_OWNER"),
        /**
   * The ID of the repository the deployment is triggered from.
   * @example "117716146"
   */ VERCEL_GIT_REPO_ID: get(env, "VERCEL_GIT_REPO_ID"),
        /**
   * The git branch of the commit the deployment was triggered by.
   * @example "improve-about-page"
   */ VERCEL_GIT_COMMIT_REF: get(env, "VERCEL_GIT_COMMIT_REF"),
        /**
   * The git SHA of the commit the deployment was triggered by.
   * @example "fa1eade47b73733d6312d5abfad33ce9e4068081"
   */ VERCEL_GIT_COMMIT_SHA: get(env, "VERCEL_GIT_COMMIT_SHA"),
        /**
   * The message attached to the commit the deployment was triggered by.
   * @example "Update about page"
   */ VERCEL_GIT_COMMIT_MESSAGE: get(env, "VERCEL_GIT_COMMIT_MESSAGE"),
        /**
   * The username attached to the author of the commit that the project was deployed by.
   * @example "johndoe"
   */ VERCEL_GIT_COMMIT_AUTHOR_LOGIN: get(env, "VERCEL_GIT_COMMIT_AUTHOR_LOGIN"),
        /**
   * The name attached to the author of the commit that the project was deployed by.
   * @example "John Doe"
   */ VERCEL_GIT_COMMIT_AUTHOR_NAME: get(env, "VERCEL_GIT_COMMIT_AUTHOR_NAME"),
        /**
   * The git SHA of the last successful deployment for the project and branch.
   * NOTE: This Variable is only exposed when an Ignored Build Step is provided.
   * @example "fa1eade47b73733d6312d5abfad33ce9e4068080"
   */ VERCEL_GIT_PREVIOUS_SHA: get(env, "VERCEL_GIT_PREVIOUS_SHA"),
        /**
   * The pull request id the deployment was triggered by. If a deployment is created on a branch before a pull request is made, this value will be an empty string.
   * @example "23"
   */ VERCEL_GIT_PULL_REQUEST_ID: get(env, "VERCEL_GIT_PULL_REQUEST_ID")
    });
const get = (env, key)=>{
    const value = env[key];
    return value === "" ? void 0 : value;
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getEnv
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_context_exports = {};
__export(get_context_exports, {
    SYMBOL_FOR_REQ_CONTEXT: ()=>SYMBOL_FOR_REQ_CONTEXT,
    getContext: ()=>getContext
});
module.exports = __toCommonJS(get_context_exports);
const SYMBOL_FOR_REQ_CONTEXT = Symbol.for("@vercel/request-context");
function getContext() {
    const fromSymbol = globalThis;
    return fromSymbol[SYMBOL_FOR_REQ_CONTEXT]?.get?.() ?? {};
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    SYMBOL_FOR_REQ_CONTEXT,
    getContext
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/wait-until.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var wait_until_exports = {};
__export(wait_until_exports, {
    waitUntil: ()=>waitUntil
});
module.exports = __toCommonJS(wait_until_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const waitUntil = (promise)=>{
    if (promise === null || typeof promise !== "object" || typeof promise.then !== "function") {
        throw new TypeError(`waitUntil can only be called with a Promise, got ${typeof promise}`);
    }
    return (0, import_get_context.getContext)().waitUntil?.(promise);
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    waitUntil
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/middleware.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var middleware_exports = {};
__export(middleware_exports, {
    next: ()=>next,
    rewrite: ()=>rewrite
});
module.exports = __toCommonJS(middleware_exports);
function handleMiddlewareField(init, headers) {
    if (init?.request?.headers) {
        if (!(init.request.headers instanceof Headers)) {
            throw new Error("request.headers must be an instance of Headers");
        }
        const keys = [];
        for (const [key, value] of init.request.headers){
            headers.set("x-middleware-request-" + key, value);
            keys.push(key);
        }
        headers.set("x-middleware-override-headers", keys.join(","));
    }
}
function rewrite(destination, init) {
    const headers = new Headers(init?.headers ?? {});
    headers.set("x-middleware-rewrite", String(destination));
    handleMiddlewareField(init, headers);
    return new Response(null, {
        ...init,
        headers
    });
}
function next(init) {
    const headers = new Headers(init?.headers ?? {});
    headers.set("x-middleware-next", "1");
    handleMiddlewareField(init, headers);
    return new Response(null, {
        ...init,
        headers
    });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    next,
    rewrite
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/in-memory-cache.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var in_memory_cache_exports = {};
__export(in_memory_cache_exports, {
    InMemoryCache: ()=>InMemoryCache
});
module.exports = __toCommonJS(in_memory_cache_exports);
class InMemoryCache {
    constructor(){
        this.cache = {};
    }
    async get(key) {
        const entry = this.cache[key];
        if (entry) {
            if (entry.ttl && entry.lastModified + entry.ttl * 1e3 < Date.now()) {
                await this.delete(key);
                return null;
            }
            return entry.value;
        }
        return null;
    }
    async set(key, value, options) {
        this.cache[key] = {
            value,
            lastModified: Date.now(),
            ttl: options?.ttl,
            tags: new Set(options?.tags || [])
        };
    }
    async delete(key) {
        delete this.cache[key];
    }
    async expireTag(tag) {
        const tags = Array.isArray(tag) ? tag : [
            tag
        ];
        for(const key in this.cache){
            if (Object.prototype.hasOwnProperty.call(this.cache, key)) {
                const entry = this.cache[key];
                if (tags.some((t)=>entry.tags.has(t))) {
                    delete this.cache[key];
                }
            }
        }
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    InMemoryCache
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/build-client.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var build_client_exports = {};
__export(build_client_exports, {
    BuildCache: ()=>BuildCache
});
module.exports = __toCommonJS(build_client_exports);
var import_index = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)");
class BuildCache {
    constructor({ endpoint, headers, onError, timeout = 500 }){
        this.get = async (key)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const res = await fetch(`${this.endpoint}${key}`, {
                    headers: this.headers,
                    method: "GET",
                    signal: controller.signal
                });
                if (res.status === 404) {
                    clearTimeout(timeoutId);
                    return null;
                }
                if (res.status === 200) {
                    const cacheState = res.headers.get(import_index.HEADERS_VERCEL_CACHE_STATE);
                    if (cacheState !== import_index.PkgCacheState.Fresh) {
                        res.body?.cancel?.();
                        clearTimeout(timeoutId);
                        return null;
                    }
                    const result = await res.json();
                    clearTimeout(timeoutId);
                    return result;
                } else {
                    clearTimeout(timeoutId);
                    throw new Error(`Failed to get cache: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
                return null;
            }
        };
        this.set = async (key, value, options)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const optionalHeaders = {};
                if (options?.ttl) {
                    optionalHeaders[import_index.HEADERS_VERCEL_REVALIDATE] = options.ttl.toString();
                }
                if (options?.tags && options.tags.length > 0) {
                    optionalHeaders[import_index.HEADERS_VERCEL_CACHE_TAGS] = options.tags.join(",");
                }
                if (options?.name) {
                    optionalHeaders[import_index.HEADERS_VERCEL_CACHE_ITEM_NAME] = options.name;
                }
                const res = await fetch(`${this.endpoint}${key}`, {
                    method: "POST",
                    headers: {
                        ...this.headers,
                        ...optionalHeaders
                    },
                    body: JSON.stringify(value),
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to set cache: ${res.status} ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.delete = async (key)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                const res = await fetch(`${this.endpoint}${key}`, {
                    method: "DELETE",
                    headers: this.headers,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to delete cache: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.expireTag = async (tag)=>{
            const controller = new AbortController();
            const timeoutId = setTimeout(()=>controller.abort(), this.timeout);
            try {
                if (Array.isArray(tag)) {
                    tag = tag.join(",");
                }
                const res = await fetch(`${this.endpoint}revalidate?tags=${tag}`, {
                    method: "POST",
                    headers: this.headers,
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.status !== 200) {
                    throw new Error(`Failed to revalidate tag: ${res.statusText}`);
                }
            } catch (error) {
                clearTimeout(timeoutId);
                if (error.name === "AbortError") {
                    const timeoutError = new Error(`Cache request timed out after ${this.timeout}ms`);
                    timeoutError.stack = error.stack;
                    this.onError?.(timeoutError);
                } else {
                    this.onError?.(error);
                }
            }
        };
        this.endpoint = endpoint;
        this.headers = headers;
        this.onError = onError;
        this.timeout = timeout;
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    BuildCache
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var cache_exports = {};
__export(cache_exports, {
    HEADERS_VERCEL_CACHE_ITEM_NAME: ()=>HEADERS_VERCEL_CACHE_ITEM_NAME,
    HEADERS_VERCEL_CACHE_STATE: ()=>HEADERS_VERCEL_CACHE_STATE,
    HEADERS_VERCEL_CACHE_TAGS: ()=>HEADERS_VERCEL_CACHE_TAGS,
    HEADERS_VERCEL_REVALIDATE: ()=>HEADERS_VERCEL_REVALIDATE,
    PkgCacheState: ()=>PkgCacheState,
    getCache: ()=>getCache
});
module.exports = __toCommonJS(cache_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
var import_in_memory_cache = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/in-memory-cache.js [app-route] (ecmascript)");
var import_build_client = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/build-client.js [app-route] (ecmascript)");
const defaultKeyHashFunction = (key)=>{
    let hash = 5381;
    for(let i = 0; i < key.length; i++){
        hash = hash * 33 ^ key.charCodeAt(i);
    }
    return (hash >>> 0).toString(16);
};
const defaultNamespaceSeparator = "$";
let inMemoryCacheInstance = null;
let buildCacheInstance = null;
const getCache = (cacheOptions)=>{
    const resolveCache = ()=>{
        let cache;
        if ((0, import_get_context.getContext)().cache) {
            cache = (0, import_get_context.getContext)().cache;
        } else {
            cache = getCacheImplementation(process.env.SUSPENSE_CACHE_DEBUG === "true");
        }
        return cache;
    };
    return wrapWithKeyTransformation(resolveCache, createKeyTransformer(cacheOptions));
};
function createKeyTransformer(cacheOptions) {
    const hashFunction = cacheOptions?.keyHashFunction || defaultKeyHashFunction;
    return (key)=>{
        if (!cacheOptions?.namespace) return hashFunction(key);
        const separator = cacheOptions.namespaceSeparator || defaultNamespaceSeparator;
        return `${cacheOptions.namespace}${separator}${hashFunction(key)}`;
    };
}
function wrapWithKeyTransformation(resolveCache, makeKey) {
    return {
        get: (key)=>{
            return resolveCache().get(makeKey(key));
        },
        set: (key, value, options)=>{
            return resolveCache().set(makeKey(key), value, options);
        },
        delete: (key)=>{
            return resolveCache().delete(makeKey(key));
        },
        expireTag: (tag)=>{
            return resolveCache().expireTag(tag);
        }
    };
}
let warnedCacheUnavailable = false;
function getCacheImplementation(debug) {
    if (!inMemoryCacheInstance) {
        inMemoryCacheInstance = new import_in_memory_cache.InMemoryCache();
    }
    if (process.env.RUNTIME_CACHE_DISABLE_BUILD_CACHE === "true") {
        debug && console.log("Using InMemoryCache as build cache is disabled");
        return inMemoryCacheInstance;
    }
    const { RUNTIME_CACHE_ENDPOINT, RUNTIME_CACHE_HEADERS } = process.env;
    if (debug) {
        console.log("Runtime cache environment variables:", {
            RUNTIME_CACHE_ENDPOINT,
            RUNTIME_CACHE_HEADERS
        });
    }
    if (!RUNTIME_CACHE_ENDPOINT || !RUNTIME_CACHE_HEADERS) {
        if (!warnedCacheUnavailable) {
            console.warn("Runtime Cache unavailable in this environment. Falling back to in-memory cache.");
            warnedCacheUnavailable = true;
        }
        return inMemoryCacheInstance;
    }
    if (!buildCacheInstance) {
        let parsedHeaders = {};
        try {
            parsedHeaders = JSON.parse(RUNTIME_CACHE_HEADERS);
        } catch (e) {
            console.error("Failed to parse RUNTIME_CACHE_HEADERS:", e);
            return inMemoryCacheInstance;
        }
        let timeout = 500;
        if (process.env.RUNTIME_CACHE_TIMEOUT) {
            const parsed = parseInt(process.env.RUNTIME_CACHE_TIMEOUT, 10);
            if (!isNaN(parsed) && parsed > 0) {
                timeout = parsed;
            } else {
                console.warn(`Invalid RUNTIME_CACHE_TIMEOUT value: "${process.env.RUNTIME_CACHE_TIMEOUT}". Using default: ${timeout}ms`);
            }
        }
        buildCacheInstance = new import_build_client.BuildCache({
            endpoint: RUNTIME_CACHE_ENDPOINT,
            headers: parsedHeaders,
            onError: (error)=>console.error(error),
            timeout
        });
    }
    return buildCacheInstance;
}
var PkgCacheState = /* @__PURE__ */ ((PkgCacheState2)=>{
    PkgCacheState2["Fresh"] = "fresh";
    PkgCacheState2["Stale"] = "stale";
    PkgCacheState2["Expired"] = "expired";
    PkgCacheState2["NotFound"] = "notFound";
    PkgCacheState2["Error"] = "error";
    return PkgCacheState2;
})(PkgCacheState || {});
const HEADERS_VERCEL_CACHE_STATE = "x-vercel-cache-state";
const HEADERS_VERCEL_REVALIDATE = "x-vercel-revalidate";
const HEADERS_VERCEL_CACHE_TAGS = "x-vercel-cache-tags";
const HEADERS_VERCEL_CACHE_ITEM_NAME = "x-vercel-cache-item-name";
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    HEADERS_VERCEL_CACHE_ITEM_NAME,
    HEADERS_VERCEL_CACHE_STATE,
    HEADERS_VERCEL_CACHE_TAGS,
    HEADERS_VERCEL_REVALIDATE,
    PkgCacheState,
    getCache
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/db-connections/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var db_connections_exports = {};
__export(db_connections_exports, {
    attachDatabasePool: ()=>attachDatabasePool,
    experimental_attachDatabasePool: ()=>experimental_attachDatabasePool
});
module.exports = __toCommonJS(db_connections_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const DEBUG = !!process.env.DEBUG;
function getIdleTimeout(dbPool) {
    if ("options" in dbPool && dbPool.options) {
        if ("idleTimeoutMillis" in dbPool.options) {
            return typeof dbPool.options.idleTimeoutMillis === "number" ? dbPool.options.idleTimeoutMillis : 1e4;
        }
        if ("maxIdleTimeMS" in dbPool.options) {
            return typeof dbPool.options.maxIdleTimeMS === "number" ? dbPool.options.maxIdleTimeMS : 0;
        }
        if ("status" in dbPool) {
            return 5e3;
        }
        if ("connect" in dbPool && "execute" in dbPool) {
            return 3e4;
        }
    }
    if ("config" in dbPool && dbPool.config) {
        if ("connectionConfig" in dbPool.config && dbPool.config.connectionConfig) {
            return dbPool.config.connectionConfig.idleTimeout || 6e4;
        }
        if ("idleTimeout" in dbPool.config) {
            return typeof dbPool.config.idleTimeout === "number" ? dbPool.config.idleTimeout : 6e4;
        }
    }
    if ("poolTimeout" in dbPool) {
        return typeof dbPool.poolTimeout === "number" ? dbPool.poolTimeout : 6e4;
    }
    if ("idleTimeout" in dbPool) {
        return typeof dbPool.idleTimeout === "number" ? dbPool.idleTimeout : 0;
    }
    return 1e4;
}
let idleTimeout = null;
let idleTimeoutResolve = ()=>{};
const bootTime = Date.now();
const maximumDuration = 15 * 60 * 1e3 - 1e3;
function waitUntilIdleTimeout(dbPool) {
    if (!process.env.VERCEL_URL || // This is not set during builds where we don't need to wait for idle connections using the mechanism
    !process.env.VERCEL_REGION) {
        return;
    }
    if (idleTimeout) {
        clearTimeout(idleTimeout);
        idleTimeoutResolve();
    }
    const promise = new Promise((resolve)=>{
        idleTimeoutResolve = resolve;
    });
    const waitTime = Math.min(getIdleTimeout(dbPool) + 100, maximumDuration - (Date.now() - bootTime));
    idleTimeout = setTimeout(()=>{
        idleTimeoutResolve?.();
        if (DEBUG) {
            console.log("Database pool idle timeout reached. Releasing connections.");
        }
    }, waitTime);
    const requestContext = (0, import_get_context.getContext)();
    if (requestContext?.waitUntil) {
        requestContext.waitUntil(promise);
    } else {
        console.warn("Pool release event triggered outside of request scope.");
    }
}
function attachDatabasePool(dbPool) {
    if (idleTimeout) {
        idleTimeoutResolve?.();
        clearTimeout(idleTimeout);
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && "idleTimeoutMillis" in dbPool.options) {
        const pgPool = dbPool;
        pgPool.on("release", ()=>{
            if (DEBUG) {
                console.log("Client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    } else if ("on" in dbPool && dbPool.on && "config" in dbPool && dbPool.config && "connectionConfig" in dbPool.config) {
        const mysqlPool = dbPool;
        mysqlPool.on("release", ()=>{
            if (DEBUG) {
                console.log("MySQL client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    } else if ("on" in dbPool && dbPool.on && "config" in dbPool && dbPool.config && "idleTimeout" in dbPool.config) {
        const mysql2Pool = dbPool;
        mysql2Pool.on("release", ()=>{
            if (DEBUG) {
                console.log("MySQL2/MariaDB client released from pool");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && dbPool.options && "maxIdleTimeMS" in dbPool.options) {
        const mongoPool = dbPool;
        mongoPool.on("connectionCheckedOut", ()=>{
            if (DEBUG) {
                console.log("MongoDB connection checked out");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    if ("on" in dbPool && dbPool.on && "options" in dbPool && dbPool.options && "socket" in dbPool.options) {
        const redisPool = dbPool;
        redisPool.on("end", ()=>{
            if (DEBUG) {
                console.log("Redis connection ended");
            }
            waitUntilIdleTimeout(dbPool);
        });
        return;
    }
    throw new Error("Unsupported database pool type");
}
const experimental_attachDatabasePool = attachDatabasePool;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    attachDatabasePool,
    experimental_attachDatabasePool
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/purge/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var purge_exports = {};
__export(purge_exports, {
    dangerouslyDeleteBySrcImage: ()=>dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag: ()=>dangerouslyDeleteByTag,
    invalidateBySrcImage: ()=>invalidateBySrcImage,
    invalidateByTag: ()=>invalidateByTag
});
module.exports = __toCommonJS(purge_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const invalidateByTag = (tag)=>{
    const api = (0, import_get_context.getContext)().purge;
    if (api) {
        return api.invalidateByTag(tag);
    }
    return Promise.resolve();
};
const dangerouslyDeleteByTag = (tag, options)=>{
    const api = (0, import_get_context.getContext)().purge;
    if (api) {
        return api.dangerouslyDeleteByTag(tag, options);
    }
    return Promise.resolve();
};
const invalidateBySrcImage = (src)=>{
    const api = (0, import_get_context.getContext)().purge;
    return api ? api.invalidateBySrcImage(src) : Promise.resolve();
};
const dangerouslyDeleteBySrcImage = (src, options)=>{
    const api = (0, import_get_context.getContext)().purge;
    return api ? api.dangerouslyDeleteBySrcImage(src, options) : Promise.resolve();
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag,
    invalidateBySrcImage,
    invalidateByTag
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/addcachetag/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var addcachetag_exports = {};
__export(addcachetag_exports, {
    addCacheTag: ()=>addCacheTag
});
module.exports = __toCommonJS(addcachetag_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-context.js [app-route] (ecmascript)");
const addCacheTag = (tag)=>{
    const addCacheTag2 = (0, import_get_context.getContext)().addCacheTag;
    if (addCacheTag2) {
        return addCacheTag2(tag);
    }
    return Promise.resolve();
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    addCacheTag
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var src_exports = {};
__export(src_exports, {
    addCacheTag: ()=>import_addcachetag.addCacheTag,
    attachDatabasePool: ()=>import_db_connections.attachDatabasePool,
    dangerouslyDeleteBySrcImage: ()=>import_purge.dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag: ()=>import_purge.dangerouslyDeleteByTag,
    experimental_attachDatabasePool: ()=>import_db_connections.experimental_attachDatabasePool,
    geolocation: ()=>import_headers.geolocation,
    getCache: ()=>import_cache.getCache,
    getEnv: ()=>import_get_env.getEnv,
    invalidateBySrcImage: ()=>import_purge.invalidateBySrcImage,
    invalidateByTag: ()=>import_purge.invalidateByTag,
    ipAddress: ()=>import_headers.ipAddress,
    next: ()=>import_middleware.next,
    rewrite: ()=>import_middleware.rewrite,
    waitUntil: ()=>import_wait_until.waitUntil
});
module.exports = __toCommonJS(src_exports);
var import_headers = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/headers.js [app-route] (ecmascript)");
var import_get_env = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/get-env.js [app-route] (ecmascript)");
var import_wait_until = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/wait-until.js [app-route] (ecmascript)");
var import_middleware = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/middleware.js [app-route] (ecmascript)");
var import_cache = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/cache/index.js [app-route] (ecmascript)");
var import_db_connections = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/db-connections/index.js [app-route] (ecmascript)");
var import_purge = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/purge/index.js [app-route] (ecmascript)");
var import_addcachetag = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/addcachetag/index.js [app-route] (ecmascript)");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    addCacheTag,
    attachDatabasePool,
    dangerouslyDeleteBySrcImage,
    dangerouslyDeleteByTag,
    experimental_attachDatabasePool,
    geolocation,
    getCache,
    getEnv,
    invalidateBySrcImage,
    invalidateByTag,
    ipAddress,
    next,
    rewrite,
    waitUntil
});
}),
"[project]/node_modules/devalue/src/utils.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** @type {Record<string, string>} */ __turbopack_context__.s([
    "DevalueError",
    ()=>DevalueError,
    "enumerable_symbols",
    ()=>enumerable_symbols,
    "escaped",
    ()=>escaped,
    "get_type",
    ()=>get_type,
    "is_plain_object",
    ()=>is_plain_object,
    "is_primitive",
    ()=>is_primitive,
    "stringify_key",
    ()=>stringify_key,
    "stringify_string",
    ()=>stringify_string
]);
const escaped = {
    '<': '\\u003C',
    '\\': '\\\\',
    '\b': '\\b',
    '\f': '\\f',
    '\n': '\\n',
    '\r': '\\r',
    '\t': '\\t',
    '\u2028': '\\u2028',
    '\u2029': '\\u2029'
};
class DevalueError extends Error {
    /**
	 * @param {string} message
	 * @param {string[]} keys
	 * @param {any} [value] - The value that failed to be serialized
	 * @param {any} [root] - The root value being serialized
	 */ constructor(message, keys, value, root){
        super(message);
        this.name = 'DevalueError';
        this.path = keys.join('');
        this.value = value;
        this.root = root;
    }
}
function is_primitive(thing) {
    return Object(thing) !== thing;
}
const object_proto_names = /* @__PURE__ */ Object.getOwnPropertyNames(Object.prototype).sort().join('\0');
function is_plain_object(thing) {
    const proto = Object.getPrototypeOf(thing);
    return proto === Object.prototype || proto === null || Object.getPrototypeOf(proto) === null || Object.getOwnPropertyNames(proto).sort().join('\0') === object_proto_names;
}
function get_type(thing) {
    return Object.prototype.toString.call(thing).slice(8, -1);
}
/** @param {string} char */ function get_escaped_char(char) {
    switch(char){
        case '"':
            return '\\"';
        case '<':
            return '\\u003C';
        case '\\':
            return '\\\\';
        case '\n':
            return '\\n';
        case '\r':
            return '\\r';
        case '\t':
            return '\\t';
        case '\b':
            return '\\b';
        case '\f':
            return '\\f';
        case '\u2028':
            return '\\u2028';
        case '\u2029':
            return '\\u2029';
        default:
            return char < ' ' ? `\\u${char.charCodeAt(0).toString(16).padStart(4, '0')}` : '';
    }
}
function stringify_string(str) {
    let result = '';
    let last_pos = 0;
    const len = str.length;
    for(let i = 0; i < len; i += 1){
        const char = str[i];
        const replacement = get_escaped_char(char);
        if (replacement) {
            result += str.slice(last_pos, i) + replacement;
            last_pos = i + 1;
        }
    }
    return `"${last_pos === 0 ? str : result + str.slice(last_pos)}"`;
}
function enumerable_symbols(object) {
    return Object.getOwnPropertySymbols(object).filter((symbol)=>Object.getOwnPropertyDescriptor(object, symbol).enumerable);
}
const is_identifier = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;
function stringify_key(key) {
    return is_identifier.test(key) ? '.' + key : '[' + JSON.stringify(key) + ']';
}
}),
"[project]/node_modules/devalue/src/base64.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Base64 Encodes an arraybuffer
 * @param {ArrayBuffer} arraybuffer
 * @returns {string}
 */ __turbopack_context__.s([
    "decode64",
    ()=>decode64,
    "encode64",
    ()=>encode64
]);
function encode64(arraybuffer) {
    const dv = new DataView(arraybuffer);
    let binaryString = "";
    for(let i = 0; i < arraybuffer.byteLength; i++){
        binaryString += String.fromCharCode(dv.getUint8(i));
    }
    return binaryToAscii(binaryString);
}
function decode64(string) {
    const binaryString = asciiToBinary(string);
    const arraybuffer = new ArrayBuffer(binaryString.length);
    const dv = new DataView(arraybuffer);
    for(let i = 0; i < arraybuffer.byteLength; i++){
        dv.setUint8(i, binaryString.charCodeAt(i));
    }
    return arraybuffer;
}
const KEY_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
/**
 * Substitute for atob since it's deprecated in node.
 * Does not do any input validation.
 *
 * @see https://github.com/jsdom/abab/blob/master/lib/atob.js
 *
 * @param {string} data
 * @returns {string}
 */ function asciiToBinary(data) {
    if (data.length % 4 === 0) {
        data = data.replace(/==?$/, "");
    }
    let output = "";
    let buffer = 0;
    let accumulatedBits = 0;
    for(let i = 0; i < data.length; i++){
        buffer <<= 6;
        buffer |= KEY_STRING.indexOf(data[i]);
        accumulatedBits += 6;
        if (accumulatedBits === 24) {
            output += String.fromCharCode((buffer & 0xff0000) >> 16);
            output += String.fromCharCode((buffer & 0xff00) >> 8);
            output += String.fromCharCode(buffer & 0xff);
            buffer = accumulatedBits = 0;
        }
    }
    if (accumulatedBits === 12) {
        buffer >>= 4;
        output += String.fromCharCode(buffer);
    } else if (accumulatedBits === 18) {
        buffer >>= 2;
        output += String.fromCharCode((buffer & 0xff00) >> 8);
        output += String.fromCharCode(buffer & 0xff);
    }
    return output;
}
/**
 * Substitute for btoa since it's deprecated in node.
 * Does not do any input validation.
 *
 * @see https://github.com/jsdom/abab/blob/master/lib/btoa.js
 *
 * @param {string} str
 * @returns {string}
 */ function binaryToAscii(str) {
    let out = "";
    for(let i = 0; i < str.length; i += 3){
        /** @type {[number, number, number, number]} */ const groupsOfSix = [
            undefined,
            undefined,
            undefined,
            undefined
        ];
        groupsOfSix[0] = str.charCodeAt(i) >> 2;
        groupsOfSix[1] = (str.charCodeAt(i) & 0x03) << 4;
        if (str.length > i + 1) {
            groupsOfSix[1] |= str.charCodeAt(i + 1) >> 4;
            groupsOfSix[2] = (str.charCodeAt(i + 1) & 0x0f) << 2;
        }
        if (str.length > i + 2) {
            groupsOfSix[2] |= str.charCodeAt(i + 2) >> 6;
            groupsOfSix[3] = str.charCodeAt(i + 2) & 0x3f;
        }
        for(let j = 0; j < groupsOfSix.length; j++){
            if (typeof groupsOfSix[j] === "undefined") {
                out += "=";
            } else {
                out += KEY_STRING[groupsOfSix[j]];
            }
        }
    }
    return out;
}
}),
"[project]/node_modules/devalue/src/constants.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HOLE",
    ()=>HOLE,
    "NAN",
    ()=>NAN,
    "NEGATIVE_INFINITY",
    ()=>NEGATIVE_INFINITY,
    "NEGATIVE_ZERO",
    ()=>NEGATIVE_ZERO,
    "POSITIVE_INFINITY",
    ()=>POSITIVE_INFINITY,
    "UNDEFINED",
    ()=>UNDEFINED
]);
const UNDEFINED = -1;
const HOLE = -2;
const NAN = -3;
const POSITIVE_INFINITY = -4;
const NEGATIVE_INFINITY = -5;
const NEGATIVE_ZERO = -6;
}),
"[project]/node_modules/devalue/src/parse.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parse",
    ()=>parse,
    "unflatten",
    ()=>unflatten
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/devalue/src/base64.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/devalue/src/constants.js [app-route] (ecmascript)");
;
;
function parse(serialized, revivers) {
    return unflatten(JSON.parse(serialized), revivers);
}
function unflatten(parsed, revivers) {
    if (typeof parsed === 'number') return hydrate(parsed, true);
    if (!Array.isArray(parsed) || parsed.length === 0) {
        throw new Error('Invalid input');
    }
    const values = parsed;
    const hydrated = Array(values.length);
    /**
	 * @param {number} index
	 * @returns {any}
	 */ function hydrate(index, standalone = false) {
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"]) return undefined;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NAN"]) return NaN;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["POSITIVE_INFINITY"]) return Infinity;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_INFINITY"]) return -Infinity;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"]) return -0;
        if (standalone || typeof index !== 'number') {
            throw new Error(`Invalid input`);
        }
        if (index in hydrated) return hydrated[index];
        const value = values[index];
        if (!value || typeof value !== 'object') {
            hydrated[index] = value;
        } else if (Array.isArray(value)) {
            if (typeof value[0] === 'string') {
                const type = value[0];
                const reviver = revivers?.[type];
                if (reviver) {
                    let i = value[1];
                    if (typeof i !== 'number') {
                        // if it's not a number, it was serialized by a builtin reviver
                        // so we need to munge it into the format expected by a custom reviver
                        i = values.push(value[1]) - 1;
                    }
                    return hydrated[index] = reviver(hydrate(i));
                }
                switch(type){
                    case 'Date':
                        hydrated[index] = new Date(value[1]);
                        break;
                    case 'Set':
                        const set = new Set();
                        hydrated[index] = set;
                        for(let i = 1; i < value.length; i += 1){
                            set.add(hydrate(value[i]));
                        }
                        break;
                    case 'Map':
                        const map = new Map();
                        hydrated[index] = map;
                        for(let i = 1; i < value.length; i += 2){
                            map.set(hydrate(value[i]), hydrate(value[i + 1]));
                        }
                        break;
                    case 'RegExp':
                        hydrated[index] = new RegExp(value[1], value[2]);
                        break;
                    case 'Object':
                        hydrated[index] = Object(value[1]);
                        break;
                    case 'BigInt':
                        hydrated[index] = BigInt(value[1]);
                        break;
                    case 'null':
                        const obj = Object.create(null);
                        hydrated[index] = obj;
                        for(let i = 1; i < value.length; i += 2){
                            obj[value[i]] = hydrate(value[i + 1]);
                        }
                        break;
                    case 'Int8Array':
                    case 'Uint8Array':
                    case 'Uint8ClampedArray':
                    case 'Int16Array':
                    case 'Uint16Array':
                    case 'Int32Array':
                    case 'Uint32Array':
                    case 'Float32Array':
                    case 'Float64Array':
                    case 'BigInt64Array':
                    case 'BigUint64Array':
                        {
                            const TypedArrayConstructor = globalThis[type];
                            const typedArray = new TypedArrayConstructor(hydrate(value[1]));
                            hydrated[index] = value[2] !== undefined ? typedArray.subarray(value[2], value[3]) : typedArray;
                            break;
                        }
                    case 'ArrayBuffer':
                        {
                            const base64 = value[1];
                            const arraybuffer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decode64"])(base64);
                            hydrated[index] = arraybuffer;
                            break;
                        }
                    case 'Temporal.Duration':
                    case 'Temporal.Instant':
                    case 'Temporal.PlainDate':
                    case 'Temporal.PlainTime':
                    case 'Temporal.PlainDateTime':
                    case 'Temporal.PlainMonthDay':
                    case 'Temporal.PlainYearMonth':
                    case 'Temporal.ZonedDateTime':
                        {
                            const temporalName = type.slice(9);
                            // @ts-expect-error TS doesn't know about Temporal yet
                            hydrated[index] = Temporal[temporalName].from(value[1]);
                            break;
                        }
                    case 'URL':
                        {
                            const url = new URL(value[1]);
                            hydrated[index] = url;
                            break;
                        }
                    case 'URLSearchParams':
                        {
                            const url = new URLSearchParams(value[1]);
                            hydrated[index] = url;
                            break;
                        }
                    default:
                        throw new Error(`Unknown type ${type}`);
                }
            } else {
                const array = new Array(value.length);
                hydrated[index] = array;
                for(let i = 0; i < value.length; i += 1){
                    const n = value[i];
                    if (n === __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HOLE"]) continue;
                    array[i] = hydrate(n);
                }
            }
        } else {
            /** @type {Record<string, any>} */ const object = {};
            hydrated[index] = object;
            for(const key in value){
                if (key === '__proto__') {
                    throw new Error('Cannot parse an object with a `__proto__` property');
                }
                const n = value[key];
                object[key] = hydrate(n);
            }
        }
        return hydrated[index];
    }
    return hydrate(0);
}
}),
"[project]/node_modules/devalue/src/stringify.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stringify",
    ()=>stringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/devalue/src/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/devalue/src/constants.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/devalue/src/base64.js [app-route] (ecmascript)");
;
;
;
function stringify(value, reducers) {
    /** @type {any[]} */ const stringified = [];
    /** @type {Map<any, number>} */ const indexes = new Map();
    /** @type {Array<{ key: string, fn: (value: any) => any }>} */ const custom = [];
    if (reducers) {
        for (const key of Object.getOwnPropertyNames(reducers)){
            custom.push({
                key,
                fn: reducers[key]
            });
        }
    }
    /** @type {string[]} */ const keys = [];
    let p = 0;
    /** @param {any} thing */ function flatten(thing) {
        if (thing === undefined) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"];
        if (Number.isNaN(thing)) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NAN"];
        if (thing === Infinity) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["POSITIVE_INFINITY"];
        if (thing === -Infinity) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_INFINITY"];
        if (thing === 0 && 1 / thing < 0) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"];
        if (indexes.has(thing)) return indexes.get(thing);
        const index = p++;
        indexes.set(thing, index);
        for (const { key, fn } of custom){
            const value = fn(thing);
            if (value) {
                stringified[index] = `["${key}",${flatten(value)}]`;
                return index;
            }
        }
        if (typeof thing === 'function') {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify a function`, keys, thing, value);
        }
        let str = '';
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_primitive"])(thing)) {
            str = stringify_primitive(thing);
        } else {
            const type = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["get_type"])(thing);
            switch(type){
                case 'Number':
                case 'String':
                case 'Boolean':
                    str = `["Object",${stringify_primitive(thing)}]`;
                    break;
                case 'BigInt':
                    str = `["BigInt",${thing}]`;
                    break;
                case 'Date':
                    const valid = !isNaN(thing.getDate());
                    str = `["Date","${valid ? thing.toISOString() : ''}"]`;
                    break;
                case 'URL':
                    str = `["URL",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                case 'URLSearchParams':
                    str = `["URLSearchParams",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                case 'RegExp':
                    const { source, flags } = thing;
                    str = flags ? `["RegExp",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(source)},"${flags}"]` : `["RegExp",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(source)}]`;
                    break;
                case 'Array':
                    str = '[';
                    for(let i = 0; i < thing.length; i += 1){
                        if (i > 0) str += ',';
                        if (i in thing) {
                            keys.push(`[${i}]`);
                            str += flatten(thing[i]);
                            keys.pop();
                        } else {
                            str += __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HOLE"];
                        }
                    }
                    str += ']';
                    break;
                case 'Set':
                    str = '["Set"';
                    for (const value of thing){
                        str += `,${flatten(value)}`;
                    }
                    str += ']';
                    break;
                case 'Map':
                    str = '["Map"';
                    for (const [key, value] of thing){
                        keys.push(`.get(${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_primitive"])(key) ? stringify_primitive(key) : '...'})`);
                        str += `,${flatten(key)},${flatten(value)}`;
                        keys.pop();
                    }
                    str += ']';
                    break;
                case 'Int8Array':
                case 'Uint8Array':
                case 'Uint8ClampedArray':
                case 'Int16Array':
                case 'Uint16Array':
                case 'Int32Array':
                case 'Uint32Array':
                case 'Float32Array':
                case 'Float64Array':
                case 'BigInt64Array':
                case 'BigUint64Array':
                    {
                        /** @type {import("./types.js").TypedArray} */ const typedArray = thing;
                        str = '["' + type + '",' + flatten(typedArray.buffer);
                        const a = thing.byteOffset;
                        const b = a + thing.byteLength;
                        // handle subarrays
                        if (a > 0 || b !== typedArray.buffer.byteLength) {
                            const m = +/(\d+)/.exec(type)[1] / 8;
                            str += `,${a / m},${b / m}`;
                        }
                        str += ']';
                        break;
                    }
                case 'ArrayBuffer':
                    {
                        /** @type {ArrayBuffer} */ const arraybuffer = thing;
                        const base64 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["encode64"])(arraybuffer);
                        str = `["ArrayBuffer","${base64}"]`;
                        break;
                    }
                case 'Temporal.Duration':
                case 'Temporal.Instant':
                case 'Temporal.PlainDate':
                case 'Temporal.PlainTime':
                case 'Temporal.PlainDateTime':
                case 'Temporal.PlainMonthDay':
                case 'Temporal.PlainYearMonth':
                case 'Temporal.ZonedDateTime':
                    str = `["${type}",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                default:
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_plain_object"])(thing)) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify arbitrary non-POJOs`, keys, thing, value);
                    }
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["enumerable_symbols"])(thing).length > 0) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify POJOs with symbolic keys`, keys, thing, value);
                    }
                    if (Object.getPrototypeOf(thing) === null) {
                        str = '["null"';
                        for(const key in thing){
                            keys.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_key"])(key));
                            str += `,${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(key)},${flatten(thing[key])}`;
                            keys.pop();
                        }
                        str += ']';
                    } else {
                        str = '{';
                        let started = false;
                        for(const key in thing){
                            if (started) str += ',';
                            started = true;
                            keys.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_key"])(key));
                            str += `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(key)}:${flatten(thing[key])}`;
                            keys.pop();
                        }
                        str += '}';
                    }
            }
        }
        stringified[index] = str;
        return index;
    }
    const index = flatten(value);
    // special case — value is represented as a negative index
    if (index < 0) return `${index}`;
    return `[${stringified.join(',')}]`;
}
/**
 * @param {any} thing
 * @returns {string}
 */ function stringify_primitive(thing) {
    const type = typeof thing;
    if (type === 'string') return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing);
    if (thing instanceof String) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString());
    if (thing === void 0) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"].toString();
    if (thing === 0 && 1 / thing < 0) return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"].toString();
    if (type === 'bigint') return `["BigInt","${thing}"]`;
    return String(thing);
}
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/utils.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/** @type {Record<string, string>} */ __turbopack_context__.s([
    "DevalueError",
    ()=>DevalueError,
    "enumerable_symbols",
    ()=>enumerable_symbols,
    "escaped",
    ()=>escaped,
    "get_type",
    ()=>get_type,
    "is_plain_object",
    ()=>is_plain_object,
    "is_primitive",
    ()=>is_primitive,
    "stringify_key",
    ()=>stringify_key,
    "stringify_string",
    ()=>stringify_string
]);
const escaped = {
    '<': '\\u003C',
    '\\': '\\\\',
    '\b': '\\b',
    '\f': '\\f',
    '\n': '\\n',
    '\r': '\\r',
    '\t': '\\t',
    '\u2028': '\\u2028',
    '\u2029': '\\u2029'
};
class DevalueError extends Error {
    /**
	 * @param {string} message
	 * @param {string[]} keys
	 * @param {any} [value] - The value that failed to be serialized
	 * @param {any} [root] - The root value being serialized
	 */ constructor(message, keys, value, root){
        super(message);
        this.name = 'DevalueError';
        this.path = keys.join('');
        this.value = value;
        this.root = root;
    }
}
function is_primitive(thing) {
    return Object(thing) !== thing;
}
const object_proto_names = /* @__PURE__ */ Object.getOwnPropertyNames(Object.prototype).sort().join('\0');
function is_plain_object(thing) {
    const proto = Object.getPrototypeOf(thing);
    return proto === Object.prototype || proto === null || Object.getPrototypeOf(proto) === null || Object.getOwnPropertyNames(proto).sort().join('\0') === object_proto_names;
}
function get_type(thing) {
    return Object.prototype.toString.call(thing).slice(8, -1);
}
/** @param {string} char */ function get_escaped_char(char) {
    switch(char){
        case '"':
            return '\\"';
        case '<':
            return '\\u003C';
        case '\\':
            return '\\\\';
        case '\n':
            return '\\n';
        case '\r':
            return '\\r';
        case '\t':
            return '\\t';
        case '\b':
            return '\\b';
        case '\f':
            return '\\f';
        case '\u2028':
            return '\\u2028';
        case '\u2029':
            return '\\u2029';
        default:
            return char < ' ' ? `\\u${char.charCodeAt(0).toString(16).padStart(4, '0')}` : '';
    }
}
function stringify_string(str) {
    let result = '';
    let last_pos = 0;
    const len = str.length;
    for(let i = 0; i < len; i += 1){
        const char = str[i];
        const replacement = get_escaped_char(char);
        if (replacement) {
            result += str.slice(last_pos, i) + replacement;
            last_pos = i + 1;
        }
    }
    return `"${last_pos === 0 ? str : result + str.slice(last_pos)}"`;
}
function enumerable_symbols(object) {
    return Object.getOwnPropertySymbols(object).filter((symbol)=>Object.getOwnPropertyDescriptor(object, symbol).enumerable);
}
const is_identifier = /^[a-zA-Z_$][a-zA-Z_$0-9]*$/;
function stringify_key(key) {
    return is_identifier.test(key) ? '.' + key : '[' + JSON.stringify(key) + ']';
}
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/base64.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Base64 Encodes an arraybuffer
 * @param {ArrayBuffer} arraybuffer
 * @returns {string}
 */ __turbopack_context__.s([
    "decode64",
    ()=>decode64,
    "encode64",
    ()=>encode64
]);
function encode64(arraybuffer) {
    const dv = new DataView(arraybuffer);
    let binaryString = "";
    for(let i = 0; i < arraybuffer.byteLength; i++){
        binaryString += String.fromCharCode(dv.getUint8(i));
    }
    return binaryToAscii(binaryString);
}
function decode64(string) {
    const binaryString = asciiToBinary(string);
    const arraybuffer = new ArrayBuffer(binaryString.length);
    const dv = new DataView(arraybuffer);
    for(let i = 0; i < arraybuffer.byteLength; i++){
        dv.setUint8(i, binaryString.charCodeAt(i));
    }
    return arraybuffer;
}
const KEY_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
/**
 * Substitute for atob since it's deprecated in node.
 * Does not do any input validation.
 *
 * @see https://github.com/jsdom/abab/blob/master/lib/atob.js
 *
 * @param {string} data
 * @returns {string}
 */ function asciiToBinary(data) {
    if (data.length % 4 === 0) {
        data = data.replace(/==?$/, "");
    }
    let output = "";
    let buffer = 0;
    let accumulatedBits = 0;
    for(let i = 0; i < data.length; i++){
        buffer <<= 6;
        buffer |= KEY_STRING.indexOf(data[i]);
        accumulatedBits += 6;
        if (accumulatedBits === 24) {
            output += String.fromCharCode((buffer & 0xff0000) >> 16);
            output += String.fromCharCode((buffer & 0xff00) >> 8);
            output += String.fromCharCode(buffer & 0xff);
            buffer = accumulatedBits = 0;
        }
    }
    if (accumulatedBits === 12) {
        buffer >>= 4;
        output += String.fromCharCode(buffer);
    } else if (accumulatedBits === 18) {
        buffer >>= 2;
        output += String.fromCharCode((buffer & 0xff00) >> 8);
        output += String.fromCharCode(buffer & 0xff);
    }
    return output;
}
/**
 * Substitute for btoa since it's deprecated in node.
 * Does not do any input validation.
 *
 * @see https://github.com/jsdom/abab/blob/master/lib/btoa.js
 *
 * @param {string} str
 * @returns {string}
 */ function binaryToAscii(str) {
    let out = "";
    for(let i = 0; i < str.length; i += 3){
        /** @type {[number, number, number, number]} */ const groupsOfSix = [
            undefined,
            undefined,
            undefined,
            undefined
        ];
        groupsOfSix[0] = str.charCodeAt(i) >> 2;
        groupsOfSix[1] = (str.charCodeAt(i) & 0x03) << 4;
        if (str.length > i + 1) {
            groupsOfSix[1] |= str.charCodeAt(i + 1) >> 4;
            groupsOfSix[2] = (str.charCodeAt(i + 1) & 0x0f) << 2;
        }
        if (str.length > i + 2) {
            groupsOfSix[2] |= str.charCodeAt(i + 2) >> 6;
            groupsOfSix[3] = str.charCodeAt(i + 2) & 0x3f;
        }
        for(let j = 0; j < groupsOfSix.length; j++){
            if (typeof groupsOfSix[j] === "undefined") {
                out += "=";
            } else {
                out += KEY_STRING[groupsOfSix[j]];
            }
        }
    }
    return out;
}
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/constants.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HOLE",
    ()=>HOLE,
    "NAN",
    ()=>NAN,
    "NEGATIVE_INFINITY",
    ()=>NEGATIVE_INFINITY,
    "NEGATIVE_ZERO",
    ()=>NEGATIVE_ZERO,
    "POSITIVE_INFINITY",
    ()=>POSITIVE_INFINITY,
    "UNDEFINED",
    ()=>UNDEFINED
]);
const UNDEFINED = -1;
const HOLE = -2;
const NAN = -3;
const POSITIVE_INFINITY = -4;
const NEGATIVE_INFINITY = -5;
const NEGATIVE_ZERO = -6;
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/parse.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "parse",
    ()=>parse,
    "unflatten",
    ()=>unflatten
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/base64.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/constants.js [app-route] (ecmascript)");
;
;
function parse(serialized, revivers) {
    return unflatten(JSON.parse(serialized), revivers);
}
function unflatten(parsed, revivers) {
    if (typeof parsed === 'number') return hydrate(parsed, true);
    if (!Array.isArray(parsed) || parsed.length === 0) {
        throw new Error('Invalid input');
    }
    const values = parsed;
    const hydrated = Array(values.length);
    /**
	 * @param {number} index
	 * @returns {any}
	 */ function hydrate(index, standalone = false) {
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"]) return undefined;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NAN"]) return NaN;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["POSITIVE_INFINITY"]) return Infinity;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_INFINITY"]) return -Infinity;
        if (index === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"]) return -0;
        if (standalone || typeof index !== 'number') {
            throw new Error(`Invalid input`);
        }
        if (index in hydrated) return hydrated[index];
        const value = values[index];
        if (!value || typeof value !== 'object') {
            hydrated[index] = value;
        } else if (Array.isArray(value)) {
            if (typeof value[0] === 'string') {
                const type = value[0];
                const reviver = revivers?.[type];
                if (reviver) {
                    let i = value[1];
                    if (typeof i !== 'number') {
                        // if it's not a number, it was serialized by a builtin reviver
                        // so we need to munge it into the format expected by a custom reviver
                        i = values.push(value[1]) - 1;
                    }
                    return hydrated[index] = reviver(hydrate(i));
                }
                switch(type){
                    case 'Date':
                        hydrated[index] = new Date(value[1]);
                        break;
                    case 'Set':
                        const set = new Set();
                        hydrated[index] = set;
                        for(let i = 1; i < value.length; i += 1){
                            set.add(hydrate(value[i]));
                        }
                        break;
                    case 'Map':
                        const map = new Map();
                        hydrated[index] = map;
                        for(let i = 1; i < value.length; i += 2){
                            map.set(hydrate(value[i]), hydrate(value[i + 1]));
                        }
                        break;
                    case 'RegExp':
                        hydrated[index] = new RegExp(value[1], value[2]);
                        break;
                    case 'Object':
                        hydrated[index] = Object(value[1]);
                        break;
                    case 'BigInt':
                        hydrated[index] = BigInt(value[1]);
                        break;
                    case 'null':
                        const obj = Object.create(null);
                        hydrated[index] = obj;
                        for(let i = 1; i < value.length; i += 2){
                            obj[value[i]] = hydrate(value[i + 1]);
                        }
                        break;
                    case 'Int8Array':
                    case 'Uint8Array':
                    case 'Uint8ClampedArray':
                    case 'Int16Array':
                    case 'Uint16Array':
                    case 'Int32Array':
                    case 'Uint32Array':
                    case 'Float32Array':
                    case 'Float64Array':
                    case 'BigInt64Array':
                    case 'BigUint64Array':
                        {
                            const TypedArrayConstructor = globalThis[type];
                            const typedArray = new TypedArrayConstructor(hydrate(value[1]));
                            hydrated[index] = value[2] !== undefined ? typedArray.subarray(value[2], value[3]) : typedArray;
                            break;
                        }
                    case 'ArrayBuffer':
                        {
                            const base64 = value[1];
                            const arraybuffer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decode64"])(base64);
                            hydrated[index] = arraybuffer;
                            break;
                        }
                    case 'Temporal.Duration':
                    case 'Temporal.Instant':
                    case 'Temporal.PlainDate':
                    case 'Temporal.PlainTime':
                    case 'Temporal.PlainDateTime':
                    case 'Temporal.PlainMonthDay':
                    case 'Temporal.PlainYearMonth':
                    case 'Temporal.ZonedDateTime':
                        {
                            const temporalName = type.slice(9);
                            // @ts-expect-error TS doesn't know about Temporal yet
                            hydrated[index] = Temporal[temporalName].from(value[1]);
                            break;
                        }
                    case 'URL':
                        {
                            const url = new URL(value[1]);
                            hydrated[index] = url;
                            break;
                        }
                    case 'URLSearchParams':
                        {
                            const url = new URLSearchParams(value[1]);
                            hydrated[index] = url;
                            break;
                        }
                    default:
                        throw new Error(`Unknown type ${type}`);
                }
            } else {
                const array = new Array(value.length);
                hydrated[index] = array;
                for(let i = 0; i < value.length; i += 1){
                    const n = value[i];
                    if (n === __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HOLE"]) continue;
                    array[i] = hydrate(n);
                }
            }
        } else {
            /** @type {Record<string, any>} */ const object = {};
            hydrated[index] = object;
            for(const key in value){
                if (key === '__proto__') {
                    throw new Error('Cannot parse an object with a `__proto__` property');
                }
                const n = value[key];
                object[key] = hydrate(n);
            }
        }
        return hydrated[index];
    }
    return hydrate(0);
}
}),
"[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/stringify.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "stringify",
    ()=>stringify
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/constants.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/base64.js [app-route] (ecmascript)");
;
;
;
function stringify(value, reducers) {
    /** @type {any[]} */ const stringified = [];
    /** @type {Map<any, number>} */ const indexes = new Map();
    /** @type {Array<{ key: string, fn: (value: any) => any }>} */ const custom = [];
    if (reducers) {
        for (const key of Object.getOwnPropertyNames(reducers)){
            custom.push({
                key,
                fn: reducers[key]
            });
        }
    }
    /** @type {string[]} */ const keys = [];
    let p = 0;
    /** @param {any} thing */ function flatten(thing) {
        if (thing === undefined) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"];
        if (Number.isNaN(thing)) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NAN"];
        if (thing === Infinity) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["POSITIVE_INFINITY"];
        if (thing === -Infinity) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_INFINITY"];
        if (thing === 0 && 1 / thing < 0) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"];
        if (indexes.has(thing)) return indexes.get(thing);
        const index = p++;
        indexes.set(thing, index);
        for (const { key, fn } of custom){
            const value = fn(thing);
            if (value) {
                stringified[index] = `["${key}",${flatten(value)}]`;
                return index;
            }
        }
        if (typeof thing === 'function') {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify a function`, keys, thing, value);
        }
        let str = '';
        if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_primitive"])(thing)) {
            str = stringify_primitive(thing);
        } else {
            const type = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["get_type"])(thing);
            switch(type){
                case 'Number':
                case 'String':
                case 'Boolean':
                    str = `["Object",${stringify_primitive(thing)}]`;
                    break;
                case 'BigInt':
                    str = `["BigInt",${thing}]`;
                    break;
                case 'Date':
                    const valid = !isNaN(thing.getDate());
                    str = `["Date","${valid ? thing.toISOString() : ''}"]`;
                    break;
                case 'URL':
                    str = `["URL",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                case 'URLSearchParams':
                    str = `["URLSearchParams",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                case 'RegExp':
                    const { source, flags } = thing;
                    str = flags ? `["RegExp",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(source)},"${flags}"]` : `["RegExp",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(source)}]`;
                    break;
                case 'Array':
                    str = '[';
                    for(let i = 0; i < thing.length; i += 1){
                        if (i > 0) str += ',';
                        if (i in thing) {
                            keys.push(`[${i}]`);
                            str += flatten(thing[i]);
                            keys.pop();
                        } else {
                            str += __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HOLE"];
                        }
                    }
                    str += ']';
                    break;
                case 'Set':
                    str = '["Set"';
                    for (const value of thing){
                        str += `,${flatten(value)}`;
                    }
                    str += ']';
                    break;
                case 'Map':
                    str = '["Map"';
                    for (const [key, value] of thing){
                        keys.push(`.get(${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_primitive"])(key) ? stringify_primitive(key) : '...'})`);
                        str += `,${flatten(key)},${flatten(value)}`;
                        keys.pop();
                    }
                    str += ']';
                    break;
                case 'Int8Array':
                case 'Uint8Array':
                case 'Uint8ClampedArray':
                case 'Int16Array':
                case 'Uint16Array':
                case 'Int32Array':
                case 'Uint32Array':
                case 'Float32Array':
                case 'Float64Array':
                case 'BigInt64Array':
                case 'BigUint64Array':
                    {
                        /** @type {import("./types.js").TypedArray} */ const typedArray = thing;
                        str = '["' + type + '",' + flatten(typedArray.buffer);
                        const a = thing.byteOffset;
                        const b = a + thing.byteLength;
                        // handle subarrays
                        if (a > 0 || b !== typedArray.buffer.byteLength) {
                            const m = +/(\d+)/.exec(type)[1] / 8;
                            str += `,${a / m},${b / m}`;
                        }
                        str += ']';
                        break;
                    }
                case 'ArrayBuffer':
                    {
                        /** @type {ArrayBuffer} */ const arraybuffer = thing;
                        const base64 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$base64$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["encode64"])(arraybuffer);
                        str = `["ArrayBuffer","${base64}"]`;
                        break;
                    }
                case 'Temporal.Duration':
                case 'Temporal.Instant':
                case 'Temporal.PlainDate':
                case 'Temporal.PlainTime':
                case 'Temporal.PlainDateTime':
                case 'Temporal.PlainMonthDay':
                case 'Temporal.PlainYearMonth':
                case 'Temporal.ZonedDateTime':
                    str = `["${type}",${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString())}]`;
                    break;
                default:
                    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["is_plain_object"])(thing)) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify arbitrary non-POJOs`, keys, thing, value);
                    }
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["enumerable_symbols"])(thing).length > 0) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"](`Cannot stringify POJOs with symbolic keys`, keys, thing, value);
                    }
                    if (Object.getPrototypeOf(thing) === null) {
                        str = '["null"';
                        for(const key in thing){
                            keys.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_key"])(key));
                            str += `,${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(key)},${flatten(thing[key])}`;
                            keys.pop();
                        }
                        str += ']';
                    } else {
                        str = '{';
                        let started = false;
                        for(const key in thing){
                            if (started) str += ',';
                            started = true;
                            keys.push((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_key"])(key));
                            str += `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(key)}:${flatten(thing[key])}`;
                            keys.pop();
                        }
                        str += '}';
                    }
            }
        }
        stringified[index] = str;
        return index;
    }
    const index = flatten(value);
    // special case — value is represented as a negative index
    if (index < 0) return `${index}`;
    return `[${stringified.join(',')}]`;
}
/**
 * @param {any} thing
 * @returns {string}
 */ function stringify_primitive(thing) {
    const type = typeof thing;
    if (type === 'string') return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing);
    if (thing instanceof String) return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify_string"])(thing.toString());
    if (thing === void 0) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UNDEFINED"].toString();
    if (thing === 0 && 1 / thing < 0) return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$constants$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NEGATIVE_ZERO"].toString();
    if (type === 'bigint') return `["BigInt","${thing}"]`;
    return String(thing);
}
}),
"[project]/node_modules/@vercel/queue/node_modules/mixpart/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/parser.ts
__turbopack_context__.s([
    "MultipartParseError",
    ()=>MultipartParseError,
    "extractBoundary",
    ()=>extractBoundary,
    "parseMultipartStream",
    ()=>parseMultipartStream
]);
var MultipartParseError = class extends Error {
    constructor(message){
        super(message);
        this.name = "MultipartParseError";
    }
};
function createSearch(pattern) {
    const needle = new TextEncoder().encode(pattern);
    return (haystack, start = 0)=>Buffer.prototype.indexOf.call(haystack, needle, start);
}
function createPartialTailSearch(pattern) {
    const needle = new TextEncoder().encode(pattern);
    const byteIndexes = {};
    for(let i = 0; i < needle.length; ++i){
        const byte = needle[i];
        if (byteIndexes[byte] === void 0) byteIndexes[byte] = [];
        byteIndexes[byte].push(i);
    }
    return function(haystack) {
        const haystackEnd = haystack.length - 1;
        if (haystack[haystackEnd] in byteIndexes) {
            const indexes = byteIndexes[haystack[haystackEnd]];
            for(let i = indexes.length - 1; i >= 0; --i){
                for(let j = indexes[i], k = haystackEnd; j >= 0 && haystack[k] === needle[j]; --j, --k){
                    if (j === 0) return k;
                }
            }
        }
        return -1;
    };
}
function parseHeaders(headerBytes) {
    const headerText = new TextDecoder("iso-8859-1").decode(headerBytes);
    const lines = headerText.trim().split(/\r?\n/);
    const headerInit = [];
    for (const line of lines){
        const colonIndex = line.indexOf(":");
        if (colonIndex > 0) {
            const name = line.slice(0, colonIndex).trim();
            const value = line.slice(colonIndex + 1).trim();
            headerInit.push([
                name,
                value
            ]);
        }
    }
    return new Headers(headerInit);
}
function extractBoundary(contentType) {
    const boundaryMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
    if (!boundaryMatch) {
        throw new MultipartParseError("No boundary found in Content-Type header");
    }
    return boundaryMatch[1] ?? boundaryMatch[2];
}
var AsyncMessageQueue = class {
    queue = [];
    waiters = [];
    finished = false;
    cancelled = false;
    error = null;
    /**
   * Producer: Enqueue a message for consumption
   */ enqueue(message) {
        if (this.finished || this.cancelled) return;
        if (this.waiters.length > 0) {
            const waiter = this.waiters.shift();
            waiter.resolve(message);
        } else {
            this.queue.push(message);
        }
    }
    /**
   * Producer: Signal completion (with optional error)
   */ finish(error) {
        if (this.finished) return;
        this.finished = true;
        this.error = error || null;
        while(this.waiters.length > 0){
            const waiter = this.waiters.shift();
            if (error) {
                waiter.reject(error);
            } else {
                waiter.resolve(null);
            }
        }
    }
    /**
   * Consumer: Cancel the queue (stops accepting new messages and notifies waiters)
   */ cancel() {
        if (this.cancelled || this.finished) return;
        this.cancelled = true;
        while(this.waiters.length > 0){
            const waiter = this.waiters.shift();
            waiter.resolve(null);
        }
    }
    /**
   * Consumer: Dequeue next message (or null if finished/cancelled)
   */ async dequeue() {
        if (this.queue.length > 0) {
            return this.queue.shift();
        }
        if (this.finished || this.cancelled) {
            if (this.error) throw this.error;
            return null;
        }
        return new Promise((resolve, reject)=>{
            this.waiters.push({
                resolve,
                reject
            });
        });
    }
    /**
   * Check if the queue is in a terminal state
   */ get isTerminal() {
        return this.finished || this.cancelled;
    }
};
async function* parseMultipartStream(response, options) {
    if (!response.body) {
        throw new MultipartParseError("Response body is null");
    }
    const contentType = response.headers.get("content-type");
    if (!contentType) {
        throw new MultipartParseError("Missing Content-Type header");
    }
    const boundary = extractBoundary(contentType);
    const parser = new StreamingMultipartParser(boundary, options);
    yield* parser.parseStream(response.body);
}
var StreamingMultipartParser = class {
    boundary;
    findOpeningBoundary;
    openingBoundaryLength;
    findBoundary;
    findPartialTailBoundary;
    boundaryLength;
    findDoubleNewline;
    // Safety limits
    maxHeaderSize;
    maxBoundaryBuffer;
    state = 0 /* Start */ ;
    buffer = null;
    currentHeaders = new Headers();
    currentPayloadController = null;
    constructor(boundary, options = {}){
        this.boundary = boundary;
        this.findOpeningBoundary = createSearch(`--${boundary}`);
        this.openingBoundaryLength = 2 + boundary.length;
        this.findBoundary = createSearch(`\r
--${boundary}`);
        this.findPartialTailBoundary = createPartialTailSearch(`\r
--${boundary}`);
        this.boundaryLength = 4 + boundary.length;
        this.findDoubleNewline = createSearch("\r\n\r\n");
        this.maxHeaderSize = options.maxHeaderSize ?? 65536;
        this.maxBoundaryBuffer = options.maxBoundaryBuffer ?? 8192;
    }
    async *parseStream(stream) {
        const reader = stream.getReader();
        const messageQueue = new AsyncMessageQueue();
        const producer = this.startProducer(reader, messageQueue);
        try {
            yield* this.consumeMessages(messageQueue);
        } finally{
            messageQueue.cancel();
            this.closeCurrentPayload();
            try {
                await reader.cancel();
            } catch (error) {}
            await producer;
        }
    }
    /**
   * Producer: Continuously read chunks and parse messages
   */ async startProducer(reader, messageQueue) {
        try {
            while(!messageQueue.isTerminal){
                let result;
                try {
                    result = await reader.read();
                } catch (readError) {
                    if (readError instanceof Error && (readError.name === "AbortError" || readError.constructor.name === "AbortError" || readError.name === "TimeoutError" || readError.constructor.name === "TimeoutError")) {
                        break;
                    }
                    throw readError;
                }
                const { done, value } = result;
                if (done) {
                    if (this.buffer !== null && this.buffer.length > 0) {
                        const messages2 = this.write(new Uint8Array(0));
                        for (const message of messages2){
                            if (messageQueue.isTerminal) break;
                            messageQueue.enqueue(message);
                        }
                    }
                    if (this.state !== 4 /* Done */ ) {
                        if (this.state === 0 /* Start */ ) {
                            throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
                        }
                        throw new MultipartParseError("Unexpected end of stream");
                    }
                    break;
                }
                if (!(value instanceof Uint8Array)) {
                    throw new MultipartParseError(`Invalid chunk type: expected Uint8Array, got ${typeof value}`);
                }
                const messages = this.write(value);
                for (const message of messages){
                    if (messageQueue.isTerminal) break;
                    messageQueue.enqueue(message);
                }
            }
            if (!messageQueue.isTerminal) {
                messageQueue.finish();
            }
        } catch (error) {
            this.closeCurrentPayload(error);
            if (!messageQueue.isTerminal) {
                messageQueue.finish(error);
            }
        } finally{
            try {
                reader.releaseLock();
            } catch (error) {}
        }
    }
    /**
   * Consumer: Yield messages from the queue
   */ async *consumeMessages(messageQueue) {
        while(true){
            const message = await messageQueue.dequeue();
            if (message === null) {
                break;
            }
            yield message;
        }
    }
    /**
   * Process a chunk of data through the state machine and return any complete messages.
   *
   * Returns an array because a single chunk can contain multiple complete messages
   * when small messages with headers + body + boundary all fit in one network chunk.
   * All messages must be captured and queued to maintain proper message ordering.
   */ write(chunk) {
        const newMessages = [];
        if (this.state === 4 /* Done */ ) {
            throw new MultipartParseError("Unexpected data after end of stream");
        }
        let index = 0;
        let chunkLength = chunk.length;
        if (this.buffer !== null) {
            const newSize = this.buffer.length + chunkLength;
            const maxAllowedSize = this.state === 2 /* Header */  ? this.maxHeaderSize : this.maxBoundaryBuffer;
            if (newSize > maxAllowedSize) {
                throw new MultipartParseError(`Buffer size limit exceeded: ${newSize} bytes > ${maxAllowedSize} bytes. This may indicate malformed multipart data with ${this.state === 2 /* Header */  ? "oversized headers" : "invalid boundaries"}.`);
            }
            const newChunk = new Uint8Array(newSize);
            newChunk.set(this.buffer, 0);
            newChunk.set(chunk, this.buffer.length);
            chunk = newChunk;
            chunkLength = chunk.length;
            this.buffer = null;
        }
        if (chunkLength === 0 && this.state === 0 /* Start */ ) {
            throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
        }
        while(true){
            if (this.state === 3 /* Body */ ) {
                if (chunkLength - index < this.boundaryLength) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`Boundary buffer limit exceeded: ${remainingData.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                const boundaryIndex = this.findBoundary(chunk, index);
                if (boundaryIndex === -1) {
                    const partialTailIndex = this.findPartialTailBoundary(chunk);
                    if (partialTailIndex === -1) {
                        this.writeBody(index === 0 ? chunk : chunk.subarray(index));
                    } else {
                        this.writeBody(chunk.subarray(index, partialTailIndex));
                        const partialBoundary = chunk.subarray(partialTailIndex);
                        if (partialBoundary.length > this.maxBoundaryBuffer) {
                            throw new MultipartParseError(`Partial boundary too large: ${partialBoundary.length} > ${this.maxBoundaryBuffer}`);
                        }
                        this.buffer = partialBoundary;
                    }
                    break;
                }
                this.writeBody(chunk.subarray(index, boundaryIndex));
                this.finishMessage();
                index = boundaryIndex + this.boundaryLength;
                this.state = 1 /* AfterBoundary */ ;
            }
            if (this.state === 1 /* AfterBoundary */ ) {
                if (chunkLength - index < 2) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`After-boundary buffer limit exceeded: ${remainingData.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                if (chunk[index] === 45 && chunk[index + 1] === 45) {
                    this.state = 4 /* Done */ ;
                    break;
                }
                if (chunk[index] === 13 && chunk[index + 1] === 10) {
                    index += 2;
                } else if (chunk[index] === 10) {
                    index += 1;
                } else {
                    throw new MultipartParseError(`Invalid character after boundary: expected CRLF or LF, got 0x${chunk[index].toString(16)}`);
                }
                this.state = 2 /* Header */ ;
            }
            if (this.state === 2 /* Header */ ) {
                if (chunkLength - index < 4) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxHeaderSize) {
                        throw new MultipartParseError(`Header buffer limit exceeded: ${remainingData.length} > ${this.maxHeaderSize}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                let headerEndIndex = this.findDoubleNewline(chunk, index);
                let headerEndOffset = 4;
                if (headerEndIndex === -1) {
                    const lfDoubleNewline = createSearch("\n\n");
                    headerEndIndex = lfDoubleNewline(chunk, index);
                    headerEndOffset = 2;
                }
                if (headerEndIndex === -1) {
                    const headerData = chunk.subarray(index);
                    if (headerData.length > this.maxHeaderSize) {
                        throw new MultipartParseError(`Headers too large: ${headerData.length} > ${this.maxHeaderSize} bytes`);
                    }
                    this.buffer = headerData;
                    break;
                }
                const headerBytes = chunk.subarray(index, headerEndIndex);
                this.currentHeaders = parseHeaders(headerBytes);
                const message = this.createStreamingMessage();
                newMessages.push(message);
                index = headerEndIndex + headerEndOffset;
                this.state = 3 /* Body */ ;
                continue;
            }
            if (this.state === 0 /* Start */ ) {
                if (chunkLength < this.openingBoundaryLength) {
                    if (chunk.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`Initial chunk too large for boundary detection: ${chunk.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = chunk;
                    break;
                }
                const boundaryIndex = this.findOpeningBoundary(chunk);
                if (boundaryIndex !== 0) {
                    throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
                }
                index = this.openingBoundaryLength;
                this.state = 1 /* AfterBoundary */ ;
            }
        }
        return newMessages;
    }
    createStreamingMessage() {
        const headers = new Headers(this.currentHeaders);
        const payload = new ReadableStream({
            start: (controller)=>{
                this.currentPayloadController = controller;
            }
        });
        this.currentHeaders = new Headers();
        return {
            headers,
            payload
        };
    }
    writeBody(chunk) {
        if (this.currentPayloadController) {
            this.currentPayloadController.enqueue(chunk);
        }
    }
    finishMessage() {
        if (this.currentPayloadController) {
            this.currentPayloadController.close();
            this.currentPayloadController = null;
        }
    }
    /**
   * Close current payload controller if open (used during cleanup)
   * If an error is provided, forwards it to the payload consumer
   */ closeCurrentPayload(error) {
        if (this.currentPayloadController) {
            try {
                if (error) {
                    this.currentPayloadController.error(error);
                } else {
                    this.currentPayloadController.close();
                }
            } catch (controllerError) {}
            this.currentPayloadController = null;
        }
    }
};
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/frontend/node_modules/.pnpm/mixpart@0.0.5-alpha.1/node_modules/mixpart/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/parser.ts
__turbopack_context__.s([
    "MultipartParseError",
    ()=>MultipartParseError,
    "extractBoundary",
    ()=>extractBoundary,
    "parseMultipartStream",
    ()=>parseMultipartStream
]);
var MultipartParseError = class extends Error {
    constructor(message){
        super(message);
        this.name = "MultipartParseError";
    }
};
function createSearch(pattern) {
    const needle = new TextEncoder().encode(pattern);
    return (haystack, start = 0)=>Buffer.prototype.indexOf.call(haystack, needle, start);
}
function createPartialTailSearch(pattern) {
    const needle = new TextEncoder().encode(pattern);
    const byteIndexes = {};
    for(let i = 0; i < needle.length; ++i){
        const byte = needle[i];
        if (byteIndexes[byte] === void 0) byteIndexes[byte] = [];
        byteIndexes[byte].push(i);
    }
    return function(haystack) {
        const haystackEnd = haystack.length - 1;
        if (haystack[haystackEnd] in byteIndexes) {
            const indexes = byteIndexes[haystack[haystackEnd]];
            for(let i = indexes.length - 1; i >= 0; --i){
                for(let j = indexes[i], k = haystackEnd; j >= 0 && haystack[k] === needle[j]; --j, --k){
                    if (j === 0) return k;
                }
            }
        }
        return -1;
    };
}
function parseHeaders(headerBytes) {
    const headerText = new TextDecoder("iso-8859-1").decode(headerBytes);
    const lines = headerText.trim().split(/\r?\n/);
    const headerInit = [];
    for (const line of lines){
        const colonIndex = line.indexOf(":");
        if (colonIndex > 0) {
            const name = line.slice(0, colonIndex).trim();
            const value = line.slice(colonIndex + 1).trim();
            headerInit.push([
                name,
                value
            ]);
        }
    }
    return new Headers(headerInit);
}
function extractBoundary(contentType) {
    const boundaryMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
    if (!boundaryMatch) {
        throw new MultipartParseError("No boundary found in Content-Type header");
    }
    return boundaryMatch[1] ?? boundaryMatch[2];
}
var AsyncMessageQueue = class {
    queue = [];
    waiters = [];
    finished = false;
    cancelled = false;
    error = null;
    /**
   * Producer: Enqueue a message for consumption
   */ enqueue(message) {
        if (this.finished || this.cancelled) return;
        if (this.waiters.length > 0) {
            const waiter = this.waiters.shift();
            waiter.resolve(message);
        } else {
            this.queue.push(message);
        }
    }
    /**
   * Producer: Signal completion (with optional error)
   */ finish(error) {
        if (this.finished) return;
        this.finished = true;
        this.error = error || null;
        while(this.waiters.length > 0){
            const waiter = this.waiters.shift();
            if (error) {
                waiter.reject(error);
            } else {
                waiter.resolve(null);
            }
        }
    }
    /**
   * Consumer: Cancel the queue (stops accepting new messages and notifies waiters)
   */ cancel() {
        if (this.cancelled || this.finished) return;
        this.cancelled = true;
        while(this.waiters.length > 0){
            const waiter = this.waiters.shift();
            waiter.resolve(null);
        }
    }
    /**
   * Consumer: Dequeue next message (or null if finished/cancelled)
   */ async dequeue() {
        if (this.queue.length > 0) {
            return this.queue.shift();
        }
        if (this.finished || this.cancelled) {
            if (this.error) throw this.error;
            return null;
        }
        return new Promise((resolve, reject)=>{
            this.waiters.push({
                resolve,
                reject
            });
        });
    }
    /**
   * Check if the queue is in a terminal state
   */ get isTerminal() {
        return this.finished || this.cancelled;
    }
};
async function* parseMultipartStream(response, options) {
    if (!response.body) {
        throw new MultipartParseError("Response body is null");
    }
    const contentType = response.headers.get("content-type");
    if (!contentType) {
        throw new MultipartParseError("Missing Content-Type header");
    }
    const boundary = extractBoundary(contentType);
    const parser = new StreamingMultipartParser(boundary, options);
    yield* parser.parseStream(response.body);
}
var StreamingMultipartParser = class {
    boundary;
    findOpeningBoundary;
    openingBoundaryLength;
    findBoundary;
    findPartialTailBoundary;
    boundaryLength;
    findDoubleNewline;
    // Safety limits
    maxHeaderSize;
    maxBoundaryBuffer;
    state = 0 /* Start */ ;
    buffer = null;
    currentHeaders = new Headers();
    currentPayloadController = null;
    constructor(boundary, options = {}){
        this.boundary = boundary;
        this.findOpeningBoundary = createSearch(`--${boundary}`);
        this.openingBoundaryLength = 2 + boundary.length;
        this.findBoundary = createSearch(`\r
--${boundary}`);
        this.findPartialTailBoundary = createPartialTailSearch(`\r
--${boundary}`);
        this.boundaryLength = 4 + boundary.length;
        this.findDoubleNewline = createSearch("\r\n\r\n");
        this.maxHeaderSize = options.maxHeaderSize ?? 65536;
        this.maxBoundaryBuffer = options.maxBoundaryBuffer ?? 8192;
    }
    async *parseStream(stream) {
        const reader = stream.getReader();
        const messageQueue = new AsyncMessageQueue();
        const producer = this.startProducer(reader, messageQueue);
        try {
            yield* this.consumeMessages(messageQueue);
        } finally{
            messageQueue.cancel();
            this.closeCurrentPayload();
            try {
                await reader.cancel();
            } catch (error) {}
            await producer;
        }
    }
    /**
   * Producer: Continuously read chunks and parse messages
   */ async startProducer(reader, messageQueue) {
        try {
            while(!messageQueue.isTerminal){
                let result;
                try {
                    result = await reader.read();
                } catch (readError) {
                    if (readError instanceof Error && (readError.name === "AbortError" || readError.constructor.name === "AbortError" || readError.name === "TimeoutError" || readError.constructor.name === "TimeoutError")) {
                        break;
                    }
                    throw readError;
                }
                const { done, value } = result;
                if (done) {
                    if (this.buffer !== null && this.buffer.length > 0) {
                        const messages2 = this.write(new Uint8Array(0));
                        for (const message of messages2){
                            if (messageQueue.isTerminal) break;
                            messageQueue.enqueue(message);
                        }
                    }
                    if (this.state !== 4 /* Done */ ) {
                        if (this.state === 0 /* Start */ ) {
                            throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
                        }
                        throw new MultipartParseError("Unexpected end of stream");
                    }
                    break;
                }
                if (!(value instanceof Uint8Array)) {
                    throw new MultipartParseError(`Invalid chunk type: expected Uint8Array, got ${typeof value}`);
                }
                const messages = this.write(value);
                for (const message of messages){
                    if (messageQueue.isTerminal) break;
                    messageQueue.enqueue(message);
                }
            }
            if (!messageQueue.isTerminal) {
                messageQueue.finish();
            }
        } catch (error) {
            this.closeCurrentPayload(error);
            if (!messageQueue.isTerminal) {
                messageQueue.finish(error);
            }
        } finally{
            try {
                reader.releaseLock();
            } catch (error) {}
        }
    }
    /**
   * Consumer: Yield messages from the queue
   */ async *consumeMessages(messageQueue) {
        while(true){
            const message = await messageQueue.dequeue();
            if (message === null) {
                break;
            }
            yield message;
        }
    }
    /**
   * Process a chunk of data through the state machine and return any complete messages.
   *
   * Returns an array because a single chunk can contain multiple complete messages
   * when small messages with headers + body + boundary all fit in one network chunk.
   * All messages must be captured and queued to maintain proper message ordering.
   */ write(chunk) {
        const newMessages = [];
        if (this.state === 4 /* Done */ ) {
            throw new MultipartParseError("Unexpected data after end of stream");
        }
        let index = 0;
        let chunkLength = chunk.length;
        if (this.buffer !== null) {
            const newSize = this.buffer.length + chunkLength;
            const maxAllowedSize = this.state === 2 /* Header */  ? this.maxHeaderSize : this.maxBoundaryBuffer;
            if (newSize > maxAllowedSize) {
                throw new MultipartParseError(`Buffer size limit exceeded: ${newSize} bytes > ${maxAllowedSize} bytes. This may indicate malformed multipart data with ${this.state === 2 /* Header */  ? "oversized headers" : "invalid boundaries"}.`);
            }
            const newChunk = new Uint8Array(newSize);
            newChunk.set(this.buffer, 0);
            newChunk.set(chunk, this.buffer.length);
            chunk = newChunk;
            chunkLength = chunk.length;
            this.buffer = null;
        }
        if (chunkLength === 0 && this.state === 0 /* Start */ ) {
            throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
        }
        while(true){
            if (this.state === 3 /* Body */ ) {
                if (chunkLength - index < this.boundaryLength) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`Boundary buffer limit exceeded: ${remainingData.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                const boundaryIndex = this.findBoundary(chunk, index);
                if (boundaryIndex === -1) {
                    const partialTailIndex = this.findPartialTailBoundary(chunk);
                    if (partialTailIndex === -1) {
                        this.writeBody(index === 0 ? chunk : chunk.subarray(index));
                    } else {
                        this.writeBody(chunk.subarray(index, partialTailIndex));
                        const partialBoundary = chunk.subarray(partialTailIndex);
                        if (partialBoundary.length > this.maxBoundaryBuffer) {
                            throw new MultipartParseError(`Partial boundary too large: ${partialBoundary.length} > ${this.maxBoundaryBuffer}`);
                        }
                        this.buffer = partialBoundary;
                    }
                    break;
                }
                this.writeBody(chunk.subarray(index, boundaryIndex));
                this.finishMessage();
                index = boundaryIndex + this.boundaryLength;
                this.state = 1 /* AfterBoundary */ ;
            }
            if (this.state === 1 /* AfterBoundary */ ) {
                if (chunkLength - index < 2) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`After-boundary buffer limit exceeded: ${remainingData.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                if (chunk[index] === 45 && chunk[index + 1] === 45) {
                    this.state = 4 /* Done */ ;
                    break;
                }
                if (chunk[index] === 13 && chunk[index + 1] === 10) {
                    index += 2;
                } else if (chunk[index] === 10) {
                    index += 1;
                } else {
                    throw new MultipartParseError(`Invalid character after boundary: expected CRLF or LF, got 0x${chunk[index].toString(16)}`);
                }
                this.state = 2 /* Header */ ;
            }
            if (this.state === 2 /* Header */ ) {
                if (chunkLength - index < 4) {
                    const remainingData = chunk.subarray(index);
                    if (remainingData.length > this.maxHeaderSize) {
                        throw new MultipartParseError(`Header buffer limit exceeded: ${remainingData.length} > ${this.maxHeaderSize}`);
                    }
                    this.buffer = remainingData;
                    break;
                }
                let headerEndIndex = this.findDoubleNewline(chunk, index);
                let headerEndOffset = 4;
                if (headerEndIndex === -1) {
                    const lfDoubleNewline = createSearch("\n\n");
                    headerEndIndex = lfDoubleNewline(chunk, index);
                    headerEndOffset = 2;
                }
                if (headerEndIndex === -1) {
                    const headerData = chunk.subarray(index);
                    if (headerData.length > this.maxHeaderSize) {
                        throw new MultipartParseError(`Headers too large: ${headerData.length} > ${this.maxHeaderSize} bytes`);
                    }
                    this.buffer = headerData;
                    break;
                }
                const headerBytes = chunk.subarray(index, headerEndIndex);
                this.currentHeaders = parseHeaders(headerBytes);
                const message = this.createStreamingMessage();
                newMessages.push(message);
                index = headerEndIndex + headerEndOffset;
                this.state = 3 /* Body */ ;
                continue;
            }
            if (this.state === 0 /* Start */ ) {
                if (chunkLength < this.openingBoundaryLength) {
                    if (chunk.length > this.maxBoundaryBuffer) {
                        throw new MultipartParseError(`Initial chunk too large for boundary detection: ${chunk.length} > ${this.maxBoundaryBuffer}`);
                    }
                    this.buffer = chunk;
                    break;
                }
                const boundaryIndex = this.findOpeningBoundary(chunk);
                if (boundaryIndex !== 0) {
                    throw new MultipartParseError("Invalid multipart stream: missing initial boundary");
                }
                index = this.openingBoundaryLength;
                this.state = 1 /* AfterBoundary */ ;
            }
        }
        return newMessages;
    }
    createStreamingMessage() {
        const headers = new Headers(this.currentHeaders);
        const payload = new ReadableStream({
            start: (controller)=>{
                this.currentPayloadController = controller;
            }
        });
        this.currentHeaders = new Headers();
        return {
            headers,
            payload
        };
    }
    writeBody(chunk) {
        if (this.currentPayloadController) {
            this.currentPayloadController.enqueue(chunk);
        }
    }
    finishMessage() {
        if (this.currentPayloadController) {
            this.currentPayloadController.close();
            this.currentPayloadController = null;
        }
    }
    /**
   * Close current payload controller if open (used during cleanup)
   * If an error is provided, forwards it to the payload consumer
   */ closeCurrentPayload(error) {
        if (this.currentPayloadController) {
            try {
                if (error) {
                    this.currentPayloadController.error(error);
                } else {
                    this.currentPayloadController.close();
                }
            } catch (controllerError) {}
            this.currentPayloadController = null;
        }
    }
};
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_context_exports = {};
__export(get_context_exports, {
    SYMBOL_FOR_REQ_CONTEXT: ()=>SYMBOL_FOR_REQ_CONTEXT,
    getContext: ()=>getContext
});
module.exports = __toCommonJS(get_context_exports);
const SYMBOL_FOR_REQ_CONTEXT = Symbol.for("@vercel/request-context");
function getContext() {
    const fromSymbol = globalThis;
    return fromSymbol[SYMBOL_FOR_REQ_CONTEXT]?.get?.() ?? {};
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    SYMBOL_FOR_REQ_CONTEXT,
    getContext
});
}),
"[project]/node_modules/@vercel/oidc/dist/token-error.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var token_error_exports = {};
__export(token_error_exports, {
    VercelOidcTokenError: ()=>VercelOidcTokenError
});
module.exports = __toCommonJS(token_error_exports);
class VercelOidcTokenError extends Error {
    constructor(message, cause){
        super(message);
        this.name = "VercelOidcTokenError";
        this.cause = cause;
    }
    toString() {
        if (this.cause) {
            return `${this.name}: ${this.message}: ${this.cause}`;
        }
        return `${this.name}: ${this.message}`;
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    VercelOidcTokenError
});
}),
"[project]/node_modules/@vercel/oidc/dist/get-vercel-oidc-token.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toESM = (mod, isNodeMode, target)=>(target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(// If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
        value: mod,
        enumerable: true
    }) : target, mod));
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_vercel_oidc_token_exports = {};
__export(get_vercel_oidc_token_exports, {
    getVercelOidcToken: ()=>getVercelOidcToken,
    getVercelOidcTokenSync: ()=>getVercelOidcTokenSync
});
module.exports = __toCommonJS(get_vercel_oidc_token_exports);
var import_get_context = __turbopack_context__.r("[project]/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)");
var import_token_error = __turbopack_context__.r("[project]/node_modules/@vercel/oidc/dist/token-error.js [app-route] (ecmascript)");
async function getVercelOidcToken() {
    let token = "";
    let err;
    try {
        token = getVercelOidcTokenSync();
    } catch (error) {
        err = error;
    }
    try {
        const [{ getTokenPayload, isExpired }, { refreshToken }] = await Promise.all([
            await __turbopack_context__.A("[project]/node_modules/@vercel/oidc/dist/token-util.js [app-route] (ecmascript, async loader)"),
            await __turbopack_context__.A("[project]/node_modules/@vercel/oidc/dist/token.js [app-route] (ecmascript, async loader)")
        ]);
        if (!token || isExpired(getTokenPayload(token))) {
            await refreshToken();
            token = getVercelOidcTokenSync();
        }
    } catch (error) {
        if (err?.message && error instanceof Error) {
            error.message = `${err.message}
${error.message}`;
        }
        throw new import_token_error.VercelOidcTokenError(`Failed to refresh OIDC token`, error);
    }
    return token;
}
function getVercelOidcTokenSync() {
    const token = (0, import_get_context.getContext)().headers?.["x-vercel-oidc-token"] ?? process.env.VERCEL_OIDC_TOKEN;
    if (!token) {
        throw new Error(`The 'x-vercel-oidc-token' header is missing from the request. Do you have the OIDC option enabled in the Vercel project settings?`);
    }
    return token;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getVercelOidcToken,
    getVercelOidcTokenSync
});
}),
"[project]/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var src_exports = {};
__export(src_exports, {
    getContext: ()=>import_get_context.getContext,
    getVercelOidcToken: ()=>import_get_vercel_oidc_token.getVercelOidcToken,
    getVercelOidcTokenSync: ()=>import_get_vercel_oidc_token.getVercelOidcTokenSync
});
module.exports = __toCommonJS(src_exports);
var import_get_vercel_oidc_token = __turbopack_context__.r("[project]/node_modules/@vercel/oidc/dist/get-vercel-oidc-token.js [app-route] (ecmascript)");
var import_get_context = __turbopack_context__.r("[project]/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getContext,
    getVercelOidcToken,
    getVercelOidcTokenSync
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_context_exports = {};
__export(get_context_exports, {
    SYMBOL_FOR_REQ_CONTEXT: ()=>SYMBOL_FOR_REQ_CONTEXT,
    getContext: ()=>getContext
});
module.exports = __toCommonJS(get_context_exports);
const SYMBOL_FOR_REQ_CONTEXT = Symbol.for("@vercel/request-context");
function getContext() {
    const fromSymbol = globalThis;
    return fromSymbol[SYMBOL_FOR_REQ_CONTEXT]?.get?.() ?? {};
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    SYMBOL_FOR_REQ_CONTEXT,
    getContext
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token-error.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var token_error_exports = {};
__export(token_error_exports, {
    VercelOidcTokenError: ()=>VercelOidcTokenError
});
module.exports = __toCommonJS(token_error_exports);
class VercelOidcTokenError extends Error {
    constructor(message, cause){
        super(message);
        this.name = "VercelOidcTokenError";
        this.cause = cause;
    }
    toString() {
        if (this.cause) {
            return `${this.name}: ${this.message}: ${this.cause}`;
        }
        return `${this.name}: ${this.message}`;
    }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    VercelOidcTokenError
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-vercel-oidc-token.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toESM = (mod, isNodeMode, target)=>(target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(// If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", {
        value: mod,
        enumerable: true
    }) : target, mod));
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var get_vercel_oidc_token_exports = {};
__export(get_vercel_oidc_token_exports, {
    getVercelOidcToken: ()=>getVercelOidcToken,
    getVercelOidcTokenSync: ()=>getVercelOidcTokenSync
});
module.exports = __toCommonJS(get_vercel_oidc_token_exports);
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)");
var import_token_error = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token-error.js [app-route] (ecmascript)");
async function getVercelOidcToken() {
    let token = "";
    let err;
    try {
        token = getVercelOidcTokenSync();
    } catch (error) {
        err = error;
    }
    try {
        const [{ getTokenPayload, isExpired }, { refreshToken }] = await Promise.all([
            await __turbopack_context__.A("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token-util.js [app-route] (ecmascript, async loader)"),
            await __turbopack_context__.A("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/token.js [app-route] (ecmascript, async loader)")
        ]);
        if (!token || isExpired(getTokenPayload(token))) {
            await refreshToken();
            token = getVercelOidcTokenSync();
        }
    } catch (error) {
        if (err?.message && error instanceof Error) {
            error.message = `${err.message}
${error.message}`;
        }
        throw new import_token_error.VercelOidcTokenError(`Failed to refresh OIDC token`, error);
    }
    return token;
}
function getVercelOidcTokenSync() {
    const token = (0, import_get_context.getContext)().headers?.["x-vercel-oidc-token"] ?? process.env.VERCEL_OIDC_TOKEN;
    if (!token) {
        throw new Error(`The 'x-vercel-oidc-token' header is missing from the request. Do you have the OIDC option enabled in the Vercel project settings?`);
    }
    return token;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getVercelOidcToken,
    getVercelOidcTokenSync
});
}),
"[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all)=>{
    for(var name in all)__defProp(target, name, {
        get: all[name],
        enumerable: true
    });
};
var __copyProps = (to, from, except, desc)=>{
    if (from && typeof from === "object" || typeof from === "function") {
        for (let key of __getOwnPropNames(from))if (!__hasOwnProp.call(to, key) && key !== except) __defProp(to, key, {
            get: ()=>from[key],
            enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
    }
    return to;
};
var __toCommonJS = (mod)=>__copyProps(__defProp({}, "__esModule", {
        value: true
    }), mod);
var src_exports = {};
__export(src_exports, {
    getContext: ()=>import_get_context.getContext,
    getVercelOidcToken: ()=>import_get_vercel_oidc_token.getVercelOidcToken,
    getVercelOidcTokenSync: ()=>import_get_vercel_oidc_token.getVercelOidcTokenSync
});
module.exports = __toCommonJS(src_exports);
var import_get_vercel_oidc_token = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-vercel-oidc-token.js [app-route] (ecmascript)");
var import_get_context = __turbopack_context__.r("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/get-context.js [app-route] (ecmascript)");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
    getContext,
    getVercelOidcToken,
    getVercelOidcTokenSync
});
}),
"[project]/node_modules/@vercel/queue/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/transports.ts
__turbopack_context__.s([
    "BadRequestError",
    ()=>BadRequestError,
    "BufferTransport",
    ()=>BufferTransport,
    "Client",
    ()=>Client,
    "ForbiddenError",
    ()=>ForbiddenError,
    "InternalServerError",
    ()=>InternalServerError,
    "InvalidLimitError",
    ()=>InvalidLimitError,
    "JsonTransport",
    ()=>JsonTransport,
    "MessageCorruptedError",
    ()=>MessageCorruptedError,
    "MessageLockedError",
    ()=>MessageLockedError,
    "MessageNotAvailableError",
    ()=>MessageNotAvailableError,
    "MessageNotFoundError",
    ()=>MessageNotFoundError,
    "QueueEmptyError",
    ()=>QueueEmptyError,
    "StreamTransport",
    ()=>StreamTransport,
    "UnauthorizedError",
    ()=>UnauthorizedError,
    "handleCallback",
    ()=>handleCallback,
    "parseCallback",
    ()=>parseCallback,
    "receive",
    ()=>receive,
    "send",
    ()=>send
]);
// src/client.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$queue$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vercel/queue/node_modules/mixpart/dist/index.mjs [app-route] (ecmascript)");
// src/oidc.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)");
async function streamToBuffer(stream) {
    let totalLength = 0;
    const reader = stream.getReader();
    const chunks = [];
    try {
        while(true){
            const { done, value } = await reader.read();
            if (done) break;
            chunks.push(value);
            totalLength += value.length;
        }
    } finally{
        reader.releaseLock();
    }
    return Buffer.concat(chunks, totalLength);
}
var JsonTransport = class {
    contentType = "application/json";
    replacer;
    reviver;
    constructor(options = {}){
        this.replacer = options.replacer;
        this.reviver = options.reviver;
    }
    serialize(value) {
        return Buffer.from(JSON.stringify(value, this.replacer), "utf8");
    }
    async deserialize(stream) {
        const buffer = await streamToBuffer(stream);
        return JSON.parse(buffer.toString("utf8"), this.reviver);
    }
};
var BufferTransport = class {
    contentType = "application/octet-stream";
    serialize(value) {
        return value;
    }
    async deserialize(stream) {
        return await streamToBuffer(stream);
    }
};
var StreamTransport = class {
    contentType = "application/octet-stream";
    serialize(value) {
        return value;
    }
    async deserialize(stream) {
        return stream;
    }
    async finalize(payload) {
        const reader = payload.getReader();
        try {
            while(true){
                const { done } = await reader.read();
                if (done) break;
            }
        } finally{
            reader.releaseLock();
        }
    }
};
;
;
// src/types.ts
var MessageNotFoundError = class extends Error {
    constructor(messageId){
        super(`Message ${messageId} not found`);
        this.name = "MessageNotFoundError";
    }
};
var MessageNotAvailableError = class extends Error {
    constructor(messageId, reason){
        super(`Message ${messageId} not available for processing${reason ? `: ${reason}` : ""}`);
        this.name = "MessageNotAvailableError";
    }
};
var MessageCorruptedError = class extends Error {
    constructor(messageId, reason){
        super(`Message ${messageId} is corrupted: ${reason}`);
        this.name = "MessageCorruptedError";
    }
};
var QueueEmptyError = class extends Error {
    constructor(queueName, consumerGroup){
        super(`No messages available in queue "${queueName}" for consumer group "${consumerGroup}"`);
        this.name = "QueueEmptyError";
    }
};
var MessageLockedError = class extends Error {
    retryAfter;
    constructor(messageId, retryAfter){
        const retryMessage = retryAfter ? ` Retry after ${retryAfter} seconds.` : " Try again later.";
        super(`Message ${messageId} is temporarily locked.${retryMessage}`);
        this.name = "MessageLockedError";
        this.retryAfter = retryAfter;
    }
};
var UnauthorizedError = class extends Error {
    constructor(message = "Missing or invalid authentication token"){
        super(message);
        this.name = "UnauthorizedError";
    }
};
var ForbiddenError = class extends Error {
    constructor(message = "Queue environment doesn't match token environment"){
        super(message);
        this.name = "ForbiddenError";
    }
};
var BadRequestError = class extends Error {
    constructor(message){
        super(message);
        this.name = "BadRequestError";
    }
};
var InternalServerError = class extends Error {
    constructor(message = "Unexpected server error"){
        super(message);
        this.name = "InternalServerError";
    }
};
var InvalidLimitError = class extends Error {
    constructor(limit, min = 1, max = 10){
        super(`Invalid limit: ${limit}. Limit must be between ${min} and ${max}.`);
        this.name = "InvalidLimitError";
    }
};
// src/client.ts
function isDebugEnabled() {
    return process.env.VERCEL_QUEUE_DEBUG === "1" || process.env.VERCEL_QUEUE_DEBUG === "true";
}
async function consumeStream(stream) {
    const reader = stream.getReader();
    try {
        while(true){
            const { done } = await reader.read();
            if (done) break;
        }
    } finally{
        reader.releaseLock();
    }
}
function parseRetryAfter(headers) {
    const retryAfterHeader = headers.get("Retry-After");
    if (retryAfterHeader) {
        const parsed = parseInt(retryAfterHeader, 10);
        return Number.isNaN(parsed) ? void 0 : parsed;
    }
    return void 0;
}
function throwCommonHttpError(status, statusText, errorText, operation, badRequestDefault = "Invalid parameters") {
    if (status === 400) {
        throw new BadRequestError(errorText || badRequestDefault);
    }
    if (status === 401) {
        throw new UnauthorizedError(errorText || void 0);
    }
    if (status === 403) {
        throw new ForbiddenError(errorText || void 0);
    }
    if (status >= 500) {
        throw new InternalServerError(errorText || `Server error: ${status} ${statusText}`);
    }
    throw new Error(`Failed to ${operation}: ${status} ${statusText}`);
}
function parseQueueHeaders(headers) {
    const messageId = headers.get("Vqs-Message-Id");
    const deliveryCountStr = headers.get("Vqs-Delivery-Count") || "0";
    const timestamp = headers.get("Vqs-Timestamp");
    const contentType = headers.get("Content-Type") || "application/octet-stream";
    const ticket = headers.get("Vqs-Ticket");
    if (!messageId || !timestamp || !ticket) {
        return null;
    }
    const deliveryCount = parseInt(deliveryCountStr, 10);
    if (Number.isNaN(deliveryCount)) {
        return null;
    }
    return {
        messageId,
        deliveryCount,
        createdAt: new Date(timestamp),
        contentType,
        ticket
    };
}
var QueueClient = class {
    baseUrl;
    basePath;
    customHeaders;
    providedToken;
    /**
   * Create a new Vercel Queue Service client
   * @param options QueueClient configuration options
   */ constructor(options = {}){
        this.baseUrl = options.baseUrl || process.env.VERCEL_QUEUE_BASE_URL || "https://vercel-queue.com";
        this.basePath = options.basePath || process.env.VERCEL_QUEUE_BASE_PATH || "/api/v2/messages";
        this.customHeaders = options.headers || {};
        this.providedToken = options.token;
    }
    async getToken() {
        if (this.providedToken) {
            return this.providedToken;
        }
        const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVercelOidcToken"])();
        if (!token) {
            throw new Error("Failed to get OIDC token from Vercel Functions. Make sure you are running in a Vercel Function environment, or provide a token explicitly.\n\nTo set up your environment:\n1. Link your project: 'vercel link'\n2. Pull environment variables: 'vercel env pull'\n3. Run with environment: 'dotenv -e .env.local -- your-command'");
        }
        return token;
    }
    /**
   * Internal fetch wrapper that automatically handles debug logging
   * when VERCEL_QUEUE_DEBUG is enabled
   */ async fetch(url, init) {
        const method = init.method || "GET";
        if (isDebugEnabled()) {
            const logData = {
                method,
                url,
                headers: init.headers
            };
            const body = init.body;
            if (body !== void 0 && body !== null) {
                if (body instanceof ArrayBuffer) {
                    logData.bodySize = body.byteLength;
                } else if (body instanceof Uint8Array) {
                    logData.bodySize = body.byteLength;
                } else if (typeof body === "string") {
                    logData.bodySize = body.length;
                } else {
                    logData.bodyType = typeof body;
                }
            }
            console.debug("[VQS Debug] Request:", JSON.stringify(logData, null, 2));
        }
        const response = await fetch(url, init);
        if (isDebugEnabled()) {
            const logData = {
                method,
                url,
                status: response.status,
                statusText: response.statusText,
                headers: response.headers
            };
            console.debug("[VQS Debug] Response:", JSON.stringify(logData, null, 2));
        }
        return response;
    }
    /**
   * Send a message to a queue
   * @param options Send message options
   * @param transport Serializer/deserializer for the payload
   * @returns Promise with the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async sendMessage(options, transport) {
        const { queueName, payload, idempotencyKey, retentionSeconds } = options;
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Content-Type": transport.contentType,
            ...this.customHeaders
        });
        const deploymentId = options.deploymentId || process.env.VERCEL_DEPLOYMENT_ID;
        if (deploymentId) {
            headers.set("Vqs-Deployment-Id", deploymentId);
        }
        if (idempotencyKey) {
            headers.set("Vqs-Idempotency-Key", idempotencyKey);
        }
        if (retentionSeconds !== void 0) {
            headers.set("Vqs-Retention-Seconds", retentionSeconds.toString());
        }
        const body = transport.serialize(payload);
        const response = await this.fetch(`${this.baseUrl}${this.basePath}`, {
            method: "POST",
            body,
            headers
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 409) {
                throw new Error("Duplicate idempotency key detected");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "send message");
        }
        const responseData = await response.json();
        return responseData;
    }
    /**
   * Receive messages from a queue
   * @param options Receive messages options
   * @param transport Serializer/deserializer for the payload
   * @returns AsyncGenerator that yields messages as they arrive
   * @throws {InvalidLimitError} When limit parameter is not between 1 and 10
   * @throws {QueueEmptyError} When no messages are available (204)
   * @throws {MessageLockedError} When messages are temporarily locked (423)
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async *receiveMessages(options, transport) {
        const { queueName, consumerGroup, visibilityTimeoutSeconds, limit } = options;
        if (limit !== void 0 && (limit < 1 || limit > 10)) {
            throw new InvalidLimitError(limit);
        }
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Vqs-Consumer-Group": consumerGroup,
            Accept: "multipart/mixed",
            ...this.customHeaders
        });
        if (visibilityTimeoutSeconds !== void 0) {
            headers.set("Vqs-Visibility-Timeout", visibilityTimeoutSeconds.toString());
        }
        if (limit !== void 0) {
            headers.set("Vqs-Limit", limit.toString());
        }
        const response = await this.fetch(`${this.baseUrl}${this.basePath}`, {
            method: "GET",
            headers
        });
        if (response.status === 204) {
            throw new QueueEmptyError(queueName, consumerGroup);
        }
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 423) {
                throw new MessageLockedError("next message", parseRetryAfter(response.headers));
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "receive messages");
        }
        for await (const multipartMessage of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$queue$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMultipartStream"])(response)){
            try {
                const parsedHeaders = parseQueueHeaders(multipartMessage.headers);
                if (!parsedHeaders) {
                    console.warn("Missing required queue headers in multipart part");
                    await consumeStream(multipartMessage.payload);
                    continue;
                }
                const deserializedPayload = await transport.deserialize(multipartMessage.payload);
                const message = {
                    ...parsedHeaders,
                    payload: deserializedPayload
                };
                yield message;
            } catch (error) {
                console.warn("Failed to process multipart message:", error);
                await consumeStream(multipartMessage.payload);
            }
        }
    }
    async receiveMessageById(options, transport) {
        const { queueName, consumerGroup, messageId, visibilityTimeoutSeconds, skipPayload } = options;
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Vqs-Consumer-Group": consumerGroup,
            Accept: "multipart/mixed",
            ...this.customHeaders
        });
        if (visibilityTimeoutSeconds !== void 0) {
            headers.set("Vqs-Visibility-Timeout", visibilityTimeoutSeconds.toString());
        }
        if (skipPayload) {
            headers.set("Vqs-Skip-Payload", "1");
        }
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "GET",
            headers
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId);
            }
            if (response.status === 423) {
                throw new MessageLockedError(messageId, parseRetryAfter(response.headers));
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "receive message by ID");
        }
        if (skipPayload && response.status === 204) {
            const parsedHeaders = parseQueueHeaders(response.headers);
            if (!parsedHeaders) {
                throw new MessageCorruptedError(messageId, "Missing required queue headers in 204 response");
            }
            const message = {
                ...parsedHeaders,
                payload: void 0
            };
            return {
                message
            };
        }
        if (!transport) {
            throw new Error("Transport is required when skipPayload is not true");
        }
        try {
            for await (const multipartMessage of (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$queue$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMultipartStream"])(response)){
                try {
                    const parsedHeaders = parseQueueHeaders(multipartMessage.headers);
                    if (!parsedHeaders) {
                        console.warn("Missing required queue headers in multipart part");
                        await consumeStream(multipartMessage.payload);
                        continue;
                    }
                    const deserializedPayload = await transport.deserialize(multipartMessage.payload);
                    const message = {
                        ...parsedHeaders,
                        payload: deserializedPayload
                    };
                    return {
                        message
                    };
                } catch (error) {
                    console.warn("Failed to deserialize message by ID:", error);
                    await consumeStream(multipartMessage.payload);
                    throw new MessageCorruptedError(messageId, `Failed to deserialize payload: ${error}`);
                }
            }
        } catch (error) {
            if (error instanceof MessageCorruptedError) {
                throw error;
            }
            throw new MessageCorruptedError(messageId, `Failed to parse multipart response: ${error}`);
        }
        throw new MessageNotFoundError(messageId);
    }
    /**
   * Delete a message (acknowledge processing)
   * @param options Delete message options
   * @returns Promise with delete status
   * @throws {MessageNotFoundError} When the message doesn't exist (404)
   * @throws {MessageNotAvailableError} When message can't be deleted (409)
   * @throws {BadRequestError} When ticket is missing or invalid (400)
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async deleteMessage(options) {
        const { queueName, consumerGroup, messageId, ticket } = options;
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "DELETE",
            headers: new Headers({
                Authorization: `Bearer ${await this.getToken()}`,
                "Vqs-Queue-Name": queueName,
                "Vqs-Consumer-Group": consumerGroup,
                "Vqs-Ticket": ticket,
                ...this.customHeaders
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId, errorText || "Invalid ticket, message not in correct state, or already processed");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "delete message", "Missing or invalid ticket");
        }
        return {
            deleted: true
        };
    }
    /**
   * Change the visibility timeout of a message
   * @param options Change visibility options
   * @returns Promise with update status
   * @throws {MessageNotFoundError} When the message doesn't exist (404)
   * @throws {MessageNotAvailableError} When message can't be updated (409)
   * @throws {BadRequestError} When ticket is missing or visibility timeout invalid (400)
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async changeVisibility(options) {
        const { queueName, consumerGroup, messageId, ticket, visibilityTimeoutSeconds } = options;
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "PATCH",
            headers: new Headers({
                Authorization: `Bearer ${await this.getToken()}`,
                "Vqs-Queue-Name": queueName,
                "Vqs-Consumer-Group": consumerGroup,
                "Vqs-Ticket": ticket,
                "Vqs-Visibility-Timeout": visibilityTimeoutSeconds.toString(),
                ...this.customHeaders
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId, errorText || "Invalid ticket, message not in correct state, or already processed");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "change visibility", "Missing ticket or invalid visibility timeout");
        }
        return {
            updated: true
        };
    }
};
// src/dev.ts
var GLOBAL_KEY = Symbol.for("@vercel/queue.devHandlers");
function getDevHandlerState() {
    const g = globalThis;
    if (!g[GLOBAL_KEY]) {
        g[GLOBAL_KEY] = {
            devRouteHandlers: /* @__PURE__ */ new Map(),
            wildcardRouteHandlers: /* @__PURE__ */ new Map()
        };
    }
    return g[GLOBAL_KEY];
}
var { devRouteHandlers, wildcardRouteHandlers } = getDevHandlerState();
function cleanupDeadRefs(key, refs) {
    const aliveRefs = refs.filter((ref)=>ref.deref() !== void 0);
    if (aliveRefs.length === 0) {
        wildcardRouteHandlers.delete(key);
    } else if (aliveRefs.length < refs.length) {
        wildcardRouteHandlers.set(key, aliveRefs);
    }
}
function isDevMode() {
    return ("TURBOPACK compile-time value", "development") === "development";
}
function registerDevRouteHandler(routeHandler, handlers) {
    for(const topicName in handlers){
        for(const consumerGroup in handlers[topicName]){
            const key = `${topicName}:${consumerGroup}`;
            if (topicName.includes("*")) {
                const existing = wildcardRouteHandlers.get(key) || [];
                cleanupDeadRefs(key, existing);
                const cleanedRefs = wildcardRouteHandlers.get(key) || [];
                const weakRef = new WeakRef(routeHandler);
                cleanedRefs.push(weakRef);
                wildcardRouteHandlers.set(key, cleanedRefs);
            } else {
                devRouteHandlers.set(key, {
                    routeHandler,
                    topicPattern: topicName
                });
            }
        }
    }
}
function findRouteHandlersForTopic(topicName) {
    const handlersMap = /* @__PURE__ */ new Map();
    for (const [key, { routeHandler, topicPattern }] of devRouteHandlers.entries()){
        const [_, consumerGroup] = key.split(":");
        if (topicPattern === topicName) {
            if (!handlersMap.has(routeHandler)) {
                handlersMap.set(routeHandler, /* @__PURE__ */ new Set());
            }
            handlersMap.get(routeHandler).add(consumerGroup);
        }
    }
    for (const [key, refs] of wildcardRouteHandlers.entries()){
        const [pattern, consumerGroup] = key.split(":");
        if (matchesWildcardPattern(topicName, pattern)) {
            cleanupDeadRefs(key, refs);
            const cleanedRefs = wildcardRouteHandlers.get(key) || [];
            for (const ref of cleanedRefs){
                const routeHandler = ref.deref();
                if (routeHandler) {
                    if (!handlersMap.has(routeHandler)) {
                        handlersMap.set(routeHandler, /* @__PURE__ */ new Set());
                    }
                    handlersMap.get(routeHandler).add(consumerGroup);
                }
            }
        }
    }
    return handlersMap;
}
function createMockCloudEventRequest(topicName, consumerGroup, messageId) {
    const cloudEvent = {
        type: "com.vercel.queue.v1beta",
        source: `/topic/${topicName}/consumer/${consumerGroup}`,
        id: messageId,
        datacontenttype: "application/json",
        data: {
            messageId,
            queueName: topicName,
            consumerGroup
        },
        time: /* @__PURE__ */ new Date().toISOString(),
        specversion: "1.0"
    };
    return new Request("https://localhost/api/queue/callback", {
        method: "POST",
        headers: {
            "Content-Type": "application/cloudevents+json"
        },
        body: JSON.stringify(cloudEvent)
    });
}
var DEV_CALLBACK_DELAY = 1e3;
function scheduleDevTimeout(topicName, messageId, timeoutSeconds) {
    console.log(`[Dev Mode] Message ${messageId} timed out for ${timeoutSeconds}s, will re-trigger`);
    setTimeout(()=>{
        console.log(`[Dev Mode] Re-triggering callback for timed-out message ${messageId}`);
        triggerDevCallbacks(topicName, messageId);
    }, timeoutSeconds * 1e3 + DEV_CALLBACK_DELAY);
}
function triggerDevCallbacks(topicName, messageId) {
    const handlersMap = findRouteHandlersForTopic(topicName);
    if (handlersMap.size === 0) {
        return;
    }
    const consumerGroups = Array.from(new Set(Array.from(handlersMap.values()).flatMap((groups)=>Array.from(groups))));
    console.log(`[Dev Mode] Triggering local callbacks for topic "${topicName}" \u2192 consumers: ${consumerGroups.join(", ")}`);
    setTimeout(async ()=>{
        for (const [routeHandler, consumerGroups2] of handlersMap.entries()){
            for (const consumerGroup of consumerGroups2){
                try {
                    const request = createMockCloudEventRequest(topicName, consumerGroup, messageId);
                    const response = await routeHandler(request);
                    if (response.ok) {
                        try {
                            const responseData = await response.json();
                            if (responseData.status === "success") {
                                console.log(`[Dev Mode] Message processed for ${topicName}/${consumerGroup}`);
                            }
                        } catch (jsonError) {
                            console.error(`[Dev Mode] Failed to parse success response for ${topicName}/${consumerGroup}:`, jsonError);
                        }
                    } else {
                        try {
                            const errorData = await response.json();
                            console.error(`[Dev Mode] Failed to process message for ${topicName}/${consumerGroup}:`, errorData.error || response.statusText);
                        } catch (jsonError) {
                            console.error(`[Dev Mode] Failed to process message for ${topicName}/${consumerGroup}:`, response.statusText);
                        }
                    }
                } catch (error) {
                    console.error(`[Dev Mode] Error triggering callback for ${topicName}/${consumerGroup}:`, error);
                }
            }
        }
    }, DEV_CALLBACK_DELAY);
}
function clearDevHandlers() {
    devRouteHandlers.clear();
    wildcardRouteHandlers.clear();
}
if (("TURBOPACK compile-time value", "development") === "test" || process.env.VITEST) {
    globalThis.__clearDevHandlers = clearDevHandlers;
}
// src/consumer-group.ts
var ConsumerGroup = class {
    client;
    topicName;
    consumerGroupName;
    visibilityTimeout;
    refreshInterval;
    transport;
    /**
   * Create a new ConsumerGroup instance
   * @param client QueueClient instance to use for API calls
   * @param topicName Name of the topic to consume from
   * @param consumerGroupName Name of the consumer group
   * @param options Optional configuration
   */ constructor(client, topicName, consumerGroupName, options = {}){
        this.client = client;
        this.topicName = topicName;
        this.consumerGroupName = consumerGroupName;
        this.visibilityTimeout = options.visibilityTimeoutSeconds || 30;
        this.refreshInterval = options.refreshInterval || 10;
        this.transport = options.transport || new JsonTransport();
    }
    /**
   * Starts a background loop that periodically extends the visibility timeout for a message.
   * This prevents the message from becoming visible to other consumers while it's being processed.
   *
   * The extension loop runs every `refreshInterval` seconds and updates the message's
   * visibility timeout to `visibilityTimeout` seconds from the current time.
   *
   * @param messageId - The unique identifier of the message to extend visibility for
   * @param ticket - The receipt ticket that proves ownership of the message
   * @returns A function that when called will stop the extension loop
   *
   * @remarks
   * - The first extension attempt occurs after `refreshInterval` seconds, not immediately
   * - If an extension fails, the loop terminates with an error logged to console
   * - The returned stop function is idempotent - calling it multiple times is safe
   * - By default, the stop function returns immediately without waiting for in-flight
   * - Pass `true` to the stop function to wait for any in-flight extension to complete
   */ startVisibilityExtension(messageId, ticket) {
        let isRunning = true;
        let resolveLifecycle;
        let timeoutId = null;
        const lifecyclePromise = new Promise((resolve)=>{
            resolveLifecycle = resolve;
        });
        const extend = async ()=>{
            if (!isRunning) {
                resolveLifecycle();
                return;
            }
            try {
                await this.client.changeVisibility({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId,
                    ticket,
                    visibilityTimeoutSeconds: this.visibilityTimeout
                });
                if (isRunning) {
                    timeoutId = setTimeout(()=>extend(), this.refreshInterval * 1e3);
                } else {
                    resolveLifecycle();
                }
            } catch (error) {
                console.error(`Failed to extend visibility for message ${messageId}:`, error);
                resolveLifecycle();
            }
        };
        timeoutId = setTimeout(()=>extend(), this.refreshInterval * 1e3);
        return async (waitForCompletion = false)=>{
            isRunning = false;
            if (timeoutId) {
                clearTimeout(timeoutId);
                timeoutId = null;
            }
            if (waitForCompletion) {
                await lifecyclePromise;
            } else {
                resolveLifecycle();
            }
        };
    }
    /**
   * Process a single message with the given handler
   * @param message The message to process
   * @param handler Function to process the message
   */ async processMessage(message, handler) {
        const stopExtension = this.startVisibilityExtension(message.messageId, message.ticket);
        try {
            const result = await handler(message.payload, {
                messageId: message.messageId,
                deliveryCount: message.deliveryCount,
                createdAt: message.createdAt,
                topicName: this.topicName,
                consumerGroup: this.consumerGroupName
            });
            await stopExtension();
            if (result && "timeoutSeconds" in result) {
                await this.client.changeVisibility({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: message.messageId,
                    ticket: message.ticket,
                    visibilityTimeoutSeconds: result.timeoutSeconds
                });
                if (isDevMode()) {
                    scheduleDevTimeout(this.topicName, message.messageId, result.timeoutSeconds);
                }
            } else {
                await this.client.deleteMessage({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: message.messageId,
                    ticket: message.ticket
                });
            }
        } catch (error) {
            await stopExtension();
            if (this.transport.finalize && message.payload !== void 0 && message.payload !== null) {
                try {
                    await this.transport.finalize(message.payload);
                } catch (finalizeError) {
                    console.warn("Failed to finalize message payload:", finalizeError);
                }
            }
            throw error;
        }
    }
    async consume(handler, options) {
        if (options?.messageId) {
            if (options.skipPayload) {
                const response = await this.client.receiveMessageById({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: options.messageId,
                    visibilityTimeoutSeconds: this.visibilityTimeout,
                    skipPayload: true
                }, this.transport);
                await this.processMessage(response.message, handler);
            } else {
                const response = await this.client.receiveMessageById({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: options.messageId,
                    visibilityTimeoutSeconds: this.visibilityTimeout
                }, this.transport);
                await this.processMessage(response.message, handler);
            }
        } else {
            let messageFound = false;
            for await (const message of this.client.receiveMessages({
                queueName: this.topicName,
                consumerGroup: this.consumerGroupName,
                visibilityTimeoutSeconds: this.visibilityTimeout,
                limit: 1
            }, this.transport)){
                messageFound = true;
                await this.processMessage(message, handler);
                break;
            }
            if (!messageFound) {
                throw new Error("No messages available");
            }
        }
    }
    /**
   * Get the consumer group name
   */ get name() {
        return this.consumerGroupName;
    }
    /**
   * Get the topic name this consumer group is subscribed to
   */ get topic() {
        return this.topicName;
    }
};
// src/topic.ts
var Topic = class {
    client;
    topicName;
    transport;
    /**
   * Create a new Topic instance
   * @param client QueueClient instance to use for API calls
   * @param topicName Name of the topic to work with
   * @param transport Optional serializer/deserializer for the payload (defaults to JSON)
   */ constructor(client, topicName, transport){
        this.client = client;
        this.topicName = topicName;
        this.transport = transport || new JsonTransport();
    }
    /**
   * Publish a message to the topic
   * @param payload The data to publish
   * @param options Optional publish options
   * @returns An object containing the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async publish(payload, options) {
        const result = await this.client.sendMessage({
            queueName: this.topicName,
            payload,
            idempotencyKey: options?.idempotencyKey,
            retentionSeconds: options?.retentionSeconds,
            deploymentId: options?.deploymentId
        }, this.transport);
        if (isDevMode()) {
            triggerDevCallbacks(this.topicName, result.messageId);
        }
        return {
            messageId: result.messageId
        };
    }
    /**
   * Create a consumer group for this topic
   * @param consumerGroupName Name of the consumer group
   * @param options Optional configuration for the consumer group
   * @returns A ConsumerGroup instance
   */ consumerGroup(consumerGroupName, options) {
        const consumerOptions = {
            ...options,
            transport: options?.transport || this.transport
        };
        return new ConsumerGroup(this.client, this.topicName, consumerGroupName, consumerOptions);
    }
    /**
   * Get the topic name
   */ get name() {
        return this.topicName;
    }
    /**
   * Get the transport used by this topic
   */ get serializer() {
        return this.transport;
    }
};
// src/callback.ts
function validateWildcardPattern(pattern) {
    const firstIndex = pattern.indexOf("*");
    const lastIndex = pattern.lastIndexOf("*");
    if (firstIndex !== lastIndex) {
        return false;
    }
    if (firstIndex === -1) {
        return false;
    }
    if (firstIndex !== pattern.length - 1) {
        return false;
    }
    return true;
}
function matchesWildcardPattern(topicName, pattern) {
    const prefix = pattern.slice(0, -1);
    return topicName.startsWith(prefix);
}
function findTopicHandler(queueName, handlers) {
    const exactHandler = handlers[queueName];
    if (exactHandler) {
        return exactHandler;
    }
    for(const pattern in handlers){
        if (pattern.includes("*") && matchesWildcardPattern(queueName, pattern)) {
            return handlers[pattern];
        }
    }
    return null;
}
async function parseCallback(request) {
    const contentType = request.headers.get("content-type");
    if (!contentType || !contentType.includes("application/cloudevents+json")) {
        throw new Error("Invalid content type: expected 'application/cloudevents+json'");
    }
    let cloudEvent;
    try {
        cloudEvent = await request.json();
    } catch (error) {
        throw new Error("Failed to parse CloudEvent from request body");
    }
    if (!cloudEvent.type || !cloudEvent.source || !cloudEvent.id || typeof cloudEvent.data !== "object" || cloudEvent.data == null) {
        throw new Error("Invalid CloudEvent: missing required fields");
    }
    if (cloudEvent.type !== "com.vercel.queue.v1beta") {
        throw new Error(`Invalid CloudEvent type: expected 'com.vercel.queue.v1beta', got '${cloudEvent.type}'`);
    }
    const missingFields = [];
    if (!("queueName" in cloudEvent.data)) missingFields.push("queueName");
    if (!("consumerGroup" in cloudEvent.data)) missingFields.push("consumerGroup");
    if (!("messageId" in cloudEvent.data)) missingFields.push("messageId");
    if (missingFields.length > 0) {
        throw new Error(`Missing required CloudEvent data fields: ${missingFields.join(", ")}`);
    }
    const { messageId, queueName, consumerGroup } = cloudEvent.data;
    return {
        queueName,
        consumerGroup,
        messageId
    };
}
function createCallbackHandler(handlers, client) {
    for(const topicPattern in handlers){
        if (topicPattern.includes("*")) {
            if (!validateWildcardPattern(topicPattern)) {
                throw new Error(`Invalid wildcard pattern "${topicPattern}": * may only appear once and must be at the end of the topic name`);
            }
        }
    }
    const routeHandler = async (request)=>{
        try {
            const { queueName, consumerGroup, messageId } = await parseCallback(request);
            const topicHandler = findTopicHandler(queueName, handlers);
            if (!topicHandler) {
                const availableTopics = Object.keys(handlers).join(", ");
                return Response.json({
                    error: `No handler found for topic: ${queueName}`,
                    availableTopics
                }, {
                    status: 404
                });
            }
            const consumerGroupHandler = topicHandler[consumerGroup];
            if (!consumerGroupHandler) {
                const availableGroups = Object.keys(topicHandler).join(", ");
                return Response.json({
                    error: `No handler found for consumer group "${consumerGroup}" in topic "${queueName}".`,
                    availableGroups
                }, {
                    status: 404
                });
            }
            const topic = new Topic(client, queueName);
            const cg = topic.consumerGroup(consumerGroup);
            await cg.consume(consumerGroupHandler, {
                messageId
            });
            return Response.json({
                status: "success"
            });
        } catch (error) {
            console.error("Queue callback error:", error);
            if (error instanceof Error && (error.message.includes("Missing required CloudEvent data fields") || error.message.includes("Invalid CloudEvent") || error.message.includes("Invalid CloudEvent type") || error.message.includes("Invalid content type") || error.message.includes("Failed to parse CloudEvent"))) {
                return Response.json({
                    error: error.message
                }, {
                    status: 400
                });
            }
            return Response.json({
                error: "Failed to process queue message"
            }, {
                status: 500
            });
        }
    };
    if (isDevMode()) {
        registerDevRouteHandler(routeHandler, handlers);
    }
    return routeHandler;
}
function handleCallback(handlers, client) {
    return createCallbackHandler(handlers, client || new QueueClient());
}
// src/factory.ts
async function send(topicName, payload, options) {
    const transport = options?.transport || new JsonTransport();
    const client = options?.client || new QueueClient();
    const result = await client.sendMessage({
        queueName: topicName,
        payload,
        idempotencyKey: options?.idempotencyKey,
        retentionSeconds: options?.retentionSeconds,
        deploymentId: options?.deploymentId
    }, transport);
    if (isDevMode()) {
        triggerDevCallbacks(topicName, result.messageId);
    }
    return {
        messageId: result.messageId
    };
}
async function receive(topicName, consumerGroup, handler, options) {
    const transport = options?.transport || new JsonTransport();
    const client = options?.client || new QueueClient();
    const topic = new Topic(client, topicName, transport);
    const { messageId, skipPayload, client: _, ...consumerGroupOptions } = options || {};
    const consumer = topic.consumerGroup(consumerGroup, consumerGroupOptions);
    if (messageId) {
        if (skipPayload) {
            return consumer.consume(handler, {
                messageId,
                skipPayload: true
            });
        } else {
            return consumer.consume(handler, {
                messageId
            });
        }
    } else {
        return consumer.consume(handler);
    }
}
// src/queue-client.ts
var Client = class {
    client;
    /**
   * Create a new Client
   * @param options QueueClient configuration options
   */ constructor(options = {}){
        this.client = new QueueClient(options);
    }
    /**
   * Send a message to a topic
   * @param topicName Name of the topic to send to
   * @param payload The data to send
   * @param options Optional publish options and transport
   * @returns Promise with the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async send(topicName, payload, options) {
        return send(topicName, payload, {
            ...options,
            client: this.client
        });
    }
    /**
   * Create a callback handler for processing queue messages
   * Returns a Next.js route handler function that routes messages to appropriate handlers
   * @param handlers Object with topic-specific handlers organized by consumer groups
   * @returns A Next.js route handler function
   *
   * @example
   * ```typescript
   * export const POST = client.handleCallback({
   *   "user-events": {
   *     "welcome": (user, metadata) => console.log("Welcoming user", user),
   *     "analytics": (user, metadata) => console.log("Tracking user", user),
   *   },
   * });
   * ```
   */ handleCallback(handlers) {
        return handleCallback(handlers, this.client);
    }
};
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/frontend/node_modules/.pnpm/@vercel+queue@0.0.0-alpha.33/node_modules/@vercel/queue/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/transports.ts
__turbopack_context__.s([
    "BadRequestError",
    ()=>BadRequestError,
    "BufferTransport",
    ()=>BufferTransport,
    "Client",
    ()=>Client,
    "ForbiddenError",
    ()=>ForbiddenError,
    "InternalServerError",
    ()=>InternalServerError,
    "InvalidLimitError",
    ()=>InvalidLimitError,
    "JsonTransport",
    ()=>JsonTransport,
    "MessageCorruptedError",
    ()=>MessageCorruptedError,
    "MessageLockedError",
    ()=>MessageLockedError,
    "MessageNotAvailableError",
    ()=>MessageNotAvailableError,
    "MessageNotFoundError",
    ()=>MessageNotFoundError,
    "QueueEmptyError",
    ()=>QueueEmptyError,
    "StreamTransport",
    ()=>StreamTransport,
    "UnauthorizedError",
    ()=>UnauthorizedError,
    "handleCallback",
    ()=>handleCallback,
    "parseCallback",
    ()=>parseCallback,
    "receive",
    ()=>receive,
    "send",
    ()=>send
]);
// src/client.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$mixpart$40$0$2e$0$2e$5$2d$alpha$2e$1$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/mixpart@0.0.5-alpha.1/node_modules/mixpart/dist/index.mjs [app-route] (ecmascript)");
// src/oidc.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$oidc$40$3$2e$0$2e$5$2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+oidc@3.0.5/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)");
async function streamToBuffer(stream) {
    let totalLength = 0;
    const reader = stream.getReader();
    const chunks = [];
    try {
        while(true){
            const { done, value } = await reader.read();
            if (done) break;
            chunks.push(value);
            totalLength += value.length;
        }
    } finally{
        reader.releaseLock();
    }
    return Buffer.concat(chunks, totalLength);
}
var JsonTransport = class {
    contentType = "application/json";
    replacer;
    reviver;
    constructor(options = {}){
        this.replacer = options.replacer;
        this.reviver = options.reviver;
    }
    serialize(value) {
        return Buffer.from(JSON.stringify(value, this.replacer), "utf8");
    }
    async deserialize(stream) {
        const buffer = await streamToBuffer(stream);
        return JSON.parse(buffer.toString("utf8"), this.reviver);
    }
};
var BufferTransport = class {
    contentType = "application/octet-stream";
    serialize(value) {
        return value;
    }
    async deserialize(stream) {
        return await streamToBuffer(stream);
    }
};
var StreamTransport = class {
    contentType = "application/octet-stream";
    serialize(value) {
        return value;
    }
    async deserialize(stream) {
        return stream;
    }
    async finalize(payload) {
        const reader = payload.getReader();
        try {
            while(true){
                const { done } = await reader.read();
                if (done) break;
            }
        } finally{
            reader.releaseLock();
        }
    }
};
;
;
// src/types.ts
var MessageNotFoundError = class extends Error {
    constructor(messageId){
        super(`Message ${messageId} not found`);
        this.name = "MessageNotFoundError";
    }
};
var MessageNotAvailableError = class extends Error {
    constructor(messageId, reason){
        super(`Message ${messageId} not available for processing${reason ? `: ${reason}` : ""}`);
        this.name = "MessageNotAvailableError";
    }
};
var MessageCorruptedError = class extends Error {
    constructor(messageId, reason){
        super(`Message ${messageId} is corrupted: ${reason}`);
        this.name = "MessageCorruptedError";
    }
};
var QueueEmptyError = class extends Error {
    constructor(queueName, consumerGroup){
        super(`No messages available in queue "${queueName}" for consumer group "${consumerGroup}"`);
        this.name = "QueueEmptyError";
    }
};
var MessageLockedError = class extends Error {
    retryAfter;
    constructor(messageId, retryAfter){
        const retryMessage = retryAfter ? ` Retry after ${retryAfter} seconds.` : " Try again later.";
        super(`Message ${messageId} is temporarily locked.${retryMessage}`);
        this.name = "MessageLockedError";
        this.retryAfter = retryAfter;
    }
};
var UnauthorizedError = class extends Error {
    constructor(message = "Missing or invalid authentication token"){
        super(message);
        this.name = "UnauthorizedError";
    }
};
var ForbiddenError = class extends Error {
    constructor(message = "Queue environment doesn't match token environment"){
        super(message);
        this.name = "ForbiddenError";
    }
};
var BadRequestError = class extends Error {
    constructor(message){
        super(message);
        this.name = "BadRequestError";
    }
};
var InternalServerError = class extends Error {
    constructor(message = "Unexpected server error"){
        super(message);
        this.name = "InternalServerError";
    }
};
var InvalidLimitError = class extends Error {
    constructor(limit, min = 1, max = 10){
        super(`Invalid limit: ${limit}. Limit must be between ${min} and ${max}.`);
        this.name = "InvalidLimitError";
    }
};
// src/client.ts
function isDebugEnabled() {
    return process.env.VERCEL_QUEUE_DEBUG === "1" || process.env.VERCEL_QUEUE_DEBUG === "true";
}
async function consumeStream(stream) {
    const reader = stream.getReader();
    try {
        while(true){
            const { done } = await reader.read();
            if (done) break;
        }
    } finally{
        reader.releaseLock();
    }
}
function parseRetryAfter(headers) {
    const retryAfterHeader = headers.get("Retry-After");
    if (retryAfterHeader) {
        const parsed = parseInt(retryAfterHeader, 10);
        return Number.isNaN(parsed) ? void 0 : parsed;
    }
    return void 0;
}
function throwCommonHttpError(status, statusText, errorText, operation, badRequestDefault = "Invalid parameters") {
    if (status === 400) {
        throw new BadRequestError(errorText || badRequestDefault);
    }
    if (status === 401) {
        throw new UnauthorizedError(errorText || void 0);
    }
    if (status === 403) {
        throw new ForbiddenError(errorText || void 0);
    }
    if (status >= 500) {
        throw new InternalServerError(errorText || `Server error: ${status} ${statusText}`);
    }
    throw new Error(`Failed to ${operation}: ${status} ${statusText}`);
}
function parseQueueHeaders(headers) {
    const messageId = headers.get("Vqs-Message-Id");
    const deliveryCountStr = headers.get("Vqs-Delivery-Count") || "0";
    const timestamp = headers.get("Vqs-Timestamp");
    const contentType = headers.get("Content-Type") || "application/octet-stream";
    const ticket = headers.get("Vqs-Ticket");
    if (!messageId || !timestamp || !ticket) {
        return null;
    }
    const deliveryCount = parseInt(deliveryCountStr, 10);
    if (Number.isNaN(deliveryCount)) {
        return null;
    }
    return {
        messageId,
        deliveryCount,
        createdAt: new Date(timestamp),
        contentType,
        ticket
    };
}
var QueueClient = class {
    baseUrl;
    basePath;
    customHeaders;
    providedToken;
    /**
   * Create a new Vercel Queue Service client
   * @param options QueueClient configuration options
   */ constructor(options = {}){
        this.baseUrl = options.baseUrl || process.env.VERCEL_QUEUE_BASE_URL || "https://vercel-queue.com";
        this.basePath = options.basePath || process.env.VERCEL_QUEUE_BASE_PATH || "/api/v2/messages";
        this.customHeaders = options.headers || {};
        this.providedToken = options.token;
    }
    async getToken() {
        if (this.providedToken) {
            return this.providedToken;
        }
        const token = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$oidc$40$3$2e$0$2e$5$2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVercelOidcToken"])();
        if (!token) {
            throw new Error("Failed to get OIDC token from Vercel Functions. Make sure you are running in a Vercel Function environment, or provide a token explicitly.\n\nTo set up your environment:\n1. Link your project: 'vercel link'\n2. Pull environment variables: 'vercel env pull'\n3. Run with environment: 'dotenv -e .env.local -- your-command'");
        }
        return token;
    }
    /**
   * Internal fetch wrapper that automatically handles debug logging
   * when VERCEL_QUEUE_DEBUG is enabled
   */ async fetch(url, init) {
        const method = init.method || "GET";
        if (isDebugEnabled()) {
            const logData = {
                method,
                url,
                headers: init.headers
            };
            const body = init.body;
            if (body !== void 0 && body !== null) {
                if (body instanceof ArrayBuffer) {
                    logData.bodySize = body.byteLength;
                } else if (body instanceof Uint8Array) {
                    logData.bodySize = body.byteLength;
                } else if (typeof body === "string") {
                    logData.bodySize = body.length;
                } else {
                    logData.bodyType = typeof body;
                }
            }
            console.debug("[VQS Debug] Request:", JSON.stringify(logData, null, 2));
        }
        const response = await fetch(url, init);
        if (isDebugEnabled()) {
            const logData = {
                method,
                url,
                status: response.status,
                statusText: response.statusText,
                headers: response.headers
            };
            console.debug("[VQS Debug] Response:", JSON.stringify(logData, null, 2));
        }
        return response;
    }
    /**
   * Send a message to a queue
   * @param options Send message options
   * @param transport Serializer/deserializer for the payload
   * @returns Promise with the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async sendMessage(options, transport) {
        const { queueName, payload, idempotencyKey, retentionSeconds } = options;
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Content-Type": transport.contentType,
            ...this.customHeaders
        });
        const deploymentId = options.deploymentId || process.env.VERCEL_DEPLOYMENT_ID;
        if (deploymentId) {
            headers.set("Vqs-Deployment-Id", deploymentId);
        }
        if (idempotencyKey) {
            headers.set("Vqs-Idempotency-Key", idempotencyKey);
        }
        if (retentionSeconds !== void 0) {
            headers.set("Vqs-Retention-Seconds", retentionSeconds.toString());
        }
        const body = transport.serialize(payload);
        const response = await this.fetch(`${this.baseUrl}${this.basePath}`, {
            method: "POST",
            body,
            headers
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 409) {
                throw new Error("Duplicate idempotency key detected");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "send message");
        }
        const responseData = await response.json();
        return responseData;
    }
    /**
   * Receive messages from a queue
   * @param options Receive messages options
   * @param transport Serializer/deserializer for the payload
   * @returns AsyncGenerator that yields messages as they arrive
   * @throws {InvalidLimitError} When limit parameter is not between 1 and 10
   * @throws {QueueEmptyError} When no messages are available (204)
   * @throws {MessageLockedError} When messages are temporarily locked (423)
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async *receiveMessages(options, transport) {
        const { queueName, consumerGroup, visibilityTimeoutSeconds, limit } = options;
        if (limit !== void 0 && (limit < 1 || limit > 10)) {
            throw new InvalidLimitError(limit);
        }
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Vqs-Consumer-Group": consumerGroup,
            Accept: "multipart/mixed",
            ...this.customHeaders
        });
        if (visibilityTimeoutSeconds !== void 0) {
            headers.set("Vqs-Visibility-Timeout", visibilityTimeoutSeconds.toString());
        }
        if (limit !== void 0) {
            headers.set("Vqs-Limit", limit.toString());
        }
        const response = await this.fetch(`${this.baseUrl}${this.basePath}`, {
            method: "GET",
            headers
        });
        if (response.status === 204) {
            throw new QueueEmptyError(queueName, consumerGroup);
        }
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 423) {
                throw new MessageLockedError("next message", parseRetryAfter(response.headers));
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "receive messages");
        }
        for await (const multipartMessage of (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$mixpart$40$0$2e$0$2e$5$2d$alpha$2e$1$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMultipartStream"])(response)){
            try {
                const parsedHeaders = parseQueueHeaders(multipartMessage.headers);
                if (!parsedHeaders) {
                    console.warn("Missing required queue headers in multipart part");
                    await consumeStream(multipartMessage.payload);
                    continue;
                }
                const deserializedPayload = await transport.deserialize(multipartMessage.payload);
                const message = {
                    ...parsedHeaders,
                    payload: deserializedPayload
                };
                yield message;
            } catch (error) {
                console.warn("Failed to process multipart message:", error);
                await consumeStream(multipartMessage.payload);
            }
        }
    }
    async receiveMessageById(options, transport) {
        const { queueName, consumerGroup, messageId, visibilityTimeoutSeconds, skipPayload } = options;
        const headers = new Headers({
            Authorization: `Bearer ${await this.getToken()}`,
            "Vqs-Queue-Name": queueName,
            "Vqs-Consumer-Group": consumerGroup,
            Accept: "multipart/mixed",
            ...this.customHeaders
        });
        if (visibilityTimeoutSeconds !== void 0) {
            headers.set("Vqs-Visibility-Timeout", visibilityTimeoutSeconds.toString());
        }
        if (skipPayload) {
            headers.set("Vqs-Skip-Payload", "1");
        }
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "GET",
            headers
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId);
            }
            if (response.status === 423) {
                throw new MessageLockedError(messageId, parseRetryAfter(response.headers));
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "receive message by ID");
        }
        if (skipPayload && response.status === 204) {
            const parsedHeaders = parseQueueHeaders(response.headers);
            if (!parsedHeaders) {
                throw new MessageCorruptedError(messageId, "Missing required queue headers in 204 response");
            }
            const message = {
                ...parsedHeaders,
                payload: void 0
            };
            return {
                message
            };
        }
        if (!transport) {
            throw new Error("Transport is required when skipPayload is not true");
        }
        try {
            for await (const multipartMessage of (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$mixpart$40$0$2e$0$2e$5$2d$alpha$2e$1$2f$node_modules$2f$mixpart$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parseMultipartStream"])(response)){
                try {
                    const parsedHeaders = parseQueueHeaders(multipartMessage.headers);
                    if (!parsedHeaders) {
                        console.warn("Missing required queue headers in multipart part");
                        await consumeStream(multipartMessage.payload);
                        continue;
                    }
                    const deserializedPayload = await transport.deserialize(multipartMessage.payload);
                    const message = {
                        ...parsedHeaders,
                        payload: deserializedPayload
                    };
                    return {
                        message
                    };
                } catch (error) {
                    console.warn("Failed to deserialize message by ID:", error);
                    await consumeStream(multipartMessage.payload);
                    throw new MessageCorruptedError(messageId, `Failed to deserialize payload: ${error}`);
                }
            }
        } catch (error) {
            if (error instanceof MessageCorruptedError) {
                throw error;
            }
            throw new MessageCorruptedError(messageId, `Failed to parse multipart response: ${error}`);
        }
        throw new MessageNotFoundError(messageId);
    }
    /**
   * Delete a message (acknowledge processing)
   * @param options Delete message options
   * @returns Promise with delete status
   * @throws {MessageNotFoundError} When the message doesn't exist (404)
   * @throws {MessageNotAvailableError} When message can't be deleted (409)
   * @throws {BadRequestError} When ticket is missing or invalid (400)
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async deleteMessage(options) {
        const { queueName, consumerGroup, messageId, ticket } = options;
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "DELETE",
            headers: new Headers({
                Authorization: `Bearer ${await this.getToken()}`,
                "Vqs-Queue-Name": queueName,
                "Vqs-Consumer-Group": consumerGroup,
                "Vqs-Ticket": ticket,
                ...this.customHeaders
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId, errorText || "Invalid ticket, message not in correct state, or already processed");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "delete message", "Missing or invalid ticket");
        }
        return {
            deleted: true
        };
    }
    /**
   * Change the visibility timeout of a message
   * @param options Change visibility options
   * @returns Promise with update status
   * @throws {MessageNotFoundError} When the message doesn't exist (404)
   * @throws {MessageNotAvailableError} When message can't be updated (409)
   * @throws {BadRequestError} When ticket is missing or visibility timeout invalid (400)
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async changeVisibility(options) {
        const { queueName, consumerGroup, messageId, ticket, visibilityTimeoutSeconds } = options;
        const response = await this.fetch(`${this.baseUrl}${this.basePath}/${encodeURIComponent(messageId)}`, {
            method: "PATCH",
            headers: new Headers({
                Authorization: `Bearer ${await this.getToken()}`,
                "Vqs-Queue-Name": queueName,
                "Vqs-Consumer-Group": consumerGroup,
                "Vqs-Ticket": ticket,
                "Vqs-Visibility-Timeout": visibilityTimeoutSeconds.toString(),
                ...this.customHeaders
            })
        });
        if (!response.ok) {
            const errorText = await response.text();
            if (response.status === 404) {
                throw new MessageNotFoundError(messageId);
            }
            if (response.status === 409) {
                throw new MessageNotAvailableError(messageId, errorText || "Invalid ticket, message not in correct state, or already processed");
            }
            throwCommonHttpError(response.status, response.statusText, errorText, "change visibility", "Missing ticket or invalid visibility timeout");
        }
        return {
            updated: true
        };
    }
};
// src/dev.ts
var GLOBAL_KEY = Symbol.for("@vercel/queue.devHandlers");
function getDevHandlerState() {
    const g = globalThis;
    if (!g[GLOBAL_KEY]) {
        g[GLOBAL_KEY] = {
            devRouteHandlers: /* @__PURE__ */ new Map(),
            wildcardRouteHandlers: /* @__PURE__ */ new Map()
        };
    }
    return g[GLOBAL_KEY];
}
var { devRouteHandlers, wildcardRouteHandlers } = getDevHandlerState();
function cleanupDeadRefs(key, refs) {
    const aliveRefs = refs.filter((ref)=>ref.deref() !== void 0);
    if (aliveRefs.length === 0) {
        wildcardRouteHandlers.delete(key);
    } else if (aliveRefs.length < refs.length) {
        wildcardRouteHandlers.set(key, aliveRefs);
    }
}
function isDevMode() {
    return ("TURBOPACK compile-time value", "development") === "development";
}
function registerDevRouteHandler(routeHandler, handlers) {
    for(const topicName in handlers){
        for(const consumerGroup in handlers[topicName]){
            const key = `${topicName}:${consumerGroup}`;
            if (topicName.includes("*")) {
                const existing = wildcardRouteHandlers.get(key) || [];
                cleanupDeadRefs(key, existing);
                const cleanedRefs = wildcardRouteHandlers.get(key) || [];
                const weakRef = new WeakRef(routeHandler);
                cleanedRefs.push(weakRef);
                wildcardRouteHandlers.set(key, cleanedRefs);
            } else {
                devRouteHandlers.set(key, {
                    routeHandler,
                    topicPattern: topicName
                });
            }
        }
    }
}
function findRouteHandlersForTopic(topicName) {
    const handlersMap = /* @__PURE__ */ new Map();
    for (const [key, { routeHandler, topicPattern }] of devRouteHandlers.entries()){
        const [_, consumerGroup] = key.split(":");
        if (topicPattern === topicName) {
            if (!handlersMap.has(routeHandler)) {
                handlersMap.set(routeHandler, /* @__PURE__ */ new Set());
            }
            handlersMap.get(routeHandler).add(consumerGroup);
        }
    }
    for (const [key, refs] of wildcardRouteHandlers.entries()){
        const [pattern, consumerGroup] = key.split(":");
        if (matchesWildcardPattern(topicName, pattern)) {
            cleanupDeadRefs(key, refs);
            const cleanedRefs = wildcardRouteHandlers.get(key) || [];
            for (const ref of cleanedRefs){
                const routeHandler = ref.deref();
                if (routeHandler) {
                    if (!handlersMap.has(routeHandler)) {
                        handlersMap.set(routeHandler, /* @__PURE__ */ new Set());
                    }
                    handlersMap.get(routeHandler).add(consumerGroup);
                }
            }
        }
    }
    return handlersMap;
}
function createMockCloudEventRequest(topicName, consumerGroup, messageId) {
    const cloudEvent = {
        type: "com.vercel.queue.v1beta",
        source: `/topic/${topicName}/consumer/${consumerGroup}`,
        id: messageId,
        datacontenttype: "application/json",
        data: {
            messageId,
            queueName: topicName,
            consumerGroup
        },
        time: /* @__PURE__ */ new Date().toISOString(),
        specversion: "1.0"
    };
    return new Request("https://localhost/api/queue/callback", {
        method: "POST",
        headers: {
            "Content-Type": "application/cloudevents+json"
        },
        body: JSON.stringify(cloudEvent)
    });
}
var DEV_CALLBACK_DELAY = 1e3;
function scheduleDevTimeout(topicName, messageId, timeoutSeconds) {
    console.log(`[Dev Mode] Message ${messageId} timed out for ${timeoutSeconds}s, will re-trigger`);
    setTimeout(()=>{
        console.log(`[Dev Mode] Re-triggering callback for timed-out message ${messageId}`);
        triggerDevCallbacks(topicName, messageId);
    }, timeoutSeconds * 1e3 + DEV_CALLBACK_DELAY);
}
function triggerDevCallbacks(topicName, messageId) {
    const handlersMap = findRouteHandlersForTopic(topicName);
    if (handlersMap.size === 0) {
        return;
    }
    const consumerGroups = Array.from(new Set(Array.from(handlersMap.values()).flatMap((groups)=>Array.from(groups))));
    console.log(`[Dev Mode] Triggering local callbacks for topic "${topicName}" \u2192 consumers: ${consumerGroups.join(", ")}`);
    setTimeout(async ()=>{
        for (const [routeHandler, consumerGroups2] of handlersMap.entries()){
            for (const consumerGroup of consumerGroups2){
                try {
                    const request = createMockCloudEventRequest(topicName, consumerGroup, messageId);
                    const response = await routeHandler(request);
                    if (response.ok) {
                        try {
                            const responseData = await response.json();
                            if (responseData.status === "success") {
                                console.log(`[Dev Mode] Message processed for ${topicName}/${consumerGroup}`);
                            }
                        } catch (jsonError) {
                            console.error(`[Dev Mode] Failed to parse success response for ${topicName}/${consumerGroup}:`, jsonError);
                        }
                    } else {
                        try {
                            const errorData = await response.json();
                            console.error(`[Dev Mode] Failed to process message for ${topicName}/${consumerGroup}:`, errorData.error || response.statusText);
                        } catch (jsonError) {
                            console.error(`[Dev Mode] Failed to process message for ${topicName}/${consumerGroup}:`, response.statusText);
                        }
                    }
                } catch (error) {
                    console.error(`[Dev Mode] Error triggering callback for ${topicName}/${consumerGroup}:`, error);
                }
            }
        }
    }, DEV_CALLBACK_DELAY);
}
function clearDevHandlers() {
    devRouteHandlers.clear();
    wildcardRouteHandlers.clear();
}
if (("TURBOPACK compile-time value", "development") === "test" || process.env.VITEST) {
    globalThis.__clearDevHandlers = clearDevHandlers;
}
// src/consumer-group.ts
var ConsumerGroup = class {
    client;
    topicName;
    consumerGroupName;
    visibilityTimeout;
    refreshInterval;
    transport;
    /**
   * Create a new ConsumerGroup instance
   * @param client QueueClient instance to use for API calls
   * @param topicName Name of the topic to consume from
   * @param consumerGroupName Name of the consumer group
   * @param options Optional configuration
   */ constructor(client, topicName, consumerGroupName, options = {}){
        this.client = client;
        this.topicName = topicName;
        this.consumerGroupName = consumerGroupName;
        this.visibilityTimeout = options.visibilityTimeoutSeconds || 30;
        this.refreshInterval = options.refreshInterval || 10;
        this.transport = options.transport || new JsonTransport();
    }
    /**
   * Starts a background loop that periodically extends the visibility timeout for a message.
   * This prevents the message from becoming visible to other consumers while it's being processed.
   *
   * The extension loop runs every `refreshInterval` seconds and updates the message's
   * visibility timeout to `visibilityTimeout` seconds from the current time.
   *
   * @param messageId - The unique identifier of the message to extend visibility for
   * @param ticket - The receipt ticket that proves ownership of the message
   * @returns A function that when called will stop the extension loop
   *
   * @remarks
   * - The first extension attempt occurs after `refreshInterval` seconds, not immediately
   * - If an extension fails, the loop terminates with an error logged to console
   * - The returned stop function is idempotent - calling it multiple times is safe
   * - By default, the stop function returns immediately without waiting for in-flight
   * - Pass `true` to the stop function to wait for any in-flight extension to complete
   */ startVisibilityExtension(messageId, ticket) {
        let isRunning = true;
        let resolveLifecycle;
        let timeoutId = null;
        const lifecyclePromise = new Promise((resolve)=>{
            resolveLifecycle = resolve;
        });
        const extend = async ()=>{
            if (!isRunning) {
                resolveLifecycle();
                return;
            }
            try {
                await this.client.changeVisibility({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId,
                    ticket,
                    visibilityTimeoutSeconds: this.visibilityTimeout
                });
                if (isRunning) {
                    timeoutId = setTimeout(()=>extend(), this.refreshInterval * 1e3);
                } else {
                    resolveLifecycle();
                }
            } catch (error) {
                console.error(`Failed to extend visibility for message ${messageId}:`, error);
                resolveLifecycle();
            }
        };
        timeoutId = setTimeout(()=>extend(), this.refreshInterval * 1e3);
        return async (waitForCompletion = false)=>{
            isRunning = false;
            if (timeoutId) {
                clearTimeout(timeoutId);
                timeoutId = null;
            }
            if (waitForCompletion) {
                await lifecyclePromise;
            } else {
                resolveLifecycle();
            }
        };
    }
    /**
   * Process a single message with the given handler
   * @param message The message to process
   * @param handler Function to process the message
   */ async processMessage(message, handler) {
        const stopExtension = this.startVisibilityExtension(message.messageId, message.ticket);
        try {
            const result = await handler(message.payload, {
                messageId: message.messageId,
                deliveryCount: message.deliveryCount,
                createdAt: message.createdAt,
                topicName: this.topicName,
                consumerGroup: this.consumerGroupName
            });
            await stopExtension();
            if (result && "timeoutSeconds" in result) {
                await this.client.changeVisibility({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: message.messageId,
                    ticket: message.ticket,
                    visibilityTimeoutSeconds: result.timeoutSeconds
                });
                if (isDevMode()) {
                    scheduleDevTimeout(this.topicName, message.messageId, result.timeoutSeconds);
                }
            } else {
                await this.client.deleteMessage({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: message.messageId,
                    ticket: message.ticket
                });
            }
        } catch (error) {
            await stopExtension();
            if (this.transport.finalize && message.payload !== void 0 && message.payload !== null) {
                try {
                    await this.transport.finalize(message.payload);
                } catch (finalizeError) {
                    console.warn("Failed to finalize message payload:", finalizeError);
                }
            }
            throw error;
        }
    }
    async consume(handler, options) {
        if (options?.messageId) {
            if (options.skipPayload) {
                const response = await this.client.receiveMessageById({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: options.messageId,
                    visibilityTimeoutSeconds: this.visibilityTimeout,
                    skipPayload: true
                }, this.transport);
                await this.processMessage(response.message, handler);
            } else {
                const response = await this.client.receiveMessageById({
                    queueName: this.topicName,
                    consumerGroup: this.consumerGroupName,
                    messageId: options.messageId,
                    visibilityTimeoutSeconds: this.visibilityTimeout
                }, this.transport);
                await this.processMessage(response.message, handler);
            }
        } else {
            let messageFound = false;
            for await (const message of this.client.receiveMessages({
                queueName: this.topicName,
                consumerGroup: this.consumerGroupName,
                visibilityTimeoutSeconds: this.visibilityTimeout,
                limit: 1
            }, this.transport)){
                messageFound = true;
                await this.processMessage(message, handler);
                break;
            }
            if (!messageFound) {
                throw new Error("No messages available");
            }
        }
    }
    /**
   * Get the consumer group name
   */ get name() {
        return this.consumerGroupName;
    }
    /**
   * Get the topic name this consumer group is subscribed to
   */ get topic() {
        return this.topicName;
    }
};
// src/topic.ts
var Topic = class {
    client;
    topicName;
    transport;
    /**
   * Create a new Topic instance
   * @param client QueueClient instance to use for API calls
   * @param topicName Name of the topic to work with
   * @param transport Optional serializer/deserializer for the payload (defaults to JSON)
   */ constructor(client, topicName, transport){
        this.client = client;
        this.topicName = topicName;
        this.transport = transport || new JsonTransport();
    }
    /**
   * Publish a message to the topic
   * @param payload The data to publish
   * @param options Optional publish options
   * @returns An object containing the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async publish(payload, options) {
        const result = await this.client.sendMessage({
            queueName: this.topicName,
            payload,
            idempotencyKey: options?.idempotencyKey,
            retentionSeconds: options?.retentionSeconds,
            deploymentId: options?.deploymentId
        }, this.transport);
        if (isDevMode()) {
            triggerDevCallbacks(this.topicName, result.messageId);
        }
        return {
            messageId: result.messageId
        };
    }
    /**
   * Create a consumer group for this topic
   * @param consumerGroupName Name of the consumer group
   * @param options Optional configuration for the consumer group
   * @returns A ConsumerGroup instance
   */ consumerGroup(consumerGroupName, options) {
        const consumerOptions = {
            ...options,
            transport: options?.transport || this.transport
        };
        return new ConsumerGroup(this.client, this.topicName, consumerGroupName, consumerOptions);
    }
    /**
   * Get the topic name
   */ get name() {
        return this.topicName;
    }
    /**
   * Get the transport used by this topic
   */ get serializer() {
        return this.transport;
    }
};
// src/callback.ts
function validateWildcardPattern(pattern) {
    const firstIndex = pattern.indexOf("*");
    const lastIndex = pattern.lastIndexOf("*");
    if (firstIndex !== lastIndex) {
        return false;
    }
    if (firstIndex === -1) {
        return false;
    }
    if (firstIndex !== pattern.length - 1) {
        return false;
    }
    return true;
}
function matchesWildcardPattern(topicName, pattern) {
    const prefix = pattern.slice(0, -1);
    return topicName.startsWith(prefix);
}
function findTopicHandler(queueName, handlers) {
    const exactHandler = handlers[queueName];
    if (exactHandler) {
        return exactHandler;
    }
    for(const pattern in handlers){
        if (pattern.includes("*") && matchesWildcardPattern(queueName, pattern)) {
            return handlers[pattern];
        }
    }
    return null;
}
async function parseCallback(request) {
    const contentType = request.headers.get("content-type");
    if (!contentType || !contentType.includes("application/cloudevents+json")) {
        throw new Error("Invalid content type: expected 'application/cloudevents+json'");
    }
    let cloudEvent;
    try {
        cloudEvent = await request.json();
    } catch (error) {
        throw new Error("Failed to parse CloudEvent from request body");
    }
    if (!cloudEvent.type || !cloudEvent.source || !cloudEvent.id || typeof cloudEvent.data !== "object" || cloudEvent.data == null) {
        throw new Error("Invalid CloudEvent: missing required fields");
    }
    if (cloudEvent.type !== "com.vercel.queue.v1beta") {
        throw new Error(`Invalid CloudEvent type: expected 'com.vercel.queue.v1beta', got '${cloudEvent.type}'`);
    }
    const missingFields = [];
    if (!("queueName" in cloudEvent.data)) missingFields.push("queueName");
    if (!("consumerGroup" in cloudEvent.data)) missingFields.push("consumerGroup");
    if (!("messageId" in cloudEvent.data)) missingFields.push("messageId");
    if (missingFields.length > 0) {
        throw new Error(`Missing required CloudEvent data fields: ${missingFields.join(", ")}`);
    }
    const { messageId, queueName, consumerGroup } = cloudEvent.data;
    return {
        queueName,
        consumerGroup,
        messageId
    };
}
function createCallbackHandler(handlers, client) {
    for(const topicPattern in handlers){
        if (topicPattern.includes("*")) {
            if (!validateWildcardPattern(topicPattern)) {
                throw new Error(`Invalid wildcard pattern "${topicPattern}": * may only appear once and must be at the end of the topic name`);
            }
        }
    }
    const routeHandler = async (request)=>{
        try {
            const { queueName, consumerGroup, messageId } = await parseCallback(request);
            const topicHandler = findTopicHandler(queueName, handlers);
            if (!topicHandler) {
                const availableTopics = Object.keys(handlers).join(", ");
                return Response.json({
                    error: `No handler found for topic: ${queueName}`,
                    availableTopics
                }, {
                    status: 404
                });
            }
            const consumerGroupHandler = topicHandler[consumerGroup];
            if (!consumerGroupHandler) {
                const availableGroups = Object.keys(topicHandler).join(", ");
                return Response.json({
                    error: `No handler found for consumer group "${consumerGroup}" in topic "${queueName}".`,
                    availableGroups
                }, {
                    status: 404
                });
            }
            const topic = new Topic(client, queueName);
            const cg = topic.consumerGroup(consumerGroup);
            await cg.consume(consumerGroupHandler, {
                messageId
            });
            return Response.json({
                status: "success"
            });
        } catch (error) {
            console.error("Queue callback error:", error);
            if (error instanceof Error && (error.message.includes("Missing required CloudEvent data fields") || error.message.includes("Invalid CloudEvent") || error.message.includes("Invalid CloudEvent type") || error.message.includes("Invalid content type") || error.message.includes("Failed to parse CloudEvent"))) {
                return Response.json({
                    error: error.message
                }, {
                    status: 400
                });
            }
            return Response.json({
                error: "Failed to process queue message"
            }, {
                status: 500
            });
        }
    };
    if (isDevMode()) {
        registerDevRouteHandler(routeHandler, handlers);
    }
    return routeHandler;
}
function handleCallback(handlers, client) {
    return createCallbackHandler(handlers, client || new QueueClient());
}
// src/factory.ts
async function send(topicName, payload, options) {
    const transport = options?.transport || new JsonTransport();
    const client = options?.client || new QueueClient();
    const result = await client.sendMessage({
        queueName: topicName,
        payload,
        idempotencyKey: options?.idempotencyKey,
        retentionSeconds: options?.retentionSeconds,
        deploymentId: options?.deploymentId
    }, transport);
    if (isDevMode()) {
        triggerDevCallbacks(topicName, result.messageId);
    }
    return {
        messageId: result.messageId
    };
}
async function receive(topicName, consumerGroup, handler, options) {
    const transport = options?.transport || new JsonTransport();
    const client = options?.client || new QueueClient();
    const topic = new Topic(client, topicName, transport);
    const { messageId, skipPayload, client: _, ...consumerGroupOptions } = options || {};
    const consumer = topic.consumerGroup(consumerGroup, consumerGroupOptions);
    if (messageId) {
        if (skipPayload) {
            return consumer.consume(handler, {
                messageId,
                skipPayload: true
            });
        } else {
            return consumer.consume(handler, {
                messageId
            });
        }
    } else {
        return consumer.consume(handler);
    }
}
// src/queue-client.ts
var Client = class {
    client;
    /**
   * Create a new Client
   * @param options QueueClient configuration options
   */ constructor(options = {}){
        this.client = new QueueClient(options);
    }
    /**
   * Send a message to a topic
   * @param topicName Name of the topic to send to
   * @param payload The data to send
   * @param options Optional publish options and transport
   * @returns Promise with the message ID
   * @throws {BadRequestError} When request parameters are invalid
   * @throws {UnauthorizedError} When authentication fails
   * @throws {ForbiddenError} When access is denied (environment mismatch)
   * @throws {InternalServerError} When server encounters an error
   */ async send(topicName, payload, options) {
        return send(topicName, payload, {
            ...options,
            client: this.client
        });
    }
    /**
   * Create a callback handler for processing queue messages
   * Returns a Next.js route handler function that routes messages to appropriate handlers
   * @param handlers Object with topic-specific handlers organized by consumer groups
   * @returns A Next.js route handler function
   *
   * @example
   * ```typescript
   * export const POST = client.handleCallback({
   *   "user-events": {
   *     "welcome": (user, metadata) => console.log("Welcoming user", user),
   *     "analytics": (user, metadata) => console.log("Tracking user", user),
   *   },
   * });
   * ```
   */ handleCallback(handlers) {
        return handleCallback(handlers, this.client);
    }
};
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseEventSchema",
    ()=>BaseEventSchema,
    "CreateEventSchema",
    ()=>CreateEventSchema,
    "EventSchema",
    ()=>EventSchema,
    "EventTypeSchema",
    ()=>EventTypeSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const EventTypeSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'step_completed',
    'step_failed',
    'step_retrying',
    'step_started',
    'hook_created',
    'hook_received',
    'hook_disposed',
    'wait_created',
    'wait_completed',
    'workflow_completed',
    'workflow_failed',
    'workflow_started'
]);
const BaseEventSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    eventType: EventTypeSchema,
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
});
// Event schemas (shared between creation requests and server responses)
const StepCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_completed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        result: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
const StepFailedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_failed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
        stack: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
        fatal: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().optional()
    })
});
// TODO: this is not actually used anywhere yet, we could remove it
// on client and server if needed
const StepRetryingEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_retrying'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        attempt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().min(1)
    })
});
const StepStartedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_started'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const HookCreatedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_created'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const HookReceivedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_received'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        payload: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
const HookDisposedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_disposed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const WaitCreatedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('wait_created'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        resumeAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    })
});
const WaitCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('wait_completed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
// TODO: not used yet
const WorkflowCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_completed')
});
// TODO: not used yet
const WorkflowFailedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_failed'),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
// TODO: not used yet
const WorkflowStartedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_started')
});
const CreateEventSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].discriminatedUnion('eventType', [
    StepCompletedEventSchema,
    StepFailedEventSchema,
    StepRetryingEventSchema,
    StepStartedEventSchema,
    HookCreatedEventSchema,
    HookReceivedEventSchema,
    HookDisposedEventSchema,
    WaitCreatedEventSchema,
    WaitCompletedEventSchema,
    WorkflowCompletedEventSchema,
    WorkflowFailedEventSchema,
    WorkflowStartedEventSchema
]);
const EventSchema = CreateEventSchema.and(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
})); //# sourceMappingURL=events.js.map
}),
"[project]/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PaginatedResponseSchema",
    ()=>PaginatedResponseSchema,
    "StructuredErrorSchema",
    ()=>StructuredErrorSchema,
    "zodJsonSchema",
    ()=>zodJsonSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const zodJsonSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].lazy(()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].null(),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(zodJsonSchema),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(), zodJsonSchema)
    ]);
});
const PaginatedResponseSchema = (dataSchema)=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        data: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(dataSchema),
        cursor: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        hasMore: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
    });
const StructuredErrorSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stack: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
    code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
}); //# sourceMappingURL=shared.js.map
}),
"[project]/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HookSchema",
    ()=>HookSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const HookSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    hookId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    token: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    ownerId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    projectId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    environment: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    metadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["zodJsonSchema"].optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
}); //# sourceMappingURL=hooks.js.map
}),
"[project]/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageId",
    ()=>MessageId,
    "QueuePayloadSchema",
    ()=>QueuePayloadSchema,
    "QueuePrefix",
    ()=>QueuePrefix,
    "StepInvokePayloadSchema",
    ()=>StepInvokePayloadSchema,
    "TraceCarrierSchema",
    ()=>TraceCarrierSchema,
    "ValidQueueName",
    ()=>ValidQueueName,
    "WorkflowInvokePayloadSchema",
    ()=>WorkflowInvokePayloadSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/index.js [app-route] (ecmascript)");
;
const QueuePrefix = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal('__wkf_step_'),
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal('__wkf_workflow_')
]);
const ValidQueueName = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].templateLiteral([
    QueuePrefix,
    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
]);
const MessageId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().brand().describe('A stored queue message ID');
const TraceCarrierSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string());
const WorkflowInvokePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    traceCarrier: TraceCarrierSchema.optional(),
    requestedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].coerce.date().optional()
});
const StepInvokePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    workflowName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    workflowRunId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    workflowStartedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number(),
    stepId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    traceCarrier: TraceCarrierSchema.optional(),
    requestedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].coerce.date().optional()
});
const QueuePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    WorkflowInvokePayloadSchema,
    StepInvokePayloadSchema
]); //# sourceMappingURL=queue.js.map
}),
"[project]/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkflowRunBaseSchema",
    ()=>WorkflowRunBaseSchema,
    "WorkflowRunSchema",
    ()=>WorkflowRunSchema,
    "WorkflowRunStatusSchema",
    ()=>WorkflowRunStatusSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const WorkflowRunStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'pending',
    'running',
    'completed',
    'failed',
    'paused',
    'cancelled'
]);
const WorkflowRunBaseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: WorkflowRunStatusSchema,
    deploymentId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    workflowName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    executionContext: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()).optional(),
    input: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"].optional(),
    expiredAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    startedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    updatedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
});
const WorkflowRunSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].discriminatedUnion('status', [
    // Non-final states
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
            'pending',
            'running',
            'paused'
        ]),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined()
    }),
    // Cancelled state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('cancelled'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    }),
    // Completed state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('completed'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    }),
    // Failed state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('failed'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"],
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    })
]); //# sourceMappingURL=runs.js.map
}),
"[project]/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepSchema",
    ()=>StepSchema,
    "StepStatusSchema",
    ()=>StepStatusSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const StepStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'pending',
    'running',
    'completed',
    'failed',
    'cancelled'
]);
const StepSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stepId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stepName: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: StepStatusSchema,
    input: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"].optional(),
    attempt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    startedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    updatedAt: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    retryAfter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional()
}); //# sourceMappingURL=steps.js.map
}),
"[project]/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)"); //# sourceMappingURL=index.js.map
;
;
;
;
;
;
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BaseEventSchema",
    ()=>BaseEventSchema,
    "CreateEventSchema",
    ()=>CreateEventSchema,
    "EventSchema",
    ()=>EventSchema,
    "EventTypeSchema",
    ()=>EventTypeSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const EventTypeSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'step_completed',
    'step_failed',
    'step_retrying',
    'step_started',
    'hook_created',
    'hook_received',
    'hook_disposed',
    'wait_created',
    'wait_completed',
    'workflow_completed',
    'workflow_failed',
    'workflow_started'
]);
const BaseEventSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    eventType: EventTypeSchema,
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
});
// Event schemas (shared between creation requests and server responses)
const StepCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_completed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        result: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
const StepFailedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_failed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
        stack: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
        fatal: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean().optional()
    })
});
// TODO: this is not actually used anywhere yet, we could remove it
// on client and server if needed
const StepRetryingEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_retrying'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        attempt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().min(1)
    })
});
const StepStartedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('step_started'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const HookCreatedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_created'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const HookReceivedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_received'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        payload: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
const HookDisposedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('hook_disposed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
const WaitCreatedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('wait_created'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        resumeAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    })
});
const WaitCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('wait_completed'),
    correlationId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string()
});
// TODO: not used yet
const WorkflowCompletedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_completed')
});
// TODO: not used yet
const WorkflowFailedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_failed'),
    eventData: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()
    })
});
// TODO: not used yet
const WorkflowStartedEventSchema = BaseEventSchema.extend({
    eventType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('workflow_started')
});
const CreateEventSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].discriminatedUnion('eventType', [
    StepCompletedEventSchema,
    StepFailedEventSchema,
    StepRetryingEventSchema,
    StepStartedEventSchema,
    HookCreatedEventSchema,
    HookReceivedEventSchema,
    HookDisposedEventSchema,
    WaitCreatedEventSchema,
    WaitCompletedEventSchema,
    WorkflowCompletedEventSchema,
    WorkflowFailedEventSchema,
    WorkflowStartedEventSchema
]);
const EventSchema = CreateEventSchema.and(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    eventId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
})); //# sourceMappingURL=events.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "PaginatedResponseSchema",
    ()=>PaginatedResponseSchema,
    "StructuredErrorSchema",
    ()=>StructuredErrorSchema,
    "zodJsonSchema",
    ()=>zodJsonSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
const zodJsonSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].lazy(()=>{
    return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].null(),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(zodJsonSchema),
        __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(), zodJsonSchema)
    ]);
});
const PaginatedResponseSchema = (dataSchema)=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
        data: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(dataSchema),
        cursor: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().nullable(),
        hasMore: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].boolean()
    });
const StructuredErrorSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    message: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stack: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional(),
    code: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().optional()
}); //# sourceMappingURL=shared.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HookSchema",
    ()=>HookSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const HookSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    hookId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    token: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    ownerId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    projectId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    environment: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    metadata: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["zodJsonSchema"].optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
}); //# sourceMappingURL=hooks.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MessageId",
    ()=>MessageId,
    "QueuePayloadSchema",
    ()=>QueuePayloadSchema,
    "QueuePrefix",
    ()=>QueuePrefix,
    "StepInvokePayloadSchema",
    ()=>StepInvokePayloadSchema,
    "TraceCarrierSchema",
    ()=>TraceCarrierSchema,
    "ValidQueueName",
    ()=>ValidQueueName,
    "WorkflowInvokePayloadSchema",
    ()=>WorkflowInvokePayloadSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/index.js [app-route] (ecmascript)");
;
const QueuePrefix = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal('__wkf_step_'),
    __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal('__wkf_workflow_')
]);
const ValidQueueName = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].templateLiteral([
    QueuePrefix,
    __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
]);
const MessageId = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().brand().describe('A stored queue message ID');
const TraceCarrierSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string());
const WorkflowInvokePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    traceCarrier: TraceCarrierSchema.optional(),
    requestedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].coerce.date().optional()
});
const StepInvokePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    workflowName: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    workflowRunId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    workflowStartedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number(),
    stepId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
    traceCarrier: TraceCarrierSchema.optional(),
    requestedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].coerce.date().optional()
});
const QueuePayloadSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
    WorkflowInvokePayloadSchema,
    StepInvokePayloadSchema
]); //# sourceMappingURL=queue.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkflowRunBaseSchema",
    ()=>WorkflowRunBaseSchema,
    "WorkflowRunSchema",
    ()=>WorkflowRunSchema,
    "WorkflowRunStatusSchema",
    ()=>WorkflowRunStatusSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const WorkflowRunStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'pending',
    'running',
    'completed',
    'failed',
    'paused',
    'cancelled'
]);
const WorkflowRunBaseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: WorkflowRunStatusSchema,
    deploymentId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    workflowName: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    executionContext: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()).optional(),
    input: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"].optional(),
    expiredAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    startedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    updatedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
});
const WorkflowRunSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].discriminatedUnion('status', [
    // Non-final states
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
            'pending',
            'running',
            'paused'
        ]),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined()
    }),
    // Cancelled state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('cancelled'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    }),
    // Completed state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('completed'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    }),
    // Failed state
    WorkflowRunBaseSchema.extend({
        status: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].literal('failed'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].undefined(),
        error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"],
        completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date()
    })
]); //# sourceMappingURL=runs.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "StepSchema",
    ()=>StepSchema,
    "StepStatusSchema",
    ()=>StepStatusSchema
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
;
;
const StepStatusSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
    'pending',
    'running',
    'completed',
    'failed',
    'cancelled'
]);
const StepSchema = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
    runId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stepId: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    stepName: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
    status: StepStatusSchema,
    input: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any()),
    output: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].any().optional(),
    error: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StructuredErrorSchema"].optional(),
    attempt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number(),
    startedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    completedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional(),
    createdAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    updatedAt: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date(),
    retryAfter: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].coerce.date().optional()
}); //# sourceMappingURL=steps.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$shared$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/shared.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)"); //# sourceMappingURL=index.js.map
;
;
;
;
;
;
}),
"[project]/node_modules/async-sema/lib/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RateLimit = exports.Sema = void 0;
const events_1 = __importDefault(__turbopack_context__.r("[externals]/events [external] (events, cjs)"));
function arrayMove(src, srcIndex, dst, dstIndex, len) {
    for(let j = 0; j < len; ++j){
        dst[j + dstIndex] = src[j + srcIndex];
        src[j + srcIndex] = void 0;
    }
}
function pow2AtLeast(n) {
    n = n >>> 0;
    n = n - 1;
    n = n | n >> 1;
    n = n | n >> 2;
    n = n | n >> 4;
    n = n | n >> 8;
    n = n | n >> 16;
    return n + 1;
}
function getCapacity(capacity) {
    return pow2AtLeast(Math.min(Math.max(16, capacity), 1073741824));
}
// Deque is based on https://github.com/petkaantonov/deque/blob/master/js/deque.js
// Released under the MIT License: https://github.com/petkaantonov/deque/blob/6ef4b6400ad3ba82853fdcc6531a38eb4f78c18c/LICENSE
class Deque {
    constructor(capacity){
        this._capacity = getCapacity(capacity);
        this._length = 0;
        this._front = 0;
        this.arr = [];
    }
    push(item) {
        const length = this._length;
        this.checkCapacity(length + 1);
        const i = this._front + length & this._capacity - 1;
        this.arr[i] = item;
        this._length = length + 1;
        return length + 1;
    }
    pop() {
        const length = this._length;
        if (length === 0) {
            return void 0;
        }
        const i = this._front + length - 1 & this._capacity - 1;
        const ret = this.arr[i];
        this.arr[i] = void 0;
        this._length = length - 1;
        return ret;
    }
    shift() {
        const length = this._length;
        if (length === 0) {
            return void 0;
        }
        const front = this._front;
        const ret = this.arr[front];
        this.arr[front] = void 0;
        this._front = front + 1 & this._capacity - 1;
        this._length = length - 1;
        return ret;
    }
    get length() {
        return this._length;
    }
    checkCapacity(size) {
        if (this._capacity < size) {
            this.resizeTo(getCapacity(this._capacity * 1.5 + 16));
        }
    }
    resizeTo(capacity) {
        const oldCapacity = this._capacity;
        this._capacity = capacity;
        const front = this._front;
        const length = this._length;
        if (front + length > oldCapacity) {
            const moveItemsCount = front + length & oldCapacity - 1;
            arrayMove(this.arr, 0, this.arr, oldCapacity, moveItemsCount);
        }
    }
}
class ReleaseEmitter extends events_1.default {
}
function isFn(x) {
    return typeof x === 'function';
}
function defaultInit() {
    return '1';
}
class Sema {
    constructor(nr, { initFn = defaultInit, pauseFn, resumeFn, capacity = 10 } = {}){
        if (isFn(pauseFn) !== isFn(resumeFn)) {
            throw new Error('pauseFn and resumeFn must be both set for pausing');
        }
        this.nrTokens = nr;
        this.free = new Deque(nr);
        this.waiting = new Deque(capacity);
        this.releaseEmitter = new ReleaseEmitter();
        this.noTokens = initFn === defaultInit;
        this.pauseFn = pauseFn;
        this.resumeFn = resumeFn;
        this.paused = false;
        this.releaseEmitter.on('release', (token)=>{
            const p = this.waiting.shift();
            if (p) {
                p.resolve(token);
            } else {
                if (this.resumeFn && this.paused) {
                    this.paused = false;
                    this.resumeFn();
                }
                this.free.push(token);
            }
        });
        for(let i = 0; i < nr; i++){
            this.free.push(initFn());
        }
    }
    tryAcquire() {
        return this.free.pop();
    }
    async acquire() {
        let token = this.tryAcquire();
        if (token !== void 0) {
            return token;
        }
        return new Promise((resolve, reject)=>{
            if (this.pauseFn && !this.paused) {
                this.paused = true;
                this.pauseFn();
            }
            this.waiting.push({
                resolve,
                reject
            });
        });
    }
    release(token) {
        this.releaseEmitter.emit('release', this.noTokens ? '1' : token);
    }
    drain() {
        const a = new Array(this.nrTokens);
        for(let i = 0; i < this.nrTokens; i++){
            a[i] = this.acquire();
        }
        return Promise.all(a);
    }
    nrWaiting() {
        return this.waiting.length;
    }
}
exports.Sema = Sema;
function RateLimit(rps, { timeUnit = 1000, uniformDistribution = false } = {}) {
    const sema = new Sema(uniformDistribution ? 1 : rps);
    const delay = uniformDistribution ? timeUnit / rps : timeUnit;
    return async function rl() {
        await sema.acquire();
        setTimeout(()=>sema.release(), delay);
    };
}
exports.RateLimit = RateLimit;
}),
"[project]/frontend/node_modules/.pnpm/async-sema@3.1.1/node_modules/async-sema/lib/index.js [app-route] (ecmascript)", ((__turbopack_context__, module, exports) => {
"use strict";

var __importDefault = /*TURBOPACK member replacement*/ __turbopack_context__.e && /*TURBOPACK member replacement*/ __turbopack_context__.e.__importDefault || function(mod) {
    return mod && mod.__esModule ? mod : {
        "default": mod
    };
};
Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RateLimit = exports.Sema = void 0;
const events_1 = __importDefault(__turbopack_context__.r("[externals]/events [external] (events, cjs)"));
function arrayMove(src, srcIndex, dst, dstIndex, len) {
    for(let j = 0; j < len; ++j){
        dst[j + dstIndex] = src[j + srcIndex];
        src[j + srcIndex] = void 0;
    }
}
function pow2AtLeast(n) {
    n = n >>> 0;
    n = n - 1;
    n = n | n >> 1;
    n = n | n >> 2;
    n = n | n >> 4;
    n = n | n >> 8;
    n = n | n >> 16;
    return n + 1;
}
function getCapacity(capacity) {
    return pow2AtLeast(Math.min(Math.max(16, capacity), 1073741824));
}
// Deque is based on https://github.com/petkaantonov/deque/blob/master/js/deque.js
// Released under the MIT License: https://github.com/petkaantonov/deque/blob/6ef4b6400ad3ba82853fdcc6531a38eb4f78c18c/LICENSE
class Deque {
    constructor(capacity){
        this._capacity = getCapacity(capacity);
        this._length = 0;
        this._front = 0;
        this.arr = [];
    }
    push(item) {
        const length = this._length;
        this.checkCapacity(length + 1);
        const i = this._front + length & this._capacity - 1;
        this.arr[i] = item;
        this._length = length + 1;
        return length + 1;
    }
    pop() {
        const length = this._length;
        if (length === 0) {
            return void 0;
        }
        const i = this._front + length - 1 & this._capacity - 1;
        const ret = this.arr[i];
        this.arr[i] = void 0;
        this._length = length - 1;
        return ret;
    }
    shift() {
        const length = this._length;
        if (length === 0) {
            return void 0;
        }
        const front = this._front;
        const ret = this.arr[front];
        this.arr[front] = void 0;
        this._front = front + 1 & this._capacity - 1;
        this._length = length - 1;
        return ret;
    }
    get length() {
        return this._length;
    }
    checkCapacity(size) {
        if (this._capacity < size) {
            this.resizeTo(getCapacity(this._capacity * 1.5 + 16));
        }
    }
    resizeTo(capacity) {
        const oldCapacity = this._capacity;
        this._capacity = capacity;
        const front = this._front;
        const length = this._length;
        if (front + length > oldCapacity) {
            const moveItemsCount = front + length & oldCapacity - 1;
            arrayMove(this.arr, 0, this.arr, oldCapacity, moveItemsCount);
        }
    }
}
class ReleaseEmitter extends events_1.default {
}
function isFn(x) {
    return typeof x === 'function';
}
function defaultInit() {
    return '1';
}
class Sema {
    constructor(nr, { initFn = defaultInit, pauseFn, resumeFn, capacity = 10 } = {}){
        if (isFn(pauseFn) !== isFn(resumeFn)) {
            throw new Error('pauseFn and resumeFn must be both set for pausing');
        }
        this.nrTokens = nr;
        this.free = new Deque(nr);
        this.waiting = new Deque(capacity);
        this.releaseEmitter = new ReleaseEmitter();
        this.noTokens = initFn === defaultInit;
        this.pauseFn = pauseFn;
        this.resumeFn = resumeFn;
        this.paused = false;
        this.releaseEmitter.on('release', (token)=>{
            const p = this.waiting.shift();
            if (p) {
                p.resolve(token);
            } else {
                if (this.resumeFn && this.paused) {
                    this.paused = false;
                    this.resumeFn();
                }
                this.free.push(token);
            }
        });
        for(let i = 0; i < nr; i++){
            this.free.push(initFn());
        }
    }
    tryAcquire() {
        return this.free.pop();
    }
    async acquire() {
        let token = this.tryAcquire();
        if (token !== void 0) {
            return token;
        }
        return new Promise((resolve, reject)=>{
            if (this.pauseFn && !this.paused) {
                this.paused = true;
                this.pauseFn();
            }
            this.waiting.push({
                resolve,
                reject
            });
        });
    }
    release(token) {
        this.releaseEmitter.emit('release', this.noTokens ? '1' : token);
    }
    drain() {
        const a = new Array(this.nrTokens);
        for(let i = 0; i < this.nrTokens; i++){
            a[i] = this.acquire();
        }
        return Promise.all(a);
    }
    nrWaiting() {
        return this.waiting.length;
    }
}
exports.Sema = Sema;
function RateLimit(rps, { timeUnit = 1000, uniformDistribution = false } = {}) {
    const sema = new Sema(uniformDistribution ? 1 : rps);
    const delay = uniformDistribution ? timeUnit / rps : timeUnit;
    return async function rl() {
        await sema.acquire();
        setTimeout(()=>sema.release(), delay);
    };
}
exports.RateLimit = RateLimit;
}),
"[project]/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_ULID",
    ()=>MAX_ULID,
    "MIN_ULID",
    ()=>MIN_ULID,
    "TIME_LEN",
    ()=>TIME_LEN,
    "TIME_MAX",
    ()=>TIME_MAX,
    "ULIDError",
    ()=>ULIDError,
    "ULIDErrorCode",
    ()=>ULIDErrorCode,
    "decodeTime",
    ()=>decodeTime,
    "encodeTime",
    ()=>encodeTime,
    "fixULIDBase32",
    ()=>fixULIDBase32,
    "incrementBase32",
    ()=>incrementBase32,
    "isValid",
    ()=>isValid,
    "monotonicFactory",
    ()=>monotonicFactory,
    "ulid",
    ()=>ulid,
    "ulidToUUID",
    ()=>ulidToUUID,
    "uuidToULID",
    ()=>uuidToULID
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:crypto [external] (node:crypto, cjs)");
;
// These values should NEVER change. The values are precisely for
// generating ULIDs.
const B32_CHARACTERS = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
const ENCODING = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; // Crockford's Base32
const ENCODING_LEN = 32; // from ENCODING.length;
const MAX_ULID = "7ZZZZZZZZZZZZZZZZZZZZZZZZZ";
const MIN_ULID = "00000000000000000000000000";
const RANDOM_LEN = 16;
const TIME_LEN = 10;
const TIME_MAX = 281474976710655; // from Math.pow(2, 48) - 1;
const ULID_REGEX = /^[0-7][0-9a-hjkmnp-tv-zA-HJKMNP-TV-Z]{25}$/;
const UUID_REGEX = /^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$/;
var ULIDErrorCode;
(function(ULIDErrorCode) {
    ULIDErrorCode["Base32IncorrectEncoding"] = "B32_ENC_INVALID";
    ULIDErrorCode["DecodeTimeInvalidCharacter"] = "DEC_TIME_CHAR";
    ULIDErrorCode["DecodeTimeValueMalformed"] = "DEC_TIME_MALFORMED";
    ULIDErrorCode["EncodeTimeNegative"] = "ENC_TIME_NEG";
    ULIDErrorCode["EncodeTimeSizeExceeded"] = "ENC_TIME_SIZE_EXCEED";
    ULIDErrorCode["EncodeTimeValueMalformed"] = "ENC_TIME_MALFORMED";
    ULIDErrorCode["PRNGDetectFailure"] = "PRNG_DETECT";
    ULIDErrorCode["ULIDInvalid"] = "ULID_INVALID";
    ULIDErrorCode["Unexpected"] = "UNEXPECTED";
    ULIDErrorCode["UUIDInvalid"] = "UUID_INVALID";
})(ULIDErrorCode || (ULIDErrorCode = {}));
class ULIDError extends Error {
    constructor(errorCode, message){
        super(`${message} (${errorCode})`);
        this.name = "ULIDError";
        this.code = errorCode;
    }
}
function randomChar(prng) {
    // Currently PRNGs generate fractions from 0 to _less than_ 1, so no "%" is necessary.
    // However, just in case a future PRNG can generate 1,
    // we are applying "% ENCODING LEN" to wrap back to the first character
    const randomPosition = Math.floor(prng() * ENCODING_LEN) % ENCODING_LEN;
    return ENCODING.charAt(randomPosition);
}
function replaceCharAt(str, index, char) {
    if (index > str.length - 1) {
        return str;
    }
    return str.substr(0, index) + char + str.substr(index + 1);
}
// Code from https://github.com/devbanana/crockford-base32/blob/develop/src/index.ts
function crockfordEncode(input) {
    const output = [];
    let bitsRead = 0;
    let buffer = 0;
    const reversedInput = new Uint8Array(input.slice().reverse());
    for (const byte of reversedInput){
        buffer |= byte << bitsRead;
        bitsRead += 8;
        while(bitsRead >= 5){
            output.unshift(buffer & 0x1f);
            buffer >>>= 5;
            bitsRead -= 5;
        }
    }
    if (bitsRead > 0) {
        output.unshift(buffer & 0x1f);
    }
    return output.map((byte)=>B32_CHARACTERS.charAt(byte)).join("");
}
function crockfordDecode(input) {
    const sanitizedInput = input.toUpperCase().split("").reverse().join("");
    const output = [];
    let bitsRead = 0;
    let buffer = 0;
    for (const character of sanitizedInput){
        const byte = B32_CHARACTERS.indexOf(character);
        if (byte === -1) {
            throw new Error(`Invalid base 32 character found in string: ${character}`);
        }
        buffer |= byte << bitsRead;
        bitsRead += 5;
        while(bitsRead >= 8){
            output.unshift(buffer & 0xff);
            buffer >>>= 8;
            bitsRead -= 8;
        }
    }
    if (bitsRead >= 5 || buffer > 0) {
        output.unshift(buffer & 0xff);
    }
    return new Uint8Array(output);
}
/**
 * Fix a ULID's Base32 encoding -
 * i and l (case-insensitive) will be treated as 1 and o (case-insensitive) will be treated as 0.
 * hyphens are ignored during decoding.
 * @param id The ULID
 * @returns The cleaned up ULID
 */ function fixULIDBase32(id) {
    return id.replace(/i/gi, "1").replace(/l/gi, "1").replace(/o/gi, "0").replace(/-/g, "");
}
function incrementBase32(str) {
    let done = undefined, index = str.length, char, charIndex, output = str;
    const maxCharIndex = ENCODING_LEN - 1;
    while(!done && index-- >= 0){
        char = output[index];
        charIndex = ENCODING.indexOf(char);
        if (charIndex === -1) {
            throw new ULIDError(ULIDErrorCode.Base32IncorrectEncoding, "Incorrectly encoded string");
        }
        if (charIndex === maxCharIndex) {
            output = replaceCharAt(output, index, ENCODING[0]);
            continue;
        }
        done = replaceCharAt(output, index, ENCODING[charIndex + 1]);
    }
    if (typeof done === "string") {
        return done;
    }
    throw new ULIDError(ULIDErrorCode.Base32IncorrectEncoding, "Failed incrementing string");
}
/**
 * Decode time from a ULID
 * @param id The ULID
 * @returns The decoded timestamp
 */ function decodeTime(id) {
    if (id.length !== TIME_LEN + RANDOM_LEN) {
        throw new ULIDError(ULIDErrorCode.DecodeTimeValueMalformed, "Malformed ULID");
    }
    const time = id.substr(0, TIME_LEN).toUpperCase().split("").reverse().reduce((carry, char, index)=>{
        const encodingIndex = ENCODING.indexOf(char);
        if (encodingIndex === -1) {
            throw new ULIDError(ULIDErrorCode.DecodeTimeInvalidCharacter, `Time decode error: Invalid character: ${char}`);
        }
        return carry += encodingIndex * Math.pow(ENCODING_LEN, index);
    }, 0);
    if (time > TIME_MAX) {
        throw new ULIDError(ULIDErrorCode.DecodeTimeValueMalformed, `Malformed ULID: timestamp too large: ${time}`);
    }
    return time;
}
/**
 * Detect the best PRNG (pseudo-random number generator)
 * @param root The root to check from (global/window)
 * @returns The PRNG function
 */ function detectPRNG(root) {
    const rootLookup = detectRoot();
    const globalCrypto = rootLookup && (rootLookup.crypto || rootLookup.msCrypto) || (typeof __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"] !== "undefined" ? __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"] : null);
    if (typeof globalCrypto?.getRandomValues === "function") {
        return ()=>{
            const buffer = new Uint8Array(1);
            globalCrypto.getRandomValues(buffer);
            return buffer[0] / 0xff;
        };
    } else if (typeof globalCrypto?.randomBytes === "function") {
        return ()=>globalCrypto.randomBytes(1).readUInt8() / 0xff;
    } else if (__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"]?.randomBytes) {
        return ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"].randomBytes(1).readUInt8() / 0xff;
    }
    throw new ULIDError(ULIDErrorCode.PRNGDetectFailure, "Failed to find a reliable PRNG");
}
function detectRoot() {
    if (inWebWorker()) return self;
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if ("TURBOPACK compile-time truthy", 1) {
        return /*TURBOPACK member replacement*/ __turbopack_context__.g;
    }
    //TURBOPACK unreachable
    ;
}
function encodeRandom(len, prng) {
    let str = "";
    for(; len > 0; len--){
        str = randomChar(prng) + str;
    }
    return str;
}
/**
 * Encode the time portion of a ULID
 * @param now The current timestamp
 * @param len Length to generate
 * @returns The encoded time
 */ function encodeTime(now, len = TIME_LEN) {
    if (isNaN(now)) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeValueMalformed, `Time must be a number: ${now}`);
    } else if (now > TIME_MAX) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeSizeExceeded, `Cannot encode a time larger than ${TIME_MAX}: ${now}`);
    } else if (now < 0) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeNegative, `Time must be positive: ${now}`);
    } else if (Number.isInteger(now) === false) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeValueMalformed, `Time must be an integer: ${now}`);
    }
    let mod, str = "";
    for(let currentLen = len; currentLen > 0; currentLen--){
        mod = now % ENCODING_LEN;
        str = ENCODING.charAt(mod) + str;
        now = (now - mod) / ENCODING_LEN;
    }
    return str;
}
function inWebWorker() {
    // @ts-ignore
    return typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
}
/**
 * Check if a ULID is valid
 * @param id The ULID to test
 * @returns True if valid, false otherwise
 * @example
 *   isValid("01HNZX8JGFACFA36RBXDHEQN6E"); // true
 *   isValid(""); // false
 */ function isValid(id) {
    return typeof id === "string" && id.length === TIME_LEN + RANDOM_LEN && id.toUpperCase().split("").every((char)=>ENCODING.indexOf(char) !== -1);
}
/**
 * Create a ULID factory to generate monotonically-increasing
 *  ULIDs
 * @param prng The PRNG to use
 * @returns A ulid factory
 * @example
 *  const ulid = monotonicFactory();
 *  ulid(); // "01HNZXD07M5CEN5XA66EMZSRZW"
 */ function monotonicFactory(prng) {
    const currentPRNG = prng || detectPRNG();
    let lastTime = 0, lastRandom;
    return function _ulid(seedTime) {
        const seed = !seedTime || isNaN(seedTime) ? Date.now() : seedTime;
        if (seed <= lastTime) {
            const incrementedRandom = lastRandom = incrementBase32(lastRandom);
            return encodeTime(lastTime, TIME_LEN) + incrementedRandom;
        }
        lastTime = seed;
        const newRandom = lastRandom = encodeRandom(RANDOM_LEN, currentPRNG);
        return encodeTime(seed, TIME_LEN) + newRandom;
    };
}
/**
 * Generate a ULID
 * @param seedTime Optional time seed
 * @param prng Optional PRNG function
 * @returns A ULID string
 * @example
 *  ulid(); // "01HNZXD07M5CEN5XA66EMZSRZW"
 */ function ulid(seedTime, prng) {
    const currentPRNG = prng || detectPRNG();
    const seed = !seedTime || isNaN(seedTime) ? Date.now() : seedTime;
    return encodeTime(seed, TIME_LEN) + encodeRandom(RANDOM_LEN, currentPRNG);
}
/**
 * Convert a ULID to a UUID
 * @param ulid The ULID to convert
 * @returns A UUID string
 */ function ulidToUUID(ulid) {
    const isValid = ULID_REGEX.test(ulid);
    if (!isValid) {
        throw new ULIDError(ULIDErrorCode.ULIDInvalid, `Invalid ULID: ${ulid}`);
    }
    const uint8Array = crockfordDecode(ulid);
    let uuid = Array.from(uint8Array).map((byte)=>byte.toString(16).padStart(2, "0")).join("");
    uuid = uuid.substring(0, 8) + "-" + uuid.substring(8, 12) + "-" + uuid.substring(12, 16) + "-" + uuid.substring(16, 20) + "-" + uuid.substring(20);
    return uuid.toUpperCase();
}
/**
 * Convert a UUID to a ULID
 * @param uuid The UUID to convert
 * @returns A ULID string
 */ function uuidToULID(uuid) {
    const isValid = UUID_REGEX.test(uuid);
    if (!isValid) {
        throw new ULIDError(ULIDErrorCode.UUIDInvalid, `Invalid UUID: ${uuid}`);
    }
    const bytes = uuid.replace(/-/g, "").match(/.{1,2}/g);
    if (!bytes) {
        throw new ULIDError(ULIDErrorCode.Unexpected, `Failed parsing UUID bytes: ${uuid}`);
    }
    const uint8Array = new Uint8Array(bytes.map((byte)=>parseInt(byte, 16)));
    return crockfordEncode(uint8Array);
}
;
}),
"[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_ULID",
    ()=>MAX_ULID,
    "MIN_ULID",
    ()=>MIN_ULID,
    "TIME_LEN",
    ()=>TIME_LEN,
    "TIME_MAX",
    ()=>TIME_MAX,
    "ULIDError",
    ()=>ULIDError,
    "ULIDErrorCode",
    ()=>ULIDErrorCode,
    "decodeTime",
    ()=>decodeTime,
    "encodeTime",
    ()=>encodeTime,
    "fixULIDBase32",
    ()=>fixULIDBase32,
    "incrementBase32",
    ()=>incrementBase32,
    "isValid",
    ()=>isValid,
    "monotonicFactory",
    ()=>monotonicFactory,
    "ulid",
    ()=>ulid,
    "ulidToUUID",
    ()=>ulidToUUID,
    "uuidToULID",
    ()=>uuidToULID
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:crypto [external] (node:crypto, cjs)");
;
// These values should NEVER change. The values are precisely for
// generating ULIDs.
const B32_CHARACTERS = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
const ENCODING = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"; // Crockford's Base32
const ENCODING_LEN = 32; // from ENCODING.length;
const MAX_ULID = "7ZZZZZZZZZZZZZZZZZZZZZZZZZ";
const MIN_ULID = "00000000000000000000000000";
const RANDOM_LEN = 16;
const TIME_LEN = 10;
const TIME_MAX = 281474976710655; // from Math.pow(2, 48) - 1;
const ULID_REGEX = /^[0-7][0-9a-hjkmnp-tv-zA-HJKMNP-TV-Z]{25}$/;
const UUID_REGEX = /^[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$/;
var ULIDErrorCode;
(function(ULIDErrorCode) {
    ULIDErrorCode["Base32IncorrectEncoding"] = "B32_ENC_INVALID";
    ULIDErrorCode["DecodeTimeInvalidCharacter"] = "DEC_TIME_CHAR";
    ULIDErrorCode["DecodeTimeValueMalformed"] = "DEC_TIME_MALFORMED";
    ULIDErrorCode["EncodeTimeNegative"] = "ENC_TIME_NEG";
    ULIDErrorCode["EncodeTimeSizeExceeded"] = "ENC_TIME_SIZE_EXCEED";
    ULIDErrorCode["EncodeTimeValueMalformed"] = "ENC_TIME_MALFORMED";
    ULIDErrorCode["PRNGDetectFailure"] = "PRNG_DETECT";
    ULIDErrorCode["ULIDInvalid"] = "ULID_INVALID";
    ULIDErrorCode["Unexpected"] = "UNEXPECTED";
    ULIDErrorCode["UUIDInvalid"] = "UUID_INVALID";
})(ULIDErrorCode || (ULIDErrorCode = {}));
class ULIDError extends Error {
    constructor(errorCode, message){
        super(`${message} (${errorCode})`);
        this.name = "ULIDError";
        this.code = errorCode;
    }
}
function randomChar(prng) {
    // Currently PRNGs generate fractions from 0 to _less than_ 1, so no "%" is necessary.
    // However, just in case a future PRNG can generate 1,
    // we are applying "% ENCODING LEN" to wrap back to the first character
    const randomPosition = Math.floor(prng() * ENCODING_LEN) % ENCODING_LEN;
    return ENCODING.charAt(randomPosition);
}
function replaceCharAt(str, index, char) {
    if (index > str.length - 1) {
        return str;
    }
    return str.substr(0, index) + char + str.substr(index + 1);
}
// Code from https://github.com/devbanana/crockford-base32/blob/develop/src/index.ts
function crockfordEncode(input) {
    const output = [];
    let bitsRead = 0;
    let buffer = 0;
    const reversedInput = new Uint8Array(input.slice().reverse());
    for (const byte of reversedInput){
        buffer |= byte << bitsRead;
        bitsRead += 8;
        while(bitsRead >= 5){
            output.unshift(buffer & 0x1f);
            buffer >>>= 5;
            bitsRead -= 5;
        }
    }
    if (bitsRead > 0) {
        output.unshift(buffer & 0x1f);
    }
    return output.map((byte)=>B32_CHARACTERS.charAt(byte)).join("");
}
function crockfordDecode(input) {
    const sanitizedInput = input.toUpperCase().split("").reverse().join("");
    const output = [];
    let bitsRead = 0;
    let buffer = 0;
    for (const character of sanitizedInput){
        const byte = B32_CHARACTERS.indexOf(character);
        if (byte === -1) {
            throw new Error(`Invalid base 32 character found in string: ${character}`);
        }
        buffer |= byte << bitsRead;
        bitsRead += 5;
        while(bitsRead >= 8){
            output.unshift(buffer & 0xff);
            buffer >>>= 8;
            bitsRead -= 8;
        }
    }
    if (bitsRead >= 5 || buffer > 0) {
        output.unshift(buffer & 0xff);
    }
    return new Uint8Array(output);
}
/**
 * Fix a ULID's Base32 encoding -
 * i and l (case-insensitive) will be treated as 1 and o (case-insensitive) will be treated as 0.
 * hyphens are ignored during decoding.
 * @param id The ULID
 * @returns The cleaned up ULID
 */ function fixULIDBase32(id) {
    return id.replace(/i/gi, "1").replace(/l/gi, "1").replace(/o/gi, "0").replace(/-/g, "");
}
function incrementBase32(str) {
    let done = undefined, index = str.length, char, charIndex, output = str;
    const maxCharIndex = ENCODING_LEN - 1;
    while(!done && index-- >= 0){
        char = output[index];
        charIndex = ENCODING.indexOf(char);
        if (charIndex === -1) {
            throw new ULIDError(ULIDErrorCode.Base32IncorrectEncoding, "Incorrectly encoded string");
        }
        if (charIndex === maxCharIndex) {
            output = replaceCharAt(output, index, ENCODING[0]);
            continue;
        }
        done = replaceCharAt(output, index, ENCODING[charIndex + 1]);
    }
    if (typeof done === "string") {
        return done;
    }
    throw new ULIDError(ULIDErrorCode.Base32IncorrectEncoding, "Failed incrementing string");
}
/**
 * Decode time from a ULID
 * @param id The ULID
 * @returns The decoded timestamp
 */ function decodeTime(id) {
    if (id.length !== TIME_LEN + RANDOM_LEN) {
        throw new ULIDError(ULIDErrorCode.DecodeTimeValueMalformed, "Malformed ULID");
    }
    const time = id.substr(0, TIME_LEN).toUpperCase().split("").reverse().reduce((carry, char, index)=>{
        const encodingIndex = ENCODING.indexOf(char);
        if (encodingIndex === -1) {
            throw new ULIDError(ULIDErrorCode.DecodeTimeInvalidCharacter, `Time decode error: Invalid character: ${char}`);
        }
        return carry += encodingIndex * Math.pow(ENCODING_LEN, index);
    }, 0);
    if (time > TIME_MAX) {
        throw new ULIDError(ULIDErrorCode.DecodeTimeValueMalformed, `Malformed ULID: timestamp too large: ${time}`);
    }
    return time;
}
/**
 * Detect the best PRNG (pseudo-random number generator)
 * @param root The root to check from (global/window)
 * @returns The PRNG function
 */ function detectPRNG(root) {
    const rootLookup = detectRoot();
    const globalCrypto = rootLookup && (rootLookup.crypto || rootLookup.msCrypto) || (typeof __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"] !== "undefined" ? __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"] : null);
    if (typeof globalCrypto?.getRandomValues === "function") {
        return ()=>{
            const buffer = new Uint8Array(1);
            globalCrypto.getRandomValues(buffer);
            return buffer[0] / 0xff;
        };
    } else if (typeof globalCrypto?.randomBytes === "function") {
        return ()=>globalCrypto.randomBytes(1).readUInt8() / 0xff;
    } else if (__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"]?.randomBytes) {
        return ()=>__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$crypto__$5b$external$5d$__$28$node$3a$crypto$2c$__cjs$29$__["default"].randomBytes(1).readUInt8() / 0xff;
    }
    throw new ULIDError(ULIDErrorCode.PRNGDetectFailure, "Failed to find a reliable PRNG");
}
function detectRoot() {
    if (inWebWorker()) return self;
    if ("TURBOPACK compile-time falsy", 0) //TURBOPACK unreachable
    ;
    if ("TURBOPACK compile-time truthy", 1) {
        return /*TURBOPACK member replacement*/ __turbopack_context__.g;
    }
    //TURBOPACK unreachable
    ;
}
function encodeRandom(len, prng) {
    let str = "";
    for(; len > 0; len--){
        str = randomChar(prng) + str;
    }
    return str;
}
/**
 * Encode the time portion of a ULID
 * @param now The current timestamp
 * @param len Length to generate
 * @returns The encoded time
 */ function encodeTime(now, len = TIME_LEN) {
    if (isNaN(now)) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeValueMalformed, `Time must be a number: ${now}`);
    } else if (now > TIME_MAX) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeSizeExceeded, `Cannot encode a time larger than ${TIME_MAX}: ${now}`);
    } else if (now < 0) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeNegative, `Time must be positive: ${now}`);
    } else if (Number.isInteger(now) === false) {
        throw new ULIDError(ULIDErrorCode.EncodeTimeValueMalformed, `Time must be an integer: ${now}`);
    }
    let mod, str = "";
    for(let currentLen = len; currentLen > 0; currentLen--){
        mod = now % ENCODING_LEN;
        str = ENCODING.charAt(mod) + str;
        now = (now - mod) / ENCODING_LEN;
    }
    return str;
}
function inWebWorker() {
    // @ts-ignore
    return typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
}
/**
 * Check if a ULID is valid
 * @param id The ULID to test
 * @returns True if valid, false otherwise
 * @example
 *   isValid("01HNZX8JGFACFA36RBXDHEQN6E"); // true
 *   isValid(""); // false
 */ function isValid(id) {
    return typeof id === "string" && id.length === TIME_LEN + RANDOM_LEN && id.toUpperCase().split("").every((char)=>ENCODING.indexOf(char) !== -1);
}
/**
 * Create a ULID factory to generate monotonically-increasing
 *  ULIDs
 * @param prng The PRNG to use
 * @returns A ulid factory
 * @example
 *  const ulid = monotonicFactory();
 *  ulid(); // "01HNZXD07M5CEN5XA66EMZSRZW"
 */ function monotonicFactory(prng) {
    const currentPRNG = prng || detectPRNG();
    let lastTime = 0, lastRandom;
    return function _ulid(seedTime) {
        const seed = !seedTime || isNaN(seedTime) ? Date.now() : seedTime;
        if (seed <= lastTime) {
            const incrementedRandom = lastRandom = incrementBase32(lastRandom);
            return encodeTime(lastTime, TIME_LEN) + incrementedRandom;
        }
        lastTime = seed;
        const newRandom = lastRandom = encodeRandom(RANDOM_LEN, currentPRNG);
        return encodeTime(seed, TIME_LEN) + newRandom;
    };
}
/**
 * Generate a ULID
 * @param seedTime Optional time seed
 * @param prng Optional PRNG function
 * @returns A ULID string
 * @example
 *  ulid(); // "01HNZXD07M5CEN5XA66EMZSRZW"
 */ function ulid(seedTime, prng) {
    const currentPRNG = prng || detectPRNG();
    const seed = !seedTime || isNaN(seedTime) ? Date.now() : seedTime;
    return encodeTime(seed, TIME_LEN) + encodeRandom(RANDOM_LEN, currentPRNG);
}
/**
 * Convert a ULID to a UUID
 * @param ulid The ULID to convert
 * @returns A UUID string
 */ function ulidToUUID(ulid) {
    const isValid = ULID_REGEX.test(ulid);
    if (!isValid) {
        throw new ULIDError(ULIDErrorCode.ULIDInvalid, `Invalid ULID: ${ulid}`);
    }
    const uint8Array = crockfordDecode(ulid);
    let uuid = Array.from(uint8Array).map((byte)=>byte.toString(16).padStart(2, "0")).join("");
    uuid = uuid.substring(0, 8) + "-" + uuid.substring(8, 12) + "-" + uuid.substring(12, 16) + "-" + uuid.substring(16, 20) + "-" + uuid.substring(20);
    return uuid.toUpperCase();
}
/**
 * Convert a UUID to a ULID
 * @param uuid The UUID to convert
 * @returns A ULID string
 */ function uuidToULID(uuid) {
    const isValid = UUID_REGEX.test(uuid);
    if (!isValid) {
        throw new ULIDError(ULIDErrorCode.UUIDInvalid, `Invalid UUID: ${uuid}`);
    }
    const bytes = uuid.replace(/-/g, "").match(/.{1,2}/g);
    if (!bytes) {
        throw new ULIDError(ULIDErrorCode.Unexpected, `Failed parsing UUID bytes: ${uuid}`);
    }
    const uint8Array = new Uint8Array(bytes.map((byte)=>parseInt(byte, 16)));
    return crockfordEncode(uint8Array);
}
;
}),
"[project]/node_modules/workflow/dist/stdlib.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * This is the "standard library" of steps that we make available to all workflow users.
 * The can be imported like so: `import { fetch } from 'workflow'`. and used in workflow.
 * The need to be exported directly in this package and cannot live in `core` to prevent
 * circular dependencies post-compilation.
 */ /**
 * A hoisted `fetch()` function that is executed as a "step" function,
 * for use within workflow functions.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
 */ __turbopack_context__.s([
    "fetch",
    ()=>fetch
]);
async function fetch(...args) {
    'use step';
    return globalThis.fetch(...args);
} //# sourceMappingURL=stdlib.js.map
}),
"[project]/node_modules/workflow/dist/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$workflow$2f$dist$2f$stdlib$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/workflow/dist/stdlib.js [app-route] (ecmascript)"); //# sourceMappingURL=index.js.map
;
;
}),
"[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/stdlib.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * This is the "standard library" of steps that we make available to all workflow users.
 * The can be imported like so: `import { fetch } from 'workflow'`. and used in workflow.
 * The need to be exported directly in this package and cannot live in `core` to prevent
 * circular dependencies post-compilation.
 */ /**
 * A hoisted `fetch()` function that is executed as a "step" function,
 * for use within workflow functions.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API
 */ __turbopack_context__.s([
    "fetch",
    ()=>fetch
]);
async function fetch(...args) {
    'use step';
    return globalThis.fetch(...args);
} //# sourceMappingURL=stdlib.js.map
}),
"[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$stdlib$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/stdlib.js [app-route] (ecmascript)"); //# sourceMappingURL=index.js.map
;
;
}),
"[project]/node_modules/ai/node_modules/@ai-sdk/gateway/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/gateway-provider.ts
__turbopack_context__.s([
    "GatewayAuthenticationError",
    ()=>GatewayAuthenticationError,
    "GatewayError",
    ()=>GatewayError,
    "GatewayInternalServerError",
    ()=>GatewayInternalServerError,
    "GatewayInvalidRequestError",
    ()=>GatewayInvalidRequestError,
    "GatewayModelNotFoundError",
    ()=>GatewayModelNotFoundError,
    "GatewayRateLimitError",
    ()=>GatewayRateLimitError,
    "GatewayResponseError",
    ()=>GatewayResponseError,
    "createGateway",
    ()=>createGatewayProvider,
    "createGatewayProvider",
    ()=>createGatewayProvider,
    "gateway",
    ()=>gateway
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-route] (ecmascript) <locals>");
// src/errors/as-gateway-error.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/provider/dist/index.mjs [app-route] (ecmascript)");
// src/errors/create-gateway-error.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/index.js [app-route] (ecmascript)");
// src/vercel-environment.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vercel/oidc/dist/index.js [app-route] (ecmascript)");
;
;
;
// src/errors/gateway-error.ts
var marker = "vercel.ai.gateway.error";
var symbol = Symbol.for(marker);
var _a, _b;
var GatewayError = class _GatewayError extends (_b = Error, _a = symbol, _b) {
    constructor({ message, statusCode = 500, cause }){
        super(message);
        this[_a] = true;
        this.statusCode = statusCode;
        this.cause = cause;
    }
    /**
   * Checks if the given error is a Gateway Error.
   * @param {unknown} error - The error to check.
   * @returns {boolean} True if the error is a Gateway Error, false otherwise.
   */ static isInstance(error) {
        return _GatewayError.hasMarker(error);
    }
    static hasMarker(error) {
        return typeof error === "object" && error !== null && symbol in error && error[symbol] === true;
    }
};
// src/errors/gateway-authentication-error.ts
var name = "GatewayAuthenticationError";
var marker2 = `vercel.ai.gateway.error.${name}`;
var symbol2 = Symbol.for(marker2);
var _a2, _b2;
var GatewayAuthenticationError = class _GatewayAuthenticationError extends (_b2 = GatewayError, _a2 = symbol2, _b2) {
    constructor({ message = "Authentication failed", statusCode = 401, cause } = {}){
        super({
            message,
            statusCode,
            cause
        });
        this[_a2] = true;
        // used in isInstance
        this.name = name;
        this.type = "authentication_error";
    }
    static isInstance(error) {
        return GatewayError.hasMarker(error) && symbol2 in error;
    }
    /**
   * Creates a contextual error message when authentication fails
   */ static createContextualError({ apiKeyProvided, oidcTokenProvided, message = "Authentication failed", statusCode = 401, cause }) {
        let contextualMessage;
        if (apiKeyProvided) {
            contextualMessage = `AI Gateway authentication failed: Invalid API key.

Create a new API key: https://vercel.com/d?to=%2F%5Bteam%5D%2F%7E%2Fai%2Fapi-keys

Provide via 'apiKey' option or 'AI_GATEWAY_API_KEY' environment variable.`;
        } else if (oidcTokenProvided) {
            contextualMessage = `AI Gateway authentication failed: Invalid OIDC token.

Run 'npx vercel link' to link your project, then 'vc env pull' to fetch the token.

Alternatively, use an API key: https://vercel.com/d?to=%2F%5Bteam%5D%2F%7E%2Fai%2Fapi-keys`;
        } else {
            contextualMessage = `AI Gateway authentication failed: No authentication provided.

Option 1 - API key:
Create an API key: https://vercel.com/d?to=%2F%5Bteam%5D%2F%7E%2Fai%2Fapi-keys
Provide via 'apiKey' option or 'AI_GATEWAY_API_KEY' environment variable.

Option 2 - OIDC token:
Run 'npx vercel link' to link your project, then 'vc env pull' to fetch the token.`;
        }
        return new _GatewayAuthenticationError({
            message: contextualMessage,
            statusCode,
            cause
        });
    }
};
// src/errors/gateway-invalid-request-error.ts
var name2 = "GatewayInvalidRequestError";
var marker3 = `vercel.ai.gateway.error.${name2}`;
var symbol3 = Symbol.for(marker3);
var _a3, _b3;
var GatewayInvalidRequestError = class extends (_b3 = GatewayError, _a3 = symbol3, _b3) {
    constructor({ message = "Invalid request", statusCode = 400, cause } = {}){
        super({
            message,
            statusCode,
            cause
        });
        this[_a3] = true;
        // used in isInstance
        this.name = name2;
        this.type = "invalid_request_error";
    }
    static isInstance(error) {
        return GatewayError.hasMarker(error) && symbol3 in error;
    }
};
// src/errors/gateway-rate-limit-error.ts
var name3 = "GatewayRateLimitError";
var marker4 = `vercel.ai.gateway.error.${name3}`;
var symbol4 = Symbol.for(marker4);
var _a4, _b4;
var GatewayRateLimitError = class extends (_b4 = GatewayError, _a4 = symbol4, _b4) {
    constructor({ message = "Rate limit exceeded", statusCode = 429, cause } = {}){
        super({
            message,
            statusCode,
            cause
        });
        this[_a4] = true;
        // used in isInstance
        this.name = name3;
        this.type = "rate_limit_exceeded";
    }
    static isInstance(error) {
        return GatewayError.hasMarker(error) && symbol4 in error;
    }
};
;
;
var name4 = "GatewayModelNotFoundError";
var marker5 = `vercel.ai.gateway.error.${name4}`;
var symbol5 = Symbol.for(marker5);
var modelNotFoundParamSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazyValidator"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        modelId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
    })));
var _a5, _b5;
var GatewayModelNotFoundError = class extends (_b5 = GatewayError, _a5 = symbol5, _b5) {
    constructor({ message = "Model not found", statusCode = 404, modelId, cause } = {}){
        super({
            message,
            statusCode,
            cause
        });
        this[_a5] = true;
        // used in isInstance
        this.name = name4;
        this.type = "model_not_found";
        this.modelId = modelId;
    }
    static isInstance(error) {
        return GatewayError.hasMarker(error) && symbol5 in error;
    }
};
// src/errors/gateway-internal-server-error.ts
var name5 = "GatewayInternalServerError";
var marker6 = `vercel.ai.gateway.error.${name5}`;
var symbol6 = Symbol.for(marker6);
var _a6, _b6;
var GatewayInternalServerError = class extends (_b6 = GatewayError, _a6 = symbol6, _b6) {
    constructor({ message = "Internal server error", statusCode = 500, cause } = {}){
        super({
            message,
            statusCode,
            cause
        });
        this[_a6] = true;
        // used in isInstance
        this.name = name5;
        this.type = "internal_server_error";
    }
    static isInstance(error) {
        return GatewayError.hasMarker(error) && symbol6 in error;
    }
};
// src/errors/gateway-response-error.ts
var name6 = "GatewayResponseError";
var marker7 = `vercel.ai.gateway.error.${name6}`;
var symbol7 = Symbol.for(marker7);
var _a7, _b7;
var GatewayResponseError = class extends (_b7 = GatewayError, _a7 = symbol7, _b7) {
    constructor({ message = "Invalid response from Gateway", statusCode = 502, response, validationError, cause } = {}){
        super({
            message,
            statusCode,
            cause
        });
        this[_a7] = true;
        // used in isInstance
        this.name = name6;
        this.type = "response_error";
        this.response = response;
        this.validationError = validationError;
    }
    static isInstance(error) {
        return GatewayError.hasMarker(error) && symbol7 in error;
    }
};
;
async function createGatewayErrorFromResponse({ response, statusCode, defaultMessage = "Gateway request failed", cause, authMethod }) {
    const parseResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["safeValidateTypes"])({
        value: response,
        schema: gatewayErrorResponseSchema
    });
    if (!parseResult.success) {
        return new GatewayResponseError({
            message: `Invalid error response format: ${defaultMessage}`,
            statusCode,
            response,
            validationError: parseResult.error,
            cause
        });
    }
    const validatedResponse = parseResult.value;
    const errorType = validatedResponse.error.type;
    const message = validatedResponse.error.message;
    switch(errorType){
        case "authentication_error":
            return GatewayAuthenticationError.createContextualError({
                apiKeyProvided: authMethod === "api-key",
                oidcTokenProvided: authMethod === "oidc",
                statusCode,
                cause
            });
        case "invalid_request_error":
            return new GatewayInvalidRequestError({
                message,
                statusCode,
                cause
            });
        case "rate_limit_exceeded":
            return new GatewayRateLimitError({
                message,
                statusCode,
                cause
            });
        case "model_not_found":
            {
                const modelResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["safeValidateTypes"])({
                    value: validatedResponse.error.param,
                    schema: modelNotFoundParamSchema
                });
                return new GatewayModelNotFoundError({
                    message,
                    statusCode,
                    modelId: modelResult.success ? modelResult.value.modelId : void 0,
                    cause
                });
            }
        case "internal_server_error":
            return new GatewayInternalServerError({
                message,
                statusCode,
                cause
            });
        default:
            return new GatewayInternalServerError({
                message,
                statusCode,
                cause
            });
    }
}
var gatewayErrorResponseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazyValidator"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
            type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
            param: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].unknown().nullish(),
            code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number()
            ]).nullish()
        })
    })));
// src/errors/as-gateway-error.ts
function asGatewayError(error, authMethod) {
    var _a8;
    if (GatewayError.isInstance(error)) {
        return error;
    }
    if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["APICallError"].isInstance(error)) {
        return createGatewayErrorFromResponse({
            response: extractApiCallResponse(error),
            statusCode: (_a8 = error.statusCode) != null ? _a8 : 500,
            defaultMessage: "Gateway request failed",
            cause: error,
            authMethod
        });
    }
    return createGatewayErrorFromResponse({
        response: {},
        statusCode: 500,
        defaultMessage: error instanceof Error ? `Gateway request failed: ${error.message}` : "Unknown Gateway error",
        cause: error,
        authMethod
    });
}
// src/errors/extract-api-call-response.ts
function extractApiCallResponse(error) {
    if (error.data !== void 0) {
        return error.data;
    }
    if (error.responseBody != null) {
        try {
            return JSON.parse(error.responseBody);
        } catch (e) {
            return error.responseBody;
        }
    }
    return {};
}
;
;
var GATEWAY_AUTH_METHOD_HEADER = "ai-gateway-auth-method";
async function parseAuthMethod(headers) {
    const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["safeValidateTypes"])({
        value: headers[GATEWAY_AUTH_METHOD_HEADER],
        schema: gatewayAuthMethodSchema
    });
    return result.success ? result.value : void 0;
}
var gatewayAuthMethodSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazyValidator"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("api-key"),
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("oidc")
    ])));
;
;
var GatewayFetchMetadata = class {
    constructor(config){
        this.config = config;
    }
    async getAvailableModels() {
        try {
            const { value } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getFromApi"])({
                url: `${this.config.baseURL}/config`,
                headers: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers()),
                successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(gatewayAvailableModelsResponseSchema),
                failedResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonErrorResponseHandler"])({
                    errorSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any(),
                    errorToMessage: (data)=>data
                }),
                fetch: this.config.fetch
            });
            return value;
        } catch (error) {
            throw await asGatewayError(error);
        }
    }
    async getCredits() {
        try {
            const baseUrl = new URL(this.config.baseURL);
            const { value } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getFromApi"])({
                url: `${baseUrl.origin}/v1/credits`,
                headers: await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers()),
                successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(gatewayCreditsResponseSchema),
                failedResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonErrorResponseHandler"])({
                    errorSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any(),
                    errorToMessage: (data)=>data
                }),
                fetch: this.config.fetch
            });
            return value;
        } catch (error) {
            throw await asGatewayError(error);
        }
    }
};
var gatewayAvailableModelsResponseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazyValidator"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        models: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            id: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
            name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
            description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
            pricing: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                input: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                input_cache_read: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
                input_cache_write: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish()
            }).transform(({ input, output, input_cache_read, input_cache_write })=>({
                    input,
                    output,
                    ...input_cache_read ? {
                        cachedInputTokens: input_cache_read
                    } : {},
                    ...input_cache_write ? {
                        cacheCreationInputTokens: input_cache_write
                    } : {}
                })).nullish(),
            specification: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                specificationVersion: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("v2"),
                provider: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                modelId: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
            }),
            modelType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
                "language",
                "embedding",
                "image"
            ]).nullish()
        }))
    })));
var gatewayCreditsResponseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazyValidator"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        balance: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
        total_used: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
    }).transform(({ balance, total_used })=>({
            balance,
            totalUsed: total_used
        }))));
;
;
var GatewayLanguageModel = class {
    constructor(modelId, config){
        this.modelId = modelId;
        this.config = config;
        this.specificationVersion = "v2";
        this.supportedUrls = {
            "*/*": [
                /.*/
            ]
        };
    }
    get provider() {
        return this.config.provider;
    }
    async getArgs(options) {
        const { abortSignal: _abortSignal, ...optionsWithoutSignal } = options;
        return {
            args: this.maybeEncodeFileParts(optionsWithoutSignal),
            warnings: []
        };
    }
    async doGenerate(options) {
        const { args, warnings } = await this.getArgs(options);
        const { abortSignal } = options;
        const resolvedHeaders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers());
        try {
            const { responseHeaders, value: responseBody, rawValue: rawResponse } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
                url: this.getUrl(),
                headers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(resolvedHeaders, options.headers, this.getModelConfigHeaders(this.modelId, false), await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.o11yHeaders)),
                body: args,
                successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any()),
                failedResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonErrorResponseHandler"])({
                    errorSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any(),
                    errorToMessage: (data)=>data
                }),
                ...abortSignal && {
                    abortSignal
                },
                fetch: this.config.fetch
            });
            return {
                ...responseBody,
                request: {
                    body: args
                },
                response: {
                    headers: responseHeaders,
                    body: rawResponse
                },
                warnings
            };
        } catch (error) {
            throw await asGatewayError(error, await parseAuthMethod(resolvedHeaders));
        }
    }
    async doStream(options) {
        const { args, warnings } = await this.getArgs(options);
        const { abortSignal } = options;
        const resolvedHeaders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers());
        try {
            const { value: response, responseHeaders } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
                url: this.getUrl(),
                headers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(resolvedHeaders, options.headers, this.getModelConfigHeaders(this.modelId, true), await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.o11yHeaders)),
                body: args,
                successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createEventSourceResponseHandler"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any()),
                failedResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonErrorResponseHandler"])({
                    errorSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any(),
                    errorToMessage: (data)=>data
                }),
                ...abortSignal && {
                    abortSignal
                },
                fetch: this.config.fetch
            });
            return {
                stream: response.pipeThrough(new TransformStream({
                    start (controller) {
                        if (warnings.length > 0) {
                            controller.enqueue({
                                type: "stream-start",
                                warnings
                            });
                        }
                    },
                    transform (chunk, controller) {
                        if (chunk.success) {
                            const streamPart = chunk.value;
                            if (streamPart.type === "raw" && !options.includeRawChunks) {
                                return;
                            }
                            if (streamPart.type === "response-metadata" && streamPart.timestamp && typeof streamPart.timestamp === "string") {
                                streamPart.timestamp = new Date(streamPart.timestamp);
                            }
                            controller.enqueue(streamPart);
                        } else {
                            controller.error(chunk.error);
                        }
                    }
                })),
                request: {
                    body: args
                },
                response: {
                    headers: responseHeaders
                }
            };
        } catch (error) {
            throw await asGatewayError(error, await parseAuthMethod(resolvedHeaders));
        }
    }
    isFilePart(part) {
        return part && typeof part === "object" && "type" in part && part.type === "file";
    }
    /**
   * Encodes file parts in the prompt to base64. Mutates the passed options
   * instance directly to avoid copying the file data.
   * @param options - The options to encode.
   * @returns The options with the file parts encoded.
   */ maybeEncodeFileParts(options) {
        for (const message of options.prompt){
            for (const part of message.content){
                if (this.isFilePart(part)) {
                    const filePart = part;
                    if (filePart.data instanceof Uint8Array) {
                        const buffer = Uint8Array.from(filePart.data);
                        const base64Data = Buffer.from(buffer).toString("base64");
                        filePart.data = new URL(`data:${filePart.mediaType || "application/octet-stream"};base64,${base64Data}`);
                    }
                }
            }
        }
        return options;
    }
    getUrl() {
        return `${this.config.baseURL}/language-model`;
    }
    getModelConfigHeaders(modelId, streaming) {
        return {
            "ai-language-model-specification-version": "2",
            "ai-language-model-id": modelId,
            "ai-language-model-streaming": String(streaming)
        };
    }
};
;
;
var GatewayEmbeddingModel = class {
    constructor(modelId, config){
        this.modelId = modelId;
        this.config = config;
        this.specificationVersion = "v2";
        this.maxEmbeddingsPerCall = 2048;
        this.supportsParallelCalls = true;
    }
    get provider() {
        return this.config.provider;
    }
    async doEmbed({ values, headers, abortSignal, providerOptions }) {
        var _a8;
        const resolvedHeaders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers());
        try {
            const { responseHeaders, value: responseBody, rawValue } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
                url: this.getUrl(),
                headers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(resolvedHeaders, headers != null ? headers : {}, this.getModelConfigHeaders(), await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.o11yHeaders)),
                body: {
                    input: values.length === 1 ? values[0] : values,
                    ...providerOptions ? {
                        providerOptions
                    } : {}
                },
                successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(gatewayEmbeddingResponseSchema),
                failedResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonErrorResponseHandler"])({
                    errorSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any(),
                    errorToMessage: (data)=>data
                }),
                ...abortSignal && {
                    abortSignal
                },
                fetch: this.config.fetch
            });
            return {
                embeddings: responseBody.embeddings,
                usage: (_a8 = responseBody.usage) != null ? _a8 : void 0,
                providerMetadata: responseBody.providerMetadata,
                response: {
                    headers: responseHeaders,
                    body: rawValue
                }
            };
        } catch (error) {
            throw await asGatewayError(error, await parseAuthMethod(resolvedHeaders));
        }
    }
    getUrl() {
        return `${this.config.baseURL}/embedding-model`;
    }
    getModelConfigHeaders() {
        return {
            "ai-embedding-model-specification-version": "2",
            "ai-model-id": this.modelId
        };
    }
};
var gatewayEmbeddingResponseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazyValidator"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        embeddings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number())),
        usage: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            tokens: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number()
        }).nullish(),
        providerMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].unknown())).optional()
    })));
;
;
var GatewayImageModel = class {
    constructor(modelId, config){
        this.modelId = modelId;
        this.config = config;
        this.specificationVersion = "v2";
        // Set a very large number to prevent client-side splitting of requests
        this.maxImagesPerCall = Number.MAX_SAFE_INTEGER;
    }
    get provider() {
        return this.config.provider;
    }
    async doGenerate({ prompt, n, size, aspectRatio, seed, providerOptions, headers, abortSignal }) {
        var _a8;
        const resolvedHeaders = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers());
        try {
            const { responseHeaders, value: responseBody, rawValue } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
                url: this.getUrl(),
                headers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(resolvedHeaders, headers != null ? headers : {}, this.getModelConfigHeaders(), await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.o11yHeaders)),
                body: {
                    prompt,
                    n,
                    ...size && {
                        size
                    },
                    ...aspectRatio && {
                        aspectRatio
                    },
                    ...seed && {
                        seed
                    },
                    ...providerOptions && {
                        providerOptions
                    }
                },
                successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(gatewayImageResponseSchema),
                failedResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonErrorResponseHandler"])({
                    errorSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].any(),
                    errorToMessage: (data)=>data
                }),
                ...abortSignal && {
                    abortSignal
                },
                fetch: this.config.fetch
            });
            return {
                images: responseBody.images,
                // Always base64 strings from server
                warnings: (_a8 = responseBody.warnings) != null ? _a8 : [],
                providerMetadata: responseBody.providerMetadata,
                response: {
                    timestamp: /* @__PURE__ */ new Date(),
                    modelId: this.modelId,
                    headers: responseHeaders
                }
            };
        } catch (error) {
            throw asGatewayError(error, await parseAuthMethod(resolvedHeaders));
        }
    }
    getUrl() {
        return `${this.config.baseURL}/image-model`;
    }
    getModelConfigHeaders() {
        return {
            "ai-image-model-specification-version": "2",
            "ai-model-id": this.modelId
        };
    }
};
var providerMetadataEntrySchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    images: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].unknown()).optional()
}).catchall(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].unknown());
var gatewayImageResponseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    images: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()),
    // Always base64 strings over the wire
    warnings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        type: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].literal("other"),
        message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
    })).optional(),
    providerMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), providerMetadataEntrySchema).optional()
});
;
;
async function getVercelRequestId() {
    var _a8;
    return (_a8 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getContext"])().headers) == null ? void 0 : _a8["x-vercel-id"];
}
;
// src/version.ts
var VERSION = ("TURBOPACK compile-time truthy", 1) ? "2.0.18" : "TURBOPACK unreachable";
// src/gateway-provider.ts
var AI_GATEWAY_PROTOCOL_VERSION = "0.0.1";
function createGatewayProvider(options = {}) {
    var _a8, _b8;
    let pendingMetadata = null;
    let metadataCache = null;
    const cacheRefreshMillis = (_a8 = options.metadataCacheRefreshMillis) != null ? _a8 : 1e3 * 60 * 5;
    let lastFetchTime = 0;
    const baseURL = (_b8 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["withoutTrailingSlash"])(options.baseURL)) != null ? _b8 : "https://ai-gateway.vercel.sh/v1/ai";
    const getHeaders = async ()=>{
        const auth = await getGatewayAuthToken(options);
        if (auth) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["withUserAgentSuffix"])({
                Authorization: `Bearer ${auth.token}`,
                "ai-gateway-protocol-version": AI_GATEWAY_PROTOCOL_VERSION,
                [GATEWAY_AUTH_METHOD_HEADER]: auth.authMethod,
                ...options.headers
            }, `ai-sdk/gateway/${VERSION}`);
        }
        throw GatewayAuthenticationError.createContextualError({
            apiKeyProvided: false,
            oidcTokenProvided: false,
            statusCode: 401
        });
    };
    const createO11yHeaders = ()=>{
        const deploymentId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadOptionalSetting"])({
            settingValue: void 0,
            environmentVariableName: "VERCEL_DEPLOYMENT_ID"
        });
        const environment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadOptionalSetting"])({
            settingValue: void 0,
            environmentVariableName: "VERCEL_ENV"
        });
        const region = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadOptionalSetting"])({
            settingValue: void 0,
            environmentVariableName: "VERCEL_REGION"
        });
        return async ()=>{
            const requestId = await getVercelRequestId();
            return {
                ...deploymentId && {
                    "ai-o11y-deployment-id": deploymentId
                },
                ...environment && {
                    "ai-o11y-environment": environment
                },
                ...region && {
                    "ai-o11y-region": region
                },
                ...requestId && {
                    "ai-o11y-request-id": requestId
                }
            };
        };
    };
    const createLanguageModel = (modelId)=>{
        return new GatewayLanguageModel(modelId, {
            provider: "gateway",
            baseURL,
            headers: getHeaders,
            fetch: options.fetch,
            o11yHeaders: createO11yHeaders()
        });
    };
    const getAvailableModels = async ()=>{
        var _a9, _b9, _c;
        const now = (_c = (_b9 = (_a9 = options._internal) == null ? void 0 : _a9.currentDate) == null ? void 0 : _b9.call(_a9).getTime()) != null ? _c : Date.now();
        if (!pendingMetadata || now - lastFetchTime > cacheRefreshMillis) {
            lastFetchTime = now;
            pendingMetadata = new GatewayFetchMetadata({
                baseURL,
                headers: getHeaders,
                fetch: options.fetch
            }).getAvailableModels().then((metadata)=>{
                metadataCache = metadata;
                return metadata;
            }).catch(async (error)=>{
                throw await asGatewayError(error, await parseAuthMethod(await getHeaders()));
            });
        }
        return metadataCache ? Promise.resolve(metadataCache) : pendingMetadata;
    };
    const getCredits = async ()=>{
        return new GatewayFetchMetadata({
            baseURL,
            headers: getHeaders,
            fetch: options.fetch
        }).getCredits().catch(async (error)=>{
            throw await asGatewayError(error, await parseAuthMethod(await getHeaders()));
        });
    };
    const provider = function(modelId) {
        if (new.target) {
            throw new Error("The Gateway Provider model function cannot be called with the new keyword.");
        }
        return createLanguageModel(modelId);
    };
    provider.getAvailableModels = getAvailableModels;
    provider.getCredits = getCredits;
    provider.imageModel = (modelId)=>{
        return new GatewayImageModel(modelId, {
            provider: "gateway",
            baseURL,
            headers: getHeaders,
            fetch: options.fetch,
            o11yHeaders: createO11yHeaders()
        });
    };
    provider.languageModel = createLanguageModel;
    provider.textEmbeddingModel = (modelId)=>{
        return new GatewayEmbeddingModel(modelId, {
            provider: "gateway",
            baseURL,
            headers: getHeaders,
            fetch: options.fetch,
            o11yHeaders: createO11yHeaders()
        });
    };
    return provider;
}
var gateway = createGatewayProvider();
async function getGatewayAuthToken(options) {
    const apiKey = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadOptionalSetting"])({
        settingValue: options.apiKey,
        environmentVariableName: "AI_GATEWAY_API_KEY"
    });
    if (apiKey) {
        return {
            token: apiKey,
            authMethod: "api-key"
        };
    }
    try {
        const oidcToken = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$oidc$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVercelOidcToken"])();
        return {
            token: oidcToken,
            authMethod: "oidc"
        };
    } catch (e) {
        return null;
    }
}
;
 //# sourceMappingURL=index.mjs.map
}),
"[project]/node_modules/@workflow/ai/dist/agent/do-stream-step.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "doStreamStep",
    ()=>doStreamStep
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$gateway$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/gateway/dist/index.mjs [app-route] (ecmascript)");
;
async function doStreamStep(conversationPrompt, modelInit, writable, tools, options) {
    'use step';
    let model;
    if (typeof modelInit === 'string') {
        model = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$gateway$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateway"])(modelInit);
    } else if (typeof modelInit === 'function') {
        model = await modelInit();
    } else {
        throw new Error('Invalid "model initialization" argument. Must be a string or a function that returns a LanguageModelV2 instance.');
    }
    const result = await model.doStream({
        prompt: conversationPrompt,
        tools
    });
    let finish;
    const toolCalls = [];
    const chunks = [];
    await result.stream.pipeThrough(new TransformStream({
        transform (chunk, controller) {
            if (chunk.type === 'tool-call') {
                toolCalls.push({
                    ...chunk,
                    input: chunk.input || '{}'
                });
            } else if (chunk.type === 'finish') {
                finish = chunk;
            }
            chunks.push(chunk);
            controller.enqueue(chunk);
        }
    })).pipeThrough(new TransformStream({
        start: (controller)=>{
            if (options?.sendStart) {
                controller.enqueue({
                    type: 'start'
                });
            }
            controller.enqueue({
                type: 'start-step'
            });
        },
        flush: (controller)=>{
            controller.enqueue({
                type: 'finish-step'
            });
        },
        transform: async (part, controller)=>{
            const partType = part.type;
            switch(partType){
                case 'text-start':
                    {
                        controller.enqueue({
                            type: 'text-start',
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case 'text-delta':
                    {
                        controller.enqueue({
                            type: 'text-delta',
                            id: part.id,
                            delta: part.delta,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case 'text-end':
                    {
                        controller.enqueue({
                            type: 'text-end',
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case 'reasoning-start':
                    {
                        controller.enqueue({
                            type: 'reasoning-start',
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case 'reasoning-delta':
                    {
                        controller.enqueue({
                            type: 'reasoning-delta',
                            id: part.id,
                            delta: part.delta,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case 'reasoning-end':
                    {
                        controller.enqueue({
                            type: 'reasoning-end',
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                // case "file": {
                //   controller.enqueue({
                //     type: "file",
                //     mediaType: part.file.mediaType,
                //     url: `data:${part.file.mediaType};base64,${part.file.base64}`,
                //   });
                //   break;
                // }
                // case "source": {
                //   if (sendSources && part.sourceType === "url") {
                //     controller.enqueue({
                //       type: "source-url",
                //       sourceId: part.id,
                //       url: part.url,
                //       title: part.title,
                //       ...(part.providerMetadata != null
                //         ? { providerMetadata: part.providerMetadata }
                //         : {}),
                //     });
                //   }
                //   if (sendSources && part.sourceType === "document") {
                //     controller.enqueue({
                //       type: "source-document",
                //       sourceId: part.id,
                //       mediaType: part.mediaType,
                //       title: part.title,
                //       filename: part.filename,
                //       ...(part.providerMetadata != null
                //         ? { providerMetadata: part.providerMetadata }
                //         : {}),
                //     });
                //   }
                //   break;
                // }
                // case "tool-input-start": {
                //   const dynamic = isDynamic(part);
                //   controller.enqueue({
                //     type: "tool-input-start",
                //     toolCallId: part.id,
                //     toolName: part.toolName,
                //     ...(part.providerExecuted != null
                //       ? { providerExecuted: part.providerExecuted }
                //       : {}),
                //     ...(dynamic != null ? { dynamic } : {}),
                //   });
                //   break;
                // }
                // case "tool-input-delta": {
                //   controller.enqueue({
                //     type: "tool-input-delta",
                //     toolCallId: part.id,
                //     inputTextDelta: part.delta,
                //   });
                //   break;
                // }
                case 'tool-call':
                    {
                        // const dynamic = isDynamic(part);
                        // if (part.invalid) {
                        //   controller.enqueue({
                        //     type: "tool-input-error",
                        //     toolCallId: part.toolCallId,
                        //     toolName: part.toolName,
                        //     input: part.input,
                        //     ...(part.providerExecuted != null
                        //       ? { providerExecuted: part.providerExecuted }
                        //       : {}),
                        //     ...(part.providerMetadata != null
                        //       ? { providerMetadata: part.providerMetadata }
                        //       : {}),
                        //     ...(dynamic != null ? { dynamic } : {}),
                        //     errorText: onError(part.error),
                        //   });
                        // } else {
                        controller.enqueue({
                            type: 'tool-input-available',
                            toolCallId: part.toolCallId,
                            toolName: part.toolName,
                            input: JSON.parse(part.input || '{}'),
                            ...part.providerExecuted != null ? {
                                providerExecuted: part.providerExecuted
                            } : {},
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                // case "tool-approval-request": {
                //   controller.enqueue({
                //     type: "tool-approval-request",
                //     approvalId: part.approvalId,
                //     toolCallId: part.toolCall.toolCallId,
                //   });
                //   break;
                // }
                // case "tool-result": {
                //   const dynamic = isDynamic(part);
                //   controller.enqueue({
                //     type: "tool-output-available",
                //     toolCallId: part.toolCallId,
                //     output: part.output,
                //     ...(part.providerExecuted != null
                //       ? { providerExecuted: part.providerExecuted }
                //       : {}),
                //     ...(part.preliminary != null
                //       ? { preliminary: part.preliminary }
                //       : {}),
                //     ...(dynamic != null ? { dynamic } : {}),
                //   });
                //   break;
                // }
                // case "tool-error": {
                //   const dynamic = isDynamic(part);
                //   controller.enqueue({
                //     type: "tool-output-error",
                //     toolCallId: part.toolCallId,
                //     errorText: onError(part.error),
                //     ...(part.providerExecuted != null
                //       ? { providerExecuted: part.providerExecuted }
                //       : {}),
                //     ...(dynamic != null ? { dynamic } : {}),
                //   });
                //   break;
                // }
                // case "tool-output-denied": {
                //   controller.enqueue({
                //     type: "tool-output-denied",
                //     toolCallId: part.toolCallId,
                //   });
                //   break;
                // }
                case 'error':
                    {
                        const error = part.error;
                        controller.enqueue({
                            type: 'error',
                            errorText: error instanceof Error ? error.message : String(error)
                        });
                        break;
                    }
            }
        }
    })).pipeTo(writable, {
        preventClose: true
    });
    // if (!finish) {
    //   // This will cause the step to be retried
    //   throw new Error('LLM stream ended without a "finish" chunk');
    // }
    const step = chunksToStep(chunks, toolCalls, conversationPrompt, finish);
    return {
        toolCalls,
        finish,
        step
    };
}
// This is a stand-in for logic in the AI-SDK streamText code which aggregates
// chunks into a single step result.
function chunksToStep(chunks, toolCalls, conversationPrompt, finish) {
    // Transform chunks to a single step result
    const text = chunks.filter((chunk)=>chunk.type === 'text-delta').map((chunk)=>chunk.delta).join('');
    const reasoning = chunks.filter((chunk)=>chunk.type === 'reasoning-delta');
    const reasoningText = reasoning.map((chunk)=>chunk.delta).join('');
    // Extract warnings from stream-start chunk
    const streamStart = chunks.find((chunk)=>chunk.type === 'stream-start');
    // Extract response metadata from response-metadata chunk
    const responseMetadata = chunks.find((chunk)=>chunk.type === 'response-metadata');
    const stepResult = {
        content: [
            ...text ? [
                {
                    type: 'text',
                    text
                }
            ] : [],
            ...toolCalls.map((toolCall)=>({
                    type: 'tool-call',
                    toolCallId: toolCall.toolCallId,
                    toolName: toolCall.toolName,
                    input: JSON.parse(toolCall.input),
                    dynamic: true
                }))
        ],
        text,
        reasoning: reasoning.map((chunk)=>({
                type: 'reasoning',
                text: chunk.delta
            })),
        reasoningText: reasoningText || undefined,
        files: [],
        sources: [],
        toolCalls: toolCalls.map((toolCall)=>({
                type: 'tool-call',
                toolCallId: toolCall.toolCallId,
                toolName: toolCall.toolName,
                input: JSON.parse(toolCall.input),
                dynamic: true
            })),
        staticToolCalls: [],
        dynamicToolCalls: toolCalls.map((toolCall)=>({
                type: 'tool-call',
                toolCallId: toolCall.toolCallId,
                toolName: toolCall.toolName,
                input: JSON.parse(toolCall.input),
                dynamic: true
            })),
        toolResults: [],
        staticToolResults: [],
        dynamicToolResults: [],
        finishReason: finish?.finishReason || 'unknown',
        usage: finish?.usage || {
            inputTokens: 0,
            outputTokens: 0,
            totalTokens: 0
        },
        warnings: streamStart?.warnings,
        request: {
            body: JSON.stringify({
                prompt: conversationPrompt,
                tools: toolCalls.map((toolCall)=>({
                        type: 'tool-call',
                        toolCallId: toolCall.toolCallId,
                        toolName: toolCall.toolName,
                        input: JSON.parse(toolCall.input),
                        dynamic: true
                    }))
            })
        },
        response: {
            id: responseMetadata?.id ?? 'unknown',
            timestamp: responseMetadata?.timestamp ?? new Date(),
            modelId: responseMetadata?.modelId ?? 'unknown',
            messages: []
        },
        providerMetadata: finish?.providerMetadata || {}
    };
    return stepResult;
} //# sourceMappingURL=do-stream-step.js.map
}),
"[project]/node_modules/@workflow/ai/dist/agent/tools-to-model-tools.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "toolsToModelTools",
    ()=>toolsToModelTools
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-route] (ecmascript) <locals>");
;
function toolsToModelTools(tools) {
    return Object.entries(tools).map(([name, tool])=>({
            type: 'function',
            name,
            description: tool.description,
            inputSchema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["asSchema"])(tool.inputSchema).jsonSchema
        }));
} //# sourceMappingURL=tools-to-model-tools.js.map
}),
"[project]/node_modules/@workflow/ai/dist/agent/stream-text-iterator.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "streamTextIterator",
    ()=>streamTextIterator
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$do$2d$stream$2d$step$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/ai/dist/agent/do-stream-step.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$tools$2d$to$2d$model$2d$tools$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/ai/dist/agent/tools-to-model-tools.js [app-route] (ecmascript)");
;
;
async function* streamTextIterator({ prompt, tools = {}, writable, model, stopConditions, sendStart = true, onStepFinish, prepareStep }) {
    let conversationPrompt = [
        ...prompt
    ]; // Create a mutable copy
    let currentModel = model;
    const steps = [];
    let done = false;
    let isFirstIteration = true;
    let stepNumber = 0;
    while(!done){
        // Call prepareStep callback before each step if provided
        if (prepareStep) {
            const prepareResult = await prepareStep({
                model: currentModel,
                stepNumber,
                steps,
                messages: conversationPrompt
            });
            // Apply any overrides from prepareStep
            if (prepareResult.model !== undefined) {
                currentModel = prepareResult.model;
            }
            if (prepareResult.messages !== undefined) {
                conversationPrompt = [
                    ...prepareResult.messages
                ];
            }
        }
        const { toolCalls, finish, step } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$do$2d$stream$2d$step$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["doStreamStep"])(conversationPrompt, currentModel, writable, (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$tools$2d$to$2d$model$2d$tools$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["toolsToModelTools"])(tools), {
            sendStart: sendStart && isFirstIteration
        });
        isFirstIteration = false;
        stepNumber++;
        steps.push(step);
        if (finish?.finishReason === 'tool-calls') {
            // Add assistant message with tool calls to the conversation
            conversationPrompt.push({
                role: 'assistant',
                content: toolCalls.map((toolCall)=>({
                        type: 'tool-call',
                        toolCallId: toolCall.toolCallId,
                        toolName: toolCall.toolName,
                        input: JSON.parse(toolCall.input)
                    }))
            });
            // Yield the tool calls along with the current conversation messages
            // This allows executeTool to pass the conversation context to tool execute functions
            const toolResults = yield {
                toolCalls,
                messages: conversationPrompt
            };
            await writeToolOutputToUI(writable, toolResults);
            conversationPrompt.push({
                role: 'tool',
                content: toolResults
            });
            if (stopConditions) {
                const stopConditionList = Array.isArray(stopConditions) ? stopConditions : [
                    stopConditions
                ];
                if (stopConditionList.some((test)=>test({
                        steps
                    }))) {
                    done = true;
                }
            }
        } else if (finish?.finishReason === 'stop') {
            // Add assistant message with text content to the conversation
            const textContent = step.content.filter((item)=>item.type === 'text');
            if (textContent.length > 0) {
                conversationPrompt.push({
                    role: 'assistant',
                    content: textContent
                });
            }
            done = true;
        } else {
            throw new Error(`Unexpected finish reason: ${finish?.finishReason}`);
        }
        if (onStepFinish) {
            await onStepFinish(step);
        }
    }
    return conversationPrompt;
}
async function writeToolOutputToUI(writable, toolResults) {
    'use step';
    const writer = writable.getWriter();
    try {
        for (const result of toolResults){
            await writer.write({
                type: 'tool-output-available',
                toolCallId: result.toolCallId,
                output: JSON.stringify(result) ?? ''
            });
        }
    } finally{
        writer.releaseLock();
    }
} //# sourceMappingURL=stream-text-iterator.js.map
}),
"[project]/node_modules/@workflow/ai/dist/agent/durable-agent.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DurableAgent",
    ()=>DurableAgent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$internal$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/dist/internal/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$workflow$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/workflow/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$stream$2d$text$2d$iterator$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/ai/dist/agent/stream-text-iterator.js [app-route] (ecmascript)");
;
;
;
;
class DurableAgent {
    model;
    tools;
    system;
    constructor(options){
        this.model = options.model;
        this.tools = options.tools ?? {};
        this.system = options.system;
    }
    generate() {
        throw new Error('Not implemented');
    }
    async stream(options) {
        const prompt = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$internal$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["standardizePrompt"])({
            system: options.system || this.system,
            messages: options.messages
        });
        const modelPrompt = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$dist$2f$internal$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["convertToLanguageModelPrompt"])({
            prompt,
            supportedUrls: {},
            download: undefined
        });
        const iterator = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$stream$2d$text$2d$iterator$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["streamTextIterator"])({
            model: this.model,
            tools: this.tools,
            writable: options.writable,
            prompt: modelPrompt,
            stopConditions: options.stopWhen,
            sendStart: options.sendStart ?? true,
            onStepFinish: options.onStepFinish,
            prepareStep: options.prepareStep
        });
        let result = await iterator.next();
        while(!result.done){
            const { toolCalls, messages } = result.value;
            const toolResults = await Promise.all(toolCalls.map((toolCall)=>executeTool(toolCall, this.tools, messages)));
            result = await iterator.next(toolResults);
        }
        const sendFinish = options.sendFinish ?? true;
        const preventClose = options.preventClose ?? false;
        // Only call closeStream if there's something to do
        if (sendFinish || !preventClose) {
            await closeStream(options.writable, preventClose, sendFinish);
        }
        // The iterator returns the final conversation prompt (LanguageModelV2Prompt)
        // which is compatible with ModelMessage[]
        const messages = result.value;
        return {
            messages
        };
    }
}
async function closeStream(writable, preventClose, sendFinish) {
    'use step';
    // Conditionally write the finish chunk
    if (sendFinish) {
        const writer = writable.getWriter();
        try {
            await writer.write({
                type: 'finish'
            });
        } finally{
            writer.releaseLock();
        }
    }
    // Conditionally close the stream
    if (!preventClose) {
        await writable.close();
    }
}
async function executeTool(toolCall, tools, messages) {
    const tool = tools[toolCall.toolName];
    if (!tool) throw new Error(`Tool "${toolCall.toolName}" not found`);
    if (typeof tool.execute !== 'function') throw new Error(`Tool "${toolCall.toolName}" does not have an execute function`);
    const schema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["asSchema"])(tool.inputSchema);
    const input = await schema.validate?.(JSON.parse(toolCall.input || '{}'));
    if (!input?.success) {
        throw new Error(`Invalid input for tool "${toolCall.toolName}": ${input?.error?.message}`);
    }
    try {
        const toolResult = await tool.execute(input.value, {
            toolCallId: toolCall.toolCallId,
            // Pass the conversation messages to the tool so it has context about the conversation
            messages
        });
        return {
            type: 'tool-result',
            toolCallId: toolCall.toolCallId,
            toolName: toolCall.toolName,
            output: {
                type: 'text',
                value: JSON.stringify(toolResult) ?? ''
            }
        };
    } catch (error) {
        // If it's a FatalError, convert it to a tool error result that gets sent back to the LLM
        // This mimics AI SDK behavior where tool call failures are propagated back to the model
        if (__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FatalError"].is(error)) {
            return {
                type: 'tool-result',
                toolCallId: toolCall.toolCallId,
                toolName: toolCall.toolName,
                output: {
                    type: 'error-text',
                    value: error.message
                }
            };
        }
        // This should technically never happen, since any error that's not FatalError would be caught in the step boundary and re-try the step
        throw error;
    }
} //# sourceMappingURL=durable-agent.js.map
}),
"[project]/node_modules/@ai-sdk/google/dist/index.mjs [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/google-provider.ts
__turbopack_context__.s([
    "VERSION",
    ()=>VERSION,
    "createGoogleGenerativeAI",
    ()=>createGoogleGenerativeAI,
    "google",
    ()=>google
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-route] (ecmascript) <locals>");
// src/google-generative-ai-embedding-model.ts
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ai-sdk/provider/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/index.js [app-route] (ecmascript)");
;
// src/version.ts
var VERSION = ("TURBOPACK compile-time truthy", 1) ? "2.0.43" : "TURBOPACK unreachable";
;
;
;
;
;
var googleErrorDataSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        error: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullable(),
            message: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
            status: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
        })
    })));
var googleFailedResponseHandler = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonErrorResponseHandler"])({
    errorSchema: googleErrorDataSchema,
    errorToMessage: (data)=>data.error.message
});
;
;
var googleGenerativeAIEmbeddingProviderOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        /**
       * Optional. Optional reduced dimension for the output embedding.
       * If set, excessive values in the output embedding are truncated from the end.
       */ outputDimensionality: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().optional(),
        /**
       * Optional. Specifies the task type for generating embeddings.
       * Supported task types:
       * - SEMANTIC_SIMILARITY: Optimized for text similarity.
       * - CLASSIFICATION: Optimized for text classification.
       * - CLUSTERING: Optimized for clustering texts based on similarity.
       * - RETRIEVAL_DOCUMENT: Optimized for document retrieval.
       * - RETRIEVAL_QUERY: Optimized for query-based retrieval.
       * - QUESTION_ANSWERING: Optimized for answering questions.
       * - FACT_VERIFICATION: Optimized for verifying factual information.
       * - CODE_RETRIEVAL_QUERY: Optimized for retrieving code blocks based on natural language queries.
       */ taskType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
            "SEMANTIC_SIMILARITY",
            "CLASSIFICATION",
            "CLUSTERING",
            "RETRIEVAL_DOCUMENT",
            "RETRIEVAL_QUERY",
            "QUESTION_ANSWERING",
            "FACT_VERIFICATION",
            "CODE_RETRIEVAL_QUERY"
        ]).optional()
    })));
// src/google-generative-ai-embedding-model.ts
var GoogleGenerativeAIEmbeddingModel = class {
    constructor(modelId, config){
        this.specificationVersion = "v2";
        this.maxEmbeddingsPerCall = 2048;
        this.supportsParallelCalls = true;
        this.modelId = modelId;
        this.config = config;
    }
    get provider() {
        return this.config.provider;
    }
    async doEmbed({ values, headers, abortSignal, providerOptions }) {
        const googleOptions = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseProviderOptions"])({
            provider: "google",
            providerOptions,
            schema: googleGenerativeAIEmbeddingProviderOptions
        });
        if (values.length > this.maxEmbeddingsPerCall) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["TooManyEmbeddingValuesForCallError"]({
                provider: this.provider,
                modelId: this.modelId,
                maxEmbeddingsPerCall: this.maxEmbeddingsPerCall,
                values
            });
        }
        const mergedHeaders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers), headers);
        if (values.length === 1) {
            const { responseHeaders: responseHeaders2, value: response2, rawValue: rawValue2 } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
                url: `${this.config.baseURL}/models/${this.modelId}:embedContent`,
                headers: mergedHeaders,
                body: {
                    model: `models/${this.modelId}`,
                    content: {
                        parts: [
                            {
                                text: values[0]
                            }
                        ]
                    },
                    outputDimensionality: googleOptions == null ? void 0 : googleOptions.outputDimensionality,
                    taskType: googleOptions == null ? void 0 : googleOptions.taskType
                },
                failedResponseHandler: googleFailedResponseHandler,
                successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(googleGenerativeAISingleEmbeddingResponseSchema),
                abortSignal,
                fetch: this.config.fetch
            });
            return {
                embeddings: [
                    response2.embedding.values
                ],
                usage: void 0,
                response: {
                    headers: responseHeaders2,
                    body: rawValue2
                }
            };
        }
        const { responseHeaders, value: response, rawValue } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
            url: `${this.config.baseURL}/models/${this.modelId}:batchEmbedContents`,
            headers: mergedHeaders,
            body: {
                requests: values.map((value)=>({
                        model: `models/${this.modelId}`,
                        content: {
                            role: "user",
                            parts: [
                                {
                                    text: value
                                }
                            ]
                        },
                        outputDimensionality: googleOptions == null ? void 0 : googleOptions.outputDimensionality,
                        taskType: googleOptions == null ? void 0 : googleOptions.taskType
                    }))
            },
            failedResponseHandler: googleFailedResponseHandler,
            successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(googleGenerativeAITextEmbeddingResponseSchema),
            abortSignal,
            fetch: this.config.fetch
        });
        return {
            embeddings: response.embeddings.map((item)=>item.values),
            usage: void 0,
            response: {
                headers: responseHeaders,
                body: rawValue
            }
        };
    }
};
var googleGenerativeAITextEmbeddingResponseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        embeddings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number())
        }))
    })));
var googleGenerativeAISingleEmbeddingResponseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        embedding: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            values: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number())
        })
    })));
;
;
// src/convert-json-schema-to-openapi-schema.ts
function convertJSONSchemaToOpenAPISchema(jsonSchema) {
    if (jsonSchema == null || isEmptyObjectSchema(jsonSchema)) {
        return void 0;
    }
    if (typeof jsonSchema === "boolean") {
        return {
            type: "boolean",
            properties: {}
        };
    }
    const { type, description, required, properties, items, allOf, anyOf, oneOf, format, const: constValue, minLength, enum: enumValues } = jsonSchema;
    const result = {};
    if (description) result.description = description;
    if (required) result.required = required;
    if (format) result.format = format;
    if (constValue !== void 0) {
        result.enum = [
            constValue
        ];
    }
    if (type) {
        if (Array.isArray(type)) {
            const hasNull = type.includes("null");
            const nonNullTypes = type.filter((t)=>t !== "null");
            if (nonNullTypes.length === 0) {
                result.type = "null";
            } else {
                result.anyOf = nonNullTypes.map((t)=>({
                        type: t
                    }));
                if (hasNull) {
                    result.nullable = true;
                }
            }
        } else {
            result.type = type;
        }
    }
    if (enumValues !== void 0) {
        result.enum = enumValues;
    }
    if (properties != null) {
        result.properties = Object.entries(properties).reduce((acc, [key, value])=>{
            acc[key] = convertJSONSchemaToOpenAPISchema(value);
            return acc;
        }, {});
    }
    if (items) {
        result.items = Array.isArray(items) ? items.map(convertJSONSchemaToOpenAPISchema) : convertJSONSchemaToOpenAPISchema(items);
    }
    if (allOf) {
        result.allOf = allOf.map(convertJSONSchemaToOpenAPISchema);
    }
    if (anyOf) {
        if (anyOf.some((schema)=>typeof schema === "object" && (schema == null ? void 0 : schema.type) === "null")) {
            const nonNullSchemas = anyOf.filter((schema)=>!(typeof schema === "object" && (schema == null ? void 0 : schema.type) === "null"));
            if (nonNullSchemas.length === 1) {
                const converted = convertJSONSchemaToOpenAPISchema(nonNullSchemas[0]);
                if (typeof converted === "object") {
                    result.nullable = true;
                    Object.assign(result, converted);
                }
            } else {
                result.anyOf = nonNullSchemas.map(convertJSONSchemaToOpenAPISchema);
                result.nullable = true;
            }
        } else {
            result.anyOf = anyOf.map(convertJSONSchemaToOpenAPISchema);
        }
    }
    if (oneOf) {
        result.oneOf = oneOf.map(convertJSONSchemaToOpenAPISchema);
    }
    if (minLength !== void 0) {
        result.minLength = minLength;
    }
    return result;
}
function isEmptyObjectSchema(jsonSchema) {
    return jsonSchema != null && typeof jsonSchema === "object" && jsonSchema.type === "object" && (jsonSchema.properties == null || Object.keys(jsonSchema.properties).length === 0) && !jsonSchema.additionalProperties;
}
;
;
function convertToGoogleGenerativeAIMessages(prompt, options) {
    var _a;
    const systemInstructionParts = [];
    const contents = [];
    let systemMessagesAllowed = true;
    const isGemmaModel = (_a = options == null ? void 0 : options.isGemmaModel) != null ? _a : false;
    for (const { role, content } of prompt){
        switch(role){
            case "system":
                {
                    if (!systemMessagesAllowed) {
                        throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UnsupportedFunctionalityError"]({
                            functionality: "system messages are only supported at the beginning of the conversation"
                        });
                    }
                    systemInstructionParts.push({
                        text: content
                    });
                    break;
                }
            case "user":
                {
                    systemMessagesAllowed = false;
                    const parts = [];
                    for (const part of content){
                        switch(part.type){
                            case "text":
                                {
                                    parts.push({
                                        text: part.text
                                    });
                                    break;
                                }
                            case "file":
                                {
                                    const mediaType = part.mediaType === "image/*" ? "image/jpeg" : part.mediaType;
                                    parts.push(part.data instanceof URL ? {
                                        fileData: {
                                            mimeType: mediaType,
                                            fileUri: part.data.toString()
                                        }
                                    } : {
                                        inlineData: {
                                            mimeType: mediaType,
                                            data: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["convertToBase64"])(part.data)
                                        }
                                    });
                                    break;
                                }
                        }
                    }
                    contents.push({
                        role: "user",
                        parts
                    });
                    break;
                }
            case "assistant":
                {
                    systemMessagesAllowed = false;
                    contents.push({
                        role: "model",
                        parts: content.map((part)=>{
                            var _a2, _b, _c;
                            const thoughtSignature = ((_b = (_a2 = part.providerOptions) == null ? void 0 : _a2.google) == null ? void 0 : _b.thoughtSignature) != null ? String((_c = part.providerOptions.google) == null ? void 0 : _c.thoughtSignature) : void 0;
                            switch(part.type){
                                case "text":
                                    {
                                        return part.text.length === 0 ? void 0 : {
                                            text: part.text,
                                            thoughtSignature
                                        };
                                    }
                                case "reasoning":
                                    {
                                        return part.text.length === 0 ? void 0 : {
                                            text: part.text,
                                            thought: true,
                                            thoughtSignature
                                        };
                                    }
                                case "file":
                                    {
                                        if (part.mediaType !== "image/png") {
                                            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UnsupportedFunctionalityError"]({
                                                functionality: "Only PNG images are supported in assistant messages"
                                            });
                                        }
                                        if (part.data instanceof URL) {
                                            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UnsupportedFunctionalityError"]({
                                                functionality: "File data URLs in assistant messages are not supported"
                                            });
                                        }
                                        return {
                                            inlineData: {
                                                mimeType: part.mediaType,
                                                data: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["convertToBase64"])(part.data)
                                            }
                                        };
                                    }
                                case "tool-call":
                                    {
                                        return {
                                            functionCall: {
                                                name: part.toolName,
                                                args: part.input
                                            },
                                            thoughtSignature
                                        };
                                    }
                            }
                        }).filter((part)=>part !== void 0)
                    });
                    break;
                }
            case "tool":
                {
                    systemMessagesAllowed = false;
                    const parts = [];
                    for (const part of content){
                        const output = part.output;
                        if (output.type === "content") {
                            for (const contentPart of output.value){
                                switch(contentPart.type){
                                    case "text":
                                        parts.push({
                                            functionResponse: {
                                                name: part.toolName,
                                                response: {
                                                    name: part.toolName,
                                                    content: contentPart.text
                                                }
                                            }
                                        });
                                        break;
                                    case "media":
                                        parts.push({
                                            inlineData: {
                                                mimeType: contentPart.mediaType,
                                                data: contentPart.data
                                            }
                                        }, {
                                            text: "Tool executed successfully and returned this image as a response"
                                        });
                                        break;
                                    default:
                                        parts.push({
                                            text: JSON.stringify(contentPart)
                                        });
                                        break;
                                }
                            }
                        } else {
                            parts.push({
                                functionResponse: {
                                    name: part.toolName,
                                    response: {
                                        name: part.toolName,
                                        content: output.value
                                    }
                                }
                            });
                        }
                    }
                    contents.push({
                        role: "user",
                        parts
                    });
                    break;
                }
        }
    }
    if (isGemmaModel && systemInstructionParts.length > 0 && contents.length > 0 && contents[0].role === "user") {
        const systemText = systemInstructionParts.map((part)=>part.text).join("\n\n");
        contents[0].parts.unshift({
            text: systemText + "\n\n"
        });
    }
    return {
        systemInstruction: systemInstructionParts.length > 0 && !isGemmaModel ? {
            parts: systemInstructionParts
        } : void 0,
        contents
    };
}
// src/get-model-path.ts
function getModelPath(modelId) {
    return modelId.includes("/") ? modelId : `models/${modelId}`;
}
;
;
var googleGenerativeAIProviderOptions = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        responseModalities: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
            "TEXT",
            "IMAGE"
        ])).optional(),
        thinkingConfig: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            thinkingBudget: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().optional(),
            includeThoughts: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].boolean().optional(),
            // https://ai.google.dev/gemini-api/docs/gemini-3?thinking=high#thinking_level
            thinkingLevel: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
                "low",
                "medium",
                "high"
            ]).optional()
        }).optional(),
        /**
       * Optional.
       * The name of the cached content used as context to serve the prediction.
       * Format: cachedContents/{cachedContent}
       */ cachedContent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().optional(),
        /**
       * Optional. Enable structured output. Default is true.
       *
       * This is useful when the JSON Schema contains elements that are
       * not supported by the OpenAPI schema version that
       * Google Generative AI uses. You can use this to disable
       * structured outputs if you need to.
       */ structuredOutputs: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].boolean().optional(),
        /**
       * Optional. A list of unique safety settings for blocking unsafe content.
       */ safetySettings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
                "HARM_CATEGORY_UNSPECIFIED",
                "HARM_CATEGORY_HATE_SPEECH",
                "HARM_CATEGORY_DANGEROUS_CONTENT",
                "HARM_CATEGORY_HARASSMENT",
                "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "HARM_CATEGORY_CIVIC_INTEGRITY"
            ]),
            threshold: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
                "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
                "BLOCK_LOW_AND_ABOVE",
                "BLOCK_MEDIUM_AND_ABOVE",
                "BLOCK_ONLY_HIGH",
                "BLOCK_NONE",
                "OFF"
            ])
        })).optional(),
        threshold: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
            "HARM_BLOCK_THRESHOLD_UNSPECIFIED",
            "BLOCK_LOW_AND_ABOVE",
            "BLOCK_MEDIUM_AND_ABOVE",
            "BLOCK_ONLY_HIGH",
            "BLOCK_NONE",
            "OFF"
        ]).optional(),
        /**
       * Optional. Enables timestamp understanding for audio-only files.
       *
       * https://cloud.google.com/vertex-ai/generative-ai/docs/multimodal/audio-understanding
       */ audioTimestamp: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].boolean().optional(),
        /**
       * Optional. Defines labels used in billing reports. Available on Vertex AI only.
       *
       * https://cloud.google.com/vertex-ai/generative-ai/docs/multimodal/add-labels-to-api-calls
       */ labels: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].record(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(), __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()).optional(),
        /**
       * Optional. If specified, the media resolution specified will be used.
       *
       * https://ai.google.dev/api/generate-content#MediaResolution
       */ mediaResolution: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
            "MEDIA_RESOLUTION_UNSPECIFIED",
            "MEDIA_RESOLUTION_LOW",
            "MEDIA_RESOLUTION_MEDIUM",
            "MEDIA_RESOLUTION_HIGH"
        ]).optional(),
        /**
       * Optional. Configures the image generation aspect ratio for Gemini models.
       *
       * https://ai.google.dev/gemini-api/docs/image-generation#aspect_ratios
       */ imageConfig: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            aspectRatio: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
                "1:1",
                "2:3",
                "3:2",
                "3:4",
                "4:3",
                "4:5",
                "5:4",
                "9:16",
                "16:9",
                "21:9"
            ]).optional(),
            imageSize: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
                "1K",
                "2K",
                "4K"
            ]).optional()
        }).optional()
    })));
;
function prepareTools({ tools, toolChoice, modelId }) {
    var _a;
    tools = (tools == null ? void 0 : tools.length) ? tools : void 0;
    const toolWarnings = [];
    const isLatest = [
        "gemini-flash-latest",
        "gemini-flash-lite-latest",
        "gemini-pro-latest"
    ].some((id)=>id === modelId);
    const isGemini2orNewer = modelId.includes("gemini-2") || modelId.includes("gemini-3") || isLatest;
    const supportsDynamicRetrieval = modelId.includes("gemini-1.5-flash") && !modelId.includes("-8b");
    const supportsFileSearch = modelId.includes("gemini-2.5");
    if (tools == null) {
        return {
            tools: void 0,
            toolConfig: void 0,
            toolWarnings
        };
    }
    const hasFunctionTools = tools.some((tool)=>tool.type === "function");
    const hasProviderDefinedTools = tools.some((tool)=>tool.type === "provider-defined");
    if (hasFunctionTools && hasProviderDefinedTools) {
        const functionTools = tools.filter((tool)=>tool.type === "function");
        toolWarnings.push({
            type: "unsupported-tool",
            tool: tools.find((tool)=>tool.type === "function"),
            details: `Cannot mix function tools with provider-defined tools in the same request. Falling back to provider-defined tools only. The following function tools will be ignored: ${functionTools.map((t)=>t.name).join(", ")}. Please use either function tools or provider-defined tools, but not both.`
        });
    }
    if (hasProviderDefinedTools) {
        const googleTools2 = [];
        const providerDefinedTools = tools.filter((tool)=>tool.type === "provider-defined");
        providerDefinedTools.forEach((tool)=>{
            switch(tool.id){
                case "google.google_search":
                    if (isGemini2orNewer) {
                        googleTools2.push({
                            googleSearch: {}
                        });
                    } else if (supportsDynamicRetrieval) {
                        googleTools2.push({
                            googleSearchRetrieval: {
                                dynamicRetrievalConfig: {
                                    mode: tool.args.mode,
                                    dynamicThreshold: tool.args.dynamicThreshold
                                }
                            }
                        });
                    } else {
                        googleTools2.push({
                            googleSearchRetrieval: {}
                        });
                    }
                    break;
                case "google.url_context":
                    if (isGemini2orNewer) {
                        googleTools2.push({
                            urlContext: {}
                        });
                    } else {
                        toolWarnings.push({
                            type: "unsupported-tool",
                            tool,
                            details: "The URL context tool is not supported with other Gemini models than Gemini 2."
                        });
                    }
                    break;
                case "google.code_execution":
                    if (isGemini2orNewer) {
                        googleTools2.push({
                            codeExecution: {}
                        });
                    } else {
                        toolWarnings.push({
                            type: "unsupported-tool",
                            tool,
                            details: "The code execution tools is not supported with other Gemini models than Gemini 2."
                        });
                    }
                    break;
                case "google.file_search":
                    if (supportsFileSearch) {
                        googleTools2.push({
                            fileSearch: {
                                ...tool.args
                            }
                        });
                    } else {
                        toolWarnings.push({
                            type: "unsupported-tool",
                            tool,
                            details: "The file search tool is only supported with Gemini 2.5 models."
                        });
                    }
                    break;
                case "google.vertex_rag_store":
                    if (isGemini2orNewer) {
                        googleTools2.push({
                            retrieval: {
                                vertex_rag_store: {
                                    rag_resources: {
                                        rag_corpus: tool.args.ragCorpus
                                    },
                                    similarity_top_k: tool.args.topK
                                }
                            }
                        });
                    } else {
                        toolWarnings.push({
                            type: "unsupported-tool",
                            tool,
                            details: "The RAG store tool is not supported with other Gemini models than Gemini 2."
                        });
                    }
                    break;
                default:
                    toolWarnings.push({
                        type: "unsupported-tool",
                        tool
                    });
                    break;
            }
        });
        return {
            tools: googleTools2.length > 0 ? googleTools2 : void 0,
            toolConfig: void 0,
            toolWarnings
        };
    }
    const functionDeclarations = [];
    for (const tool of tools){
        switch(tool.type){
            case "function":
                functionDeclarations.push({
                    name: tool.name,
                    description: (_a = tool.description) != null ? _a : "",
                    parameters: convertJSONSchemaToOpenAPISchema(tool.inputSchema)
                });
                break;
            default:
                toolWarnings.push({
                    type: "unsupported-tool",
                    tool
                });
                break;
        }
    }
    if (toolChoice == null) {
        return {
            tools: [
                {
                    functionDeclarations
                }
            ],
            toolConfig: void 0,
            toolWarnings
        };
    }
    const type = toolChoice.type;
    switch(type){
        case "auto":
            return {
                tools: [
                    {
                        functionDeclarations
                    }
                ],
                toolConfig: {
                    functionCallingConfig: {
                        mode: "AUTO"
                    }
                },
                toolWarnings
            };
        case "none":
            return {
                tools: [
                    {
                        functionDeclarations
                    }
                ],
                toolConfig: {
                    functionCallingConfig: {
                        mode: "NONE"
                    }
                },
                toolWarnings
            };
        case "required":
            return {
                tools: [
                    {
                        functionDeclarations
                    }
                ],
                toolConfig: {
                    functionCallingConfig: {
                        mode: "ANY"
                    }
                },
                toolWarnings
            };
        case "tool":
            return {
                tools: [
                    {
                        functionDeclarations
                    }
                ],
                toolConfig: {
                    functionCallingConfig: {
                        mode: "ANY",
                        allowedFunctionNames: [
                            toolChoice.toolName
                        ]
                    }
                },
                toolWarnings
            };
        default:
            {
                const _exhaustiveCheck = type;
                throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["UnsupportedFunctionalityError"]({
                    functionality: `tool choice type: ${_exhaustiveCheck}`
                });
            }
    }
}
// src/map-google-generative-ai-finish-reason.ts
function mapGoogleGenerativeAIFinishReason({ finishReason, hasToolCalls }) {
    switch(finishReason){
        case "STOP":
            return hasToolCalls ? "tool-calls" : "stop";
        case "MAX_TOKENS":
            return "length";
        case "IMAGE_SAFETY":
        case "RECITATION":
        case "SAFETY":
        case "BLOCKLIST":
        case "PROHIBITED_CONTENT":
        case "SPII":
            return "content-filter";
        case "FINISH_REASON_UNSPECIFIED":
        case "OTHER":
            return "other";
        case "MALFORMED_FUNCTION_CALL":
            return "error";
        default:
            return "unknown";
    }
}
// src/google-generative-ai-language-model.ts
var GoogleGenerativeAILanguageModel = class {
    constructor(modelId, config){
        this.specificationVersion = "v2";
        var _a;
        this.modelId = modelId;
        this.config = config;
        this.generateId = (_a = config.generateId) != null ? _a : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateId"];
    }
    get provider() {
        return this.config.provider;
    }
    get supportedUrls() {
        var _a, _b, _c;
        return (_c = (_b = (_a = this.config).supportedUrls) == null ? void 0 : _b.call(_a)) != null ? _c : {};
    }
    async getArgs({ prompt, maxOutputTokens, temperature, topP, topK, frequencyPenalty, presencePenalty, stopSequences, responseFormat, seed, tools, toolChoice, providerOptions }) {
        var _a;
        const warnings = [];
        const googleOptions = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseProviderOptions"])({
            provider: "google",
            providerOptions,
            schema: googleGenerativeAIProviderOptions
        });
        if ((tools == null ? void 0 : tools.some((tool)=>tool.type === "provider-defined" && tool.id === "google.vertex_rag_store")) && !this.config.provider.startsWith("google.vertex.")) {
            warnings.push({
                type: "other",
                message: `The 'vertex_rag_store' tool is only supported with the Google Vertex provider and might not be supported or could behave unexpectedly with the current Google provider (${this.config.provider}).`
            });
        }
        const isGemmaModel = this.modelId.toLowerCase().startsWith("gemma-");
        const { contents, systemInstruction } = convertToGoogleGenerativeAIMessages(prompt, {
            isGemmaModel
        });
        const { tools: googleTools2, toolConfig: googleToolConfig, toolWarnings } = prepareTools({
            tools,
            toolChoice,
            modelId: this.modelId
        });
        return {
            args: {
                generationConfig: {
                    // standardized settings:
                    maxOutputTokens,
                    temperature,
                    topK,
                    topP,
                    frequencyPenalty,
                    presencePenalty,
                    stopSequences,
                    seed,
                    // response format:
                    responseMimeType: (responseFormat == null ? void 0 : responseFormat.type) === "json" ? "application/json" : void 0,
                    responseSchema: (responseFormat == null ? void 0 : responseFormat.type) === "json" && responseFormat.schema != null && // Google GenAI does not support all OpenAPI Schema features,
                    // so this is needed as an escape hatch:
                    // TODO convert into provider option
                    ((_a = googleOptions == null ? void 0 : googleOptions.structuredOutputs) != null ? _a : true) ? convertJSONSchemaToOpenAPISchema(responseFormat.schema) : void 0,
                    ...(googleOptions == null ? void 0 : googleOptions.audioTimestamp) && {
                        audioTimestamp: googleOptions.audioTimestamp
                    },
                    // provider options:
                    responseModalities: googleOptions == null ? void 0 : googleOptions.responseModalities,
                    thinkingConfig: googleOptions == null ? void 0 : googleOptions.thinkingConfig,
                    ...(googleOptions == null ? void 0 : googleOptions.imageConfig) && {
                        imageConfig: googleOptions.imageConfig
                    },
                    ...(googleOptions == null ? void 0 : googleOptions.mediaResolution) && {
                        mediaResolution: googleOptions.mediaResolution
                    }
                },
                contents,
                systemInstruction: isGemmaModel ? void 0 : systemInstruction,
                safetySettings: googleOptions == null ? void 0 : googleOptions.safetySettings,
                tools: googleTools2,
                toolConfig: googleToolConfig,
                cachedContent: googleOptions == null ? void 0 : googleOptions.cachedContent,
                labels: googleOptions == null ? void 0 : googleOptions.labels
            },
            warnings: [
                ...warnings,
                ...toolWarnings
            ]
        };
    }
    async doGenerate(options) {
        var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
        const { args, warnings } = await this.getArgs(options);
        const body = JSON.stringify(args);
        const mergedHeaders = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers), options.headers);
        const { responseHeaders, value: response, rawValue: rawResponse } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
            url: `${this.config.baseURL}/${getModelPath(this.modelId)}:generateContent`,
            headers: mergedHeaders,
            body: args,
            failedResponseHandler: googleFailedResponseHandler,
            successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(responseSchema),
            abortSignal: options.abortSignal,
            fetch: this.config.fetch
        });
        const candidate = response.candidates[0];
        const content = [];
        const parts = (_b = (_a = candidate.content) == null ? void 0 : _a.parts) != null ? _b : [];
        const usageMetadata = response.usageMetadata;
        let lastCodeExecutionToolCallId;
        for (const part of parts){
            if ("executableCode" in part && ((_c = part.executableCode) == null ? void 0 : _c.code)) {
                const toolCallId = this.config.generateId();
                lastCodeExecutionToolCallId = toolCallId;
                content.push({
                    type: "tool-call",
                    toolCallId,
                    toolName: "code_execution",
                    input: JSON.stringify(part.executableCode),
                    providerExecuted: true
                });
            } else if ("codeExecutionResult" in part && part.codeExecutionResult) {
                content.push({
                    type: "tool-result",
                    // Assumes a result directly follows its corresponding call part.
                    toolCallId: lastCodeExecutionToolCallId,
                    toolName: "code_execution",
                    result: {
                        outcome: part.codeExecutionResult.outcome,
                        output: part.codeExecutionResult.output
                    },
                    providerExecuted: true
                });
                lastCodeExecutionToolCallId = void 0;
            } else if ("text" in part && part.text != null && part.text.length > 0) {
                content.push({
                    type: part.thought === true ? "reasoning" : "text",
                    text: part.text,
                    providerMetadata: part.thoughtSignature ? {
                        google: {
                            thoughtSignature: part.thoughtSignature
                        }
                    } : void 0
                });
            } else if ("functionCall" in part) {
                content.push({
                    type: "tool-call",
                    toolCallId: this.config.generateId(),
                    toolName: part.functionCall.name,
                    input: JSON.stringify(part.functionCall.args),
                    providerMetadata: part.thoughtSignature ? {
                        google: {
                            thoughtSignature: part.thoughtSignature
                        }
                    } : void 0
                });
            } else if ("inlineData" in part) {
                content.push({
                    type: "file",
                    data: part.inlineData.data,
                    mediaType: part.inlineData.mimeType
                });
            }
        }
        const sources = (_d = extractSources({
            groundingMetadata: candidate.groundingMetadata,
            generateId: this.config.generateId
        })) != null ? _d : [];
        for (const source of sources){
            content.push(source);
        }
        return {
            content,
            finishReason: mapGoogleGenerativeAIFinishReason({
                finishReason: candidate.finishReason,
                hasToolCalls: content.some((part)=>part.type === "tool-call")
            }),
            usage: {
                inputTokens: (_e = usageMetadata == null ? void 0 : usageMetadata.promptTokenCount) != null ? _e : void 0,
                outputTokens: (_f = usageMetadata == null ? void 0 : usageMetadata.candidatesTokenCount) != null ? _f : void 0,
                totalTokens: (_g = usageMetadata == null ? void 0 : usageMetadata.totalTokenCount) != null ? _g : void 0,
                reasoningTokens: (_h = usageMetadata == null ? void 0 : usageMetadata.thoughtsTokenCount) != null ? _h : void 0,
                cachedInputTokens: (_i = usageMetadata == null ? void 0 : usageMetadata.cachedContentTokenCount) != null ? _i : void 0
            },
            warnings,
            providerMetadata: {
                google: {
                    promptFeedback: (_j = response.promptFeedback) != null ? _j : null,
                    groundingMetadata: (_k = candidate.groundingMetadata) != null ? _k : null,
                    urlContextMetadata: (_l = candidate.urlContextMetadata) != null ? _l : null,
                    safetyRatings: (_m = candidate.safetyRatings) != null ? _m : null,
                    usageMetadata: usageMetadata != null ? usageMetadata : null
                }
            },
            request: {
                body
            },
            response: {
                // TODO timestamp, model id, id
                headers: responseHeaders,
                body: rawResponse
            }
        };
    }
    async doStream(options) {
        const { args, warnings } = await this.getArgs(options);
        const body = JSON.stringify(args);
        const headers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers), options.headers);
        const { responseHeaders, value: response } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
            url: `${this.config.baseURL}/${getModelPath(this.modelId)}:streamGenerateContent?alt=sse`,
            headers,
            body: args,
            failedResponseHandler: googleFailedResponseHandler,
            successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createEventSourceResponseHandler"])(chunkSchema),
            abortSignal: options.abortSignal,
            fetch: this.config.fetch
        });
        let finishReason = "unknown";
        const usage = {
            inputTokens: void 0,
            outputTokens: void 0,
            totalTokens: void 0
        };
        let providerMetadata = void 0;
        const generateId3 = this.config.generateId;
        let hasToolCalls = false;
        let currentTextBlockId = null;
        let currentReasoningBlockId = null;
        let blockCounter = 0;
        const emittedSourceUrls = /* @__PURE__ */ new Set();
        let lastCodeExecutionToolCallId;
        return {
            stream: response.pipeThrough(new TransformStream({
                start (controller) {
                    controller.enqueue({
                        type: "stream-start",
                        warnings
                    });
                },
                transform (chunk, controller) {
                    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
                    if (options.includeRawChunks) {
                        controller.enqueue({
                            type: "raw",
                            rawValue: chunk.rawValue
                        });
                    }
                    if (!chunk.success) {
                        controller.enqueue({
                            type: "error",
                            error: chunk.error
                        });
                        return;
                    }
                    const value = chunk.value;
                    const usageMetadata = value.usageMetadata;
                    if (usageMetadata != null) {
                        usage.inputTokens = (_a = usageMetadata.promptTokenCount) != null ? _a : void 0;
                        usage.outputTokens = (_b = usageMetadata.candidatesTokenCount) != null ? _b : void 0;
                        usage.totalTokens = (_c = usageMetadata.totalTokenCount) != null ? _c : void 0;
                        usage.reasoningTokens = (_d = usageMetadata.thoughtsTokenCount) != null ? _d : void 0;
                        usage.cachedInputTokens = (_e = usageMetadata.cachedContentTokenCount) != null ? _e : void 0;
                    }
                    const candidate = (_f = value.candidates) == null ? void 0 : _f[0];
                    if (candidate == null) {
                        return;
                    }
                    const content = candidate.content;
                    const sources = extractSources({
                        groundingMetadata: candidate.groundingMetadata,
                        generateId: generateId3
                    });
                    if (sources != null) {
                        for (const source of sources){
                            if (source.sourceType === "url" && !emittedSourceUrls.has(source.url)) {
                                emittedSourceUrls.add(source.url);
                                controller.enqueue(source);
                            }
                        }
                    }
                    if (content != null) {
                        const parts = (_g = content.parts) != null ? _g : [];
                        for (const part of parts){
                            if ("executableCode" in part && ((_h = part.executableCode) == null ? void 0 : _h.code)) {
                                const toolCallId = generateId3();
                                lastCodeExecutionToolCallId = toolCallId;
                                controller.enqueue({
                                    type: "tool-call",
                                    toolCallId,
                                    toolName: "code_execution",
                                    input: JSON.stringify(part.executableCode),
                                    providerExecuted: true
                                });
                                hasToolCalls = true;
                            } else if ("codeExecutionResult" in part && part.codeExecutionResult) {
                                const toolCallId = lastCodeExecutionToolCallId;
                                if (toolCallId) {
                                    controller.enqueue({
                                        type: "tool-result",
                                        toolCallId,
                                        toolName: "code_execution",
                                        result: {
                                            outcome: part.codeExecutionResult.outcome,
                                            output: part.codeExecutionResult.output
                                        },
                                        providerExecuted: true
                                    });
                                    lastCodeExecutionToolCallId = void 0;
                                }
                            } else if ("text" in part && part.text != null && part.text.length > 0) {
                                if (part.thought === true) {
                                    if (currentTextBlockId !== null) {
                                        controller.enqueue({
                                            type: "text-end",
                                            id: currentTextBlockId
                                        });
                                        currentTextBlockId = null;
                                    }
                                    if (currentReasoningBlockId === null) {
                                        currentReasoningBlockId = String(blockCounter++);
                                        controller.enqueue({
                                            type: "reasoning-start",
                                            id: currentReasoningBlockId,
                                            providerMetadata: part.thoughtSignature ? {
                                                google: {
                                                    thoughtSignature: part.thoughtSignature
                                                }
                                            } : void 0
                                        });
                                    }
                                    controller.enqueue({
                                        type: "reasoning-delta",
                                        id: currentReasoningBlockId,
                                        delta: part.text,
                                        providerMetadata: part.thoughtSignature ? {
                                            google: {
                                                thoughtSignature: part.thoughtSignature
                                            }
                                        } : void 0
                                    });
                                } else {
                                    if (currentReasoningBlockId !== null) {
                                        controller.enqueue({
                                            type: "reasoning-end",
                                            id: currentReasoningBlockId
                                        });
                                        currentReasoningBlockId = null;
                                    }
                                    if (currentTextBlockId === null) {
                                        currentTextBlockId = String(blockCounter++);
                                        controller.enqueue({
                                            type: "text-start",
                                            id: currentTextBlockId,
                                            providerMetadata: part.thoughtSignature ? {
                                                google: {
                                                    thoughtSignature: part.thoughtSignature
                                                }
                                            } : void 0
                                        });
                                    }
                                    controller.enqueue({
                                        type: "text-delta",
                                        id: currentTextBlockId,
                                        delta: part.text,
                                        providerMetadata: part.thoughtSignature ? {
                                            google: {
                                                thoughtSignature: part.thoughtSignature
                                            }
                                        } : void 0
                                    });
                                }
                            } else if ("inlineData" in part) {
                                controller.enqueue({
                                    type: "file",
                                    mediaType: part.inlineData.mimeType,
                                    data: part.inlineData.data
                                });
                            }
                        }
                        const toolCallDeltas = getToolCallsFromParts({
                            parts: content.parts,
                            generateId: generateId3
                        });
                        if (toolCallDeltas != null) {
                            for (const toolCall of toolCallDeltas){
                                controller.enqueue({
                                    type: "tool-input-start",
                                    id: toolCall.toolCallId,
                                    toolName: toolCall.toolName,
                                    providerMetadata: toolCall.providerMetadata
                                });
                                controller.enqueue({
                                    type: "tool-input-delta",
                                    id: toolCall.toolCallId,
                                    delta: toolCall.args,
                                    providerMetadata: toolCall.providerMetadata
                                });
                                controller.enqueue({
                                    type: "tool-input-end",
                                    id: toolCall.toolCallId,
                                    providerMetadata: toolCall.providerMetadata
                                });
                                controller.enqueue({
                                    type: "tool-call",
                                    toolCallId: toolCall.toolCallId,
                                    toolName: toolCall.toolName,
                                    input: toolCall.args,
                                    providerMetadata: toolCall.providerMetadata
                                });
                                hasToolCalls = true;
                            }
                        }
                    }
                    if (candidate.finishReason != null) {
                        finishReason = mapGoogleGenerativeAIFinishReason({
                            finishReason: candidate.finishReason,
                            hasToolCalls
                        });
                        providerMetadata = {
                            google: {
                                promptFeedback: (_i = value.promptFeedback) != null ? _i : null,
                                groundingMetadata: (_j = candidate.groundingMetadata) != null ? _j : null,
                                urlContextMetadata: (_k = candidate.urlContextMetadata) != null ? _k : null,
                                safetyRatings: (_l = candidate.safetyRatings) != null ? _l : null
                            }
                        };
                        if (usageMetadata != null) {
                            providerMetadata.google.usageMetadata = usageMetadata;
                        }
                    }
                },
                flush (controller) {
                    if (currentTextBlockId !== null) {
                        controller.enqueue({
                            type: "text-end",
                            id: currentTextBlockId
                        });
                    }
                    if (currentReasoningBlockId !== null) {
                        controller.enqueue({
                            type: "reasoning-end",
                            id: currentReasoningBlockId
                        });
                    }
                    controller.enqueue({
                        type: "finish",
                        finishReason,
                        usage,
                        providerMetadata
                    });
                }
            })),
            response: {
                headers: responseHeaders
            },
            request: {
                body
            }
        };
    }
};
function getToolCallsFromParts({ parts, generateId: generateId3 }) {
    const functionCallParts = parts == null ? void 0 : parts.filter((part)=>"functionCall" in part);
    return functionCallParts == null || functionCallParts.length === 0 ? void 0 : functionCallParts.map((part)=>({
            type: "tool-call",
            toolCallId: generateId3(),
            toolName: part.functionCall.name,
            args: JSON.stringify(part.functionCall.args),
            providerMetadata: part.thoughtSignature ? {
                google: {
                    thoughtSignature: part.thoughtSignature
                }
            } : void 0
        }));
}
function extractSources({ groundingMetadata, generateId: generateId3 }) {
    var _a, _b, _c, _d;
    if (!(groundingMetadata == null ? void 0 : groundingMetadata.groundingChunks)) {
        return void 0;
    }
    const sources = [];
    for (const chunk of groundingMetadata.groundingChunks){
        if (chunk.web != null) {
            sources.push({
                type: "source",
                sourceType: "url",
                id: generateId3(),
                url: chunk.web.uri,
                title: (_a = chunk.web.title) != null ? _a : void 0
            });
        } else if (chunk.retrievedContext != null) {
            const uri = chunk.retrievedContext.uri;
            const fileSearchStore = chunk.retrievedContext.fileSearchStore;
            if (uri && (uri.startsWith("http://") || uri.startsWith("https://"))) {
                sources.push({
                    type: "source",
                    sourceType: "url",
                    id: generateId3(),
                    url: uri,
                    title: (_b = chunk.retrievedContext.title) != null ? _b : void 0
                });
            } else if (uri) {
                const title = (_c = chunk.retrievedContext.title) != null ? _c : "Unknown Document";
                let mediaType = "application/octet-stream";
                let filename = void 0;
                if (uri.endsWith(".pdf")) {
                    mediaType = "application/pdf";
                    filename = uri.split("/").pop();
                } else if (uri.endsWith(".txt")) {
                    mediaType = "text/plain";
                    filename = uri.split("/").pop();
                } else if (uri.endsWith(".docx")) {
                    mediaType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                    filename = uri.split("/").pop();
                } else if (uri.endsWith(".doc")) {
                    mediaType = "application/msword";
                    filename = uri.split("/").pop();
                } else if (uri.match(/\.(md|markdown)$/)) {
                    mediaType = "text/markdown";
                    filename = uri.split("/").pop();
                } else {
                    filename = uri.split("/").pop();
                }
                sources.push({
                    type: "source",
                    sourceType: "document",
                    id: generateId3(),
                    mediaType,
                    title,
                    filename
                });
            } else if (fileSearchStore) {
                const title = (_d = chunk.retrievedContext.title) != null ? _d : "Unknown Document";
                sources.push({
                    type: "source",
                    sourceType: "document",
                    id: generateId3(),
                    mediaType: "application/octet-stream",
                    title,
                    filename: fileSearchStore.split("/").pop()
                });
            }
        }
    }
    return sources.length > 0 ? sources : void 0;
}
var getGroundingMetadataSchema = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        webSearchQueries: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()).nullish(),
        retrievalQueries: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()).nullish(),
        searchEntryPoint: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            renderedContent: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
        }).nullish(),
        groundingChunks: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            web: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                uri: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish()
            }).nullish(),
            retrievedContext: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                uri: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
                title: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
                text: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
                fileSearchStore: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish()
            }).nullish()
        })).nullish(),
        groundingSupports: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            segment: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                startIndex: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
                endIndex: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
                text: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish()
            }),
            segment_text: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
            groundingChunkIndices: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number()).nullish(),
            supportChunkIndices: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number()).nullish(),
            confidenceScores: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number()).nullish(),
            confidenceScore: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number()).nullish()
        })).nullish(),
        retrievalMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                webDynamicRetrievalScore: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number()
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({})
        ]).nullish()
    });
var getContentSchema = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        parts: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].union([
            // note: order matters since text can be fully empty
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                functionCall: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                    name: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                    args: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].unknown()
                }),
                thoughtSignature: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish()
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                inlineData: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                    mimeType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                    data: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
                })
            }),
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                executableCode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                    language: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                    code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
                }).nullish(),
                codeExecutionResult: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
                    outcome: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
                    output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
                }).nullish(),
                text: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
                thought: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].boolean().nullish(),
                thoughtSignature: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish()
            })
        ])).nullish()
    });
var getSafetyRatingSchema = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
        probability: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
        probabilityScore: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
        severity: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
        severityScore: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
        blocked: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].boolean().nullish()
    });
var usageSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    cachedContentTokenCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
    thoughtsTokenCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
    promptTokenCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
    candidatesTokenCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
    totalTokenCount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().nullish(),
    // https://cloud.google.com/vertex-ai/generative-ai/docs/reference/rest/v1/GenerateContentResponse#TrafficType
    trafficType: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish()
});
var getUrlContextMetadataSchema = ()=>__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        urlMetadata: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            retrievedUrl: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
            urlRetrievalStatus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
        }))
    });
var responseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        candidates: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            content: getContentSchema().nullish().or(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({}).strict()),
            finishReason: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
            safetyRatings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(getSafetyRatingSchema()).nullish(),
            groundingMetadata: getGroundingMetadataSchema().nullish(),
            urlContextMetadata: getUrlContextMetadataSchema().nullish()
        })),
        usageMetadata: usageSchema.nullish(),
        promptFeedback: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            blockReason: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
            safetyRatings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(getSafetyRatingSchema()).nullish()
        }).nullish()
    })));
var chunkSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        candidates: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            content: getContentSchema().nullish(),
            finishReason: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
            safetyRatings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(getSafetyRatingSchema()).nullish(),
            groundingMetadata: getGroundingMetadataSchema().nullish(),
            urlContextMetadata: getUrlContextMetadataSchema().nullish()
        })).nullish(),
        usageMetadata: usageSchema.nullish(),
        promptFeedback: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            blockReason: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().nullish(),
            safetyRatings: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(getSafetyRatingSchema()).nullish()
        }).nullish()
    })));
;
;
var codeExecution = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createProviderDefinedToolFactoryWithOutputSchema"])({
    id: "google.code_execution",
    name: "code_execution",
    inputSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        language: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().describe("The programming language of the code."),
        code: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().describe("The code to be executed.")
    }),
    outputSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        outcome: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().describe('The outcome of the execution (e.g., "OUTCOME_OK").'),
        output: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().describe("The output from the code execution.")
    })
});
;
;
var fileSearchArgsBaseSchema = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
    /** The names of the file_search_stores to retrieve from.
   *  Example: `fileSearchStores/my-file-search-store-123`
   */ fileSearchStoreNames: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()).describe("The names of the file_search_stores to retrieve from. Example: `fileSearchStores/my-file-search-store-123`"),
    /** The number of file search retrieval chunks to retrieve. */ topK: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().int().positive().describe("The number of file search retrieval chunks to retrieve.").optional(),
    /** Metadata filter to apply to the file search retrieval documents.
   *  See https://google.aip.dev/160 for the syntax of the filter expression.
   */ metadataFilter: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string().describe("Metadata filter to apply to the file search retrieval documents. See https://google.aip.dev/160 for the syntax of the filter expression.").optional()
}).passthrough();
var fileSearchArgsSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(fileSearchArgsBaseSchema));
var fileSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createProviderDefinedToolFactory"])({
    id: "google.file_search",
    name: "file_search",
    inputSchema: fileSearchArgsSchema
});
;
;
var googleSearch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createProviderDefinedToolFactory"])({
    id: "google.google_search",
    name: "google_search",
    inputSchema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            mode: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
                "MODE_DYNAMIC",
                "MODE_UNSPECIFIED"
            ]).default("MODE_UNSPECIFIED"),
            dynamicThreshold: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().default(1)
        })))
});
;
;
var urlContext = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createProviderDefinedToolFactory"])({
    id: "google.url_context",
    name: "url_context",
    inputSchema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({})))
});
;
;
var vertexRagStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createProviderDefinedToolFactory"])({
    id: "google.vertex_rag_store",
    name: "vertex_rag_store",
    inputSchema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        ragCorpus: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string(),
        topK: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].number().optional()
    })
});
// src/google-tools.ts
var googleTools = {
    /**
   * Creates a Google search tool that gives Google direct access to real-time web content.
   * Must have name "google_search".
   */ googleSearch,
    /**
   * Creates a URL context tool that gives Google direct access to real-time web content.
   * Must have name "url_context".
   */ urlContext,
    /**
   * Enables Retrieval Augmented Generation (RAG) via the Gemini File Search tool.
   * Must have name "file_search".
   *
   * @param fileSearchStoreNames - Fully-qualified File Search store resource names.
   * @param metadataFilter - Optional filter expression to restrict the files that can be retrieved.
   * @param topK - Optional result limit for the number of chunks returned from File Search.
   *
   * @see https://ai.google.dev/gemini-api/docs/file-search
   */ fileSearch,
    /**
   * A tool that enables the model to generate and run Python code.
   * Must have name "code_execution".
   *
   * @note Ensure the selected model supports Code Execution.
   * Multi-tool usage with the code execution tool is typically compatible with Gemini >=2 models.
   *
   * @see https://ai.google.dev/gemini-api/docs/code-execution (Google AI)
   * @see https://cloud.google.com/vertex-ai/generative-ai/docs/model-reference/code-execution-api (Vertex AI)
   */ codeExecution,
    /**
   * Creates a Vertex RAG Store tool that enables the model to perform RAG searches against a Vertex RAG Store.
   * Must have name "vertex_rag_store".
   */ vertexRagStore
};
;
;
var GoogleGenerativeAIImageModel = class {
    constructor(modelId, settings, config){
        this.modelId = modelId;
        this.settings = settings;
        this.config = config;
        this.specificationVersion = "v2";
    }
    get maxImagesPerCall() {
        var _a;
        return (_a = this.settings.maxImagesPerCall) != null ? _a : 4;
    }
    get provider() {
        return this.config.provider;
    }
    async doGenerate(options) {
        var _a, _b, _c;
        const { prompt, n = 1, size = "1024x1024", aspectRatio = "1:1", seed, providerOptions, headers, abortSignal } = options;
        const warnings = [];
        if (size != null) {
            warnings.push({
                type: "unsupported-setting",
                setting: "size",
                details: "This model does not support the `size` option. Use `aspectRatio` instead."
            });
        }
        if (seed != null) {
            warnings.push({
                type: "unsupported-setting",
                setting: "seed",
                details: "This model does not support the `seed` option through this provider."
            });
        }
        const googleOptions = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["parseProviderOptions"])({
            provider: "google",
            providerOptions,
            schema: googleImageProviderOptionsSchema
        });
        const currentDate = (_c = (_b = (_a = this.config._internal) == null ? void 0 : _a.currentDate) == null ? void 0 : _b.call(_a)) != null ? _c : /* @__PURE__ */ new Date();
        const parameters = {
            sampleCount: n
        };
        if (aspectRatio != null) {
            parameters.aspectRatio = aspectRatio;
        }
        if (googleOptions) {
            Object.assign(parameters, googleOptions);
        }
        const body = {
            instances: [
                {
                    prompt
                }
            ],
            parameters
        };
        const { responseHeaders, value: response } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["postJsonToApi"])({
            url: `${this.config.baseURL}/models/${this.modelId}:predict`,
            headers: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["combineHeaders"])(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["resolve"])(this.config.headers), headers),
            body,
            failedResponseHandler: googleFailedResponseHandler,
            successfulResponseHandler: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createJsonResponseHandler"])(googleImageResponseSchema),
            abortSignal,
            fetch: this.config.fetch
        });
        return {
            images: response.predictions.map((p)=>p.bytesBase64Encoded),
            warnings: warnings != null ? warnings : [],
            providerMetadata: {
                google: {
                    images: response.predictions.map((prediction)=>({
                        }))
                }
            },
            response: {
                timestamp: currentDate,
                modelId: this.modelId,
                headers: responseHeaders
            }
        };
    }
};
var googleImageResponseSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        predictions: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].array(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
            bytesBase64Encoded: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].string()
        })).default([])
    })));
var googleImageProviderOptionsSchema = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["lazySchema"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["zodSchema"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].object({
        personGeneration: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
            "dont_allow",
            "allow_adult",
            "allow_all"
        ]).nullish(),
        aspectRatio: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["z"].enum([
            "1:1",
            "3:4",
            "4:3",
            "9:16",
            "16:9"
        ]).nullish()
    })));
// src/google-provider.ts
function createGoogleGenerativeAI(options = {}) {
    var _a, _b;
    const baseURL = (_a = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["withoutTrailingSlash"])(options.baseURL)) != null ? _a : "https://generativelanguage.googleapis.com/v1beta";
    const providerName = (_b = options.name) != null ? _b : "google.generative-ai";
    const getHeaders = ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["withUserAgentSuffix"])({
            "x-goog-api-key": (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["loadApiKey"])({
                apiKey: options.apiKey,
                environmentVariableName: "GOOGLE_GENERATIVE_AI_API_KEY",
                description: "Google Generative AI"
            }),
            ...options.headers
        }, `ai-sdk/google/${VERSION}`);
    const createChatModel = (modelId)=>{
        var _a2;
        return new GoogleGenerativeAILanguageModel(modelId, {
            provider: providerName,
            baseURL,
            headers: getHeaders,
            generateId: (_a2 = options.generateId) != null ? _a2 : __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["generateId"],
            supportedUrls: ()=>({
                    "*": [
                        // Google Generative Language "files" endpoint
                        // e.g. https://generativelanguage.googleapis.com/v1beta/files/...
                        new RegExp(`^${baseURL}/files/.*$`),
                        // YouTube URLs (public or unlisted videos)
                        new RegExp(`^https://(?:www\\.)?youtube\\.com/watch\\?v=[\\w-]+(?:&[\\w=&.-]*)?$`),
                        new RegExp(`^https://youtu\\.be/[\\w-]+(?:\\?[\\w=&.-]*)?$`)
                    ]
                }),
            fetch: options.fetch
        });
    };
    const createEmbeddingModel = (modelId)=>new GoogleGenerativeAIEmbeddingModel(modelId, {
            provider: providerName,
            baseURL,
            headers: getHeaders,
            fetch: options.fetch
        });
    const createImageModel = (modelId, settings = {})=>new GoogleGenerativeAIImageModel(modelId, settings, {
            provider: providerName,
            baseURL,
            headers: getHeaders,
            fetch: options.fetch
        });
    const provider = function(modelId) {
        if (new.target) {
            throw new Error("The Google Generative AI model function cannot be called with the new keyword.");
        }
        return createChatModel(modelId);
    };
    provider.languageModel = createChatModel;
    provider.chat = createChatModel;
    provider.generativeAI = createChatModel;
    provider.embedding = createEmbeddingModel;
    provider.textEmbedding = createEmbeddingModel;
    provider.textEmbeddingModel = createEmbeddingModel;
    provider.image = createImageModel;
    provider.imageModel = createImageModel;
    provider.tools = googleTools;
    return provider;
}
var google = createGoogleGenerativeAI();
;
 //# sourceMappingURL=index.mjs.map
}),
];

//# sourceMappingURL=_29dd6eb6._.js.map