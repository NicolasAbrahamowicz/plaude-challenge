module.exports = [
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/create-hook.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Creates a {@link Hook} that can be used to suspend and resume the workflow run with a payload.
 *
 * Hooks allow external systems to send arbitrary serializable data into a workflow.
 *
 * @param options - Configuration options for the hook.
 * @returns A `Hook` that can be awaited to receive one or more payloads.
 *
 * @example
 *
 * ```ts
 * export async function workflowWithHook() {
 *   "use workflow";
 *
 *   const hook = createHook<{ message: string }>();
 *   console.log('Hook token:', hook.token);
 *
 *   const payload = await hook;
 *   console.log('Received:', payload.message);
 * }
 * ```
 */ // @ts-expect-error `options` is here for types/docs
__turbopack_context__.s([
    "createHook",
    ()=>createHook,
    "createWebhook",
    ()=>createWebhook
]);
function createHook(options) {
    throw new Error('`createHook()` can only be called inside a workflow function');
}
function createWebhook(options) {
    throw new Error('`createWebhook()` can only be called inside a workflow function');
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY3JlYXRlLWhvb2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvY3JlYXRlLWhvb2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBK0ZBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7R0FxQkc7QUFDSCxvREFBb0Q7QUFDcEQsTUFBTSxVQUFVLFVBQVUsQ0FBVSxPQUFxQjtJQUN2RCxNQUFNLElBQUksS0FBSyxDQUNiLDhEQUE4RCxDQUMvRCxDQUFDO0FBQ0osQ0FBQztBQWFELE1BQU0sVUFBVSxhQUFhO0FBQzNCLG9EQUFvRDtBQUNwRCxPQUF3QjtJQUV4QixNQUFNLElBQUksS0FBSyxDQUNiLGlFQUFpRSxDQUNsRSxDQUFDO0FBQ0osQ0FBQyJ9
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/context-storage.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "contextStorage",
    ()=>contextStorage
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$async_hooks__$5b$external$5d$__$28$node$3a$async_hooks$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:async_hooks [external] (node:async_hooks, cjs)");
;
const contextStorage = /* @__PURE__ */ new __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$async_hooks__$5b$external$5d$__$28$node$3a$async_hooks$2c$__cjs$29$__["AsyncLocalStorage"](); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGV4dC1zdG9yYWdlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3N0ZXAvY29udGV4dC1zdG9yYWdlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBSXJELE1BQU0sQ0FBQyxNQUFNLGNBQWMsR0FBRyxlQUFlLENBQUMsSUFBSSxpQkFBaUIsRUFLL0QsQ0FBQyJ9
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-closure-vars.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "__private_getClosureVars",
    ()=>__private_getClosureVars
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/context-storage.js [app-route] (ecmascript)");
;
function __private_getClosureVars() {
    const ctx = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["contextStorage"].getStore();
    if (!ctx) {
        throw new Error('Closure variables can only be accessed inside a step function');
    }
    return ctx.closureVars || {};
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2V0LWNsb3N1cmUtdmFycy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zdGVwL2dldC1jbG9zdXJlLXZhcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLHNCQUFzQixDQUFDO0FBRXREOzs7Ozs7R0FNRztBQUNILE1BQU0sVUFBVSx3QkFBd0I7SUFDdEMsTUFBTSxHQUFHLEdBQUcsY0FBYyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3RDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNULE1BQU0sSUFBSSxLQUFLLENBQ2IsK0RBQStELENBQ2hFLENBQUM7SUFDSixDQUFDO0lBQ0QsT0FBTyxHQUFHLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQztBQUMvQixDQUFDIn0=
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/private.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * Utils used by the bundler when transforming code
 */ __turbopack_context__.s([
    "getStepFunction",
    ()=>getStepFunction,
    "registerStepFunction",
    ()=>registerStepFunction
]);
/**
 * Get closure variables for the current step function
 * @internal
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$get$2d$closure$2d$vars$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-closure-vars.js [app-route] (ecmascript)"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpdmF0ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy9wcml2YXRlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOztHQUVHO0FBYUgsTUFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLEVBQXdCLENBQUM7QUFFeEQ7O0dBRUc7QUFDSCxNQUFNLFVBQVUsb0JBQW9CLENBQUMsTUFBYyxFQUFFLE1BQW9CO0lBQ3ZFLGVBQWUsQ0FBQyxHQUFHLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxDQUFDO0FBQ3RDLENBQUM7QUFFRDs7R0FFRztBQUNILE1BQU0sVUFBVSxlQUFlLENBQUMsTUFBYztJQUM1QyxPQUFPLGVBQWUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDckMsQ0FBQztBQUVEOzs7R0FHRztBQUNILE9BQU8sRUFBRSx3QkFBd0IsRUFBRSxNQUFNLDRCQUE0QixDQUFDIn0=
const registeredSteps = new Map();
function registerStepFunction(stepId, stepFn) {
    registeredSteps.set(stepId, stepFn);
}
function getStepFunction(stepId) {
    return registeredSteps.get(stepId);
}
;
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime/world.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createWorld",
    ()=>createWorld,
    "getWorld",
    ()=>getWorld,
    "getWorldHandlers",
    ()=>getWorldHandlers,
    "setWorld",
    ()=>setWorld
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$module__$5b$external$5d$__$28$node$3a$module$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:module [external] (node:module, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-vercel@4.0.1-beta.18/node_modules/@workflow/world-vercel/dist/index.js [app-route] (ecmascript) <locals>");
;
;
;
;
const require = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$module__$5b$external$5d$__$28$node$3a$module$2c$__cjs$29$__["createRequire"])((0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["join"])(process.cwd(), 'index.js'));
const WorldCache = Symbol.for('@workflow/world//cache');
const StubbedWorldCache = Symbol.for('@workflow/world//stubbedCache');
const globalSymbols = globalThis;
function defaultWorld() {
    if (process.env.VERCEL_DEPLOYMENT_ID) {
        return 'vercel';
    }
    return 'local';
}
const createWorld = ()=>{
    const targetWorld = process.env.WORKFLOW_TARGET_WORLD || defaultWorld();
    if (targetWorld === 'vercel') {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$vercel$40$4$2e$0$2e$1$2d$beta$2e$18$2f$node_modules$2f40$workflow$2f$world$2d$vercel$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createVercelWorld"])({
            baseUrl: process.env.WORKFLOW_VERCEL_PROXY_URL,
            token: process.env.WORKFLOW_VERCEL_AUTH_TOKEN,
            projectConfig: {
                environment: process.env.WORKFLOW_VERCEL_ENV,
                projectId: process.env.WORKFLOW_VERCEL_PROJECT,
                teamId: process.env.WORKFLOW_VERCEL_TEAM
            }
        });
    }
    if (targetWorld === 'local') {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createLocalWorld"])({
            dataDir: process.env.WORKFLOW_LOCAL_DATA_DIR
        });
    }
    const mod = require(targetWorld);
    if (typeof mod === 'function') {
        return mod();
    } else if (typeof mod.default === 'function') {
        return mod.default();
    } else if (typeof mod.createWorld === 'function') {
        return mod.createWorld();
    }
    throw new Error(`Invalid target world module: ${targetWorld}, must export a default function or createWorld function that returns a World instance.`);
};
const getWorldHandlers = ()=>{
    if (globalSymbols[StubbedWorldCache]) {
        return globalSymbols[StubbedWorldCache];
    }
    const _world = createWorld();
    globalSymbols[StubbedWorldCache] = _world;
    return {
        createQueueHandler: _world.createQueueHandler
    };
};
const getWorld = ()=>{
    if (globalSymbols[WorldCache]) {
        return globalSymbols[WorldCache];
    }
    globalSymbols[WorldCache] = createWorld();
    return globalSymbols[WorldCache];
};
const setWorld = (world)=>{
    globalSymbols[WorldCache] = world;
    globalSymbols[StubbedWorldCache] = world;
}; //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid29ybGQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvcnVudGltZS93b3JsZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsYUFBYSxFQUFFLE1BQU0sYUFBYSxDQUFDO0FBQzVDLE9BQU8sRUFBRSxJQUFJLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFFakMsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDekQsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sd0JBQXdCLENBQUM7QUFFM0QsTUFBTSxPQUFPLEdBQUcsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQztBQUUvRCxNQUFNLFVBQVUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHdCQUF3QixDQUFDLENBQUM7QUFDeEQsTUFBTSxpQkFBaUIsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7QUFFdEUsTUFBTSxhQUFhLEdBR2YsVUFBVSxDQUFDO0FBRWYsU0FBUyxZQUFZO0lBQ25CLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsRUFBRSxDQUFDO1FBQ3JDLE9BQU8sUUFBUSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxPQUFPLE9BQU8sQ0FBQztBQUNqQixDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQU0sQ0FBQyxNQUFNLFdBQVcsR0FBRyxHQUFVLEVBQUU7SUFDckMsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQkFBcUIsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUV4RSxJQUFJLFdBQVcsS0FBSyxRQUFRLEVBQUUsQ0FBQztRQUM3QixPQUFPLGlCQUFpQixDQUFDO1lBQ3ZCLE9BQU8sRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QjtZQUM5QyxLQUFLLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEI7WUFDN0MsYUFBYSxFQUFFO2dCQUNiLFdBQVcsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQjtnQkFDNUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCO2dCQUM5QyxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0I7YUFDekM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQsSUFBSSxXQUFXLEtBQUssT0FBTyxFQUFFLENBQUM7UUFDNUIsT0FBTyxnQkFBZ0IsQ0FBQztZQUN0QixPQUFPLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1QkFBdUI7U0FDN0MsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELE1BQU0sR0FBRyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQztJQUNqQyxJQUFJLE9BQU8sR0FBRyxLQUFLLFVBQVUsRUFBRSxDQUFDO1FBQzlCLE9BQU8sR0FBRyxFQUFXLENBQUM7SUFDeEIsQ0FBQztTQUFNLElBQUksT0FBTyxHQUFHLENBQUMsT0FBTyxLQUFLLFVBQVUsRUFBRSxDQUFDO1FBQzdDLE9BQU8sR0FBRyxDQUFDLE9BQU8sRUFBVyxDQUFDO0lBQ2hDLENBQUM7U0FBTSxJQUFJLE9BQU8sR0FBRyxDQUFDLFdBQVcsS0FBSyxVQUFVLEVBQUUsQ0FBQztRQUNqRCxPQUFPLEdBQUcsQ0FBQyxXQUFXLEVBQVcsQ0FBQztJQUNwQyxDQUFDO0lBRUQsTUFBTSxJQUFJLEtBQUssQ0FDYixnQ0FBZ0MsV0FBVyx5RkFBeUYsQ0FDckksQ0FBQztBQUNKLENBQUMsQ0FBQztBQUVGOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxDQUFDLE1BQU0sZ0JBQWdCLEdBQUcsR0FBc0MsRUFBRTtJQUN0RSxJQUFJLGFBQWEsQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFLENBQUM7UUFDckMsT0FBTyxhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQztJQUMxQyxDQUFDO0lBQ0QsTUFBTSxNQUFNLEdBQUcsV0FBVyxFQUFFLENBQUM7SUFDN0IsYUFBYSxDQUFDLGlCQUFpQixDQUFDLEdBQUcsTUFBTSxDQUFDO0lBQzFDLE9BQU87UUFDTCxrQkFBa0IsRUFBRSxNQUFNLENBQUMsa0JBQWtCO0tBQzlDLENBQUM7QUFDSixDQUFDLENBQUM7QUFFRixNQUFNLENBQUMsTUFBTSxRQUFRLEdBQUcsR0FBVSxFQUFFO0lBQ2xDLElBQUksYUFBYSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUM7UUFDOUIsT0FBTyxhQUFhLENBQUMsVUFBVSxDQUFDLENBQUM7SUFDbkMsQ0FBQztJQUNELGFBQWEsQ0FBQyxVQUFVLENBQUMsR0FBRyxXQUFXLEVBQUUsQ0FBQztJQUMxQyxPQUFPLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUNuQyxDQUFDLENBQUM7QUFFRjs7O0dBR0c7QUFDSCxNQUFNLENBQUMsTUFBTSxRQUFRLEdBQUcsQ0FBQyxLQUF3QixFQUFRLEVBQUU7SUFDekQsYUFBYSxDQUFDLFVBQVUsQ0FBQyxHQUFHLEtBQUssQ0FBQztJQUNsQyxhQUFhLENBQUMsaUJBQWlCLENBQUMsR0FBRyxLQUFLLENBQUM7QUFDM0MsQ0FBQyxDQUFDIn0=
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/symbols.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BODY_INIT_SYMBOL",
    ()=>BODY_INIT_SYMBOL,
    "STREAM_NAME_SYMBOL",
    ()=>STREAM_NAME_SYMBOL,
    "STREAM_TYPE_SYMBOL",
    ()=>STREAM_TYPE_SYMBOL,
    "WEBHOOK_RESPONSE_WRITABLE",
    ()=>WEBHOOK_RESPONSE_WRITABLE,
    "WORKFLOW_CONTEXT",
    ()=>WORKFLOW_CONTEXT,
    "WORKFLOW_CREATE_HOOK",
    ()=>WORKFLOW_CREATE_HOOK,
    "WORKFLOW_GET_STREAM_ID",
    ()=>WORKFLOW_GET_STREAM_ID,
    "WORKFLOW_SLEEP",
    ()=>WORKFLOW_SLEEP,
    "WORKFLOW_USE_STEP",
    ()=>WORKFLOW_USE_STEP
]);
const WORKFLOW_USE_STEP = Symbol.for('WORKFLOW_USE_STEP');
const WORKFLOW_CREATE_HOOK = Symbol.for('WORKFLOW_CREATE_HOOK');
const WORKFLOW_SLEEP = Symbol.for('WORKFLOW_SLEEP');
const WORKFLOW_CONTEXT = Symbol.for('WORKFLOW_CONTEXT');
const WORKFLOW_GET_STREAM_ID = Symbol.for('WORKFLOW_GET_STREAM_ID');
const STREAM_NAME_SYMBOL = Symbol.for('WORKFLOW_STREAM_NAME');
const STREAM_TYPE_SYMBOL = Symbol.for('WORKFLOW_STREAM_TYPE');
const BODY_INIT_SYMBOL = Symbol.for('BODY_INIT');
const WEBHOOK_RESPONSE_WRITABLE = Symbol.for('WEBHOOK_RESPONSE_WRITABLE'); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3ltYm9scy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy9zeW1ib2xzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sQ0FBQyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUNqRSxNQUFNLENBQUMsTUFBTSxvQkFBb0IsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDdkUsTUFBTSxDQUFDLE1BQU0sY0FBYyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztBQUMzRCxNQUFNLENBQUMsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDLENBQUM7QUFDL0QsTUFBTSxDQUFDLE1BQU0sc0JBQXNCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO0FBQzNFLE1BQU0sQ0FBQyxNQUFNLGtCQUFrQixHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLENBQUMsQ0FBQztBQUNyRSxNQUFNLENBQUMsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLHNCQUFzQixDQUFDLENBQUM7QUFDckUsTUFBTSxDQUFDLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUN4RCxNQUFNLENBQUMsTUFBTSx5QkFBeUIsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUNqRCwyQkFBMkIsQ0FDNUIsQ0FBQyJ9
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/serialization.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "WorkflowServerReadableStream",
    ()=>WorkflowServerReadableStream,
    "WorkflowServerWritableStream",
    ()=>WorkflowServerWritableStream,
    "dehydrateStepArguments",
    ()=>dehydrateStepArguments,
    "dehydrateStepReturnValue",
    ()=>dehydrateStepReturnValue,
    "dehydrateWorkflowArguments",
    ()=>dehydrateWorkflowArguments,
    "dehydrateWorkflowReturnValue",
    ()=>dehydrateWorkflowReturnValue,
    "getCommonRevivers",
    ()=>getCommonRevivers,
    "getDeserializeStream",
    ()=>getDeserializeStream,
    "getExternalReducers",
    ()=>getExternalReducers,
    "getExternalRevivers",
    ()=>getExternalRevivers,
    "getSerializeStream",
    ()=>getSerializeStream,
    "getStreamType",
    ()=>getStreamType,
    "getWorkflowReducers",
    ()=>getWorkflowReducers,
    "getWorkflowRevivers",
    ()=>getWorkflowRevivers,
    "hydrateStepArguments",
    ()=>hydrateStepArguments,
    "hydrateStepReturnValue",
    ()=>hydrateStepReturnValue,
    "hydrateWorkflowArguments",
    ()=>hydrateWorkflowArguments,
    "hydrateWorkflowReturnValue",
    ()=>hydrateWorkflowReturnValue
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/utils.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$parse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/parse.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$stringify$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/devalue@5.6.0/node_modules/devalue/src/stringify.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/private.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$world$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime/world.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/context-storage.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/symbols.js [app-route] (ecmascript)");
;
;
;
;
;
;
/**
 * Format a serialization error with context about what failed.
 * Extracts path, value, and reason from devalue's DevalueError when available.
 * Logs the problematic value to the console for better debugging.
 */ function formatSerializationError(context, error) {
    // Use "returning" for return values, "passing" for arguments/inputs
    const verb = context.includes('return value') ? 'returning' : 'passing';
    // Build the error message with path info if available from DevalueError
    let message = `Failed to serialize ${context}`;
    if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"] && error.path) {
        message += ` at path "${error.path}"`;
    }
    message += `. Ensure you're ${verb} serializable types (plain objects, arrays, primitives, Date, RegExp, Map, Set).`;
    // Log the problematic value to console for debugging
    if (error instanceof __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$utils$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DevalueError"] && error.value !== undefined) {
        console.error(`[Workflows] Serialization failed for ${context}. Problematic value:`);
        console.error(error.value);
    }
    return message;
}
function getStreamType(stream) {
    try {
        const reader = stream.getReader({
            mode: 'byob'
        });
        reader.releaseLock();
        return 'bytes';
    } catch  {}
}
function getSerializeStream(reducers) {
    const encoder = new TextEncoder();
    const stream = new TransformStream({
        transform (chunk, controller) {
            try {
                const serialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$stringify$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify"])(chunk, reducers);
                controller.enqueue(encoder.encode(`${serialized}\n`));
            } catch (error) {
                controller.error(new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRuntimeError"](formatSerializationError('stream chunk', error), {
                    slug: 'serialization-failed',
                    cause: error
                }));
            }
        }
    });
    return stream;
}
function getDeserializeStream(revivers) {
    const decoder = new TextDecoder();
    let buffer = '';
    const stream = new TransformStream({
        transform (chunk, controller) {
            // Append new chunk to buffer
            buffer += decoder.decode(chunk, {
                stream: true
            });
            // Process all complete lines
            while(true){
                const newlineIndex = buffer.indexOf('\n');
                if (newlineIndex === -1) break;
                const line = buffer.slice(0, newlineIndex);
                buffer = buffer.slice(newlineIndex + 1);
                if (line.length > 0) {
                    const obj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$parse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parse"])(line, revivers);
                    controller.enqueue(obj);
                }
            }
        },
        flush (controller) {
            // Process any remaining data in the buffer at the end of the stream
            if (buffer && buffer.length > 0) {
                const obj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$parse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["parse"])(buffer, revivers);
                controller.enqueue(obj);
            }
        }
    });
    return stream;
}
class WorkflowServerReadableStream extends ReadableStream {
    #reader;
    constructor(name, startIndex){
        if (typeof name !== 'string' || name.length === 0) {
            throw new Error(`"name" is required, got "${name}"`);
        }
        super({
            // @ts-expect-error Not sure why TypeScript is complaining about this
            type: 'bytes',
            pull: async (controller)=>{
                let reader = this.#reader;
                if (!reader) {
                    const world = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$world$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorld"])();
                    const stream = await world.readFromStream(name, startIndex);
                    reader = this.#reader = stream.getReader();
                }
                if (!reader) {
                    controller.error(new Error('Failed to get reader'));
                    return;
                }
                const result = await reader.read();
                if (result.done) {
                    this.#reader = undefined;
                    controller.close();
                } else {
                    controller.enqueue(result.value);
                }
            }
        });
    }
}
class WorkflowServerWritableStream extends WritableStream {
    constructor(name, runId){
        // runId can be a promise, because we need a runID to write to a stream,
        // but at class instantiation time, we might not have a run ID yet. This
        // mainly happens when calling start() for a workflow with already-serialized
        // arguments.
        if (typeof runId !== 'string' && !(runId instanceof Promise)) {
            throw new Error(`"runId" must be a string or a promise that resolves to a string, got "${typeof runId}"`);
        }
        if (typeof name !== 'string' || name.length === 0) {
            throw new Error(`"name" is required, got "${name}"`);
        }
        const world = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$world$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorld"])();
        super({
            async write (chunk) {
                const _runId = await runId;
                await world.writeToStream(name, _runId, chunk);
            },
            async close () {
                const _runId = await runId;
                await world.closeStream(name, _runId);
            }
        });
    }
}
function revive(str) {
    // biome-ignore lint/security/noGlobalEval: Eval is safe here - we are only passing value from `devalue.stringify()`
    // biome-ignore lint/complexity/noCommaOperator: This is how you do global scope eval
    return (0, eval)(`(${str})`);
}
function getCommonReducers(global = globalThis) {
    const abToBase64 = (value, offset, length)=>{
        // Avoid returning falsy value for zero-length buffers
        if (length === 0) return '.';
        // Create a proper copy to avoid ArrayBuffer detachment issues
        // Buffer.from(ArrayBuffer, offset, length) creates a view, not a copy
        const uint8 = new Uint8Array(value, offset, length);
        return Buffer.from(uint8).toString('base64');
    };
    const viewToBase64 = (value)=>abToBase64(value.buffer, value.byteOffset, value.byteLength);
    return {
        ArrayBuffer: (value)=>value instanceof global.ArrayBuffer && abToBase64(value, 0, value.byteLength),
        BigInt: (value)=>typeof value === 'bigint' && value.toString(),
        BigInt64Array: (value)=>value instanceof global.BigInt64Array && viewToBase64(value),
        BigUint64Array: (value)=>value instanceof global.BigUint64Array && viewToBase64(value),
        Date: (value)=>{
            if (!(value instanceof global.Date)) return false;
            const valid = !Number.isNaN(value.getDate());
            // Note: "." is to avoid returning a falsy value when the date is invalid
            return valid ? value.toISOString() : '.';
        },
        Error: (value)=>{
            if (!(value instanceof global.Error)) return false;
            return {
                name: value.name,
                message: value.message,
                stack: value.stack
            };
        },
        Float32Array: (value)=>value instanceof global.Float32Array && viewToBase64(value),
        Float64Array: (value)=>value instanceof global.Float64Array && viewToBase64(value),
        Headers: (value)=>value instanceof global.Headers && Array.from(value),
        Int8Array: (value)=>value instanceof global.Int8Array && viewToBase64(value),
        Int16Array: (value)=>value instanceof global.Int16Array && viewToBase64(value),
        Int32Array: (value)=>value instanceof global.Int32Array && viewToBase64(value),
        Map: (value)=>value instanceof global.Map && Array.from(value),
        RegExp: (value)=>value instanceof global.RegExp && {
                source: value.source,
                flags: value.flags
            },
        Request: (value)=>{
            if (!(value instanceof global.Request)) return false;
            const data = {
                method: value.method,
                url: value.url,
                headers: value.headers,
                body: value.body,
                duplex: value.duplex
            };
            const responseWritable = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WEBHOOK_RESPONSE_WRITABLE"]];
            if (responseWritable) {
                data.responseWritable = responseWritable;
            }
            return data;
        },
        Response: (value)=>{
            if (!(value instanceof global.Response)) return false;
            return {
                type: value.type,
                url: value.url,
                status: value.status,
                statusText: value.statusText,
                headers: value.headers,
                body: value.body,
                redirected: value.redirected
            };
        },
        Set: (value)=>value instanceof global.Set && Array.from(value),
        StepFunction: (value)=>{
            if (typeof value !== 'function') return false;
            const stepId = value.stepId;
            if (typeof stepId !== 'string') return false;
            // Check if the step function has closure variables
            const closureVarsFn = value.__closureVarsFn;
            if (closureVarsFn && typeof closureVarsFn === 'function') {
                // Invoke the closure variables function and serialize along with stepId
                const closureVars = closureVarsFn();
                return {
                    stepId,
                    closureVars
                };
            }
            // No closure variables - return object with just stepId
            return {
                stepId
            };
        },
        URL: (value)=>value instanceof global.URL && value.href,
        URLSearchParams: (value)=>{
            if (!(value instanceof global.URLSearchParams)) return false;
            // Avoid returning a falsy value when the URLSearchParams is empty
            if (value.size === 0) return '.';
            return String(value);
        },
        Uint8Array: (value)=>value instanceof global.Uint8Array && viewToBase64(value),
        Uint8ClampedArray: (value)=>value instanceof global.Uint8ClampedArray && viewToBase64(value),
        Uint16Array: (value)=>value instanceof global.Uint16Array && viewToBase64(value),
        Uint32Array: (value)=>value instanceof global.Uint32Array && viewToBase64(value)
    };
}
function getExternalReducers(global = globalThis, ops, runId) {
    return {
        ...getCommonReducers(global),
        ReadableStream: (value)=>{
            if (!(value instanceof global.ReadableStream)) return false;
            // Stream must not be locked when passing across execution boundary
            if (value.locked) {
                throw new Error('ReadableStream is locked');
            }
            const name = global.crypto.randomUUID();
            const type = getStreamType(value);
            const writable = new WorkflowServerWritableStream(name, runId);
            if (type === 'bytes') {
                ops.push(value.pipeTo(writable));
            } else {
                ops.push(value.pipeThrough(getSerializeStream(getExternalReducers(global, ops, runId))).pipeTo(writable));
            }
            const s = {
                name
            };
            if (type) s.type = type;
            return s;
        },
        WritableStream: (value)=>{
            if (!(value instanceof global.WritableStream)) return false;
            const name = global.crypto.randomUUID();
            const readable = new WorkflowServerReadableStream(name);
            ops.push(readable.pipeTo(value));
            return {
                name
            };
        }
    };
}
function getWorkflowReducers(global = globalThis) {
    return {
        ...getCommonReducers(global),
        // Readable/Writable streams from within the workflow execution environment
        // are simply "handles" that can be passed around to other steps.
        ReadableStream: (value)=>{
            if (!(value instanceof global.ReadableStream)) return false;
            // Check if this is a fake stream storing BodyInit from Request/Response constructor
            const bodyInit = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BODY_INIT_SYMBOL"]];
            if (bodyInit !== undefined) {
                // This is a fake stream - serialize the BodyInit directly
                // devalue will handle serializing strings, Uint8Array, etc.
                return {
                    bodyInit
                };
            }
            const name = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_NAME_SYMBOL"]];
            if (!name) {
                throw new Error('ReadableStream `name` is not set');
            }
            const s = {
                name
            };
            const type = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_TYPE_SYMBOL"]];
            if (type) s.type = type;
            return s;
        },
        WritableStream: (value)=>{
            if (!(value instanceof global.WritableStream)) return false;
            const name = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_NAME_SYMBOL"]];
            if (!name) {
                throw new Error('WritableStream `name` is not set');
            }
            return {
                name
            };
        }
    };
}
/**
 * Reducers for serialization boundary from within the step execution
 * environment, passing return value to the workflow handler.
 *
 * @param global
 * @param ops
 * @param runId
 * @returns
 */ function getStepReducers(global = globalThis, ops, runId) {
    return {
        ...getCommonReducers(global),
        ReadableStream: (value)=>{
            if (!(value instanceof global.ReadableStream)) return false;
            // Stream must not be locked when passing across execution boundary
            if (value.locked) {
                throw new Error('ReadableStream is locked');
            }
            // Check if the stream already has the name symbol set, in which case
            // it's already being sunk to the server and we can just return the
            // name and type.
            let name = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_NAME_SYMBOL"]];
            let type = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_TYPE_SYMBOL"]];
            if (!name) {
                if (!runId) {
                    throw new Error('ReadableStream cannot be serialized without a valid runId');
                }
                name = global.crypto.randomUUID();
                type = getStreamType(value);
                const writable = new WorkflowServerWritableStream(name, runId);
                if (type === 'bytes') {
                    ops.push(value.pipeTo(writable));
                } else {
                    ops.push(value.pipeThrough(getSerializeStream(getStepReducers(global, ops, runId))).pipeTo(writable));
                }
            }
            const s = {
                name
            };
            if (type) s.type = type;
            return s;
        },
        WritableStream: (value)=>{
            if (!(value instanceof global.WritableStream)) return false;
            let name = value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_NAME_SYMBOL"]];
            if (!name) {
                if (!runId) {
                    throw new Error('WritableStream cannot be serialized without a valid runId');
                }
                name = global.crypto.randomUUID();
                ops.push(new WorkflowServerReadableStream(name).pipeThrough(getDeserializeStream(getStepRevivers(global, ops, runId))).pipeTo(value));
            }
            return {
                name
            };
        }
    };
}
function getCommonRevivers(global = globalThis) {
    function reviveArrayBuffer(value) {
        // Handle sentinel value for zero-length buffers
        const base64 = value === '.' ? '' : value;
        const buffer = Buffer.from(base64, 'base64');
        const arrayBuffer = new global.ArrayBuffer(buffer.length);
        const uint8Array = new global.Uint8Array(arrayBuffer);
        uint8Array.set(buffer);
        return arrayBuffer;
    }
    return {
        ArrayBuffer: reviveArrayBuffer,
        BigInt: (value)=>global.BigInt(value),
        BigInt64Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.BigInt64Array(ab);
        },
        BigUint64Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.BigUint64Array(ab);
        },
        Date: (value)=>new global.Date(value),
        Error: (value)=>{
            const error = new global.Error(value.message);
            error.name = value.name;
            error.stack = value.stack;
            return error;
        },
        Float32Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Float32Array(ab);
        },
        Float64Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Float64Array(ab);
        },
        Headers: (value)=>new global.Headers(value),
        Int8Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Int8Array(ab);
        },
        Int16Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Int16Array(ab);
        },
        Int32Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Int32Array(ab);
        },
        Map: (value)=>new global.Map(value),
        RegExp: (value)=>new global.RegExp(value.source, value.flags),
        Set: (value)=>new global.Set(value),
        StepFunction: (value)=>{
            const stepId = value.stepId;
            const closureVars = value.closureVars;
            const stepFn = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["getStepFunction"])(stepId);
            if (!stepFn) {
                throw new Error(`Step function "${stepId}" not found. Make sure the step function is registered.`);
            }
            // If closure variables were serialized, return a wrapper function
            // that sets up AsyncLocalStorage context when invoked
            if (closureVars) {
                const wrappedStepFn = (...args)=>{
                    // Get the current context from AsyncLocalStorage
                    const currentContext = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["contextStorage"].getStore();
                    if (!currentContext) {
                        throw new Error('Cannot call step function with closure variables outside step context');
                    }
                    // Create a new context with the closure variables merged in
                    const newContext = {
                        ...currentContext,
                        closureVars
                    };
                    // Run the step function with the new context that includes closure vars
                    return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["contextStorage"].run(newContext, ()=>stepFn(...args));
                };
                // Copy properties from original step function
                Object.defineProperty(wrappedStepFn, 'name', {
                    value: stepFn.name
                });
                Object.defineProperty(wrappedStepFn, 'stepId', {
                    value: stepId,
                    writable: false,
                    enumerable: false,
                    configurable: false
                });
                if (stepFn.maxRetries !== undefined) {
                    wrappedStepFn.maxRetries = stepFn.maxRetries;
                }
                return wrappedStepFn;
            }
            return stepFn;
        },
        URL: (value)=>new global.URL(value),
        URLSearchParams: (value)=>new global.URLSearchParams(value === '.' ? '' : value),
        Uint8Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Uint8Array(ab);
        },
        Uint8ClampedArray: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Uint8ClampedArray(ab);
        },
        Uint16Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Uint16Array(ab);
        },
        Uint32Array: (value)=>{
            const ab = reviveArrayBuffer(value);
            return new global.Uint32Array(ab);
        }
    };
}
function getExternalRevivers(global = globalThis, ops, runId) {
    return {
        ...getCommonRevivers(global),
        Request: (value)=>{
            return new global.Request(value.url, {
                method: value.method,
                headers: new global.Headers(value.headers),
                body: value.body,
                duplex: value.duplex
            });
        },
        Response: (value)=>{
            // Note: Response constructor only accepts status, statusText, and headers
            // The type, url, and redirected properties are read-only and set by the constructor
            return new global.Response(value.body, {
                status: value.status,
                statusText: value.statusText,
                headers: new global.Headers(value.headers)
            });
        },
        ReadableStream: (value)=>{
            // If this has bodyInit, it came from a Response constructor
            // Convert it to a REAL stream now that we're outside the workflow
            if ('bodyInit' in value) {
                const bodyInit = value.bodyInit;
                // Use the native Response constructor to properly convert BodyInit to ReadableStream
                const response = new global.Response(bodyInit);
                return response.body;
            }
            const readable = new WorkflowServerReadableStream(value.name, value.startIndex);
            if (value.type === 'bytes') {
                return readable;
            } else {
                const transform = getDeserializeStream(getExternalRevivers(global, ops, runId));
                ops.push(readable.pipeTo(transform.writable));
                return transform.readable;
            }
        },
        WritableStream: (value)=>{
            const serialize = getSerializeStream(getExternalReducers(global, ops, runId));
            ops.push(serialize.readable.pipeTo(new WorkflowServerWritableStream(value.name, runId)));
            return serialize.writable;
        }
    };
}
function getWorkflowRevivers(global = globalThis) {
    return {
        ...getCommonRevivers(global),
        Request: (value)=>{
            Object.setPrototypeOf(value, global.Request.prototype);
            const responseWritable = value.responseWritable;
            if (responseWritable) {
                value[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WEBHOOK_RESPONSE_WRITABLE"]] = responseWritable;
                delete value.responseWritable;
                value.respondWith = ()=>{
                    throw new Error('`respondWith()` must be called from within a step function');
                };
            }
            return value;
        },
        Response: (value)=>{
            Object.setPrototypeOf(value, global.Response.prototype);
            return value;
        },
        ReadableStream: (value)=>{
            // Check if this is a BodyInit that should be wrapped in a fake stream
            if ('bodyInit' in value) {
                // Recreate the fake stream with the BodyInit
                return Object.create(global.ReadableStream.prototype, {
                    [__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["BODY_INIT_SYMBOL"]]: {
                        value: value.bodyInit,
                        writable: false
                    }
                });
            }
            // Regular stream handling
            return Object.create(global.ReadableStream.prototype, {
                [__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_NAME_SYMBOL"]]: {
                    value: value.name,
                    writable: false
                },
                [__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_TYPE_SYMBOL"]]: {
                    value: value.type,
                    writable: false
                }
            });
        },
        WritableStream: (value)=>{
            return Object.create(global.WritableStream.prototype, {
                [__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["STREAM_NAME_SYMBOL"]]: {
                    value: value.name,
                    writable: false
                }
            });
        }
    };
}
/**
 * Revivers for deserialization boundary from within the step execution
 * environment, receiving arguments from the workflow handler.
 *
 * @param global
 * @param ops
 * @param runId
 * @returns
 */ function getStepRevivers(global = globalThis, ops, runId) {
    return {
        ...getCommonRevivers(global),
        Request: (value)=>{
            const responseWritable = value.responseWritable;
            const request = new global.Request(value.url, {
                method: value.method,
                headers: new global.Headers(value.headers),
                body: value.body,
                duplex: value.duplex
            });
            if (responseWritable) {
                request.respondWith = async (response)=>{
                    const writer = responseWritable.getWriter();
                    await writer.write(response);
                    await writer.close();
                };
            }
            return request;
        },
        Response: (value)=>{
            // Note: Response constructor only accepts status, statusText, and headers
            // The type, url, and redirected properties are read-only and set by the constructor
            return new global.Response(value.body, {
                status: value.status,
                statusText: value.statusText,
                headers: new global.Headers(value.headers)
            });
        },
        ReadableStream: (value)=>{
            // If this has bodyInit, it came from a Response constructor
            // Convert it to a REAL stream now that we're in the step environment
            if ('bodyInit' in value) {
                const bodyInit = value.bodyInit;
                // Use the native Response constructor to properly convert BodyInit to ReadableStream
                const response = new global.Response(bodyInit);
                return response.body;
            }
            const readable = new WorkflowServerReadableStream(value.name);
            if (value.type === 'bytes') {
                return readable;
            } else {
                const transform = getDeserializeStream(getStepRevivers(global, ops, runId));
                ops.push(readable.pipeTo(transform.writable));
                return transform.readable;
            }
        },
        WritableStream: (value)=>{
            if (!runId) {
                throw new Error('WritableStream cannot be revived without a valid runId');
            }
            const serialize = getSerializeStream(getStepReducers(global, ops, runId));
            ops.push(serialize.readable.pipeTo(new WorkflowServerWritableStream(value.name, runId)));
            return serialize.writable;
        }
    };
}
function dehydrateWorkflowArguments(value, ops, runId, global = globalThis) {
    try {
        const str = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$stringify$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify"])(value, getExternalReducers(global, ops, runId));
        return revive(str);
    } catch (error) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRuntimeError"](formatSerializationError('workflow arguments', error), {
            slug: 'serialization-failed',
            cause: error
        });
    }
}
function hydrateWorkflowArguments(value, global = globalThis, extraRevivers = {}) {
    const obj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$parse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["unflatten"])(value, {
        ...getWorkflowRevivers(global),
        ...extraRevivers
    });
    return obj;
}
function dehydrateWorkflowReturnValue(value, global = globalThis) {
    try {
        const str = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$stringify$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify"])(value, getWorkflowReducers(global));
        return revive(str);
    } catch (error) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRuntimeError"](formatSerializationError('workflow return value', error), {
            slug: 'serialization-failed',
            cause: error
        });
    }
}
function hydrateWorkflowReturnValue(value, ops, runId, global = globalThis, extraRevivers = {}) {
    const obj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$parse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["unflatten"])(value, {
        ...getExternalRevivers(global, ops, runId),
        ...extraRevivers
    });
    return obj;
}
function dehydrateStepArguments(value, global) {
    try {
        const str = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$stringify$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify"])(value, getWorkflowReducers(global));
        return revive(str);
    } catch (error) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRuntimeError"](formatSerializationError('step arguments', error), {
            slug: 'serialization-failed',
            cause: error
        });
    }
}
function hydrateStepArguments(value, ops, runId, global = globalThis, extraRevivers = {}) {
    const obj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$parse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["unflatten"])(value, {
        ...getStepRevivers(global, ops, runId),
        ...extraRevivers
    });
    return obj;
}
function dehydrateStepReturnValue(value, ops, runId, global = globalThis) {
    try {
        const str = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$stringify$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["stringify"])(value, getStepReducers(global, ops, runId));
        return revive(str);
    } catch (error) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRuntimeError"](formatSerializationError('step return value', error), {
            slug: 'serialization-failed',
            cause: error
        });
    }
}
function hydrateStepReturnValue(value, global = globalThis, extraRevivers = {}) {
    const obj = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$devalue$40$5$2e$6$2e$0$2f$node_modules$2f$devalue$2f$src$2f$parse$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["unflatten"])(value, {
        ...getWorkflowRevivers(global),
        ...extraRevivers
    });
    return obj;
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VyaWFsaXphdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy9zZXJpYWxpemF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBQ3hELE9BQU8sRUFBRSxZQUFZLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsTUFBTSxTQUFTLENBQUM7QUFDcEUsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLGNBQWMsQ0FBQztBQUMvQyxPQUFPLEVBQUUsUUFBUSxFQUFFLE1BQU0sb0JBQW9CLENBQUM7QUFDOUMsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLDJCQUEyQixDQUFDO0FBQzNELE9BQU8sRUFDTCxnQkFBZ0IsRUFDaEIsa0JBQWtCLEVBQ2xCLGtCQUFrQixFQUNsQix5QkFBeUIsR0FDMUIsTUFBTSxjQUFjLENBQUM7QUFFdEI7Ozs7R0FJRztBQUNILFNBQVMsd0JBQXdCLENBQUMsT0FBZSxFQUFFLEtBQWM7SUFDL0Qsb0VBQW9FO0lBQ3BFLE1BQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsU0FBUyxDQUFDO0lBRXhFLHdFQUF3RTtJQUN4RSxJQUFJLE9BQU8sR0FBRyx1QkFBdUIsT0FBTyxFQUFFLENBQUM7SUFDL0MsSUFBSSxLQUFLLFlBQVksWUFBWSxJQUFJLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNoRCxPQUFPLElBQUksYUFBYSxLQUFLLENBQUMsSUFBSSxHQUFHLENBQUM7SUFDeEMsQ0FBQztJQUNELE9BQU8sSUFBSSxtQkFBbUIsSUFBSSxrRkFBa0YsQ0FBQztJQUVySCxxREFBcUQ7SUFDckQsSUFBSSxLQUFLLFlBQVksWUFBWSxJQUFJLEtBQUssQ0FBQyxLQUFLLEtBQUssU0FBUyxFQUFFLENBQUM7UUFDL0QsT0FBTyxDQUFDLEtBQUssQ0FDWCx3Q0FBd0MsT0FBTyxzQkFBc0IsQ0FDdEUsQ0FBQztRQUNGLE9BQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRCxPQUFPLE9BQU8sQ0FBQztBQUNqQixDQUFDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxNQUFNLFVBQVUsYUFBYSxDQUFDLE1BQXNCO0lBQ2xELElBQUksQ0FBQztRQUNILE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUNsRCxNQUFNLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDckIsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUFDLE1BQU0sQ0FBQyxDQUFBLENBQUM7QUFDWixDQUFDO0FBRUQsTUFBTSxVQUFVLGtCQUFrQixDQUNoQyxRQUFrQjtJQUVsQixNQUFNLE9BQU8sR0FBRyxJQUFJLFdBQVcsRUFBRSxDQUFDO0lBQ2xDLE1BQU0sTUFBTSxHQUFHLElBQUksZUFBZSxDQUFrQjtRQUNsRCxTQUFTLENBQUMsS0FBSyxFQUFFLFVBQVU7WUFDekIsSUFBSSxDQUFDO2dCQUNILE1BQU0sVUFBVSxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQzlDLFVBQVUsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFVBQVUsSUFBSSxDQUFDLENBQUMsQ0FBQztZQUN4RCxDQUFDO1lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztnQkFDZixVQUFVLENBQUMsS0FBSyxDQUNkLElBQUksb0JBQW9CLENBQ3RCLHdCQUF3QixDQUFDLGNBQWMsRUFBRSxLQUFLLENBQUMsRUFDL0MsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUMvQyxDQUNGLENBQUM7WUFDSixDQUFDO1FBQ0gsQ0FBQztLQUNGLENBQUMsQ0FBQztJQUNILE9BQU8sTUFBTSxDQUFDO0FBQ2hCLENBQUM7QUFFRCxNQUFNLFVBQVUsb0JBQW9CLENBQ2xDLFFBQWtCO0lBRWxCLE1BQU0sT0FBTyxHQUFHLElBQUksV0FBVyxFQUFFLENBQUM7SUFDbEMsSUFBSSxNQUFNLEdBQUcsRUFBRSxDQUFDO0lBQ2hCLE1BQU0sTUFBTSxHQUFHLElBQUksZUFBZSxDQUFrQjtRQUNsRCxTQUFTLENBQUMsS0FBSyxFQUFFLFVBQVU7WUFDekIsNkJBQTZCO1lBQzdCLE1BQU0sSUFBSSxPQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDO1lBRWxELDZCQUE2QjtZQUM3QixPQUFPLElBQUksRUFBRSxDQUFDO2dCQUNaLE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQzFDLElBQUksWUFBWSxLQUFLLENBQUMsQ0FBQztvQkFBRSxNQUFNO2dCQUMvQixNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQztnQkFDM0MsTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUN4QyxJQUFJLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQ3BCLE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUM7b0JBQ2xDLFVBQVUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQzFCLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztRQUNELEtBQUssQ0FBQyxVQUFVO1lBQ2Qsb0VBQW9FO1lBQ3BFLElBQUksTUFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7Z0JBQ2hDLE1BQU0sR0FBRyxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBQ3BDLFVBQVUsQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDMUIsQ0FBQztRQUNILENBQUM7S0FDRixDQUFDLENBQUM7SUFDSCxPQUFPLE1BQU0sQ0FBQztBQUNoQixDQUFDO0FBRUQsTUFBTSxPQUFPLDRCQUE2QixTQUFRLGNBQTBCO0lBQzFFLE9BQU8sQ0FBMkM7SUFFbEQsWUFBWSxJQUFZLEVBQUUsVUFBbUI7UUFDM0MsSUFBSSxPQUFPLElBQUksS0FBSyxRQUFRLElBQUksSUFBSSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNsRCxNQUFNLElBQUksS0FBSyxDQUFDLDRCQUE0QixJQUFJLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZELENBQUM7UUFDRCxLQUFLLENBQUM7WUFDSixxRUFBcUU7WUFDckUsSUFBSSxFQUFFLE9BQU87WUFFYixJQUFJLEVBQUUsS0FBSyxFQUFFLFVBQVUsRUFBRSxFQUFFO2dCQUN6QixJQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO2dCQUMxQixJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ1osTUFBTSxLQUFLLEdBQUcsUUFBUSxFQUFFLENBQUM7b0JBQ3pCLE1BQU0sTUFBTSxHQUFHLE1BQU0sS0FBSyxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLENBQUM7b0JBQzVELE1BQU0sR0FBRyxJQUFJLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQyxTQUFTLEVBQUUsQ0FBQztnQkFDN0MsQ0FBQztnQkFDRCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7b0JBQ1osVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLENBQUM7b0JBQ3BELE9BQU87Z0JBQ1QsQ0FBQztnQkFFRCxNQUFNLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDbkMsSUFBSSxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7b0JBQ2hCLElBQUksQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDO29CQUN6QixVQUFVLENBQUMsS0FBSyxFQUFFLENBQUM7Z0JBQ3JCLENBQUM7cUJBQU0sQ0FBQztvQkFDTixVQUFVLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztZQUNILENBQUM7U0FDRixDQUFDLENBQUM7SUFDTCxDQUFDO0NBQ0Y7QUFFRCxNQUFNLE9BQU8sNEJBQTZCLFNBQVEsY0FBMEI7SUFDMUUsWUFBWSxJQUFZLEVBQUUsS0FBK0I7UUFDdkQsd0VBQXdFO1FBQ3hFLHdFQUF3RTtRQUN4RSw2RUFBNkU7UUFDN0UsYUFBYTtRQUNiLElBQUksT0FBTyxLQUFLLEtBQUssUUFBUSxJQUFJLENBQUMsQ0FBQyxLQUFLLFlBQVksT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUM3RCxNQUFNLElBQUksS0FBSyxDQUNiLHlFQUF5RSxPQUFPLEtBQUssR0FBRyxDQUN6RixDQUFDO1FBQ0osQ0FBQztRQUNELElBQUksT0FBTyxJQUFJLEtBQUssUUFBUSxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDbEQsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsSUFBSSxHQUFHLENBQUMsQ0FBQztRQUN2RCxDQUFDO1FBQ0QsTUFBTSxLQUFLLEdBQUcsUUFBUSxFQUFFLENBQUM7UUFDekIsS0FBSyxDQUFDO1lBQ0osS0FBSyxDQUFDLEtBQUssQ0FBQyxLQUFLO2dCQUNmLE1BQU0sTUFBTSxHQUFHLE1BQU0sS0FBSyxDQUFDO2dCQUMzQixNQUFNLEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNqRCxDQUFDO1lBQ0QsS0FBSyxDQUFDLEtBQUs7Z0JBQ1QsTUFBTSxNQUFNLEdBQUcsTUFBTSxLQUFLLENBQUM7Z0JBQzNCLE1BQU0sS0FBSyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDeEMsQ0FBQztTQUNGLENBQUMsQ0FBQztJQUNMLENBQUM7Q0FDRjtBQWlFRCxTQUFTLE1BQU0sQ0FBQyxHQUFXO0lBQ3pCLG9IQUFvSDtJQUNwSCxxRkFBcUY7SUFDckYsT0FBTyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxJQUFJLEdBQUcsR0FBRyxDQUFDLENBQUM7QUFDL0IsQ0FBQztBQUVELFNBQVMsaUJBQWlCLENBQUMsU0FBOEIsVUFBVTtJQUNqRSxNQUFNLFVBQVUsR0FBRyxDQUNqQixLQUFzQixFQUN0QixNQUFjLEVBQ2QsTUFBYyxFQUNkLEVBQUU7UUFDRixzREFBc0Q7UUFDdEQsSUFBSSxNQUFNLEtBQUssQ0FBQztZQUFFLE9BQU8sR0FBRyxDQUFDO1FBQzdCLDhEQUE4RDtRQUM5RCxzRUFBc0U7UUFDdEUsTUFBTSxLQUFLLEdBQUcsSUFBSSxVQUFVLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUNwRCxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQy9DLENBQUMsQ0FBQztJQUNGLE1BQU0sWUFBWSxHQUFHLENBQUMsS0FBc0IsRUFBRSxFQUFFLENBQzlDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0lBRS9ELE9BQU87UUFDTCxXQUFXLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUNyQixLQUFLLFlBQVksTUFBTSxDQUFDLFdBQVc7WUFDbkMsVUFBVSxDQUFDLEtBQUssRUFBRSxDQUFDLEVBQUUsS0FBSyxDQUFDLFVBQVUsQ0FBQztRQUN4QyxNQUFNLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLE9BQU8sS0FBSyxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFO1FBQ2hFLGFBQWEsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQ3ZCLEtBQUssWUFBWSxNQUFNLENBQUMsYUFBYSxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUM7UUFDOUQsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FDeEIsS0FBSyxZQUFZLE1BQU0sQ0FBQyxjQUFjLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQztRQUMvRCxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNkLElBQUksQ0FBQyxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBQ2xELE1BQU0sS0FBSyxHQUFHLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUM3Qyx5RUFBeUU7WUFDekUsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBQzNDLENBQUM7UUFDRCxLQUFLLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNmLElBQUksQ0FBQyxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBQ25ELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO2dCQUNoQixPQUFPLEVBQUUsS0FBSyxDQUFDLE9BQU87Z0JBQ3RCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSzthQUNuQixDQUFDO1FBQ0osQ0FBQztRQUNELFlBQVksRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQ3RCLEtBQUssWUFBWSxNQUFNLENBQUMsWUFBWSxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUM7UUFDN0QsWUFBWSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FDdEIsS0FBSyxZQUFZLE1BQU0sQ0FBQyxZQUFZLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQztRQUM3RCxPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsT0FBTyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQ3hFLFNBQVMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQ25CLEtBQUssWUFBWSxNQUFNLENBQUMsU0FBUyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUM7UUFDMUQsVUFBVSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FDcEIsS0FBSyxZQUFZLE1BQU0sQ0FBQyxVQUFVLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQztRQUMzRCxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUNwQixLQUFLLFlBQVksTUFBTSxDQUFDLFVBQVUsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDO1FBQzNELEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxZQUFZLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDaEUsTUFBTSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FDaEIsS0FBSyxZQUFZLE1BQU0sQ0FBQyxNQUFNLElBQUk7WUFDaEMsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO1lBQ3BCLEtBQUssRUFBRSxLQUFLLENBQUMsS0FBSztTQUNuQjtRQUNILE9BQU8sRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ2pCLElBQUksQ0FBQyxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBQ3JELE1BQU0sSUFBSSxHQUFtQztnQkFDM0MsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO2dCQUNwQixHQUFHLEVBQUUsS0FBSyxDQUFDLEdBQUc7Z0JBQ2QsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUN0QixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7Z0JBQ2hCLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTthQUNyQixDQUFDO1lBQ0YsTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLENBQUMseUJBQXlCLENBQUMsQ0FBQztZQUMxRCxJQUFJLGdCQUFnQixFQUFFLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxnQkFBZ0IsQ0FBQztZQUMzQyxDQUFDO1lBQ0QsT0FBTyxJQUFJLENBQUM7UUFDZCxDQUFDO1FBQ0QsUUFBUSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDbEIsSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQUUsT0FBTyxLQUFLLENBQUM7WUFDdEQsT0FBTztnQkFDTCxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7Z0JBQ2hCLEdBQUcsRUFBRSxLQUFLLENBQUMsR0FBRztnQkFDZCxNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07Z0JBQ3BCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTtnQkFDNUIsT0FBTyxFQUFFLEtBQUssQ0FBQyxPQUFPO2dCQUN0QixJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7Z0JBQ2hCLFVBQVUsRUFBRSxLQUFLLENBQUMsVUFBVTthQUM3QixDQUFDO1FBQ0osQ0FBQztRQUNELEdBQUcsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsS0FBSyxZQUFZLE1BQU0sQ0FBQyxHQUFHLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDaEUsWUFBWSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDdEIsSUFBSSxPQUFPLEtBQUssS0FBSyxVQUFVO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBQzlDLE1BQU0sTUFBTSxHQUFJLEtBQWEsQ0FBQyxNQUFNLENBQUM7WUFDckMsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBRTdDLG1EQUFtRDtZQUNuRCxNQUFNLGFBQWEsR0FBSSxLQUFhLENBQUMsZUFBZSxDQUFDO1lBQ3JELElBQUksYUFBYSxJQUFJLE9BQU8sYUFBYSxLQUFLLFVBQVUsRUFBRSxDQUFDO2dCQUN6RCx3RUFBd0U7Z0JBQ3hFLE1BQU0sV0FBVyxHQUFHLGFBQWEsRUFBRSxDQUFDO2dCQUNwQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxDQUFDO1lBQ2pDLENBQUM7WUFFRCx3REFBd0Q7WUFDeEQsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDO1FBQ3BCLENBQUM7UUFDRCxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsR0FBRyxJQUFJLEtBQUssQ0FBQyxJQUFJO1FBQ3pELGVBQWUsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3pCLElBQUksQ0FBQyxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsZUFBZSxDQUFDO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBRTdELGtFQUFrRTtZQUNsRSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssQ0FBQztnQkFBRSxPQUFPLEdBQUcsQ0FBQztZQUVqQyxPQUFPLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN2QixDQUFDO1FBQ0QsVUFBVSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FDcEIsS0FBSyxZQUFZLE1BQU0sQ0FBQyxVQUFVLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQztRQUMzRCxpQkFBaUIsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQzNCLEtBQUssWUFBWSxNQUFNLENBQUMsaUJBQWlCLElBQUksWUFBWSxDQUFDLEtBQUssQ0FBQztRQUNsRSxXQUFXLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUNyQixLQUFLLFlBQVksTUFBTSxDQUFDLFdBQVcsSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDO1FBQzVELFdBQVcsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQ3JCLEtBQUssWUFBWSxNQUFNLENBQUMsV0FBVyxJQUFJLFlBQVksQ0FBQyxLQUFLLENBQUM7S0FDeEIsQ0FBQztBQUN6QyxDQUFDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILE1BQU0sVUFBVSxtQkFBbUIsQ0FDakMsU0FBOEIsVUFBVSxFQUN4QyxHQUFvQixFQUNwQixLQUErQjtJQUUvQixPQUFPO1FBQ0wsR0FBRyxpQkFBaUIsQ0FBQyxNQUFNLENBQUM7UUFFNUIsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLE1BQU0sQ0FBQyxjQUFjLENBQUM7Z0JBQUUsT0FBTyxLQUFLLENBQUM7WUFFNUQsbUVBQW1FO1lBQ25FLElBQUksS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLDBCQUEwQixDQUFDLENBQUM7WUFDOUMsQ0FBQztZQUVELE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLENBQUM7WUFDeEMsTUFBTSxJQUFJLEdBQUcsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBRWxDLE1BQU0sUUFBUSxHQUFHLElBQUksNEJBQTRCLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQy9ELElBQUksSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO2dCQUNyQixHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztZQUNuQyxDQUFDO2lCQUFNLENBQUM7Z0JBQ04sR0FBRyxDQUFDLElBQUksQ0FDTixLQUFLO3FCQUNGLFdBQVcsQ0FDVixrQkFBa0IsQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQzVEO3FCQUNBLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FDcEIsQ0FBQztZQUNKLENBQUM7WUFFRCxNQUFNLENBQUMsR0FBMEMsRUFBRSxJQUFJLEVBQUUsQ0FBQztZQUMxRCxJQUFJLElBQUk7Z0JBQUUsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDeEIsT0FBTyxDQUFDLENBQUM7UUFDWCxDQUFDO1FBRUQsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLE1BQU0sQ0FBQyxjQUFjLENBQUM7Z0JBQUUsT0FBTyxLQUFLLENBQUM7WUFFNUQsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQztZQUV4QyxNQUFNLFFBQVEsR0FBRyxJQUFJLDRCQUE0QixDQUFDLElBQUksQ0FBQyxDQUFDO1lBQ3hELEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1lBRWpDLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUNsQixDQUFDO0tBQ0YsQ0FBQztBQUNKLENBQUM7QUFFRDs7Ozs7O0dBTUc7QUFDSCxNQUFNLFVBQVUsbUJBQW1CLENBQ2pDLFNBQThCLFVBQVU7SUFFeEMsT0FBTztRQUNMLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxDQUFDO1FBRTVCLDJFQUEyRTtRQUMzRSxpRUFBaUU7UUFDakUsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLE1BQU0sQ0FBQyxjQUFjLENBQUM7Z0JBQUUsT0FBTyxLQUFLLENBQUM7WUFFNUQsb0ZBQW9GO1lBQ3BGLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3pDLElBQUksUUFBUSxLQUFLLFNBQVMsRUFBRSxDQUFDO2dCQUMzQiwwREFBMEQ7Z0JBQzFELDREQUE0RDtnQkFDNUQsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO1lBQ3RCLENBQUM7WUFFRCxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ1YsTUFBTSxJQUFJLEtBQUssQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO1lBQ3RELENBQUM7WUFDRCxNQUFNLENBQUMsR0FBMEMsRUFBRSxJQUFJLEVBQUUsQ0FBQztZQUMxRCxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUN2QyxJQUFJLElBQUk7Z0JBQUUsQ0FBQyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7WUFDeEIsT0FBTyxDQUFDLENBQUM7UUFDWCxDQUFDO1FBQ0QsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDeEIsSUFBSSxDQUFDLENBQUMsS0FBSyxZQUFZLE1BQU0sQ0FBQyxjQUFjLENBQUM7Z0JBQUUsT0FBTyxLQUFLLENBQUM7WUFDNUQsTUFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLGtCQUFrQixDQUFDLENBQUM7WUFDdkMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNWLE1BQU0sSUFBSSxLQUFLLENBQUMsa0NBQWtDLENBQUMsQ0FBQztZQUN0RCxDQUFDO1lBQ0QsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDO1FBQ2xCLENBQUM7S0FDRixDQUFDO0FBQ0osQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsU0FBUyxlQUFlLENBQ3RCLFNBQThCLFVBQVUsRUFDeEMsR0FBb0IsRUFDcEIsS0FBK0I7SUFFL0IsT0FBTztRQUNMLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxDQUFDO1FBRTVCLGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsY0FBYyxDQUFDO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBRTVELG1FQUFtRTtZQUNuRSxJQUFJLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQztnQkFDakIsTUFBTSxJQUFJLEtBQUssQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO1lBQzlDLENBQUM7WUFFRCxxRUFBcUU7WUFDckUsbUVBQW1FO1lBQ25FLGlCQUFpQjtZQUNqQixJQUFJLElBQUksR0FBRyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUNyQyxJQUFJLElBQUksR0FBRyxLQUFLLENBQUMsa0JBQWtCLENBQUMsQ0FBQztZQUVyQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ1YsSUFBSSxDQUFDLEtBQUssRUFBRSxDQUFDO29CQUNYLE1BQU0sSUFBSSxLQUFLLENBQ2IsMkRBQTJELENBQzVELENBQUM7Z0JBQ0osQ0FBQztnQkFFRCxJQUFJLEdBQUcsTUFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQztnQkFDbEMsSUFBSSxHQUFHLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFNUIsTUFBTSxRQUFRLEdBQUcsSUFBSSw0QkFBNEIsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7Z0JBQy9ELElBQUksSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO29CQUNyQixHQUFHLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFDbkMsQ0FBQztxQkFBTSxDQUFDO29CQUNOLEdBQUcsQ0FBQyxJQUFJLENBQ04sS0FBSzt5QkFDRixXQUFXLENBQ1Ysa0JBQWtCLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FDeEQ7eUJBQ0EsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUNwQixDQUFDO2dCQUNKLENBQUM7WUFDSCxDQUFDO1lBRUQsTUFBTSxDQUFDLEdBQTBDLEVBQUUsSUFBSSxFQUFFLENBQUM7WUFDMUQsSUFBSSxJQUFJO2dCQUFFLENBQUMsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO1lBQ3hCLE9BQU8sQ0FBQyxDQUFDO1FBQ1gsQ0FBQztRQUVELGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxDQUFDLEtBQUssWUFBWSxNQUFNLENBQUMsY0FBYyxDQUFDO2dCQUFFLE9BQU8sS0FBSyxDQUFDO1lBRTVELElBQUksSUFBSSxHQUFHLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDO1lBQ3JDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDVixJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ1gsTUFBTSxJQUFJLEtBQUssQ0FDYiwyREFBMkQsQ0FDNUQsQ0FBQztnQkFDSixDQUFDO2dCQUVELElBQUksR0FBRyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxDQUFDO2dCQUNsQyxHQUFHLENBQUMsSUFBSSxDQUNOLElBQUksNEJBQTRCLENBQUMsSUFBSSxDQUFDO3FCQUNuQyxXQUFXLENBQ1Ysb0JBQW9CLENBQUMsZUFBZSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FDMUQ7cUJBQ0EsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUNqQixDQUFDO1lBQ0osQ0FBQztZQUVELE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUNsQixDQUFDO0tBQ0YsQ0FBQztBQUNKLENBQUM7QUFFRCxNQUFNLFVBQVUsaUJBQWlCLENBQUMsU0FBOEIsVUFBVTtJQUN4RSxTQUFTLGlCQUFpQixDQUFDLEtBQWE7UUFDdEMsZ0RBQWdEO1FBQ2hELE1BQU0sTUFBTSxHQUFHLEtBQUssS0FBSyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQzFDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQzdDLE1BQU0sV0FBVyxHQUFHLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDMUQsTUFBTSxVQUFVLEdBQUcsSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBQ3RELFVBQVUsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdkIsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUNELE9BQU87UUFDTCxXQUFXLEVBQUUsaUJBQWlCO1FBQzlCLE1BQU0sRUFBRSxDQUFDLEtBQWEsRUFBRSxFQUFFLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDL0MsYUFBYSxFQUFFLENBQUMsS0FBYSxFQUFFLEVBQUU7WUFDL0IsTUFBTSxFQUFFLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEMsT0FBTyxJQUFJLE1BQU0sQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDdEMsQ0FBQztRQUNELGNBQWMsRUFBRSxDQUFDLEtBQWEsRUFBRSxFQUFFO1lBQ2hDLE1BQU0sRUFBRSxHQUFHLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxNQUFNLENBQUMsY0FBYyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7UUFDRCxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7UUFDdkMsS0FBSyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDZixNQUFNLEtBQUssR0FBRyxJQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQzlDLEtBQUssQ0FBQyxJQUFJLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQztZQUN4QixLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7WUFDMUIsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO1FBQ0QsWUFBWSxFQUFFLENBQUMsS0FBYSxFQUFFLEVBQUU7WUFDOUIsTUFBTSxFQUFFLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEMsT0FBTyxJQUFJLE1BQU0sQ0FBQyxZQUFZLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDckMsQ0FBQztRQUNELFlBQVksRUFBRSxDQUFDLEtBQWEsRUFBRSxFQUFFO1lBQzlCLE1BQU0sRUFBRSxHQUFHLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxNQUFNLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3JDLENBQUM7UUFDRCxPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUM7UUFDN0MsU0FBUyxFQUFFLENBQUMsS0FBYSxFQUFFLEVBQUU7WUFDM0IsTUFBTSxFQUFFLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEMsT0FBTyxJQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEMsQ0FBQztRQUNELFVBQVUsRUFBRSxDQUFDLEtBQWEsRUFBRSxFQUFFO1lBQzVCLE1BQU0sRUFBRSxHQUFHLGlCQUFpQixDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3BDLE9BQU8sSUFBSSxNQUFNLENBQUMsVUFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ25DLENBQUM7UUFDRCxVQUFVLEVBQUUsQ0FBQyxLQUFhLEVBQUUsRUFBRTtZQUM1QixNQUFNLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxPQUFPLElBQUksTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNuQyxDQUFDO1FBQ0QsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3JDLE1BQU0sRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsSUFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUMvRCxHQUFHLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7UUFDckMsWUFBWSxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDdEIsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUM1QixNQUFNLFdBQVcsR0FBRyxLQUFLLENBQUMsV0FBVyxDQUFDO1lBRXRDLE1BQU0sTUFBTSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUN2QyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7Z0JBQ1osTUFBTSxJQUFJLEtBQUssQ0FDYixrQkFBa0IsTUFBTSx5REFBeUQsQ0FDbEYsQ0FBQztZQUNKLENBQUM7WUFFRCxrRUFBa0U7WUFDbEUsc0RBQXNEO1lBQ3RELElBQUksV0FBVyxFQUFFLENBQUM7Z0JBQ2hCLE1BQU0sYUFBYSxHQUFHLENBQUMsQ0FBQyxHQUFHLElBQVcsRUFBRSxFQUFFO29CQUN4QyxpREFBaUQ7b0JBQ2pELE1BQU0sY0FBYyxHQUFHLGNBQWMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztvQkFFakQsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO3dCQUNwQixNQUFNLElBQUksS0FBSyxDQUNiLHVFQUF1RSxDQUN4RSxDQUFDO29CQUNKLENBQUM7b0JBRUQsNERBQTREO29CQUM1RCxNQUFNLFVBQVUsR0FBRzt3QkFDakIsR0FBRyxjQUFjO3dCQUNqQixXQUFXO3FCQUNaLENBQUM7b0JBRUYsd0VBQXdFO29CQUN4RSxPQUFPLGNBQWMsQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBQy9ELENBQUMsQ0FBUSxDQUFDO2dCQUVWLDhDQUE4QztnQkFDOUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxhQUFhLEVBQUUsTUFBTSxFQUFFO29CQUMzQyxLQUFLLEVBQUUsTUFBTSxDQUFDLElBQUk7aUJBQ25CLENBQUMsQ0FBQztnQkFDSCxNQUFNLENBQUMsY0FBYyxDQUFDLGFBQWEsRUFBRSxRQUFRLEVBQUU7b0JBQzdDLEtBQUssRUFBRSxNQUFNO29CQUNiLFFBQVEsRUFBRSxLQUFLO29CQUNmLFVBQVUsRUFBRSxLQUFLO29CQUNqQixZQUFZLEVBQUUsS0FBSztpQkFDcEIsQ0FBQyxDQUFDO2dCQUNILElBQUksTUFBTSxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUUsQ0FBQztvQkFDcEMsYUFBYSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMsVUFBVSxDQUFDO2dCQUMvQyxDQUFDO2dCQUVELE9BQU8sYUFBYSxDQUFDO1lBQ3ZCLENBQUM7WUFFRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDO1FBQ0QsR0FBRyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUUsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3JDLGVBQWUsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFLENBQ3pCLElBQUksTUFBTSxDQUFDLGVBQWUsQ0FBQyxLQUFLLEtBQUssR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUN4RCxVQUFVLEVBQUUsQ0FBQyxLQUFhLEVBQUUsRUFBRTtZQUM1QixNQUFNLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxPQUFPLElBQUksTUFBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNuQyxDQUFDO1FBQ0QsaUJBQWlCLEVBQUUsQ0FBQyxLQUFhLEVBQUUsRUFBRTtZQUNuQyxNQUFNLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxPQUFPLElBQUksTUFBTSxDQUFDLGlCQUFpQixDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQzFDLENBQUM7UUFDRCxXQUFXLEVBQUUsQ0FBQyxLQUFhLEVBQUUsRUFBRTtZQUM3QixNQUFNLEVBQUUsR0FBRyxpQkFBaUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNwQyxPQUFPLElBQUksTUFBTSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwQyxDQUFDO1FBQ0QsV0FBVyxFQUFFLENBQUMsS0FBYSxFQUFFLEVBQUU7WUFDN0IsTUFBTSxFQUFFLEdBQUcsaUJBQWlCLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDcEMsT0FBTyxJQUFJLE1BQU0sQ0FBQyxXQUFXLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDcEMsQ0FBQztLQUNtQyxDQUFDO0FBQ3pDLENBQUM7QUFFRDs7Ozs7OztHQU9HO0FBQ0gsTUFBTSxVQUFVLG1CQUFtQixDQUNqQyxTQUE4QixVQUFVLEVBQ3hDLEdBQW9CLEVBQ3BCLEtBQStCO0lBRS9CLE9BQU87UUFDTCxHQUFHLGlCQUFpQixDQUFDLE1BQU0sQ0FBQztRQUU1QixPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNqQixPQUFPLElBQUksTUFBTSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFO2dCQUNuQyxNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07Z0JBQ3BCLE9BQU8sRUFBRSxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDMUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJO2dCQUNoQixNQUFNLEVBQUUsS0FBSyxDQUFDLE1BQU07YUFDckIsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUNELFFBQVEsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ2xCLDBFQUEwRTtZQUMxRSxvRkFBb0Y7WUFDcEYsT0FBTyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRTtnQkFDckMsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO2dCQUNwQixVQUFVLEVBQUUsS0FBSyxDQUFDLFVBQVU7Z0JBQzVCLE9BQU8sRUFBRSxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQzthQUMzQyxDQUFDLENBQUM7UUFDTCxDQUFDO1FBQ0QsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLEVBQUU7WUFDeEIsNERBQTREO1lBQzVELGtFQUFrRTtZQUNsRSxJQUFJLFVBQVUsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDeEIsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQztnQkFDaEMscUZBQXFGO2dCQUNyRixNQUFNLFFBQVEsR0FBRyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQy9DLE9BQU8sUUFBUSxDQUFDLElBQUksQ0FBQztZQUN2QixDQUFDO1lBRUQsTUFBTSxRQUFRLEdBQUcsSUFBSSw0QkFBNEIsQ0FDL0MsS0FBSyxDQUFDLElBQUksRUFDVixLQUFLLENBQUMsVUFBVSxDQUNqQixDQUFDO1lBQ0YsSUFBSSxLQUFLLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRSxDQUFDO2dCQUMzQixPQUFPLFFBQVEsQ0FBQztZQUNsQixDQUFDO2lCQUFNLENBQUM7Z0JBQ04sTUFBTSxTQUFTLEdBQUcsb0JBQW9CLENBQ3BDLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQ3hDLENBQUM7Z0JBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUM5QyxPQUFPLFNBQVMsQ0FBQyxRQUFRLENBQUM7WUFDNUIsQ0FBQztRQUNILENBQUM7UUFDRCxjQUFjLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUN4QixNQUFNLFNBQVMsR0FBRyxrQkFBa0IsQ0FDbEMsbUJBQW1CLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FDeEMsQ0FBQztZQUNGLEdBQUcsQ0FBQyxJQUFJLENBQ04sU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQ3ZCLElBQUksNEJBQTRCLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsQ0FDcEQsQ0FDRixDQUFDO1lBQ0YsT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDO1FBQzVCLENBQUM7S0FDRixDQUFDO0FBQ0osQ0FBQztBQUVEOzs7Ozs7O0dBT0c7QUFDSCxNQUFNLFVBQVUsbUJBQW1CLENBQ2pDLFNBQThCLFVBQVU7SUFFeEMsT0FBTztRQUNMLEdBQUcsaUJBQWlCLENBQUMsTUFBTSxDQUFDO1FBQzVCLE9BQU8sRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ2pCLE1BQU0sQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDdkQsTUFBTSxnQkFBZ0IsR0FBRyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7WUFDaEQsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO2dCQUNwQixLQUFhLENBQUMseUJBQXlCLENBQUMsR0FBRyxnQkFBZ0IsQ0FBQztnQkFDN0QsT0FBTyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzdCLEtBQWEsQ0FBQyxXQUFXLEdBQUcsR0FBRyxFQUFFO29CQUNoQyxNQUFNLElBQUksS0FBSyxDQUNiLDREQUE0RCxDQUM3RCxDQUFDO2dCQUNKLENBQUMsQ0FBQztZQUNKLENBQUM7WUFDRCxPQUFPLEtBQUssQ0FBQztRQUNmLENBQUM7UUFDRCxRQUFRLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNsQixNQUFNLENBQUMsY0FBYyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3hELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztRQUNELGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3hCLHNFQUFzRTtZQUN0RSxJQUFJLFVBQVUsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDeEIsNkNBQTZDO2dCQUM3QyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUU7b0JBQ3BELENBQUMsZ0JBQWdCLENBQUMsRUFBRTt3QkFDbEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxRQUFRO3dCQUNyQixRQUFRLEVBQUUsS0FBSztxQkFDaEI7aUJBQ0YsQ0FBQyxDQUFDO1lBQ0wsQ0FBQztZQUVELDBCQUEwQjtZQUMxQixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUU7Z0JBQ3BELENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJO29CQUNqQixRQUFRLEVBQUUsS0FBSztpQkFDaEI7Z0JBQ0QsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFO29CQUNwQixLQUFLLEVBQUUsS0FBSyxDQUFDLElBQUk7b0JBQ2pCLFFBQVEsRUFBRSxLQUFLO2lCQUNoQjthQUNGLENBQUMsQ0FBQztRQUNMLENBQUM7UUFDRCxjQUFjLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUN4QixPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxTQUFTLEVBQUU7Z0JBQ3BELENBQUMsa0JBQWtCLENBQUMsRUFBRTtvQkFDcEIsS0FBSyxFQUFFLEtBQUssQ0FBQyxJQUFJO29CQUNqQixRQUFRLEVBQUUsS0FBSztpQkFDaEI7YUFDRixDQUFDLENBQUM7UUFDTCxDQUFDO0tBQ0YsQ0FBQztBQUNKLENBQUM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILFNBQVMsZUFBZSxDQUN0QixTQUE4QixVQUFVLEVBQ3hDLEdBQW9CLEVBQ3BCLEtBQStCO0lBRS9CLE9BQU87UUFDTCxHQUFHLGlCQUFpQixDQUFDLE1BQU0sQ0FBQztRQUU1QixPQUFPLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNqQixNQUFNLGdCQUFnQixHQUFHLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQztZQUNoRCxNQUFNLE9BQU8sR0FBRyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRTtnQkFDNUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO2dCQUNwQixPQUFPLEVBQUUsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQzFDLElBQUksRUFBRSxLQUFLLENBQUMsSUFBSTtnQkFDaEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxNQUFNO2FBQ3JCLENBQUMsQ0FBQztZQUNILElBQUksZ0JBQWdCLEVBQUUsQ0FBQztnQkFDckIsT0FBTyxDQUFDLFdBQVcsR0FBRyxLQUFLLEVBQUUsUUFBa0IsRUFBRSxFQUFFO29CQUNqRCxNQUFNLE1BQU0sR0FBRyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztvQkFDNUMsTUFBTSxNQUFNLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO29CQUM3QixNQUFNLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDdkIsQ0FBQyxDQUFDO1lBQ0osQ0FBQztZQUNELE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUM7UUFDRCxRQUFRLEVBQUUsQ0FBQyxLQUFLLEVBQUUsRUFBRTtZQUNsQiwwRUFBMEU7WUFDMUUsb0ZBQW9GO1lBQ3BGLE9BQU8sSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUU7Z0JBQ3JDLE1BQU0sRUFBRSxLQUFLLENBQUMsTUFBTTtnQkFDcEIsVUFBVSxFQUFFLEtBQUssQ0FBQyxVQUFVO2dCQUM1QixPQUFPLEVBQUUsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7YUFDM0MsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUNELGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3hCLDREQUE0RDtZQUM1RCxxRUFBcUU7WUFDckUsSUFBSSxVQUFVLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ3hCLE1BQU0sUUFBUSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUM7Z0JBQ2hDLHFGQUFxRjtnQkFDckYsTUFBTSxRQUFRLEdBQUcsSUFBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUMvQyxPQUFPLFFBQVEsQ0FBQyxJQUFJLENBQUM7WUFDdkIsQ0FBQztZQUVELE1BQU0sUUFBUSxHQUFHLElBQUksNEJBQTRCLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1lBQzlELElBQUksS0FBSyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUUsQ0FBQztnQkFDM0IsT0FBTyxRQUFRLENBQUM7WUFDbEIsQ0FBQztpQkFBTSxDQUFDO2dCQUNOLE1BQU0sU0FBUyxHQUFHLG9CQUFvQixDQUNwQyxlQUFlLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUMsQ0FDcEMsQ0FBQztnQkFDRixHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7Z0JBQzlDLE9BQU8sU0FBUyxDQUFDLFFBQVEsQ0FBQztZQUM1QixDQUFDO1FBQ0gsQ0FBQztRQUNELGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxFQUFFO1lBQ3hCLElBQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDWCxNQUFNLElBQUksS0FBSyxDQUNiLHdEQUF3RCxDQUN6RCxDQUFDO1lBQ0osQ0FBQztZQUVELE1BQU0sU0FBUyxHQUFHLGtCQUFrQixDQUFDLGVBQWUsQ0FBQyxNQUFNLEVBQUUsR0FBRyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDMUUsR0FBRyxDQUFDLElBQUksQ0FDTixTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FDdkIsSUFBSSw0QkFBNEIsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUNwRCxDQUNGLENBQUM7WUFDRixPQUFPLFNBQVMsQ0FBQyxRQUFRLENBQUM7UUFDNUIsQ0FBQztLQUNGLENBQUM7QUFDSixDQUFDO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsTUFBTSxVQUFVLDBCQUEwQixDQUN4QyxLQUFjLEVBQ2QsR0FBb0IsRUFDcEIsS0FBK0IsRUFDL0IsU0FBOEIsVUFBVTtJQUV4QyxJQUFJLENBQUM7UUFDSCxNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsS0FBSyxFQUFFLG1CQUFtQixDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUN0RSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNyQixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sSUFBSSxvQkFBb0IsQ0FDNUIsd0JBQXdCLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLEVBQ3JELEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FDL0MsQ0FBQztJQUNKLENBQUM7QUFDSCxDQUFDO0FBRUQ7Ozs7Ozs7O0dBUUc7QUFDSCxNQUFNLFVBQVUsd0JBQXdCLENBQ3RDLEtBQXNDLEVBQ3RDLFNBQThCLFVBQVUsRUFDeEMsZ0JBQXFELEVBQUU7SUFFdkQsTUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLEtBQUssRUFBRTtRQUMzQixHQUFHLG1CQUFtQixDQUFDLE1BQU0sQ0FBQztRQUM5QixHQUFHLGFBQWE7S0FDakIsQ0FBQyxDQUFDO0lBQ0gsT0FBTyxHQUFHLENBQUM7QUFDYixDQUFDO0FBRUQ7Ozs7Ozs7R0FPRztBQUNILE1BQU0sVUFBVSw0QkFBNEIsQ0FDMUMsS0FBYyxFQUNkLFNBQThCLFVBQVU7SUFFeEMsSUFBSSxDQUFDO1FBQ0gsTUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLEtBQUssRUFBRSxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQzFELE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsTUFBTSxJQUFJLG9CQUFvQixDQUM1Qix3QkFBd0IsQ0FBQyx1QkFBdUIsRUFBRSxLQUFLLENBQUMsRUFDeEQsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUMvQyxDQUFDO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRDs7Ozs7Ozs7Ozs7R0FXRztBQUNILE1BQU0sVUFBVSwwQkFBMEIsQ0FDeEMsS0FBc0MsRUFDdEMsR0FBb0IsRUFDcEIsS0FBK0IsRUFDL0IsU0FBOEIsVUFBVSxFQUN4QyxnQkFBcUQsRUFBRTtJQUV2RCxNQUFNLEdBQUcsR0FBRyxTQUFTLENBQUMsS0FBSyxFQUFFO1FBQzNCLEdBQUcsbUJBQW1CLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDMUMsR0FBRyxhQUFhO0tBQ2pCLENBQUMsQ0FBQztJQUNILE9BQU8sR0FBRyxDQUFDO0FBQ2IsQ0FBQztBQUVEOzs7Ozs7OztHQVFHO0FBQ0gsTUFBTSxVQUFVLHNCQUFzQixDQUNwQyxLQUFjLEVBQ2QsTUFBMkI7SUFFM0IsSUFBSSxDQUFDO1FBQ0gsTUFBTSxHQUFHLEdBQUcsU0FBUyxDQUFDLEtBQUssRUFBRSxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1FBQzFELE9BQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQ3JCLENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsTUFBTSxJQUFJLG9CQUFvQixDQUM1Qix3QkFBd0IsQ0FBQyxnQkFBZ0IsRUFBRSxLQUFLLENBQUMsRUFDakQsRUFBRSxJQUFJLEVBQUUsc0JBQXNCLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxDQUMvQyxDQUFDO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRDs7Ozs7Ozs7OztHQVVHO0FBQ0gsTUFBTSxVQUFVLG9CQUFvQixDQUNsQyxLQUFzQyxFQUN0QyxHQUFtQixFQUNuQixLQUErQixFQUMvQixTQUE4QixVQUFVLEVBQ3hDLGdCQUFxRCxFQUFFO0lBRXZELE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUU7UUFDM0IsR0FBRyxlQUFlLENBQUMsTUFBTSxFQUFFLEdBQUcsRUFBRSxLQUFLLENBQUM7UUFDdEMsR0FBRyxhQUFhO0tBQ2pCLENBQUMsQ0FBQztJQUNILE9BQU8sR0FBRyxDQUFDO0FBQ2IsQ0FBQztBQUVEOzs7Ozs7Ozs7O0dBVUc7QUFDSCxNQUFNLFVBQVUsd0JBQXdCLENBQ3RDLEtBQWMsRUFDZCxHQUFtQixFQUNuQixLQUErQixFQUMvQixTQUE4QixVQUFVO0lBRXhDLElBQUksQ0FBQztRQUNILE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUUsZUFBZSxDQUFDLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQztRQUNsRSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNyQixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE1BQU0sSUFBSSxvQkFBb0IsQ0FDNUIsd0JBQXdCLENBQUMsbUJBQW1CLEVBQUUsS0FBSyxDQUFDLEVBQ3BELEVBQUUsSUFBSSxFQUFFLHNCQUFzQixFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsQ0FDL0MsQ0FBQztJQUNKLENBQUM7QUFDSCxDQUFDO0FBRUQ7Ozs7Ozs7OztHQVNHO0FBQ0gsTUFBTSxVQUFVLHNCQUFzQixDQUNwQyxLQUFzQyxFQUN0QyxTQUE4QixVQUFVLEVBQ3hDLGdCQUFxRCxFQUFFO0lBRXZELE1BQU0sR0FBRyxHQUFHLFNBQVMsQ0FBQyxLQUFLLEVBQUU7UUFDM0IsR0FBRyxtQkFBbUIsQ0FBQyxNQUFNLENBQUM7UUFDOUIsR0FBRyxhQUFhO0tBQ2pCLENBQUMsQ0FBQztJQUNILE9BQU8sR0FBRyxDQUFDO0FBQ2IsQ0FBQyJ9
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/telemetry/semantic-conventions.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * OpenTelemetry semantic conventions for Vercel Workflow telemetry.
 *
 * This module provides standardized telemetry attributes following OpenTelemetry semantic conventions
 * for instrumenting workflow execution, step processing, and related operations. Each exported function
 * creates a properly formatted attribute object that can be used with OpenTelemetry spans.
 *
 * The semantic conventions are organized into several categories:
 * - **Workflow attributes**: Track workflow lifecycle, status, and metadata
 * - **Step attributes**: Monitor individual step execution, retries, and results
 * - **Queue attributes**: Instrument message queue operations
 * - **Deployment attributes**: Capture deployment environment information
 *
 * All attribute functions are type-safe and leverage existing backend types to ensure
 * consistency between telemetry data and actual system state.
 *
 * @example
 * ```typescript
 * import * as Attribute from './telemetry/semantic-conventions.js';
 *
 * // Set workflow attributes on a span
 * span.setAttributes({
 *   ...Attribute.WorkflowName('my-workflow'),
 *   ...Attribute.WorkflowOperation('start'),
 *   ...Attribute.WorkflowRunStatus('running'),
 * });
 *
 * // Set step attributes
 * span.setAttributes({
 *   ...Attribute.StepName('process-data'),
 *   ...Attribute.StepStatus('completed'),
 *   ...Attribute.StepAttempt(1),
 * });
 * ```
 *
 * @see {@link https://opentelemetry.io/docs/specs/semconv/} OpenTelemetry Semantic Conventions
 * @packageDocumentation
 */ /**
 * Creates a semantic convention function that returns an attribute object.
 * @param name - The attribute name following OpenTelemetry semantic conventions
 * @returns A function that takes a value and returns an attribute object
 */ __turbopack_context__.s([
    "DeploymentId",
    ()=>DeploymentId,
    "HookFound",
    ()=>HookFound,
    "HookId",
    ()=>HookId,
    "HookToken",
    ()=>HookToken,
    "QueueMessageId",
    ()=>QueueMessageId,
    "QueueName",
    ()=>QueueName,
    "QueueOverheadMs",
    ()=>QueueOverheadMs,
    "StepArgumentsCount",
    ()=>StepArgumentsCount,
    "StepAttempt",
    ()=>StepAttempt,
    "StepErrorMessage",
    ()=>StepErrorMessage,
    "StepErrorName",
    ()=>StepErrorName,
    "StepFatalError",
    ()=>StepFatalError,
    "StepId",
    ()=>StepId,
    "StepMaxRetries",
    ()=>StepMaxRetries,
    "StepName",
    ()=>StepName,
    "StepResultType",
    ()=>StepResultType,
    "StepRetryExhausted",
    ()=>StepRetryExhausted,
    "StepRetryTimeoutSeconds",
    ()=>StepRetryTimeoutSeconds,
    "StepRetryWillRetry",
    ()=>StepRetryWillRetry,
    "StepSkipReason",
    ()=>StepSkipReason,
    "StepSkipped",
    ()=>StepSkipped,
    "StepStatus",
    ()=>StepStatus,
    "StepTracePropagated",
    ()=>StepTracePropagated,
    "WebhookHandlersTriggered",
    ()=>WebhookHandlersTriggered,
    "WorkflowArgumentsCount",
    ()=>WorkflowArgumentsCount,
    "WorkflowErrorMessage",
    ()=>WorkflowErrorMessage,
    "WorkflowErrorName",
    ()=>WorkflowErrorName,
    "WorkflowEventsCount",
    ()=>WorkflowEventsCount,
    "WorkflowName",
    ()=>WorkflowName,
    "WorkflowOperation",
    ()=>WorkflowOperation,
    "WorkflowResultType",
    ()=>WorkflowResultType,
    "WorkflowRunId",
    ()=>WorkflowRunId,
    "WorkflowRunStatus",
    ()=>WorkflowRunStatus,
    "WorkflowStartedAt",
    ()=>WorkflowStartedAt,
    "WorkflowStepsCreated",
    ()=>WorkflowStepsCreated,
    "WorkflowSuspensionHookCount",
    ()=>WorkflowSuspensionHookCount,
    "WorkflowSuspensionState",
    ()=>WorkflowSuspensionState,
    "WorkflowSuspensionStepCount",
    ()=>WorkflowSuspensionStepCount,
    "WorkflowSuspensionWaitCount",
    ()=>WorkflowSuspensionWaitCount,
    "WorkflowTracePropagated",
    ()=>WorkflowTracePropagated
]);
function SemanticConvention(...names) {
    return (value)=>Object.fromEntries(names.map((name)=>[
                name,
                value
            ]));
}
const WorkflowName = SemanticConvention('workflow.name');
const WorkflowOperation = SemanticConvention('workflow.operation');
const WorkflowRunId = SemanticConvention('workflow.run.id');
const WorkflowRunStatus = SemanticConvention('workflow.run.status');
const WorkflowStartedAt = SemanticConvention('workflow.started_at');
const WorkflowEventsCount = SemanticConvention('workflow.events.count');
const WorkflowArgumentsCount = SemanticConvention('workflow.arguments.count');
const WorkflowResultType = SemanticConvention('workflow.result.type');
const WorkflowTracePropagated = SemanticConvention('workflow.trace.propagated');
const WorkflowErrorName = SemanticConvention('workflow.error.name');
const WorkflowErrorMessage = SemanticConvention('workflow.error.message');
const WorkflowStepsCreated = SemanticConvention('workflow.steps.created');
const StepName = SemanticConvention('step.name');
const StepId = SemanticConvention('step.id');
const StepAttempt = SemanticConvention('step.attempt');
const StepStatus = SemanticConvention('step.status');
const StepMaxRetries = SemanticConvention('step.max_retries');
const StepTracePropagated = SemanticConvention('step.trace.propagated');
const StepSkipped = SemanticConvention('step.skipped');
const StepSkipReason = SemanticConvention('step.skip_reason');
const StepArgumentsCount = SemanticConvention('step.arguments.count');
const StepResultType = SemanticConvention('step.result.type');
const StepErrorName = SemanticConvention('step.error.name');
const StepErrorMessage = SemanticConvention('step.error.message');
const StepFatalError = SemanticConvention('step.fatal_error');
const StepRetryExhausted = SemanticConvention('step.retry.exhausted');
const StepRetryTimeoutSeconds = SemanticConvention('step.retry.timeout_seconds');
const StepRetryWillRetry = SemanticConvention('step.retry.will_retry');
const QueueName = SemanticConvention('queue.name');
const QueueMessageId = SemanticConvention('messaging.message.id', 'queue.message.id');
const QueueOverheadMs = SemanticConvention('queue.overhead_ms');
const DeploymentId = SemanticConvention('deployment.id');
const HookToken = SemanticConvention('workflow.hook.token');
const HookId = SemanticConvention('workflow.hook.id');
const HookFound = SemanticConvention('workflow.hook.found');
const WebhookHandlersTriggered = SemanticConvention('webhook.handlers.triggered');
const WorkflowSuspensionState = SemanticConvention('workflow.suspension.state');
const WorkflowSuspensionHookCount = SemanticConvention('workflow.suspension.hook_count');
const WorkflowSuspensionStepCount = SemanticConvention('workflow.suspension.step_count');
const WorkflowSuspensionWaitCount = SemanticConvention('workflow.suspension.wait_count'); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VtYW50aWMtY29udmVudGlvbnMuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdGVsZW1ldHJ5L3NlbWFudGljLWNvbnZlbnRpb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBcUNHO0FBSUg7Ozs7R0FJRztBQUNILFNBQVMsa0JBQWtCLENBQUksR0FBRyxLQUFlO0lBQy9DLE9BQU8sQ0FBQyxLQUFRLEVBQUUsRUFBRSxDQUNsQixNQUFNLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBVSxDQUFDLENBQUMsQ0FBQztBQUNwRSxDQUFDO0FBRUQsc0JBQXNCO0FBRXRCLDhDQUE4QztBQUM5QyxNQUFNLENBQUMsTUFBTSxZQUFZLEdBQUcsa0JBQWtCLENBQVMsZUFBZSxDQUFDLENBQUM7QUFFeEUsb0RBQW9EO0FBQ3BELE1BQU0sQ0FBQyxNQUFNLGlCQUFpQixHQUFHLGtCQUFrQixDQUVqRCxvQkFBb0IsQ0FBQyxDQUFDO0FBRXhCLDZEQUE2RDtBQUM3RCxNQUFNLENBQUMsTUFBTSxhQUFhLEdBQUcsa0JBQWtCLENBQVMsaUJBQWlCLENBQUMsQ0FBQztBQUUzRSx5Q0FBeUM7QUFDekMsTUFBTSxDQUFDLE1BQU0saUJBQWlCLEdBQUcsa0JBQWtCLENBRWpELHFCQUFxQixDQUFDLENBQUM7QUFFekIscUVBQXFFO0FBQ3JFLE1BQU0sQ0FBQyxNQUFNLGlCQUFpQixHQUFHLGtCQUFrQixDQUNqRCxxQkFBcUIsQ0FDdEIsQ0FBQztBQUVGLDJEQUEyRDtBQUMzRCxNQUFNLENBQUMsTUFBTSxtQkFBbUIsR0FBRyxrQkFBa0IsQ0FDbkQsdUJBQXVCLENBQ3hCLENBQUM7QUFFRixpREFBaUQ7QUFDakQsTUFBTSxDQUFDLE1BQU0sc0JBQXNCLEdBQUcsa0JBQWtCLENBQ3RELDBCQUEwQixDQUMzQixDQUFDO0FBRUYsa0NBQWtDO0FBQ2xDLE1BQU0sQ0FBQyxNQUFNLGtCQUFrQixHQUFHLGtCQUFrQixDQUNsRCxzQkFBc0IsQ0FDdkIsQ0FBQztBQUVGLHNFQUFzRTtBQUN0RSxNQUFNLENBQUMsTUFBTSx1QkFBdUIsR0FBRyxrQkFBa0IsQ0FDdkQsMkJBQTJCLENBQzVCLENBQUM7QUFFRixxREFBcUQ7QUFDckQsTUFBTSxDQUFDLE1BQU0saUJBQWlCLEdBQUcsa0JBQWtCLENBQ2pELHFCQUFxQixDQUN0QixDQUFDO0FBRUYsd0NBQXdDO0FBQ3hDLE1BQU0sQ0FBQyxNQUFNLG9CQUFvQixHQUFHLGtCQUFrQixDQUNwRCx3QkFBd0IsQ0FDekIsQ0FBQztBQUVGLHdEQUF3RDtBQUN4RCxNQUFNLENBQUMsTUFBTSxvQkFBb0IsR0FBRyxrQkFBa0IsQ0FDcEQsd0JBQXdCLENBQ3pCLENBQUM7QUFFRixrQkFBa0I7QUFFbEIsK0NBQStDO0FBQy9DLE1BQU0sQ0FBQyxNQUFNLFFBQVEsR0FBRyxrQkFBa0IsQ0FBUyxXQUFXLENBQUMsQ0FBQztBQUVoRSw4Q0FBOEM7QUFDOUMsTUFBTSxDQUFDLE1BQU0sTUFBTSxHQUFHLGtCQUFrQixDQUFTLFNBQVMsQ0FBQyxDQUFDO0FBRTVELDhEQUE4RDtBQUM5RCxNQUFNLENBQUMsTUFBTSxXQUFXLEdBQUcsa0JBQWtCLENBQVMsY0FBYyxDQUFDLENBQUM7QUFFdEUsaUNBQWlDO0FBQ2pDLE1BQU0sQ0FBQyxNQUFNLFVBQVUsR0FBRyxrQkFBa0IsQ0FBaUIsYUFBYSxDQUFDLENBQUM7QUFFNUUsc0RBQXNEO0FBQ3RELE1BQU0sQ0FBQyxNQUFNLGNBQWMsR0FBRyxrQkFBa0IsQ0FBUyxrQkFBa0IsQ0FBQyxDQUFDO0FBRTdFLGtFQUFrRTtBQUNsRSxNQUFNLENBQUMsTUFBTSxtQkFBbUIsR0FBRyxrQkFBa0IsQ0FDbkQsdUJBQXVCLENBQ3hCLENBQUM7QUFFRixvREFBb0Q7QUFDcEQsTUFBTSxDQUFDLE1BQU0sV0FBVyxHQUFHLGtCQUFrQixDQUFVLGNBQWMsQ0FBQyxDQUFDO0FBRXZFLHNDQUFzQztBQUN0QyxNQUFNLENBQUMsTUFBTSxjQUFjLEdBQ3pCLGtCQUFrQixDQUFpQixrQkFBa0IsQ0FBQyxDQUFDO0FBRXpELHNEQUFzRDtBQUN0RCxNQUFNLENBQUMsTUFBTSxrQkFBa0IsR0FBRyxrQkFBa0IsQ0FDbEQsc0JBQXNCLENBQ3ZCLENBQUM7QUFFRiw4QkFBOEI7QUFDOUIsTUFBTSxDQUFDLE1BQU0sY0FBYyxHQUFHLGtCQUFrQixDQUFTLGtCQUFrQixDQUFDLENBQUM7QUFFN0UsaURBQWlEO0FBQ2pELE1BQU0sQ0FBQyxNQUFNLGFBQWEsR0FBRyxrQkFBa0IsQ0FBUyxpQkFBaUIsQ0FBQyxDQUFDO0FBRTNFLG9DQUFvQztBQUNwQyxNQUFNLENBQUMsTUFBTSxnQkFBZ0IsR0FDM0Isa0JBQWtCLENBQVMsb0JBQW9CLENBQUMsQ0FBQztBQUVuRCw4REFBOEQ7QUFDOUQsTUFBTSxDQUFDLE1BQU0sY0FBYyxHQUFHLGtCQUFrQixDQUFVLGtCQUFrQixDQUFDLENBQUM7QUFFOUUscURBQXFEO0FBQ3JELE1BQU0sQ0FBQyxNQUFNLGtCQUFrQixHQUFHLGtCQUFrQixDQUNsRCxzQkFBc0IsQ0FDdkIsQ0FBQztBQUVGLDBEQUEwRDtBQUMxRCxNQUFNLENBQUMsTUFBTSx1QkFBdUIsR0FBRyxrQkFBa0IsQ0FDdkQsNEJBQTRCLENBQzdCLENBQUM7QUFFRiwwREFBMEQ7QUFDMUQsTUFBTSxDQUFDLE1BQU0sa0JBQWtCLEdBQUcsa0JBQWtCLENBQ2xELHVCQUF1QixDQUN4QixDQUFDO0FBRUYsbUJBQW1CO0FBRW5CLDBEQUEwRDtBQUMxRCxNQUFNLENBQUMsTUFBTSxTQUFTLEdBQUcsa0JBQWtCLENBQVMsWUFBWSxDQUFDLENBQUM7QUFFbEUsbUNBQW1DO0FBQ25DLE1BQU0sQ0FBQyxNQUFNLGNBQWMsR0FBRyxrQkFBa0IsQ0FDOUMsc0JBQXNCLEVBQ3RCLGtCQUFrQixDQUNuQixDQUFDO0FBRUYsd0RBQXdEO0FBQ3hELE1BQU0sQ0FBQyxNQUFNLGVBQWUsR0FBRyxrQkFBa0IsQ0FBUyxtQkFBbUIsQ0FBQyxDQUFDO0FBRS9FLHdCQUF3QjtBQUV4Qix1REFBdUQ7QUFDdkQsTUFBTSxDQUFDLE1BQU0sWUFBWSxHQUFHLGtCQUFrQixDQUFTLGVBQWUsQ0FBQyxDQUFDO0FBRXhFLGtCQUFrQjtBQUVsQix3Q0FBd0M7QUFDeEMsTUFBTSxDQUFDLE1BQU0sU0FBUyxHQUFHLGtCQUFrQixDQUFTLHFCQUFxQixDQUFDLENBQUM7QUFFM0UsNENBQTRDO0FBQzVDLE1BQU0sQ0FBQyxNQUFNLE1BQU0sR0FBRyxrQkFBa0IsQ0FBUyxrQkFBa0IsQ0FBQyxDQUFDO0FBRXJFLDRDQUE0QztBQUM1QyxNQUFNLENBQUMsTUFBTSxTQUFTLEdBQUcsa0JBQWtCLENBQVUscUJBQXFCLENBQUMsQ0FBQztBQUU1RSxxQkFBcUI7QUFFckIsMkNBQTJDO0FBQzNDLE1BQU0sQ0FBQyxNQUFNLHdCQUF3QixHQUFHLGtCQUFrQixDQUN4RCw0QkFBNEIsQ0FDN0IsQ0FBQztBQUVGLHdCQUF3QjtBQUV4QixNQUFNLENBQUMsTUFBTSx1QkFBdUIsR0FBRyxrQkFBa0IsQ0FDdkQsMkJBQTJCLENBQzVCLENBQUM7QUFDRixNQUFNLENBQUMsTUFBTSwyQkFBMkIsR0FBRyxrQkFBa0IsQ0FDM0QsZ0NBQWdDLENBQ2pDLENBQUM7QUFDRixNQUFNLENBQUMsTUFBTSwyQkFBMkIsR0FBRyxrQkFBa0IsQ0FDM0QsZ0NBQWdDLENBQ2pDLENBQUM7QUFDRixNQUFNLENBQUMsTUFBTSwyQkFBMkIsR0FBRyxrQkFBa0IsQ0FDM0QsZ0NBQWdDLENBQ2pDLENBQUMifQ==
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/global.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * An error that is thrown when one or more operations (steps/hooks/etc.) are called but do
 * not yet have corresponding entries in the event log. The workflow
 * dispatcher will catch this error and push the operations
 * onto the queue.
 */ __turbopack_context__.s([
    "ENOTSUP",
    ()=>ENOTSUP,
    "WorkflowSuspension",
    ()=>WorkflowSuspension
]);
class WorkflowSuspension extends Error {
    steps;
    globalThis;
    stepCount;
    hookCount;
    waitCount;
    constructor(stepsInput, global){
        // Convert Map to array for iteration and storage
        const steps = [
            ...stepsInput.values()
        ];
        // Single-pass counting for efficiency
        let stepCount = 0;
        let hookCount = 0;
        let waitCount = 0;
        for (const item of steps){
            if (item.type === 'step') stepCount++;
            else if (item.type === 'hook') hookCount++;
            else if (item.type === 'wait') waitCount++;
        }
        // Build description parts
        const parts = [];
        if (stepCount > 0) {
            parts.push(`${stepCount} ${stepCount === 1 ? 'step' : 'steps'}`);
        }
        if (hookCount > 0) {
            parts.push(`${hookCount} ${hookCount === 1 ? 'hook' : 'hooks'}`);
        }
        if (waitCount > 0) {
            parts.push(`${waitCount} ${waitCount === 1 ? 'wait' : 'waits'}`);
        }
        // Determine verb (has/have) and action (run/created/received)
        const totalCount = stepCount + hookCount + waitCount;
        const hasOrHave = totalCount === 1 ? 'has' : 'have';
        let action;
        if (stepCount > 0) {
            action = 'run';
        } else if (hookCount > 0) {
            action = 'created';
        } else if (waitCount > 0) {
            action = 'created';
        } else {
            action = 'received';
        }
        const description = parts.length > 0 ? `${parts.join(' and ')} ${hasOrHave} not been ${action} yet` : '0 steps have not been run yet'; // Default case for empty array
        super(description);
        this.name = 'WorkflowSuspension';
        this.steps = steps;
        this.globalThis = global;
        this.stepCount = stepCount;
        this.hookCount = hookCount;
        this.waitCount = waitCount;
    }
    static is(value) {
        return value instanceof WorkflowSuspension;
    }
}
function ENOTSUP() {
    throw new Error('Not supported in workflow functions');
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2xvYmFsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vc3JjL2dsb2JhbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUE2QkE7Ozs7O0dBS0c7QUFDSCxNQUFNLE9BQU8sa0JBQW1CLFNBQVEsS0FBSztJQUMzQyxLQUFLLENBQWM7SUFDbkIsVUFBVSxDQUFvQjtJQUM5QixTQUFTLENBQVM7SUFDbEIsU0FBUyxDQUFTO0lBQ2xCLFNBQVMsQ0FBUztJQUVsQixZQUFZLFVBQWtDLEVBQUUsTUFBeUI7UUFDdkUsaURBQWlEO1FBQ2pELE1BQU0sS0FBSyxHQUFHLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUV2QyxzQ0FBc0M7UUFDdEMsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2xCLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztRQUNsQixJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUM7UUFDbEIsS0FBSyxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN6QixJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssTUFBTTtnQkFBRSxTQUFTLEVBQUUsQ0FBQztpQkFDakMsSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLE1BQU07Z0JBQUUsU0FBUyxFQUFFLENBQUM7aUJBQ3RDLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxNQUFNO2dCQUFFLFNBQVMsRUFBRSxDQUFDO1FBQzdDLENBQUM7UUFFRCwwQkFBMEI7UUFDMUIsTUFBTSxLQUFLLEdBQWEsRUFBRSxDQUFDO1FBQzNCLElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxDQUFDO1lBQ2xCLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFTLElBQUksU0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQ25FLENBQUM7UUFDRCxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNsQixLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsU0FBUyxJQUFJLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUNuRSxDQUFDO1FBQ0QsSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDbEIsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLFNBQVMsSUFBSSxTQUFTLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUVELDhEQUE4RDtRQUM5RCxNQUFNLFVBQVUsR0FBRyxTQUFTLEdBQUcsU0FBUyxHQUFHLFNBQVMsQ0FBQztRQUNyRCxNQUFNLFNBQVMsR0FBRyxVQUFVLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUNwRCxJQUFJLE1BQWMsQ0FBQztRQUNuQixJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNsQixNQUFNLEdBQUcsS0FBSyxDQUFDO1FBQ2pCLENBQUM7YUFBTSxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN6QixNQUFNLEdBQUcsU0FBUyxDQUFDO1FBQ3JCLENBQUM7YUFBTSxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN6QixNQUFNLEdBQUcsU0FBUyxDQUFDO1FBQ3JCLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxHQUFHLFVBQVUsQ0FBQztRQUN0QixDQUFDO1FBRUQsTUFBTSxXQUFXLEdBQ2YsS0FBSyxDQUFDLE1BQU0sR0FBRyxDQUFDO1lBQ2QsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxTQUFTLGFBQWEsTUFBTSxNQUFNO1lBQzlELENBQUMsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDLCtCQUErQjtRQUN0RSxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7UUFDbkIsSUFBSSxDQUFDLElBQUksR0FBRyxvQkFBb0IsQ0FBQztRQUNqQyxJQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztRQUNuQixJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQztRQUN6QixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztRQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztRQUMzQixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztJQUM3QixDQUFDO0lBRUQsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFjO1FBQ3RCLE9BQU8sS0FBSyxZQUFZLGtCQUFrQixDQUFDO0lBQzdDLENBQUM7Q0FDRjtBQUVELE1BQU0sVUFBVSxPQUFPO0lBQ3JCLE1BQU0sSUFBSSxLQUFLLENBQUMscUNBQXFDLENBQUMsQ0FBQztBQUN6RCxDQUFDIn0=
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/telemetry.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "deserializeTraceCarrier",
    ()=>deserializeTraceCarrier,
    "getActiveSpan",
    ()=>getActiveSpan,
    "getSpanContextForTraceCarrier",
    ()=>getSpanContextForTraceCarrier,
    "getSpanKind",
    ()=>getSpanKind,
    "instrumentObject",
    ()=>instrumentObject,
    "linkToCurrentContext",
    ()=>linkToCurrentContext,
    "serializeTraceCarrier",
    ()=>serializeTraceCarrier,
    "trace",
    ()=>trace,
    "withOtel",
    ()=>withOtel,
    "withTraceContext",
    ()=>withTraceContext
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$global$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/global.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/telemetry/semantic-conventions.js [app-route] (ecmascript)");
;
;
;
async function serializeTraceCarrier() {
    const otel = await OtelApi.value;
    if (!otel) return {};
    const carrier = {};
    // Inject the current context into the carrier
    otel.propagation.inject(otel.context.active(), carrier);
    return carrier;
}
async function deserializeTraceCarrier(traceCarrier) {
    const otel = await OtelApi.value;
    if (!otel) return;
    // Extract the context from the carrier
    return otel.propagation.extract(otel.context.active(), traceCarrier);
}
async function withTraceContext(traceCarrier, fn) {
    if (!traceCarrier) {
        return fn();
    }
    const otel = await OtelApi.value;
    if (!otel) return fn();
    const extractedContext = await deserializeTraceCarrier(traceCarrier);
    if (!extractedContext) {
        return fn();
    }
    return otel.context.with(extractedContext, async ()=>await fn());
}
const OtelApi = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["once"])(async ()=>{
    try {
        return await __turbopack_context__.A("[project]/node_modules/@opentelemetry/api/build/esm/index.js [app-route] (ecmascript, async loader)");
    } catch  {
        console.warn('OpenTelemetry not available, tracing will be disabled');
        return null;
    }
});
const Tracer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["once"])(async ()=>{
    const api = await OtelApi.value;
    if (!api) return null;
    return api.trace.getTracer('workflow');
});
async function trace(spanName, ...args) {
    const [tracer, otel] = await Promise.all([
        Tracer.value,
        OtelApi.value
    ]);
    const { fn, opts } = typeof args[0] === 'function' ? {
        fn: args[0],
        opts: {}
    } : {
        fn: args[1],
        opts: args[0]
    };
    if (!fn) throw new Error('Function to trace must be provided');
    if (!tracer || !otel) {
        return await fn();
    }
    return tracer.startActiveSpan(spanName, opts, async (span)=>{
        try {
            const result = await fn(span);
            span.setStatus({
                code: otel.SpanStatusCode.OK
            });
            return result;
        } catch (e) {
            span.setStatus({
                code: otel.SpanStatusCode.ERROR,
                message: e.message
            });
            applyWorkflowSuspensionToSpan(e, otel, span);
            throw e;
        } finally{
            span.end();
        }
    });
}
/**
 * Applies workflow suspension attributes to the given span if the error is a WorkflowSuspension
 * which is technically not an error, but an algebraic effect indicating suspension.
 */ function applyWorkflowSuspensionToSpan(error, otel, span) {
    if (!error || !__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$global$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowSuspension"].is(error)) {
        return;
    }
    span.setStatus({
        code: otel.SpanStatusCode.OK
    });
    span.setAttributes({
        ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowSuspensionState"]('suspended'),
        ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowSuspensionStepCount"](error.stepCount),
        ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowSuspensionHookCount"](error.hookCount),
        ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowSuspensionWaitCount"](error.waitCount)
    });
}
async function getSpanContextForTraceCarrier(carrier) {
    const [deserialized, otel] = await Promise.all([
        deserializeTraceCarrier(carrier),
        OtelApi.value
    ]);
    if (!deserialized || !otel) return;
    return otel.trace.getSpanContext(deserialized);
}
async function getActiveSpan() {
    return await withOtel((otel)=>otel.trace.getActiveSpan());
}
function instrumentObject(prefix, o) {
    const handlers = {};
    for (const key of Object.keys(o)){
        if (typeof o[key] !== 'function') {
            handlers[key] = o[key];
        } else {
            const f = o[key];
            // @ts-expect-error
            handlers[key] = async (...args)=>trace(`${prefix}.${String(key)}`, {}, ()=>f(...args));
        }
    }
    return handlers;
}
async function getSpanKind(field) {
    return withOtel((x)=>x.SpanKind[field]);
}
async function withOtel(fn) {
    const otel = await OtelApi.value;
    if (!otel) return undefined;
    return await fn(otel);
}
function linkToCurrentContext() {
    return withOtel((otel)=>{
        const context = otel.trace.getActiveSpan()?.spanContext();
        if (!context) return;
        return [
            {
                context
            }
        ];
    });
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVsZW1ldHJ5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vc3JjL3RlbGVtZXRyeS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQSxPQUFPLEVBQUUsSUFBSSxFQUFFLE1BQU0saUJBQWlCLENBQUM7QUFDdkMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLE1BQU0sYUFBYSxDQUFDO0FBQ2pELE9BQU8sS0FBSyxJQUFJLE1BQU0scUNBQXFDLENBQUM7QUFFNUQsK0RBQStEO0FBQy9ELHNDQUFzQztBQUN0QywrREFBK0Q7QUFFL0Q7OztHQUdHO0FBQ0gsTUFBTSxDQUFDLEtBQUssVUFBVSxxQkFBcUI7SUFDekMsTUFBTSxJQUFJLEdBQUcsTUFBTSxPQUFPLENBQUMsS0FBSyxDQUFDO0lBQ2pDLElBQUksQ0FBQyxJQUFJO1FBQUUsT0FBTyxFQUFFLENBQUM7SUFDckIsTUFBTSxPQUFPLEdBQTJCLEVBQUUsQ0FBQztJQUMzQyw4Q0FBOEM7SUFDOUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxPQUFPLENBQUMsQ0FBQztJQUN4RCxPQUFPLE9BQU8sQ0FBQztBQUNqQixDQUFDO0FBRUQ7Ozs7R0FJRztBQUNILE1BQU0sQ0FBQyxLQUFLLFVBQVUsdUJBQXVCLENBQzNDLFlBQW9DO0lBRXBDLE1BQU0sSUFBSSxHQUFHLE1BQU0sT0FBTyxDQUFDLEtBQUssQ0FBQztJQUNqQyxJQUFJLENBQUMsSUFBSTtRQUFFLE9BQU87SUFDbEIsdUNBQXVDO0lBQ3ZDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxZQUFZLENBQUMsQ0FBQztBQUN2RSxDQUFDO0FBRUQ7Ozs7O0dBS0c7QUFDSCxNQUFNLENBQUMsS0FBSyxVQUFVLGdCQUFnQixDQUNwQyxZQUFnRCxFQUNoRCxFQUFvQjtJQUVwQixJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7UUFDbEIsT0FBTyxFQUFFLEVBQUUsQ0FBQztJQUNkLENBQUM7SUFFRCxNQUFNLElBQUksR0FBRyxNQUFNLE9BQU8sQ0FBQyxLQUFLLENBQUM7SUFDakMsSUFBSSxDQUFDLElBQUk7UUFBRSxPQUFPLEVBQUUsRUFBRSxDQUFDO0lBRXZCLE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSx1QkFBdUIsQ0FBQyxZQUFZLENBQUMsQ0FBQztJQUNyRSxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztRQUN0QixPQUFPLEVBQUUsRUFBRSxDQUFDO0lBQ2QsQ0FBQztJQUVELE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxJQUFJLEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDckUsQ0FBQztBQUVELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRTtJQUM5QixJQUFJLENBQUM7UUFDSCxPQUFPLE1BQU0sTUFBTSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUFDLE1BQU0sQ0FBQztRQUNQLE9BQU8sQ0FBQyxJQUFJLENBQUMsdURBQXVELENBQUMsQ0FBQztRQUN0RSxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7QUFDSCxDQUFDLENBQUMsQ0FBQztBQUVILE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLElBQUksRUFBRTtJQUM3QixNQUFNLEdBQUcsR0FBRyxNQUFNLE9BQU8sQ0FBQyxLQUFLLENBQUM7SUFDaEMsSUFBSSxDQUFDLEdBQUc7UUFBRSxPQUFPLElBQUksQ0FBQztJQUN0QixPQUFPLEdBQUcsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQyxDQUFDO0FBQ3pDLENBQUMsQ0FBQyxDQUFDO0FBRUgsTUFBTSxDQUFDLEtBQUssVUFBVSxLQUFLLENBQ3pCLFFBQWdCLEVBQ2hCLEdBQUcsSUFFcUQ7SUFFeEQsTUFBTSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO0lBQ3hFLE1BQU0sRUFBRSxFQUFFLEVBQUUsSUFBSSxFQUFFLEdBQ2hCLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLFVBQVU7UUFDM0IsQ0FBQyxDQUFDLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFO1FBQzNCLENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO0lBQ3JDLElBQUksQ0FBQyxFQUFFO1FBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0lBRS9ELElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNyQixPQUFPLE1BQU0sRUFBRSxFQUFFLENBQUM7SUFDcEIsQ0FBQztJQUVELE9BQU8sTUFBTSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsRUFBRTtRQUMzRCxJQUFJLENBQUM7WUFDSCxNQUFNLE1BQU0sR0FBRyxNQUFNLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUM5QixJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNqRCxPQUFPLE1BQU0sQ0FBQztRQUNoQixDQUFDO1FBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztZQUNYLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ2IsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsS0FBSztnQkFDL0IsT0FBTyxFQUFHLENBQVcsQ0FBQyxPQUFPO2FBQzlCLENBQUMsQ0FBQztZQUNILDZCQUE2QixDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUM7WUFDN0MsTUFBTSxDQUFDLENBQUM7UUFDVixDQUFDO2dCQUFTLENBQUM7WUFDVCxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFDYixDQUFDO0lBQ0gsQ0FBQyxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQ7OztHQUdHO0FBQ0gsU0FBUyw2QkFBNkIsQ0FDcEMsS0FBYyxFQUNkLElBQWdCLEVBQ2hCLElBQWM7SUFFZCxJQUFJLENBQUMsS0FBSyxJQUFJLENBQUMsa0JBQWtCLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7UUFDNUMsT0FBTztJQUNULENBQUM7SUFFRCxJQUFJLENBQUMsU0FBUyxDQUFDLEVBQUUsSUFBSSxFQUFFLElBQUksQ0FBQyxjQUFjLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUNqRCxJQUFJLENBQUMsYUFBYSxDQUFDO1FBQ2pCLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUFDLFdBQVcsQ0FBQztRQUM1QyxHQUFHLElBQUksQ0FBQywyQkFBMkIsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO1FBQ3BELEdBQUcsSUFBSSxDQUFDLDJCQUEyQixDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7UUFDcEQsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztLQUNyRCxDQUFDLENBQUM7QUFDTCxDQUFDO0FBRUQsTUFBTSxDQUFDLEtBQUssVUFBVSw2QkFBNkIsQ0FDakQsT0FBK0I7SUFFL0IsTUFBTSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsR0FBRyxNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7UUFDN0MsdUJBQXVCLENBQUMsT0FBTyxDQUFDO1FBQ2hDLE9BQU8sQ0FBQyxLQUFLO0tBQ2QsQ0FBQyxDQUFDO0lBQ0gsSUFBSSxDQUFDLFlBQVksSUFBSSxDQUFDLElBQUk7UUFBRSxPQUFPO0lBQ25DLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDakQsQ0FBQztBQUVELE1BQU0sQ0FBQyxLQUFLLFVBQVUsYUFBYTtJQUNqQyxPQUFPLE1BQU0sUUFBUSxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxDQUFDLENBQUM7QUFDOUQsQ0FBQztBQUVELE1BQU0sVUFBVSxnQkFBZ0IsQ0FBbUIsTUFBYyxFQUFFLENBQUk7SUFDckUsTUFBTSxRQUFRLEdBQUcsRUFBTyxDQUFDO0lBQ3pCLEtBQUssTUFBTSxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQWdCLEVBQUUsQ0FBQztRQUNoRCxJQUFJLE9BQU8sQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLFVBQVUsRUFBRSxDQUFDO1lBQ2pDLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDekIsQ0FBQzthQUFNLENBQUM7WUFDTixNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDakIsbUJBQW1CO1lBQ25CLFFBQVEsQ0FBQyxHQUFHLENBQUMsR0FBRyxLQUFLLEVBQUUsR0FBRyxJQUFXLEVBQUUsRUFBRSxDQUN2QyxLQUFLLENBQUMsR0FBRyxNQUFNLElBQUksTUFBTSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7UUFDNUQsQ0FBQztJQUNILENBQUM7SUFDRCxPQUFPLFFBQVEsQ0FBQztBQUNsQixDQUFDO0FBRUQsTUFBTSxDQUFDLEtBQUssVUFBVSxXQUFXLENBQUMsS0FBNEI7SUFDNUQsT0FBTyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztBQUM1QyxDQUFDO0FBRUQsTUFBTSxDQUFDLEtBQUssVUFBVSxRQUFRLENBQzVCLEVBQTJCO0lBRTNCLE1BQU0sSUFBSSxHQUFHLE1BQU0sT0FBTyxDQUFDLEtBQUssQ0FBQztJQUNqQyxJQUFJLENBQUMsSUFBSTtRQUFFLE9BQU8sU0FBUyxDQUFDO0lBQzVCLE9BQU8sTUFBTSxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEIsQ0FBQztBQUVELE1BQU0sVUFBVSxvQkFBb0I7SUFDbEMsT0FBTyxRQUFRLENBQUMsQ0FBQyxJQUFJLEVBQTBCLEVBQUU7UUFDL0MsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxhQUFhLEVBQUUsRUFBRSxXQUFXLEVBQUUsQ0FBQztRQUMxRCxJQUFJLENBQUMsT0FBTztZQUFFLE9BQU87UUFDckIsT0FBTyxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQztJQUN2QixDQUFDLENBQUMsQ0FBQztBQUNMLENBQUMifQ==
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/util.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "buildWorkflowSuspensionMessage",
    ()=>buildWorkflowSuspensionMessage,
    "getWorkflowRunStreamId",
    ()=>getWorkflowRunStreamId,
    "waitedUntil",
    ()=>waitedUntil
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$functions$40$3$2e$3$2e$4_$40$aw_2a5c995af0e20f04763be3d47c13fa7b$2f$node_modules$2f40$vercel$2f$functions$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/index.js [app-route] (ecmascript)");
;
function buildWorkflowSuspensionMessage(runId, stepCount, hookCount, waitCount) {
    if (stepCount === 0 && hookCount === 0 && waitCount === 0) {
        return null;
    }
    const parts = [];
    if (stepCount > 0) {
        parts.push(`${stepCount} ${stepCount === 1 ? 'step' : 'steps'}`);
    }
    if (hookCount > 0) {
        parts.push(`${hookCount} ${hookCount === 1 ? 'hook' : 'hooks'}`);
    }
    if (waitCount > 0) {
        parts.push(`${waitCount} ${waitCount === 1 ? 'timer' : 'timers'}`);
    }
    const resumeMsgParts = [];
    if (stepCount > 0) {
        resumeMsgParts.push('steps are completed');
    }
    if (hookCount > 0) {
        resumeMsgParts.push('hooks are received');
    }
    if (waitCount > 0) {
        resumeMsgParts.push('timers have elapsed');
    }
    const resumeMsg = resumeMsgParts.join(' and ');
    return `[Workflows] "${runId}" - ${parts.join(' and ')} to be enqueued\n  Workflow will suspend and resume when ${resumeMsg}`;
}
function getWorkflowRunStreamId(runId, namespace) {
    const streamId = `${runId.replace('wrun_', 'strm_')}_user`;
    if (!namespace) {
        return streamId;
    }
    // Base64 encode the namespace to handle special characters that may not be allowed in Redis keys
    const encodedNamespace = Buffer.from(namespace, 'utf-8').toString('base64url');
    return `${streamId}_${encodedNamespace}`;
}
async function waitedUntil(fn) {
    const result = fn();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$functions$40$3$2e$3$2e$4_$40$aw_2a5c995af0e20f04763be3d47c13fa7b$2f$node_modules$2f40$vercel$2f$functions$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["waitUntil"])(result.catch(()=>{
    // Ignore error from the promise being rejected.
    // It's expected that the invoker of `waitedUntil`
    // will handle the error.
    }));
    return result;
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXRpbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy91dGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsTUFBTSxtQkFBbUIsQ0FBQztBQUU5Qzs7Ozs7OztHQU9HO0FBQ0gsTUFBTSxVQUFVLDhCQUE4QixDQUM1QyxLQUFhLEVBQ2IsU0FBaUIsRUFDakIsU0FBaUIsRUFDakIsU0FBaUI7SUFFakIsSUFBSSxTQUFTLEtBQUssQ0FBQyxJQUFJLFNBQVMsS0FBSyxDQUFDLElBQUksU0FBUyxLQUFLLENBQUMsRUFBRSxDQUFDO1FBQzFELE9BQU8sSUFBSSxDQUFDO0lBQ2QsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLEVBQUUsQ0FBQztJQUNqQixJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNsQixLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsU0FBUyxJQUFJLFNBQVMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBQ0QsSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDbEIsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLFNBQVMsSUFBSSxTQUFTLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFDbkUsQ0FBQztJQUNELElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ2xCLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFTLElBQUksU0FBUyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO0lBQ3JFLENBQUM7SUFFRCxNQUFNLGNBQWMsR0FBYSxFQUFFLENBQUM7SUFDcEMsSUFBSSxTQUFTLEdBQUcsQ0FBQyxFQUFFLENBQUM7UUFDbEIsY0FBYyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFDO0lBQzdDLENBQUM7SUFDRCxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztRQUNsQixjQUFjLENBQUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLENBQUM7SUFDNUMsQ0FBQztJQUNELElBQUksU0FBUyxHQUFHLENBQUMsRUFBRSxDQUFDO1FBQ2xCLGNBQWMsQ0FBQyxJQUFJLENBQUMscUJBQXFCLENBQUMsQ0FBQztJQUM3QyxDQUFDO0lBQ0QsTUFBTSxTQUFTLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUUvQyxPQUFPLGdCQUFnQixLQUFLLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsNERBQTRELFNBQVMsRUFBRSxDQUFDO0FBQ2hJLENBQUM7QUFFRDs7Ozs7Ozs7R0FRRztBQUNILE1BQU0sVUFBVSxzQkFBc0IsQ0FBQyxLQUFhLEVBQUUsU0FBa0I7SUFDdEUsTUFBTSxRQUFRLEdBQUcsR0FBRyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsT0FBTyxDQUFDO0lBQzNELElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNmLE9BQU8sUUFBUSxDQUFDO0lBQ2xCLENBQUM7SUFDRCxpR0FBaUc7SUFDakcsTUFBTSxnQkFBZ0IsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxPQUFPLENBQUMsQ0FBQyxRQUFRLENBQy9ELFdBQVcsQ0FDWixDQUFDO0lBQ0YsT0FBTyxHQUFHLFFBQVEsSUFBSSxnQkFBZ0IsRUFBRSxDQUFDO0FBQzNDLENBQUM7QUFFRDs7O0dBR0c7QUFDSCxNQUFNLENBQUMsS0FBSyxVQUFVLFdBQVcsQ0FBSSxFQUFvQjtJQUN2RCxNQUFNLE1BQU0sR0FBRyxFQUFFLEVBQUUsQ0FBQztJQUNwQixTQUFTLENBQ1AsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUU7UUFDaEIsZ0RBQWdEO1FBQ2hELGtEQUFrRDtRQUNsRCx5QkFBeUI7SUFDM0IsQ0FBQyxDQUFDLENBQ0gsQ0FBQztJQUNGLE9BQU8sTUFBTSxDQUFDO0FBQ2hCLENBQUMifQ==
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime/resume-hook.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getHookByToken",
    ()=>getHookByToken,
    "resumeHook",
    ()=>resumeHook,
    "resumeWebhook",
    ()=>resumeWebhook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$functions$40$3$2e$3$2e$4_$40$aw_2a5c995af0e20f04763be3d47c13fa7b$2f$node_modules$2f40$vercel$2f$functions$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+functions@3.3.4_@aw_2a5c995af0e20f04763be3d47c13fa7b/node_modules/@vercel/functions/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$serialization$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/serialization.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/symbols.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/telemetry/semantic-conventions.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/telemetry.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/util.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$world$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime/world.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
async function getHookByToken(token) {
    const world = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$world$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorld"])();
    const hook = await world.hooks.getByToken(token);
    if (typeof hook.metadata !== 'undefined') {
        hook.metadata = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$serialization$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hydrateStepArguments"])(hook.metadata, [], hook.runId);
    }
    return hook;
}
async function resumeHook(token, payload) {
    return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["waitedUntil"])(()=>{
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["trace"])('HOOK.resume', async (span)=>{
            const world = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$world$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorld"])();
            try {
                const hook = await getHookByToken(token);
                span?.setAttributes({
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookToken"](token),
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookId"](hook.hookId),
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunId"](hook.runId)
                });
                // Dehydrate the payload for storage
                const ops = [];
                const dehydratedPayload = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$serialization$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dehydrateStepReturnValue"])(payload, ops, hook.runId);
                // NOTE: Workaround instead of injecting catching undefined unhandled rejections in webhook bundle
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$functions$40$3$2e$3$2e$4_$40$aw_2a5c995af0e20f04763be3d47c13fa7b$2f$node_modules$2f40$vercel$2f$functions$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["waitUntil"])(Promise.all(ops).catch((err)=>{
                    if (err !== undefined) throw err;
                }));
                // Create a hook_received event with the payload
                await world.events.create(hook.runId, {
                    eventType: 'hook_received',
                    correlationId: hook.hookId,
                    eventData: {
                        payload: dehydratedPayload
                    }
                });
                const workflowRun = await world.runs.get(hook.runId);
                span?.setAttributes({
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowName"](workflowRun.workflowName)
                });
                const traceCarrier = workflowRun.executionContext?.traceCarrier;
                if (traceCarrier) {
                    const context = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSpanContextForTraceCarrier"])(traceCarrier);
                    if (context) {
                        span?.addLink?.({
                            context
                        });
                    }
                }
                // Re-trigger the workflow against the deployment ID associated
                // with the workflow run that the hook belongs to
                await world.queue(`__wkf_workflow_${workflowRun.workflowName}`, {
                    runId: hook.runId,
                    // attach the trace carrier from the workflow run
                    traceCarrier: workflowRun.executionContext?.traceCarrier ?? undefined
                }, {
                    deploymentId: workflowRun.deploymentId
                });
                return hook;
            } catch (err) {
                span?.setAttributes({
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookToken"](token),
                    ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$telemetry$2f$semantic$2d$conventions$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookFound"](false)
                });
                throw err;
            }
        });
    });
}
async function resumeWebhook(token, request) {
    const hook = await getHookByToken(token);
    let response;
    let responseReadable;
    if (hook.metadata && typeof hook.metadata === 'object' && 'respondWith' in hook.metadata) {
        if (hook.metadata.respondWith === 'manual') {
            const { readable, writable } = new TransformStream();
            responseReadable = readable;
            // The request instance includes the writable stream which will be used
            // to write the response to the client from within the workflow run
            request[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WEBHOOK_RESPONSE_WRITABLE"]] = writable;
        } else if (hook.metadata.respondWith instanceof Response) {
            response = hook.metadata.respondWith;
        } else {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRuntimeError"](`Invalid \`respondWith\` value: ${hook.metadata.respondWith}`, {
                slug: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ERROR_SLUGS"].WEBHOOK_INVALID_RESPOND_WITH_VALUE
            });
        }
    } else {
        // No `respondWith` value implies the default behavior of returning a 202
        response = new Response(null, {
            status: 202
        });
    }
    await resumeHook(hook.token, request);
    if (responseReadable) {
        // Wait for the readable stream to emit one chunk,
        // which is the `Response` object
        const reader = responseReadable.getReader();
        const chunk = await reader.read();
        if (chunk.value) {
            response = chunk.value;
        }
        reader.cancel();
    }
    if (!response) {
        throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRuntimeError"]('Workflow run did not send a response', {
            slug: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ERROR_SLUGS"].WEBHOOK_RESPONSE_NOT_SENT
        });
    }
    return response;
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzdW1lLWhvb2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvcnVudGltZS9yZXN1bWUtaG9vay50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0sbUJBQW1CLENBQUM7QUFDOUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxvQkFBb0IsRUFBRSxNQUFNLGtCQUFrQixDQUFDO0FBRXJFLE9BQU8sRUFDTCx3QkFBd0IsRUFDeEIsb0JBQW9CLEdBQ3JCLE1BQU0scUJBQXFCLENBQUM7QUFDN0IsT0FBTyxFQUFFLHlCQUF5QixFQUFFLE1BQU0sZUFBZSxDQUFDO0FBQzFELE9BQU8sS0FBSyxTQUFTLE1BQU0sc0NBQXNDLENBQUM7QUFDbEUsT0FBTyxFQUFFLDZCQUE2QixFQUFFLEtBQUssRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQ3ZFLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDekMsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUV0Qzs7Ozs7O0dBTUc7QUFDSCxNQUFNLENBQUMsS0FBSyxVQUFVLGNBQWMsQ0FBQyxLQUFhO0lBQ2hELE1BQU0sS0FBSyxHQUFHLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLE1BQU0sSUFBSSxHQUFHLE1BQU0sS0FBSyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDakQsSUFBSSxPQUFPLElBQUksQ0FBQyxRQUFRLEtBQUssV0FBVyxFQUFFLENBQUM7UUFDekMsSUFBSSxDQUFDLFFBQVEsR0FBRyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsUUFBZSxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7SUFDN0UsQ0FBQztJQUNELE9BQU8sSUFBSSxDQUFDO0FBQ2QsQ0FBQztBQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBNEJHO0FBQ0gsTUFBTSxDQUFDLEtBQUssVUFBVSxVQUFVLENBQzlCLEtBQWEsRUFDYixPQUFVO0lBRVYsT0FBTyxNQUFNLFdBQVcsQ0FBQyxHQUFHLEVBQUU7UUFDNUIsT0FBTyxLQUFLLENBQUMsYUFBYSxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsRUFBRTtZQUN6QyxNQUFNLEtBQUssR0FBRyxRQUFRLEVBQUUsQ0FBQztZQUV6QixJQUFJLENBQUM7Z0JBQ0gsTUFBTSxJQUFJLEdBQUcsTUFBTSxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBRXpDLElBQUksRUFBRSxhQUFhLENBQUM7b0JBQ2xCLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7b0JBQzdCLEdBQUcsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO29CQUNoQyxHQUFHLFNBQVMsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztpQkFDdkMsQ0FBQyxDQUFDO2dCQUVILG9DQUFvQztnQkFDcEMsTUFBTSxHQUFHLEdBQW1CLEVBQUUsQ0FBQztnQkFDL0IsTUFBTSxpQkFBaUIsR0FBRyx3QkFBd0IsQ0FDaEQsT0FBTyxFQUNQLEdBQUcsRUFDSCxJQUFJLENBQUMsS0FBSyxDQUNYLENBQUM7Z0JBQ0Ysa0dBQWtHO2dCQUNsRyxTQUFTLENBQ1AsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHLEVBQUUsRUFBRTtvQkFDN0IsSUFBSSxHQUFHLEtBQUssU0FBUzt3QkFBRSxNQUFNLEdBQUcsQ0FBQztnQkFDbkMsQ0FBQyxDQUFDLENBQ0gsQ0FBQztnQkFFRixnREFBZ0Q7Z0JBQ2hELE1BQU0sS0FBSyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRTtvQkFDcEMsU0FBUyxFQUFFLGVBQWU7b0JBQzFCLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTTtvQkFDMUIsU0FBUyxFQUFFO3dCQUNULE9BQU8sRUFBRSxpQkFBaUI7cUJBQzNCO2lCQUNGLENBQUMsQ0FBQztnQkFFSCxNQUFNLFdBQVcsR0FBRyxNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztnQkFFckQsSUFBSSxFQUFFLGFBQWEsQ0FBQztvQkFDbEIsR0FBRyxTQUFTLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxZQUFZLENBQUM7aUJBQ3BELENBQUMsQ0FBQztnQkFFSCxNQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsWUFBWSxDQUFDO2dCQUVoRSxJQUFJLFlBQVksRUFBRSxDQUFDO29CQUNqQixNQUFNLE9BQU8sR0FBRyxNQUFNLDZCQUE2QixDQUFDLFlBQVksQ0FBQyxDQUFDO29CQUNsRSxJQUFJLE9BQU8sRUFBRSxDQUFDO3dCQUNaLElBQUksRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUM7b0JBQy9CLENBQUM7Z0JBQ0gsQ0FBQztnQkFFRCwrREFBK0Q7Z0JBQy9ELGlEQUFpRDtnQkFDakQsTUFBTSxLQUFLLENBQUMsS0FBSyxDQUNmLGtCQUFrQixXQUFXLENBQUMsWUFBWSxFQUFFLEVBQzVDO29CQUNFLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztvQkFDakIsaURBQWlEO29CQUNqRCxZQUFZLEVBQ1YsV0FBVyxDQUFDLGdCQUFnQixFQUFFLFlBQVksSUFBSSxTQUFTO2lCQUMxQixFQUNqQztvQkFDRSxZQUFZLEVBQUUsV0FBVyxDQUFDLFlBQVk7aUJBQ3ZDLENBQ0YsQ0FBQztnQkFFRixPQUFPLElBQUksQ0FBQztZQUNkLENBQUM7WUFBQyxPQUFPLEdBQUcsRUFBRSxDQUFDO2dCQUNiLElBQUksRUFBRSxhQUFhLENBQUM7b0JBQ2xCLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7b0JBQzdCLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUM7aUJBQzlCLENBQUMsQ0FBQztnQkFDSCxNQUFNLEdBQUcsQ0FBQztZQUNaLENBQUM7UUFDSCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUMsQ0FBQyxDQUFDO0FBQ0wsQ0FBQztBQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBa0NHO0FBQ0gsTUFBTSxDQUFDLEtBQUssVUFBVSxhQUFhLENBQ2pDLEtBQWEsRUFDYixPQUFnQjtJQUVoQixNQUFNLElBQUksR0FBRyxNQUFNLGNBQWMsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUV6QyxJQUFJLFFBQThCLENBQUM7SUFDbkMsSUFBSSxnQkFBc0QsQ0FBQztJQUMzRCxJQUNFLElBQUksQ0FBQyxRQUFRO1FBQ2IsT0FBTyxJQUFJLENBQUMsUUFBUSxLQUFLLFFBQVE7UUFDakMsYUFBYSxJQUFJLElBQUksQ0FBQyxRQUFRLEVBQzlCLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxLQUFLLFFBQVEsRUFBRSxDQUFDO1lBQzNDLE1BQU0sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUcsSUFBSSxlQUFlLEVBQXNCLENBQUM7WUFDekUsZ0JBQWdCLEdBQUcsUUFBUSxDQUFDO1lBRTVCLHVFQUF1RTtZQUN2RSxtRUFBbUU7WUFDbEUsT0FBZSxDQUFDLHlCQUF5QixDQUFDLEdBQUcsUUFBUSxDQUFDO1FBQ3pELENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxZQUFZLFFBQVEsRUFBRSxDQUFDO1lBQ3pELFFBQVEsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQztRQUN2QyxDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sSUFBSSxvQkFBb0IsQ0FDNUIsa0NBQWtDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxFQUFFLEVBQzdELEVBQUUsSUFBSSxFQUFFLFdBQVcsQ0FBQyxrQ0FBa0MsRUFBRSxDQUN6RCxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7U0FBTSxDQUFDO1FBQ04seUVBQXlFO1FBQ3pFLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRUQsTUFBTSxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUMsQ0FBQztJQUV0QyxJQUFJLGdCQUFnQixFQUFFLENBQUM7UUFDckIsa0RBQWtEO1FBQ2xELGlDQUFpQztRQUNqQyxNQUFNLE1BQU0sR0FBRyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUM1QyxNQUFNLEtBQUssR0FBRyxNQUFNLE1BQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNsQyxJQUFJLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQztZQUNoQixRQUFRLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztRQUN6QixDQUFDO1FBQ0QsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO0lBQ2xCLENBQUM7SUFFRCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUM7UUFDZCxNQUFNLElBQUksb0JBQW9CLENBQUMsc0NBQXNDLEVBQUU7WUFDckUsSUFBSSxFQUFFLFdBQVcsQ0FBQyx5QkFBeUI7U0FDNUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVELE9BQU8sUUFBUSxDQUFDO0FBQ2xCLENBQUMifQ==
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/define-hook.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "defineHook",
    ()=>defineHook
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$resume$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime/resume-hook.js [app-route] (ecmascript)");
;
function defineHook({ schema } = {}) {
    return {
        create (_options) {
            throw new Error('`defineHook().create()` can only be called inside a workflow function.');
        },
        async resume (token, payload) {
            if (!schema?.['~standard']) {
                return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$resume$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resumeHook"])(token, payload);
            }
            let result = schema['~standard'].validate(payload);
            if (result instanceof Promise) {
                result = await result;
            }
            // if the `issues` field exists, the validation failed
            if (result.issues) {
                throw new Error(JSON.stringify(result.issues, null, 2));
            }
            return await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2f$resume$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resumeHook"])(token, result.value);
        }
    };
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGVmaW5lLWhvb2suanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvZGVmaW5lLWhvb2sudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0EsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLDBCQUEwQixDQUFDO0FBdUN0RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0dBOEJHO0FBQ0gsTUFBTSxVQUFVLFVBQVUsQ0FBMkIsRUFDbkQsTUFBTSxNQUdKLEVBQUU7SUFDSixPQUFPO1FBQ0wsTUFBTSxDQUFDLFFBQXNCO1lBQzNCLE1BQU0sSUFBSSxLQUFLLENBQ2Isd0VBQXdFLENBQ3pFLENBQUM7UUFDSixDQUFDO1FBQ0QsS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFhLEVBQUUsT0FBZTtZQUN6QyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztnQkFDM0IsT0FBTyxNQUFNLFVBQVUsQ0FBQyxLQUFLLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDMUMsQ0FBQztZQUVELElBQUksTUFBTSxHQUFHLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbkQsSUFBSSxNQUFNLFlBQVksT0FBTyxFQUFFLENBQUM7Z0JBQzlCLE1BQU0sR0FBRyxNQUFNLE1BQU0sQ0FBQztZQUN4QixDQUFDO1lBRUQsc0RBQXNEO1lBQ3RELElBQUksTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDO2dCQUNsQixNQUFNLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUMxRCxDQUFDO1lBRUQsT0FBTyxNQUFNLFVBQVUsQ0FBVSxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ3hELENBQUM7S0FDRixDQUFDO0FBQ0osQ0FBQyJ9
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/sleep.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "sleep",
    ()=>sleep
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/symbols.js [app-route] (ecmascript)");
;
async function sleep(param) {
    // Inside the workflow VM, the sleep function is stored in the globalThis object behind a symbol
    const sleepFn = globalThis[__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$symbols$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WORKFLOW_SLEEP"]];
    if (!sleepFn) {
        throw new Error('`sleep()` can only be called inside a workflow function');
    }
    return sleepFn(param);
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2xlZXAuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvc2xlZXAudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0EsT0FBTyxFQUFFLGNBQWMsRUFBRSxNQUFNLGNBQWMsQ0FBQztBQW9DOUMsTUFBTSxDQUFDLEtBQUssVUFBVSxLQUFLLENBQUMsS0FBa0M7SUFDNUQsZ0dBQWdHO0lBQ2hHLE1BQU0sT0FBTyxHQUFJLFVBQWtCLENBQUMsY0FBYyxDQUFDLENBQUM7SUFDcEQsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1FBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO0lBQzdFLENBQUM7SUFDRCxPQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUN4QixDQUFDIn0=
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-step-metadata.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getStepMetadata",
    ()=>getStepMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/context-storage.js [app-route] (ecmascript)");
;
function getStepMetadata() {
    const ctx = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["contextStorage"].getStore();
    if (!ctx) {
        throw new Error('`getStepMetadata()` can only be called inside a step function');
    }
    return ctx.stepMetadata;
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2V0LXN0ZXAtbWV0YWRhdGEuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvc3RlcC9nZXQtc3RlcC1tZXRhZGF0YS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFvQ3REOzs7O0dBSUc7QUFDSCxNQUFNLFVBQVUsZUFBZTtJQUM3QixNQUFNLEdBQUcsR0FBRyxjQUFjLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDdEMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ1QsTUFBTSxJQUFJLEtBQUssQ0FDYiwrREFBK0QsQ0FDaEUsQ0FBQztJQUNKLENBQUM7SUFDRCxPQUFPLEdBQUcsQ0FBQyxZQUFZLENBQUM7QUFDMUIsQ0FBQyJ9
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-workflow-metadata.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getWorkflowMetadata",
    ()=>getWorkflowMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/context-storage.js [app-route] (ecmascript)");
;
function getWorkflowMetadata() {
    const ctx = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["contextStorage"].getStore();
    if (!ctx) {
        throw new Error('`getWorkflowMetadata()` can only be called inside a workflow or step function');
    }
    return ctx.workflowMetadata;
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ2V0LXdvcmtmbG93LW1ldGFkYXRhLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3N0ZXAvZ2V0LXdvcmtmbG93LW1ldGFkYXRhLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBLE9BQU8sRUFBRSxjQUFjLEVBQUUsTUFBTSxzQkFBc0IsQ0FBQztBQUl0RDs7R0FFRztBQUNILE1BQU0sVUFBVSxtQkFBbUI7SUFDakMsTUFBTSxHQUFHLEdBQUcsY0FBYyxDQUFDLFFBQVEsRUFBRSxDQUFDO0lBQ3RDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNULE1BQU0sSUFBSSxLQUFLLENBQ2IsK0VBQStFLENBQ2hGLENBQUM7SUFDSixDQUFDO0lBQ0QsT0FBTyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7QUFDOUIsQ0FBQyJ9
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/writable-stream.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getWritable",
    ()=>getWritable
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$serialization$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/serialization.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/util.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/context-storage.js [app-route] (ecmascript)");
;
;
;
function getWritable(options = {}) {
    const ctx = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$context$2d$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["contextStorage"].getStore();
    if (!ctx) {
        throw new Error('`getWritable()` can only be called inside a workflow or step function');
    }
    const { namespace } = options;
    const runId = ctx.workflowMetadata.workflowRunId;
    const name = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorkflowRunStreamId"])(runId, namespace);
    // Create a transform stream that serializes chunks and pipes to the workflow server
    const serialize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$serialization$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSerializeStream"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$serialization$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExternalReducers"])(globalThis, ctx.ops, runId));
    // Pipe the serialized data to the workflow server stream
    // Register this async operation with the runtime's ops array so it's awaited via waitUntil
    ctx.ops.push(serialize.readable.pipeTo(new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$serialization$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowServerWritableStream"](name, runId)));
    // Return the writable side of the transform stream
    return serialize.writable;
} //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid3JpdGFibGUtc3RyZWFtLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3N0ZXAvd3JpdGFibGUtc3RyZWFtLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFDTCxtQkFBbUIsRUFDbkIsa0JBQWtCLEVBQ2xCLDRCQUE0QixHQUM3QixNQUFNLHFCQUFxQixDQUFDO0FBQzdCLE9BQU8sRUFBRSxzQkFBc0IsRUFBRSxNQUFNLFlBQVksQ0FBQztBQUVwRCxPQUFPLEVBQUUsY0FBYyxFQUFFLE1BQU0sc0JBQXNCLENBQUM7QUFJdEQ7Ozs7Ozs7OztHQVNHO0FBQ0gsTUFBTSxVQUFVLFdBQVcsQ0FDekIsVUFBeUMsRUFBRTtJQUUzQyxNQUFNLEdBQUcsR0FBRyxjQUFjLENBQUMsUUFBUSxFQUFFLENBQUM7SUFDdEMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBQ1QsTUFBTSxJQUFJLEtBQUssQ0FDYix1RUFBdUUsQ0FDeEUsQ0FBQztJQUNKLENBQUM7SUFFRCxNQUFNLEVBQUUsU0FBUyxFQUFFLEdBQUcsT0FBTyxDQUFDO0lBQzlCLE1BQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxhQUFhLENBQUM7SUFDakQsTUFBTSxJQUFJLEdBQUcsc0JBQXNCLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO0lBRXRELG9GQUFvRjtJQUNwRixNQUFNLFNBQVMsR0FBRyxrQkFBa0IsQ0FDbEMsbUJBQW1CLENBQUMsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQ2hELENBQUM7SUFFRix5REFBeUQ7SUFDekQsMkZBQTJGO0lBQzNGLEdBQUcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUNWLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLElBQUksNEJBQTRCLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQ3pFLENBQUM7SUFFRixtREFBbUQ7SUFDbkQsT0FBTyxTQUFTLENBQUMsUUFBUSxDQUFDO0FBQzVCLENBQUMifQ==
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

/**
 * Just the core utilities that are meant to be imported by user
 * steps/workflows. This allows the bundler to tree-shake and limit what goes
 * into the final user bundles. Logic for running/handling steps/workflows
 * should live in runtime. Eventually these might be separate packages
 * `workflow` and `workflow/runtime`?
 *
 * Everything here will get re-exported under the 'workflow' top level package.
 * This should be a minimal set of APIs so **do not anything here** unless it's
 * needed for userland workflow code.
 */ __turbopack_context__.s([]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$create$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/create-hook.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$define$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/define-hook.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$sleep$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/sleep.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$get$2d$step$2d$metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-step-metadata.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$get$2d$workflow$2d$metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-workflow-metadata.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$writable$2d$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/writable-stream.js [app-route] (ecmascript)"); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi9zcmMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7Ozs7Ozs7Ozs7R0FVRztBQUVILE9BQU8sRUFDTCxVQUFVLEVBQ1YsY0FBYyxHQUVmLE1BQU0sa0JBQWtCLENBQUM7QUFDMUIsT0FBTyxFQUNMLFVBQVUsRUFDVixhQUFhLEdBTWQsTUFBTSxrQkFBa0IsQ0FBQztBQUMxQixPQUFPLEVBQUUsVUFBVSxFQUFrQixNQUFNLGtCQUFrQixDQUFDO0FBQzlELE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxZQUFZLENBQUM7QUFDbkMsT0FBTyxFQUNMLGVBQWUsR0FFaEIsTUFBTSw2QkFBNkIsQ0FBQztBQUNyQyxPQUFPLEVBQ0wsbUJBQW1CLEdBRXBCLE1BQU0saUNBQWlDLENBQUM7QUFDekMsT0FBTyxFQUNMLFdBQVcsR0FFWixNQUFNLDJCQUEyQixDQUFDIn0=
;
;
;
;
;
;
;
}),
"[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FatalError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FatalError"],
    "RetryableError",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["RetryableError"],
    "createHook",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$create$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createHook"],
    "createWebhook",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$create$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createWebhook"],
    "defineHook",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$define$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["defineHook"],
    "getStepMetadata",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$get$2d$step$2d$metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getStepMetadata"],
    "getWorkflowMetadata",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$get$2d$workflow$2d$metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWorkflowMetadata"],
    "getWritable",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$writable$2d$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getWritable"],
    "sleep",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$sleep$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sleep"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$create$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/create-hook.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$define$2d$hook$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/define-hook.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$sleep$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/sleep.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$get$2d$step$2d$metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-step-metadata.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$get$2d$workflow$2d$metadata$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/get-workflow-metadata.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$step$2f$writable$2d$stream$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/step/writable-stream.js [app-route] (ecmascript)");
}),
];

//# sourceMappingURL=91a04_%40workflow_core_dist_69ade747._.js.map