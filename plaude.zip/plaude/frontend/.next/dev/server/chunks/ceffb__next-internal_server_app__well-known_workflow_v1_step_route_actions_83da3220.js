module.exports = [
"[project]/frontend/.next-internal/server/app/.well-known/workflow/v1/step/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=ceffb__next-internal_server_app__well-known_workflow_v1_step_route_actions_83da3220.js.map