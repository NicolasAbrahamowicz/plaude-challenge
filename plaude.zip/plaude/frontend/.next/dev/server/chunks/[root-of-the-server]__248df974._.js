module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/frontend/lib/approvals-store.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/lib/approvals-store.ts
__turbopack_context__.s([
    "getLatestApproval",
    ()=>getLatestApproval,
    "saveApproval",
    ()=>saveApproval
]);
// Guardamos solo la última decisión (para el challenge alcanza)
let latestApproval = null;
function saveApproval(decision) {
    latestApproval = {
        ...decision,
        createdAt: Date.now()
    };
    console.log("[approvals-store] saveApproval called. New latestApproval:", latestApproval);
}
function getLatestApproval() {
    console.log("[approvals-store] getLatestApproval returning:", latestApproval);
    return latestApproval;
}
}),
"[project]/frontend/app/api/approval-status/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/app/api/approval-status/route.ts
__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$lib$2f$approvals$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/lib/approvals-store.ts [app-route] (ecmascript)");
;
;
async function GET(req) {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    console.log("[/api/approval-status] Incoming request:", {
        url: req.url,
        id
    });
    if (!id) {
        console.warn("[/api/approval-status] Missing id parameter");
        return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            status: "error",
            error: "Missing id parameter"
        }, {
            status: 400
        });
    }
    const latest = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$lib$2f$approvals$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getLatestApproval"])();
    console.log("[/api/approval-status] Current latestApproval:", latest);
    if (!latest || latest.id !== id) {
        console.log("[/api/approval-status] No matching approval for this id. Returning pending.");
        return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            status: "pending"
        });
    }
    const status = latest.decision === "approve" ? "approved" : "rejected";
    const body = {
        status,
        message: status === "approved" ? `The operation with id ${id} has been approved by a human operator.` : `The operation with id ${id} has been rejected by a human operator.`,
        amount: latest.amount ?? null
    };
    console.log("[/api/approval-status] Returning response:", body);
    return __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(body);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__248df974._.js.map