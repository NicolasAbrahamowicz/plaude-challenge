module.exports = [
"[project]/frontend/.next-internal/server/app/api/slack-approval/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend__next-internal_server_app_api_slack-approval_route_actions_c2917882.js.map