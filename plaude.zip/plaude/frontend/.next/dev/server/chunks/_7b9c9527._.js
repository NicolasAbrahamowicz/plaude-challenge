module.exports = [
"[project]/node_modules/@workflow/world-local/dist/util.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Creates a lazily-evaluated, memoized version of the provided function.
 *
 * The returned object exposes a `value` getter that calls `fn` only once,
 * caches its result, and returns the cached value on subsequent accesses.
 *
 * @typeParam T - The return type of the provided function.
 * @param fn - The function to be called once and whose result will be cached.
 * @returns An object with a `value` property that returns the memoized result of `fn`.
 */ __turbopack_context__.s([
    "once",
    ()=>once
]);
function once(fn) {
    const result = {
        get value () {
            const value = fn();
            Object.defineProperty(result, 'value', {
                value
            });
            return value;
        }
    };
    return result;
} //# sourceMappingURL=util.js.map
}),
"[project]/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_RESOLVE_DATA_OPTION",
    ()=>DEFAULT_RESOLVE_DATA_OPTION,
    "config",
    ()=>config,
    "resolveBaseUrl",
    ()=>resolveBaseUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$get$2d$port$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/utils/dist/get-port.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/util.js [app-route] (ecmascript)");
;
;
const getDataDirFromEnv = ()=>{
    return process.env.WORKFLOW_LOCAL_DATA_DIR || '.workflow-data';
};
const DEFAULT_RESOLVE_DATA_OPTION = 'all';
const getBaseUrlFromEnv = ()=>{
    return process.env.WORKFLOW_LOCAL_BASE_URL;
};
const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["once"])(()=>{
    const dataDir = getDataDirFromEnv();
    const baseUrl = getBaseUrlFromEnv();
    return {
        dataDir,
        baseUrl
    };
});
async function resolveBaseUrl(config) {
    if (config.baseUrl) {
        return config.baseUrl;
    }
    if (typeof config.port === 'number') {
        return `http://localhost:${config.port}`;
    }
    if (process.env.PORT) {
        return `http://localhost:${process.env.PORT}`;
    }
    const detectedPort = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$get$2d$port$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getPort"])();
    if (detectedPort) {
        return `http://localhost:${detectedPort}`;
    }
    throw new Error('Unable to resolve base URL for workflow queue.');
} //# sourceMappingURL=config.js.map
}),
"[project]/node_modules/@workflow/world-local/dist/queue.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createQueue",
    ()=>createQueue
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$timers$2f$promises__$5b$external$5d$__$28$node$3a$timers$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:timers/promises [external] (node:timers/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@vercel/queue/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$async$2d$sema$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/async-sema/lib/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$undici$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/undici/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
// For local queue, there is no technical limit on the message visibility lifespan,
// but the environment variable can be used for testing purposes to set a max visibility limit.
const LOCAL_QUEUE_MAX_VISIBILITY = parseInt(process.env.WORKFLOW_LOCAL_QUEUE_MAX_VISIBILITY ?? '0', 10) || Infinity;
// The local workers share the same Node.js process and event loop,
// so we need to limit concurrency to avoid overwhelming the system.
const DEFAULT_CONCURRENCY_LIMIT = 100;
const WORKFLOW_LOCAL_QUEUE_CONCURRENCY = parseInt(process.env.WORKFLOW_LOCAL_QUEUE_CONCURRENCY ?? '0', 10) || DEFAULT_CONCURRENCY_LIMIT;
// Create a custom agent optimized for high-concurrency local workflows:
// - headersTimeout: 0 allows long-running steps
// - connections: 100 allows many parallel connections to the same host
// - pipelining: 1 (default) for HTTP/1.1 compatibility
// - keepAliveTimeout: 30s keeps connections warm for rapid step execution
const httpAgent = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$undici$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Agent"]({
    headersTimeout: 0,
    connections: 100,
    keepAliveTimeout: 30_000
});
function createQueue(config) {
    const transport = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["JsonTransport"]();
    const generateId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])();
    const semaphore = new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$async$2d$sema$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Sema"](WORKFLOW_LOCAL_QUEUE_CONCURRENCY);
    /**
     * holds inflight messages by idempotency key to ensure
     * that we don't queue the same message multiple times
     */ const inflightMessages = new Map();
    const queue = async (queueName, message, opts)=>{
        const cleanup = [];
        if (opts?.idempotencyKey) {
            const existing = inflightMessages.get(opts.idempotencyKey);
            if (existing) {
                return {
                    messageId: existing
                };
            }
        }
        const body = transport.serialize(message);
        let pathname;
        if (queueName.startsWith('__wkf_step_')) {
            pathname = `step`;
        } else if (queueName.startsWith('__wkf_workflow_')) {
            pathname = `flow`;
        } else {
            throw new Error('Unknown queue name prefix');
        }
        const messageId = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"].parse(`msg_${generateId()}`);
        if (opts?.idempotencyKey) {
            const key = opts.idempotencyKey;
            inflightMessages.set(key, messageId);
            cleanup.push(()=>{
                inflightMessages.delete(key);
            });
        }
        (async ()=>{
            const token = semaphore.tryAcquire();
            if (!token) {
                console.warn(`[world-local]: concurrency limit (${WORKFLOW_LOCAL_QUEUE_CONCURRENCY}) reached, waiting for queue to free up`);
                await semaphore.acquire();
            }
            try {
                let defaultRetriesLeft = 3;
                const baseUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resolveBaseUrl"])(config);
                for(let attempt = 0; defaultRetriesLeft > 0; attempt++){
                    defaultRetriesLeft--;
                    const response = await fetch(`${baseUrl}/.well-known/workflow/v1/${pathname}`, {
                        method: 'POST',
                        duplex: 'half',
                        dispatcher: httpAgent,
                        headers: {
                            'content-type': 'application/json',
                            'x-vqs-queue-name': queueName,
                            'x-vqs-message-id': messageId,
                            'x-vqs-message-attempt': String(attempt + 1)
                        },
                        body
                    });
                    if (response.ok) {
                        return;
                    }
                    const text = await response.text();
                    if (response.status === 503) {
                        try {
                            const timeoutSeconds = Number(JSON.parse(text).timeoutSeconds);
                            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$timers$2f$promises__$5b$external$5d$__$28$node$3a$timers$2f$promises$2c$__cjs$29$__["setTimeout"])(timeoutSeconds * 1000);
                            defaultRetriesLeft++;
                            continue;
                        } catch  {}
                    }
                    console.error(`[local world] Failed to queue message`, {
                        queueName,
                        text,
                        status: response.status,
                        headers: Object.fromEntries(response.headers.entries()),
                        body: body.toString()
                    });
                }
                console.error(`[local world] Reached max retries of local world queue implementation`);
            } finally{
                semaphore.release();
            }
        })().catch((err)=>{
            // Silently ignore client disconnect errors (e.g., browser refresh during streaming)
            // These are expected and should not cause unhandled rejection warnings
            const isAbortError = err?.name === 'AbortError' || err?.name === 'ResponseAborted';
            if (!isAbortError) {
                console.error('[local world] Queue operation failed:', err);
            }
        }).finally(()=>{
            for (const fn of cleanup){
                fn();
            }
        });
        return {
            messageId
        };
    };
    const HeaderParser = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].object({
        'x-vqs-queue-name': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ValidQueueName"],
        'x-vqs-message-id': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"],
        'x-vqs-message-attempt': __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].coerce.number()
    });
    const createQueueHandler = (prefix, handler)=>{
        return async (req)=>{
            const headers = HeaderParser.safeParse(Object.fromEntries(req.headers));
            if (!headers.success || !req.body) {
                return Response.json({
                    error: !req.body ? 'Missing request body' : 'Missing required headers'
                }, {
                    status: 400
                });
            }
            const queueName = headers.data['x-vqs-queue-name'];
            const messageId = headers.data['x-vqs-message-id'];
            const attempt = headers.data['x-vqs-message-attempt'];
            if (!queueName.startsWith(prefix)) {
                return Response.json({
                    error: 'Unhandled queue'
                }, {
                    status: 400
                });
            }
            const body = await new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["JsonTransport"]().deserialize(req.body);
            try {
                const result = await handler(body, {
                    attempt,
                    queueName,
                    messageId
                });
                let timeoutSeconds = null;
                if (typeof result?.timeoutSeconds === 'number') {
                    timeoutSeconds = Math.min(result.timeoutSeconds, LOCAL_QUEUE_MAX_VISIBILITY);
                }
                if (timeoutSeconds) {
                    return Response.json({
                        timeoutSeconds
                    }, {
                        status: 503
                    });
                }
                return Response.json({
                    ok: true
                });
            } catch (error) {
                return Response.json(String(error), {
                    status: 500
                });
            }
        };
    };
    const getDeploymentId = async ()=>{
        return 'dpl_local';
    };
    return {
        queue,
        createQueueHandler,
        getDeploymentId
    };
} //# sourceMappingURL=queue.js.map
}),
"[project]/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearCreatedFilesCache",
    ()=>clearCreatedFilesCache,
    "deleteJSON",
    ()=>deleteJSON,
    "ensureDir",
    ()=>ensureDir,
    "listJSONFiles",
    ()=>listJSONFiles,
    "paginatedFileSystemQuery",
    ()=>paginatedFileSystemQuery,
    "readBuffer",
    ()=>readBuffer,
    "readJSON",
    ()=>readJSON,
    "ulidToDate",
    ()=>ulidToDate,
    "write",
    ()=>write,
    "writeJSON",
    ()=>writeJSON
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
;
;
;
;
const ulid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
const Ulid = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().ulid();
// In-memory cache of created files to avoid expensive fs.access() calls
// This is safe because we only write once per file path (no overwrites without explicit flag)
const createdFilesCache = new Set();
function clearCreatedFilesCache() {
    createdFilesCache.clear();
}
function ulidToDate(maybeUlid) {
    const ulid = Ulid.safeParse(maybeUlid);
    if (!ulid.success) {
        return null;
    }
    return new Date((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decodeTime"])(ulid.data));
}
async function ensureDir(dirPath) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].mkdir(dirPath, {
            recursive: true
        });
    } catch (_error) {
    // Ignore if already exists
    }
}
async function writeJSON(filePath, data, opts) {
    return write(filePath, JSON.stringify(data, null, 2), opts);
}
async function write(filePath, data, opts) {
    if (!opts?.overwrite) {
        // Fast path: check in-memory cache first to avoid expensive fs.access() calls
        // This provides significant performance improvement when creating many files
        if (createdFilesCache.has(filePath)) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`File ${filePath} already exists and 'overwrite' is false`, {
                status: 409
            });
        }
        // Slow path: check filesystem for files created before this process started
        try {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].access(filePath);
            // File exists on disk, add to cache for future checks
            createdFilesCache.add(filePath);
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`File ${filePath} already exists and 'overwrite' is false`, {
                status: 409
            });
        } catch (error) {
            // If file doesn't exist (ENOENT), continue with write
            if (error.code !== 'ENOENT') {
                throw error;
            }
        }
    }
    const tempPath = `${filePath}.tmp.${ulid()}`;
    let tempFileCreated = false;
    try {
        await ensureDir(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].dirname(filePath));
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].writeFile(tempPath, data);
        tempFileCreated = true;
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].rename(tempPath, filePath);
        // Track this file in cache so future writes know it exists
        createdFilesCache.add(filePath);
    } catch (error) {
        // Only try to clean up temp file if it was actually created
        if (tempFileCreated) {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].unlink(tempPath).catch(()=>{});
        }
        throw error;
    }
}
async function readJSON(filePath, decoder) {
    try {
        const content = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readFile(filePath, 'utf-8');
        return decoder.parse(JSON.parse(content));
    } catch (error) {
        if (error.code === 'ENOENT') return null;
        throw error;
    }
}
async function readBuffer(filePath) {
    const content = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readFile(filePath);
    return content;
}
async function deleteJSON(filePath) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].unlink(filePath);
    } catch (error) {
        if (error.code !== 'ENOENT') throw error;
    }
}
async function listJSONFiles(dirPath) {
    try {
        const files = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readdir(dirPath);
        return files.filter((f)=>f.endsWith('.json')).map((f)=>f.replace('.json', ''));
    } catch (error) {
        if (error.code === 'ENOENT') return [];
        throw error;
    }
}
function parseCursor(cursor) {
    if (!cursor) return null;
    const parts = cursor.split('|');
    return {
        timestamp: new Date(parts[0]),
        id: parts[1] || null
    };
}
function createCursor(timestamp, id) {
    return id ? `${timestamp.toISOString()}|${id}` : timestamp.toISOString();
}
async function paginatedFileSystemQuery(config) {
    const { directory, schema, filePrefix, filter, sortOrder = 'desc', limit = 20, cursor, getCreatedAt, getId } = config;
    // 1. Get all JSON files in directory
    const fileIds = await listJSONFiles(directory);
    // 2. Filter by prefix if provided
    const relevantFileIds = filePrefix ? fileIds.filter((fileId)=>fileId.startsWith(filePrefix)) : fileIds;
    // 3. ULID Optimization: Filter by cursor using filename timestamps before loading JSON
    const parsedCursor = parseCursor(cursor);
    let candidateFileIds = relevantFileIds;
    if (parsedCursor) {
        candidateFileIds = relevantFileIds.filter((fileId)=>{
            const filenameDate = getCreatedAt(`${fileId}.json`);
            if (filenameDate) {
                // Use filename timestamp for cursor filtering
                // We need to be careful here: if parsedCursor has an ID (for tie-breaking),
                // we need to include items with the same timestamp for later ID-based filtering.
                // If no ID, we can use strict inequality for optimization.
                const cursorTime = parsedCursor.timestamp.getTime();
                const fileTime = filenameDate.getTime();
                if (parsedCursor.id) {
                    // Tie-breaking mode: include items at or near cursor timestamp
                    return sortOrder === 'desc' ? fileTime <= cursorTime : fileTime >= cursorTime;
                } else {
                    // No tie-breaking: strict inequality
                    return sortOrder === 'desc' ? fileTime < cursorTime : fileTime > cursorTime;
                }
            }
            // Skip files where we can't extract timestamp - no optimization benefit
            return false;
        });
    } else {
        // Even without cursor, skip files where getCreatedAt returns null for consistency
        candidateFileIds = relevantFileIds.filter((fileId)=>{
            return getCreatedAt(`${fileId}.json`) !== null;
        });
    }
    // 4. Load files individually and collect valid items
    const validItems = [];
    for (const fileId of candidateFileIds){
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(directory, `${fileId}.json`);
        const item = await readJSON(filePath, schema);
        if (item) {
            // Apply custom filter early if provided
            if (filter && !filter(item)) continue;
            // Double-check cursor filtering with actual createdAt from JSON
            // (in case ULID timestamp differs from stored createdAt)
            if (parsedCursor) {
                const itemTime = item.createdAt.getTime();
                const cursorTime = parsedCursor.timestamp.getTime();
                if (sortOrder === 'desc') {
                    // For descending order, skip items >= cursor
                    if (itemTime > cursorTime) continue;
                    // If timestamps are equal, use ID for tie-breaking (skip if ID >= cursorId)
                    if (itemTime === cursorTime && parsedCursor.id && getId) {
                        const itemId = getId(item);
                        if (itemId >= parsedCursor.id) continue;
                    }
                } else {
                    // For ascending order, skip items <= cursor
                    if (itemTime < cursorTime) continue;
                    // If timestamps are equal, use ID for tie-breaking (skip if ID <= cursorId)
                    if (itemTime === cursorTime && parsedCursor.id && getId) {
                        const itemId = getId(item);
                        if (itemId <= parsedCursor.id) continue;
                    }
                }
            }
            validItems.push(item);
        }
    }
    // 5. Sort by createdAt (and by ID for tie-breaking if getId is provided)
    validItems.sort((a, b)=>{
        const aTime = a.createdAt.getTime();
        const bTime = b.createdAt.getTime();
        const timeComparison = sortOrder === 'asc' ? aTime - bTime : bTime - aTime;
        // If timestamps are equal and we have getId, use ID for stable sorting
        if (timeComparison === 0 && getId) {
            const aId = getId(a);
            const bId = getId(b);
            return sortOrder === 'asc' ? aId.localeCompare(bId) : bId.localeCompare(aId);
        }
        return timeComparison;
    });
    // 6. Apply pagination
    const hasMore = validItems.length > limit;
    const items = hasMore ? validItems.slice(0, limit) : validItems;
    const nextCursor = items.length > 0 ? createCursor(items[items.length - 1].createdAt, getId?.(items[items.length - 1])) : null;
    return {
        data: items,
        cursor: nextCursor,
        hasMore
    };
} //# sourceMappingURL=fs.js.map
}),
"[project]/node_modules/@workflow/world-local/dist/storage.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStorage",
    ()=>createStorage
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)");
;
;
;
;
;
;
// Create a monotonic ULID factory that ensures ULIDs are always increasing
// even when generated within the same millisecond
const monotonicUlid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
// Helper functions to filter data based on resolveData setting
function filterRunData(run, resolveData) {
    if (resolveData === 'none') {
        return {
            ...run,
            input: [],
            output: undefined
        };
    }
    return run;
}
function filterStepData(step, resolveData) {
    if (resolveData === 'none') {
        return {
            ...step,
            input: [],
            output: undefined
        };
    }
    return step;
}
function filterEventData(event, resolveData) {
    if (resolveData === 'none') {
        const { eventData: _eventData, ...rest } = event;
        return rest;
    }
    return event;
}
function filterHookData(hook, resolveData) {
    if (resolveData === 'none') {
        const { metadata: _metadata, ...rest } = hook;
        return rest;
    }
    return hook;
}
const getObjectCreatedAt = (idPrefix)=>(filename)=>{
        const replaceRegex = new RegExp(`^${idPrefix}_`, 'g');
        const dashIndex = filename.indexOf('-');
        if (dashIndex === -1) {
            // No dash - extract ULID from the filename (e.g., wrun_ULID.json, evnt_ULID.json)
            const ulid = filename.replace(/\.json$/, '').replace(replaceRegex, '');
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
        }
        // For composite keys like {runId}-{stepId}, extract from the appropriate part
        if (idPrefix === 'step') {
            // For steps: wrun_ULID-step_123.json - extract from the runId part
            const runId = filename.substring(0, dashIndex);
            const ulid = runId.replace(/^wrun_/, '');
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
        }
        // For events: wrun_ULID-evnt_ULID.json - extract from the eventId part
        const id = filename.substring(dashIndex + 1).replace(/\.json$/, '');
        const ulid = id.replace(replaceRegex, '');
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
    };
/**
 * Creates a hooks storage implementation using the filesystem.
 * Implements the Storage['hooks'] interface with hook CRUD operations.
 */ function createHooksStorage(basedir) {
    // Helper function to find a hook by token (shared between create and getByToken)
    async function findHookByToken(token) {
        const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
        const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(hooksDir);
        for (const file of files){
            const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(hooksDir, `${file}.json`);
            const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
            if (hook && hook.token === token) {
                return hook;
            }
        }
        return null;
    }
    async function create(runId, data) {
        // Check if a hook with the same token already exists
        // Token uniqueness is enforced globally per local environment
        const existingHook = await findHookByToken(data.token);
        if (existingHook) {
            throw new Error(`Hook with token ${data.token} already exists for this project`);
        }
        const now = new Date();
        const result = {
            runId,
            hookId: data.hookId,
            token: data.token,
            metadata: data.metadata,
            ownerId: 'local-owner',
            projectId: 'local-project',
            environment: 'local',
            createdAt: now
        };
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${data.hookId}.json`);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(hookPath, result);
        return result;
    }
    async function get(hookId, params) {
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${hookId}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (!hook) {
            throw new Error(`Hook ${hookId} not found`);
        }
        const resolveData = params?.resolveData || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
        return filterHookData(hook, resolveData);
    }
    async function getByToken(token) {
        const hook = await findHookByToken(token);
        if (!hook) {
            throw new Error(`Hook with token ${token} not found`);
        }
        return hook;
    }
    async function list(params) {
        const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
        const resolveData = params.resolveData || __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
            directory: hooksDir,
            schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"],
            sortOrder: params.pagination?.sortOrder,
            limit: params.pagination?.limit,
            cursor: params.pagination?.cursor,
            filePrefix: undefined,
            filter: (hook)=>{
                // Filter by runId if provided
                if (params.runId && hook.runId !== params.runId) {
                    return false;
                }
                return true;
            },
            getCreatedAt: ()=>{
                // Hook files don't have ULID timestamps in filename
                // We need to read the file to get createdAt, but that's inefficient
                // So we return the hook's createdAt directly (item.createdAt will be used for sorting)
                // Return a dummy date to pass the null check, actual sorting uses item.createdAt
                return new Date(0);
            },
            getId: (hook)=>hook.hookId
        });
        // Transform the data after pagination
        return {
            ...result,
            data: result.data.map((hook)=>filterHookData(hook, resolveData))
        };
    }
    async function dispose(hookId) {
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${hookId}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (!hook) {
            throw new Error(`Hook ${hookId} not found`);
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deleteJSON"])(hookPath);
        return hook;
    }
    return {
        create,
        get,
        getByToken,
        list,
        dispose
    };
}
/**
 * Helper function to delete all hooks associated with a workflow run
 */ async function deleteAllHooksForRun(basedir, runId) {
    const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
    const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(hooksDir);
    for (const file of files){
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(hooksDir, `${file}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (hook && hook.runId === runId) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deleteJSON"])(hookPath);
        }
    }
}
function createStorage(basedir) {
    return {
        runs: {
            async create (data) {
                const runId = `wrun_${monotonicUlid()}`;
                const now = new Date();
                const result = {
                    runId,
                    deploymentId: data.deploymentId,
                    status: 'pending',
                    workflowName: data.workflowName,
                    executionContext: data.executionContext,
                    input: data.input || [],
                    output: undefined,
                    error: undefined,
                    startedAt: undefined,
                    completedAt: undefined,
                    createdAt: now,
                    updatedAt: now
                };
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${runId}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(runPath, result);
                return result;
            },
            async get (id, params) {
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${id}.json`);
                const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(runPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"]);
                if (!run) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
                }
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            /**
             * Updates a workflow run.
             *
             * Note: This operation is not atomic. Concurrent updates from multiple
             * processes may result in lost updates (last writer wins). This is an
             * inherent limitation of filesystem-based storage without locking.
             * For the local world, this is acceptable as it's typically
             * used in single-process scenarios.
             */ async update (id, data) {
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${id}.json`);
                const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(runPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"]);
                if (!run) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
                }
                const now = new Date();
                const updatedRun = {
                    ...run,
                    ...data,
                    updatedAt: now
                };
                // Only set startedAt the first time the run transitions to 'running'
                if (data.status === 'running' && !updatedRun.startedAt) {
                    updatedRun.startedAt = now;
                }
                const isBecomingTerminal = data.status === 'completed' || data.status === 'failed' || data.status === 'cancelled';
                if (isBecomingTerminal) {
                    updatedRun.completedAt = now;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(runPath, updatedRun, {
                    overwrite: true
                });
                // If transitioning to a terminal status, clean up all hooks for this run
                if (isBecomingTerminal) {
                    await deleteAllHooksForRun(basedir, id);
                }
                return updatedRun;
            },
            async list (params) {
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"],
                    filter: (run)=>{
                        if (params?.workflowName && run.workflowName !== params.workflowName) {
                            return false;
                        }
                        if (params?.status && run.status !== params.status) {
                            return false;
                        }
                        return true;
                    },
                    sortOrder: params?.pagination?.sortOrder ?? 'desc',
                    limit: params?.pagination?.limit,
                    cursor: params?.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('wrun'),
                    getId: (run)=>run.runId
                });
                // If resolveData is "none", replace input/output with empty data
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((run)=>({
                                ...run,
                                input: [],
                                output: undefined
                            }))
                    };
                }
                return result;
            },
            async cancel (id, params) {
                // This will call update which triggers hook cleanup automatically
                const run = await this.update(id, {
                    status: 'cancelled'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            async pause (id, params) {
                const run = await this.update(id, {
                    status: 'paused'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            async resume (id, params) {
                const run = await this.update(id, {
                    status: 'running'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            }
        },
        steps: {
            async create (runId, data) {
                const now = new Date();
                const result = {
                    runId,
                    stepId: data.stepId,
                    stepName: data.stepName,
                    status: 'pending',
                    input: data.input,
                    output: undefined,
                    error: undefined,
                    attempt: 0,
                    startedAt: undefined,
                    completedAt: undefined,
                    createdAt: now,
                    updatedAt: now
                };
                const compositeKey = `${runId}-${data.stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(stepPath, result);
                return result;
            },
            async get (runId, stepId, params) {
                if (!runId) {
                    const fileIds = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps'));
                    const fileId = fileIds.find((fileId)=>fileId.endsWith(`-${stepId}`));
                    if (!fileId) {
                        throw new Error(`Step ${stepId} not found`);
                    }
                    runId = fileId.split('-')[0];
                }
                const compositeKey = `${runId}-${stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(stepPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"]);
                if (!step) {
                    throw new Error(`Step ${stepId} in run ${runId} not found`);
                }
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterStepData(step, resolveData);
            },
            /**
             * Updates a step.
             *
             * Note: This operation is not atomic. Concurrent updates from multiple
             * processes may result in lost updates (last writer wins). This is an
             * inherent limitation of filesystem-based storage without locking.
             */ async update (runId, stepId, data) {
                const compositeKey = `${runId}-${stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(stepPath, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"]);
                if (!step) {
                    throw new Error(`Step ${stepId} in run ${runId} not found`);
                }
                const now = new Date();
                const updatedStep = {
                    ...step,
                    ...data,
                    updatedAt: now
                };
                // Only set startedAt the first time the step transitions to 'running'
                if (data.status === 'running' && !updatedStep.startedAt) {
                    updatedStep.startedAt = now;
                }
                if (data.status === 'completed' || data.status === 'failed') {
                    updatedStep.completedAt = now;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(stepPath, updatedStep, {
                    overwrite: true
                });
                return updatedStep;
            },
            async list (params) {
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"],
                    filePrefix: `${params.runId}-`,
                    sortOrder: params.pagination?.sortOrder ?? 'desc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('step'),
                    getId: (step)=>step.stepId
                });
                // If resolveData is "none", replace input/output with empty data
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((step)=>({
                                ...step,
                                input: [],
                                output: undefined
                            }))
                    };
                }
                return result;
            }
        },
        // Events - filesystem-backed storage
        events: {
            async create (runId, data, params) {
                const eventId = `evnt_${monotonicUlid()}`;
                const now = new Date();
                const result = {
                    ...data,
                    runId,
                    eventId,
                    createdAt: now
                };
                // Store event using composite key {runId}-{eventId}
                const compositeKey = `${runId}-${eventId}`;
                const eventPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events', `${compositeKey}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(eventPath, result);
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterEventData(result, resolveData);
            },
            async list (params) {
                const { runId } = params;
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"],
                    filePrefix: `${runId}-`,
                    // Events in chronological order (oldest first) by default,
                    // different from the default for other list calls.
                    sortOrder: params.pagination?.sortOrder ?? 'asc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('evnt'),
                    getId: (event)=>event.eventId
                });
                // If resolveData is "none", remove eventData from events
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((event)=>{
                            const { eventData: _eventData, ...rest } = event;
                            return rest;
                        })
                    };
                }
                return result;
            },
            async listByCorrelationId (params) {
                const correlationId = params.correlationId;
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"],
                    // No filePrefix - search all events
                    filter: (event)=>event.correlationId === correlationId,
                    // Events in chronological order (oldest first) by default,
                    // different from the default for other list calls.
                    sortOrder: params.pagination?.sortOrder ?? 'asc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('evnt'),
                    getId: (event)=>event.eventId
                });
                // If resolveData is "none", remove eventData from events
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((event)=>{
                            const { eventData: _eventData, ...rest } = event;
                            return rest;
                        })
                    };
                }
                return result;
            }
        },
        // Hooks
        hooks: createHooksStorage(basedir)
    };
} //# sourceMappingURL=storage.js.map
}),
"[project]/node_modules/@workflow/world-local/dist/streamer.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStreamer",
    ()=>createStreamer,
    "deserializeChunk",
    ()=>deserializeChunk,
    "serializeChunk",
    ()=>serializeChunk
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$events__$5b$external$5d$__$28$node$3a$events$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:events [external] (node:events, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)");
;
;
;
;
// Create a monotonic ULID factory that ensures ULIDs are always increasing
// even when generated within the same millisecond
const monotonicUlid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
function serializeChunk(chunk) {
    const eofByte = Buffer.from([
        chunk.eof ? 1 : 0
    ]);
    return Buffer.concat([
        eofByte,
        chunk.chunk
    ]);
}
function deserializeChunk(serialized) {
    const eof = serialized[0] === 1;
    // Create a copy instead of a view to prevent ArrayBuffer detachment
    const chunk = Buffer.from(serialized.subarray(1));
    return {
        eof,
        chunk
    };
}
function createStreamer(basedir) {
    const streamEmitter = new __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$events__$5b$external$5d$__$28$node$3a$events$2c$__cjs$29$__["EventEmitter"]();
    return {
        async writeToStream (name, _runId, chunk) {
            // Await runId if it's a promise to ensure proper flushing
            await _runId;
            const chunkId = `strm_${monotonicUlid()}`;
            // Convert chunk to buffer for serialization
            let chunkBuffer;
            if (typeof chunk === 'string') {
                chunkBuffer = Buffer.from(new TextEncoder().encode(chunk));
            } else if (chunk instanceof Buffer) {
                chunkBuffer = chunk;
            } else {
                chunkBuffer = Buffer.from(chunk);
            }
            const serialized = serializeChunk({
                chunk: chunkBuffer,
                eof: false
            });
            const chunkPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks', `${name}-${chunkId}.json`);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["write"])(chunkPath, serialized);
            // Emit real-time event with Uint8Array (create copy to prevent ArrayBuffer detachment)
            const chunkData = Uint8Array.from(chunkBuffer);
            streamEmitter.emit(`chunk:${name}`, {
                streamName: name,
                chunkData,
                chunkId
            });
        },
        async closeStream (name, _runId) {
            // Await runId if it's a promise to ensure proper flushing
            await _runId;
            const chunkId = `strm_${monotonicUlid()}`;
            const chunkPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks', `${name}-${chunkId}.json`);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["write"])(chunkPath, serializeChunk({
                chunk: Buffer.from([]),
                eof: true
            }));
            streamEmitter.emit(`close:${name}`, {
                streamName: name
            });
        },
        async listStreamsByRunId (runId) {
            const chunksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks');
            const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(chunksDir);
            // Convert runId (wrun_{ULID}) to stream prefix (strm_{ULID}_user)
            const streamPrefix = runId.replace('wrun_', 'strm_') + '_user';
            // Extract unique stream names that match the run's prefix
            const streamNames = new Set();
            for (const file of files){
                // Files are named: {streamName}-{chunkId}
                // Find the last occurrence of '-strm_' to split correctly
                const lastDashIndex = file.lastIndexOf('-strm_');
                if (lastDashIndex === -1) {
                    // Try splitting at the last dash for legacy format
                    const parts = file.split('-');
                    if (parts.length >= 2) {
                        parts.pop(); // Remove chunkId
                        const streamName = parts.join('-');
                        if (streamName.startsWith(streamPrefix)) {
                            streamNames.add(streamName);
                        }
                    }
                } else {
                    const streamName = file.substring(0, lastDashIndex);
                    if (streamName.startsWith(streamPrefix)) {
                        streamNames.add(streamName);
                    }
                }
            }
            return Array.from(streamNames);
        },
        async readFromStream (name, startIndex = 0) {
            const chunksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks');
            let removeListeners = ()=>{};
            return new ReadableStream({
                async start (controller) {
                    // Track chunks delivered via events to prevent duplicates and maintain order.
                    const deliveredChunkIds = new Set();
                    // Buffer for chunks that arrive via events during disk reading
                    const bufferedEventChunks = [];
                    let isReadingFromDisk = true;
                    const chunkListener = (event)=>{
                        deliveredChunkIds.add(event.chunkId);
                        // Skip empty chunks to maintain consistency with disk reading behavior
                        // Empty chunks are not enqueued when read from disk (see line 184-186)
                        if (event.chunkData.byteLength === 0) {
                            return;
                        }
                        if (isReadingFromDisk) {
                            // Buffer chunks that arrive during disk reading to maintain order
                            // Create a copy to prevent ArrayBuffer detachment when enqueued later
                            bufferedEventChunks.push({
                                chunkId: event.chunkId,
                                chunkData: Uint8Array.from(event.chunkData)
                            });
                        } else {
                            // After disk reading is complete, deliver chunks immediately
                            // Create a copy to prevent ArrayBuffer detachment
                            controller.enqueue(Uint8Array.from(event.chunkData));
                        }
                    };
                    const closeListener = ()=>{
                        // Remove listeners before closing
                        streamEmitter.off(`chunk:${name}`, chunkListener);
                        streamEmitter.off(`close:${name}`, closeListener);
                        try {
                            controller.close();
                        } catch  {
                        // Ignore if controller is already closed (e.g., from cancel() or EOF)
                        }
                    };
                    removeListeners = closeListener;
                    // Set up listeners FIRST to avoid missing events
                    streamEmitter.on(`chunk:${name}`, chunkListener);
                    streamEmitter.on(`close:${name}`, closeListener);
                    // Now load existing chunks from disk
                    const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(chunksDir);
                    const chunkFiles = files.filter((file)=>file.startsWith(`${name}-`)).sort(); // ULID lexicographic sort = chronological order
                    // Process existing chunks, skipping any already delivered via events
                    let isComplete = false;
                    for(let i = startIndex; i < chunkFiles.length; i++){
                        const file = chunkFiles[i];
                        // Extract chunk ID from filename: "streamName-chunkId"
                        const chunkId = file.substring(name.length + 1);
                        // Skip if already delivered via event
                        if (deliveredChunkIds.has(chunkId)) {
                            continue;
                        }
                        const chunk = deserializeChunk(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readBuffer"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(chunksDir, `${file}.json`)));
                        if (chunk?.eof === true) {
                            isComplete = true;
                            break;
                        }
                        if (chunk.chunk.byteLength) {
                            // Create a copy to prevent ArrayBuffer detachment
                            controller.enqueue(Uint8Array.from(chunk.chunk));
                        }
                    }
                    // Finished reading from disk - now deliver buffered event chunks in chronological order
                    isReadingFromDisk = false;
                    // Sort buffered chunks by ULID (chronological order)
                    bufferedEventChunks.sort((a, b)=>a.chunkId.localeCompare(b.chunkId));
                    for (const buffered of bufferedEventChunks){
                        // Create a copy for defense in depth (already copied at storage, but be extra safe)
                        controller.enqueue(Uint8Array.from(buffered.chunkData));
                    }
                    if (isComplete) {
                        removeListeners();
                        try {
                            controller.close();
                        } catch  {
                        // Ignore if controller is already closed (e.g., from closeListener event)
                        }
                        return;
                    }
                },
                cancel () {
                    removeListeners();
                }
            });
        }
    };
} //# sourceMappingURL=streamer.js.map
}),
"[project]/node_modules/@workflow/world-local/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createLocalWorld",
    ()=>createLocalWorld
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/storage.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/world-local/dist/streamer.js [app-route] (ecmascript)");
;
;
;
;
function createLocalWorld(args) {
    const definedArgs = args ? Object.fromEntries(Object.entries(args).filter(([, value])=>value !== undefined)) : {};
    const mergedConfig = {
        ...__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].value,
        ...definedArgs
    };
    return {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createQueue"])(mergedConfig),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStorage"])(mergedConfig.dataDir),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStreamer"])(mergedConfig.dataDir)
    };
} //# sourceMappingURL=index.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/util.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Creates a lazily-evaluated, memoized version of the provided function.
 *
 * The returned object exposes a `value` getter that calls `fn` only once,
 * caches its result, and returns the cached value on subsequent accesses.
 *
 * @typeParam T - The return type of the provided function.
 * @param fn - The function to be called once and whose result will be cached.
 * @returns An object with a `value` property that returns the memoized result of `fn`.
 */ __turbopack_context__.s([
    "once",
    ()=>once
]);
function once(fn) {
    const result = {
        get value () {
            const value = fn();
            Object.defineProperty(result, 'value', {
                value
            });
            return value;
        }
    };
    return result;
} //# sourceMappingURL=util.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_RESOLVE_DATA_OPTION",
    ()=>DEFAULT_RESOLVE_DATA_OPTION,
    "config",
    ()=>config,
    "resolveBaseUrl",
    ()=>resolveBaseUrl
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$get$2d$port$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+utils@4.0.1-beta.5/node_modules/@workflow/utils/dist/get-port.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/util.js [app-route] (ecmascript)");
;
;
const getDataDirFromEnv = ()=>{
    return process.env.WORKFLOW_LOCAL_DATA_DIR || '.workflow-data';
};
const DEFAULT_RESOLVE_DATA_OPTION = 'all';
const getBaseUrlFromEnv = ()=>{
    return process.env.WORKFLOW_LOCAL_BASE_URL;
};
const config = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$util$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["once"])(()=>{
    const dataDir = getDataDirFromEnv();
    const baseUrl = getBaseUrlFromEnv();
    return {
        dataDir,
        baseUrl
    };
});
async function resolveBaseUrl(config) {
    if (config.baseUrl) {
        return config.baseUrl;
    }
    if (typeof config.port === 'number') {
        return `http://localhost:${config.port}`;
    }
    if (process.env.PORT) {
        return `http://localhost:${process.env.PORT}`;
    }
    const detectedPort = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$utils$40$4$2e$0$2e$1$2d$beta$2e$5$2f$node_modules$2f40$workflow$2f$utils$2f$dist$2f$get$2d$port$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getPort"])();
    if (detectedPort) {
        return `http://localhost:${detectedPort}`;
    }
    throw new Error('Unable to resolve base URL for workflow queue.');
} //# sourceMappingURL=config.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/queue.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createQueue",
    ()=>createQueue
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$timers$2f$promises__$5b$external$5d$__$28$node$3a$timers$2f$promises$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:timers/promises [external] (node:timers/promises, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@vercel+queue@0.0.0-alpha.33/node_modules/@vercel/queue/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$async$2d$sema$40$3$2e$1$2e$1$2f$node_modules$2f$async$2d$sema$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/async-sema@3.1.1/node_modules/async-sema/lib/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$undici$40$6$2e$22$2e$0$2f$node_modules$2f$undici$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/undici@6.22.0/node_modules/undici/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
;
;
;
;
;
;
;
;
// For local queue, there is no technical limit on the message visibility lifespan,
// but the environment variable can be used for testing purposes to set a max visibility limit.
const LOCAL_QUEUE_MAX_VISIBILITY = parseInt(process.env.WORKFLOW_LOCAL_QUEUE_MAX_VISIBILITY ?? '0', 10) || Infinity;
// The local workers share the same Node.js process and event loop,
// so we need to limit concurrency to avoid overwhelming the system.
const DEFAULT_CONCURRENCY_LIMIT = 100;
const WORKFLOW_LOCAL_QUEUE_CONCURRENCY = parseInt(process.env.WORKFLOW_LOCAL_QUEUE_CONCURRENCY ?? '0', 10) || DEFAULT_CONCURRENCY_LIMIT;
// Create a custom agent optimized for high-concurrency local workflows:
// - headersTimeout: 0 allows long-running steps
// - connections: 100 allows many parallel connections to the same host
// - pipelining: 1 (default) for HTTP/1.1 compatibility
// - keepAliveTimeout: 30s keeps connections warm for rapid step execution
const httpAgent = new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$undici$40$6$2e$22$2e$0$2f$node_modules$2f$undici$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Agent"]({
    headersTimeout: 0,
    connections: 100,
    keepAliveTimeout: 30_000
});
function createQueue(config) {
    const transport = new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["JsonTransport"]();
    const generateId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])();
    const semaphore = new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$async$2d$sema$40$3$2e$1$2e$1$2f$node_modules$2f$async$2d$sema$2f$lib$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["Sema"](WORKFLOW_LOCAL_QUEUE_CONCURRENCY);
    /**
     * holds inflight messages by idempotency key to ensure
     * that we don't queue the same message multiple times
     */ const inflightMessages = new Map();
    const queue = async (queueName, message, opts)=>{
        const cleanup = [];
        if (opts?.idempotencyKey) {
            const existing = inflightMessages.get(opts.idempotencyKey);
            if (existing) {
                return {
                    messageId: existing
                };
            }
        }
        const body = transport.serialize(message);
        let pathname;
        if (queueName.startsWith('__wkf_step_')) {
            pathname = `step`;
        } else if (queueName.startsWith('__wkf_workflow_')) {
            pathname = `flow`;
        } else {
            throw new Error('Unknown queue name prefix');
        }
        const messageId = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"].parse(`msg_${generateId()}`);
        if (opts?.idempotencyKey) {
            const key = opts.idempotencyKey;
            inflightMessages.set(key, messageId);
            cleanup.push(()=>{
                inflightMessages.delete(key);
            });
        }
        (async ()=>{
            const token = semaphore.tryAcquire();
            if (!token) {
                console.warn(`[world-local]: concurrency limit (${WORKFLOW_LOCAL_QUEUE_CONCURRENCY}) reached, waiting for queue to free up`);
                await semaphore.acquire();
            }
            try {
                let defaultRetriesLeft = 3;
                const baseUrl = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resolveBaseUrl"])(config);
                for(let attempt = 0; defaultRetriesLeft > 0; attempt++){
                    defaultRetriesLeft--;
                    const response = await fetch(`${baseUrl}/.well-known/workflow/v1/${pathname}`, {
                        method: 'POST',
                        duplex: 'half',
                        dispatcher: httpAgent,
                        headers: {
                            'content-type': 'application/json',
                            'x-vqs-queue-name': queueName,
                            'x-vqs-message-id': messageId,
                            'x-vqs-message-attempt': String(attempt + 1)
                        },
                        body
                    });
                    if (response.ok) {
                        return;
                    }
                    const text = await response.text();
                    if (response.status === 503) {
                        try {
                            const timeoutSeconds = Number(JSON.parse(text).timeoutSeconds);
                            await (0, __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$timers$2f$promises__$5b$external$5d$__$28$node$3a$timers$2f$promises$2c$__cjs$29$__["setTimeout"])(timeoutSeconds * 1000);
                            defaultRetriesLeft++;
                            continue;
                        } catch  {}
                    }
                    console.error(`[local world] Failed to queue message`, {
                        queueName,
                        text,
                        status: response.status,
                        headers: Object.fromEntries(response.headers.entries()),
                        body: body.toString()
                    });
                }
                console.error(`[local world] Reached max retries of local world queue implementation`);
            } finally{
                semaphore.release();
            }
        })().catch((err)=>{
            // Silently ignore client disconnect errors (e.g., browser refresh during streaming)
            // These are expected and should not cause unhandled rejection warnings
            const isAbortError = err?.name === 'AbortError' || err?.name === 'ResponseAborted';
            if (!isAbortError) {
                console.error('[local world] Queue operation failed:', err);
            }
        }).finally(()=>{
            for (const fn of cleanup){
                fn();
            }
        });
        return {
            messageId
        };
    };
    const HeaderParser = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].object({
        'x-vqs-queue-name': __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ValidQueueName"],
        'x-vqs-message-id': __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["MessageId"],
        'x-vqs-message-attempt': __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["default"].coerce.number()
    });
    const createQueueHandler = (prefix, handler)=>{
        return async (req)=>{
            const headers = HeaderParser.safeParse(Object.fromEntries(req.headers));
            if (!headers.success || !req.body) {
                return Response.json({
                    error: !req.body ? 'Missing request body' : 'Missing required headers'
                }, {
                    status: 400
                });
            }
            const queueName = headers.data['x-vqs-queue-name'];
            const messageId = headers.data['x-vqs-message-id'];
            const attempt = headers.data['x-vqs-message-attempt'];
            if (!queueName.startsWith(prefix)) {
                return Response.json({
                    error: 'Unhandled queue'
                }, {
                    status: 400
                });
            }
            const body = await new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$vercel$2b$queue$40$0$2e$0$2e$0$2d$alpha$2e$33$2f$node_modules$2f40$vercel$2f$queue$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["JsonTransport"]().deserialize(req.body);
            try {
                const result = await handler(body, {
                    attempt,
                    queueName,
                    messageId
                });
                let timeoutSeconds = null;
                if (typeof result?.timeoutSeconds === 'number') {
                    timeoutSeconds = Math.min(result.timeoutSeconds, LOCAL_QUEUE_MAX_VISIBILITY);
                }
                if (timeoutSeconds) {
                    return Response.json({
                        timeoutSeconds
                    }, {
                        status: 503
                    });
                }
                return Response.json({
                    ok: true
                });
            } catch (error) {
                return Response.json(String(error), {
                    status: 500
                });
            }
        };
    };
    const getDeploymentId = async ()=>{
        return 'dpl_local';
    };
    return {
        queue,
        createQueueHandler,
        getDeploymentId
    };
} //# sourceMappingURL=queue.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "clearCreatedFilesCache",
    ()=>clearCreatedFilesCache,
    "deleteJSON",
    ()=>deleteJSON,
    "ensureDir",
    ()=>ensureDir,
    "listJSONFiles",
    ()=>listJSONFiles,
    "paginatedFileSystemQuery",
    ()=>paginatedFileSystemQuery,
    "readBuffer",
    ()=>readBuffer,
    "readJSON",
    ()=>readJSON,
    "ulidToDate",
    ()=>ulidToDate,
    "write",
    ()=>write,
    "writeJSON",
    ()=>writeJSON
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:fs [external] (node:fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@4.1.11/node_modules/zod/v4/classic/external.js [app-route] (ecmascript) <export * as z>");
;
;
;
;
;
const ulid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
const Ulid = __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$4$2e$1$2e$11$2f$node_modules$2f$zod$2f$v4$2f$classic$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string().ulid();
// In-memory cache of created files to avoid expensive fs.access() calls
// This is safe because we only write once per file path (no overwrites without explicit flag)
const createdFilesCache = new Set();
function clearCreatedFilesCache() {
    createdFilesCache.clear();
}
function ulidToDate(maybeUlid) {
    const ulid = Ulid.safeParse(maybeUlid);
    if (!ulid.success) {
        return null;
    }
    return new Date((0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["decodeTime"])(ulid.data));
}
async function ensureDir(dirPath) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].mkdir(dirPath, {
            recursive: true
        });
    } catch (_error) {
    // Ignore if already exists
    }
}
async function writeJSON(filePath, data, opts) {
    return write(filePath, JSON.stringify(data, null, 2), opts);
}
async function write(filePath, data, opts) {
    if (!opts?.overwrite) {
        // Fast path: check in-memory cache first to avoid expensive fs.access() calls
        // This provides significant performance improvement when creating many files
        if (createdFilesCache.has(filePath)) {
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`File ${filePath} already exists and 'overwrite' is false`, {
                status: 409
            });
        }
        // Slow path: check filesystem for files created before this process started
        try {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].access(filePath);
            // File exists on disk, add to cache for future checks
            createdFilesCache.add(filePath);
            throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowAPIError"](`File ${filePath} already exists and 'overwrite' is false`, {
                status: 409
            });
        } catch (error) {
            // If file doesn't exist (ENOENT), continue with write
            if (error.code !== 'ENOENT') {
                throw error;
            }
        }
    }
    const tempPath = `${filePath}.tmp.${ulid()}`;
    let tempFileCreated = false;
    try {
        await ensureDir(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].dirname(filePath));
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].writeFile(tempPath, data);
        tempFileCreated = true;
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].rename(tempPath, filePath);
        // Track this file in cache so future writes know it exists
        createdFilesCache.add(filePath);
    } catch (error) {
        // Only try to clean up temp file if it was actually created
        if (tempFileCreated) {
            await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].unlink(tempPath).catch(()=>{});
        }
        throw error;
    }
}
async function readJSON(filePath, decoder) {
    try {
        const content = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readFile(filePath, 'utf-8');
        return decoder.parse(JSON.parse(content));
    } catch (error) {
        if (error.code === 'ENOENT') return null;
        throw error;
    }
}
async function readBuffer(filePath) {
    const content = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readFile(filePath);
    return content;
}
async function deleteJSON(filePath) {
    try {
        await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].unlink(filePath);
    } catch (error) {
        if (error.code !== 'ENOENT') throw error;
    }
}
async function listJSONFiles(dirPath) {
    try {
        const files = await __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$fs__$5b$external$5d$__$28$node$3a$fs$2c$__cjs$29$__["promises"].readdir(dirPath);
        return files.filter((f)=>f.endsWith('.json')).map((f)=>f.replace('.json', ''));
    } catch (error) {
        if (error.code === 'ENOENT') return [];
        throw error;
    }
}
function parseCursor(cursor) {
    if (!cursor) return null;
    const parts = cursor.split('|');
    return {
        timestamp: new Date(parts[0]),
        id: parts[1] || null
    };
}
function createCursor(timestamp, id) {
    return id ? `${timestamp.toISOString()}|${id}` : timestamp.toISOString();
}
async function paginatedFileSystemQuery(config) {
    const { directory, schema, filePrefix, filter, sortOrder = 'desc', limit = 20, cursor, getCreatedAt, getId } = config;
    // 1. Get all JSON files in directory
    const fileIds = await listJSONFiles(directory);
    // 2. Filter by prefix if provided
    const relevantFileIds = filePrefix ? fileIds.filter((fileId)=>fileId.startsWith(filePrefix)) : fileIds;
    // 3. ULID Optimization: Filter by cursor using filename timestamps before loading JSON
    const parsedCursor = parseCursor(cursor);
    let candidateFileIds = relevantFileIds;
    if (parsedCursor) {
        candidateFileIds = relevantFileIds.filter((fileId)=>{
            const filenameDate = getCreatedAt(`${fileId}.json`);
            if (filenameDate) {
                // Use filename timestamp for cursor filtering
                // We need to be careful here: if parsedCursor has an ID (for tie-breaking),
                // we need to include items with the same timestamp for later ID-based filtering.
                // If no ID, we can use strict inequality for optimization.
                const cursorTime = parsedCursor.timestamp.getTime();
                const fileTime = filenameDate.getTime();
                if (parsedCursor.id) {
                    // Tie-breaking mode: include items at or near cursor timestamp
                    return sortOrder === 'desc' ? fileTime <= cursorTime : fileTime >= cursorTime;
                } else {
                    // No tie-breaking: strict inequality
                    return sortOrder === 'desc' ? fileTime < cursorTime : fileTime > cursorTime;
                }
            }
            // Skip files where we can't extract timestamp - no optimization benefit
            return false;
        });
    } else {
        // Even without cursor, skip files where getCreatedAt returns null for consistency
        candidateFileIds = relevantFileIds.filter((fileId)=>{
            return getCreatedAt(`${fileId}.json`) !== null;
        });
    }
    // 4. Load files individually and collect valid items
    const validItems = [];
    for (const fileId of candidateFileIds){
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(directory, `${fileId}.json`);
        const item = await readJSON(filePath, schema);
        if (item) {
            // Apply custom filter early if provided
            if (filter && !filter(item)) continue;
            // Double-check cursor filtering with actual createdAt from JSON
            // (in case ULID timestamp differs from stored createdAt)
            if (parsedCursor) {
                const itemTime = item.createdAt.getTime();
                const cursorTime = parsedCursor.timestamp.getTime();
                if (sortOrder === 'desc') {
                    // For descending order, skip items >= cursor
                    if (itemTime > cursorTime) continue;
                    // If timestamps are equal, use ID for tie-breaking (skip if ID >= cursorId)
                    if (itemTime === cursorTime && parsedCursor.id && getId) {
                        const itemId = getId(item);
                        if (itemId >= parsedCursor.id) continue;
                    }
                } else {
                    // For ascending order, skip items <= cursor
                    if (itemTime < cursorTime) continue;
                    // If timestamps are equal, use ID for tie-breaking (skip if ID <= cursorId)
                    if (itemTime === cursorTime && parsedCursor.id && getId) {
                        const itemId = getId(item);
                        if (itemId <= parsedCursor.id) continue;
                    }
                }
            }
            validItems.push(item);
        }
    }
    // 5. Sort by createdAt (and by ID for tie-breaking if getId is provided)
    validItems.sort((a, b)=>{
        const aTime = a.createdAt.getTime();
        const bTime = b.createdAt.getTime();
        const timeComparison = sortOrder === 'asc' ? aTime - bTime : bTime - aTime;
        // If timestamps are equal and we have getId, use ID for stable sorting
        if (timeComparison === 0 && getId) {
            const aId = getId(a);
            const bId = getId(b);
            return sortOrder === 'asc' ? aId.localeCompare(bId) : bId.localeCompare(aId);
        }
        return timeComparison;
    });
    // 6. Apply pagination
    const hasMore = validItems.length > limit;
    const items = hasMore ? validItems.slice(0, limit) : validItems;
    const nextCursor = items.length > 0 ? createCursor(items[items.length - 1].createdAt, getId?.(items[items.length - 1])) : null;
    return {
        data: items,
        cursor: nextCursor,
        hasMore
    };
} //# sourceMappingURL=fs.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/storage.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStorage",
    ()=>createStorage
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+errors@4.0.1-beta.7/node_modules/@workflow/errors/dist/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/events.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/hooks.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/steps.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world@4.0.1-beta.10_zod@4.1.11/node_modules/@workflow/world/dist/runs.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)");
;
;
;
;
;
;
// Create a monotonic ULID factory that ensures ULIDs are always increasing
// even when generated within the same millisecond
const monotonicUlid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
// Helper functions to filter data based on resolveData setting
function filterRunData(run, resolveData) {
    if (resolveData === 'none') {
        return {
            ...run,
            input: [],
            output: undefined
        };
    }
    return run;
}
function filterStepData(step, resolveData) {
    if (resolveData === 'none') {
        return {
            ...step,
            input: [],
            output: undefined
        };
    }
    return step;
}
function filterEventData(event, resolveData) {
    if (resolveData === 'none') {
        const { eventData: _eventData, ...rest } = event;
        return rest;
    }
    return event;
}
function filterHookData(hook, resolveData) {
    if (resolveData === 'none') {
        const { metadata: _metadata, ...rest } = hook;
        return rest;
    }
    return hook;
}
const getObjectCreatedAt = (idPrefix)=>(filename)=>{
        const replaceRegex = new RegExp(`^${idPrefix}_`, 'g');
        const dashIndex = filename.indexOf('-');
        if (dashIndex === -1) {
            // No dash - extract ULID from the filename (e.g., wrun_ULID.json, evnt_ULID.json)
            const ulid = filename.replace(/\.json$/, '').replace(replaceRegex, '');
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
        }
        // For composite keys like {runId}-{stepId}, extract from the appropriate part
        if (idPrefix === 'step') {
            // For steps: wrun_ULID-step_123.json - extract from the runId part
            const runId = filename.substring(0, dashIndex);
            const ulid = runId.replace(/^wrun_/, '');
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
        }
        // For events: wrun_ULID-evnt_ULID.json - extract from the eventId part
        const id = filename.substring(dashIndex + 1).replace(/\.json$/, '');
        const ulid = id.replace(replaceRegex, '');
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["ulidToDate"])(ulid);
    };
/**
 * Creates a hooks storage implementation using the filesystem.
 * Implements the Storage['hooks'] interface with hook CRUD operations.
 */ function createHooksStorage(basedir) {
    // Helper function to find a hook by token (shared between create and getByToken)
    async function findHookByToken(token) {
        const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
        const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(hooksDir);
        for (const file of files){
            const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(hooksDir, `${file}.json`);
            const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
            if (hook && hook.token === token) {
                return hook;
            }
        }
        return null;
    }
    async function create(runId, data) {
        // Check if a hook with the same token already exists
        // Token uniqueness is enforced globally per local environment
        const existingHook = await findHookByToken(data.token);
        if (existingHook) {
            throw new Error(`Hook with token ${data.token} already exists for this project`);
        }
        const now = new Date();
        const result = {
            runId,
            hookId: data.hookId,
            token: data.token,
            metadata: data.metadata,
            ownerId: 'local-owner',
            projectId: 'local-project',
            environment: 'local',
            createdAt: now
        };
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${data.hookId}.json`);
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(hookPath, result);
        return result;
    }
    async function get(hookId, params) {
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${hookId}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (!hook) {
            throw new Error(`Hook ${hookId} not found`);
        }
        const resolveData = params?.resolveData || __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
        return filterHookData(hook, resolveData);
    }
    async function getByToken(token) {
        const hook = await findHookByToken(token);
        if (!hook) {
            throw new Error(`Hook with token ${token} not found`);
        }
        return hook;
    }
    async function list(params) {
        const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
        const resolveData = params.resolveData || __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
        const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
            directory: hooksDir,
            schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"],
            sortOrder: params.pagination?.sortOrder,
            limit: params.pagination?.limit,
            cursor: params.pagination?.cursor,
            filePrefix: undefined,
            filter: (hook)=>{
                // Filter by runId if provided
                if (params.runId && hook.runId !== params.runId) {
                    return false;
                }
                return true;
            },
            getCreatedAt: ()=>{
                // Hook files don't have ULID timestamps in filename
                // We need to read the file to get createdAt, but that's inefficient
                // So we return the hook's createdAt directly (item.createdAt will be used for sorting)
                // Return a dummy date to pass the null check, actual sorting uses item.createdAt
                return new Date(0);
            },
            getId: (hook)=>hook.hookId
        });
        // Transform the data after pagination
        return {
            ...result,
            data: result.data.map((hook)=>filterHookData(hook, resolveData))
        };
    }
    async function dispose(hookId) {
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks', `${hookId}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (!hook) {
            throw new Error(`Hook ${hookId} not found`);
        }
        await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deleteJSON"])(hookPath);
        return hook;
    }
    return {
        create,
        get,
        getByToken,
        list,
        dispose
    };
}
/**
 * Helper function to delete all hooks associated with a workflow run
 */ async function deleteAllHooksForRun(basedir, runId) {
    const hooksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'hooks');
    const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(hooksDir);
    for (const file of files){
        const hookPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(hooksDir, `${file}.json`);
        const hook = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(hookPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$hooks$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["HookSchema"]);
        if (hook && hook.runId === runId) {
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["deleteJSON"])(hookPath);
        }
    }
}
function createStorage(basedir) {
    return {
        runs: {
            async create (data) {
                const runId = `wrun_${monotonicUlid()}`;
                const now = new Date();
                const result = {
                    runId,
                    deploymentId: data.deploymentId,
                    status: 'pending',
                    workflowName: data.workflowName,
                    executionContext: data.executionContext,
                    input: data.input || [],
                    output: undefined,
                    error: undefined,
                    startedAt: undefined,
                    completedAt: undefined,
                    createdAt: now,
                    updatedAt: now
                };
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${runId}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(runPath, result);
                return result;
            },
            async get (id, params) {
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${id}.json`);
                const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(runPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"]);
                if (!run) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
                }
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            /**
             * Updates a workflow run.
             *
             * Note: This operation is not atomic. Concurrent updates from multiple
             * processes may result in lost updates (last writer wins). This is an
             * inherent limitation of filesystem-based storage without locking.
             * For the local world, this is acceptable as it's typically
             * used in single-process scenarios.
             */ async update (id, data) {
                const runPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs', `${id}.json`);
                const run = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(runPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"]);
                if (!run) {
                    throw new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$errors$40$4$2e$0$2e$1$2d$beta$2e$7$2f$node_modules$2f40$workflow$2f$errors$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunNotFoundError"](id);
                }
                const now = new Date();
                const updatedRun = {
                    ...run,
                    ...data,
                    updatedAt: now
                };
                // Only set startedAt the first time the run transitions to 'running'
                if (data.status === 'running' && !updatedRun.startedAt) {
                    updatedRun.startedAt = now;
                }
                const isBecomingTerminal = data.status === 'completed' || data.status === 'failed' || data.status === 'cancelled';
                if (isBecomingTerminal) {
                    updatedRun.completedAt = now;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(runPath, updatedRun, {
                    overwrite: true
                });
                // If transitioning to a terminal status, clean up all hooks for this run
                if (isBecomingTerminal) {
                    await deleteAllHooksForRun(basedir, id);
                }
                return updatedRun;
            },
            async list (params) {
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'runs'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$runs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["WorkflowRunSchema"],
                    filter: (run)=>{
                        if (params?.workflowName && run.workflowName !== params.workflowName) {
                            return false;
                        }
                        if (params?.status && run.status !== params.status) {
                            return false;
                        }
                        return true;
                    },
                    sortOrder: params?.pagination?.sortOrder ?? 'desc',
                    limit: params?.pagination?.limit,
                    cursor: params?.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('wrun'),
                    getId: (run)=>run.runId
                });
                // If resolveData is "none", replace input/output with empty data
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((run)=>({
                                ...run,
                                input: [],
                                output: undefined
                            }))
                    };
                }
                return result;
            },
            async cancel (id, params) {
                // This will call update which triggers hook cleanup automatically
                const run = await this.update(id, {
                    status: 'cancelled'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            async pause (id, params) {
                const run = await this.update(id, {
                    status: 'paused'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            },
            async resume (id, params) {
                const run = await this.update(id, {
                    status: 'running'
                });
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterRunData(run, resolveData);
            }
        },
        steps: {
            async create (runId, data) {
                const now = new Date();
                const result = {
                    runId,
                    stepId: data.stepId,
                    stepName: data.stepName,
                    status: 'pending',
                    input: data.input,
                    output: undefined,
                    error: undefined,
                    attempt: 0,
                    startedAt: undefined,
                    completedAt: undefined,
                    createdAt: now,
                    updatedAt: now
                };
                const compositeKey = `${runId}-${data.stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(stepPath, result);
                return result;
            },
            async get (runId, stepId, params) {
                if (!runId) {
                    const fileIds = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps'));
                    const fileId = fileIds.find((fileId)=>fileId.endsWith(`-${stepId}`));
                    if (!fileId) {
                        throw new Error(`Step ${stepId} not found`);
                    }
                    runId = fileId.split('-')[0];
                }
                const compositeKey = `${runId}-${stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(stepPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"]);
                if (!step) {
                    throw new Error(`Step ${stepId} in run ${runId} not found`);
                }
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterStepData(step, resolveData);
            },
            /**
             * Updates a step.
             *
             * Note: This operation is not atomic. Concurrent updates from multiple
             * processes may result in lost updates (last writer wins). This is an
             * inherent limitation of filesystem-based storage without locking.
             */ async update (runId, stepId, data) {
                const compositeKey = `${runId}-${stepId}`;
                const stepPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps', `${compositeKey}.json`);
                const step = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readJSON"])(stepPath, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"]);
                if (!step) {
                    throw new Error(`Step ${stepId} in run ${runId} not found`);
                }
                const now = new Date();
                const updatedStep = {
                    ...step,
                    ...data,
                    updatedAt: now
                };
                // Only set startedAt the first time the step transitions to 'running'
                if (data.status === 'running' && !updatedStep.startedAt) {
                    updatedStep.startedAt = now;
                }
                if (data.status === 'completed' || data.status === 'failed') {
                    updatedStep.completedAt = now;
                }
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(stepPath, updatedStep, {
                    overwrite: true
                });
                return updatedStep;
            },
            async list (params) {
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'steps'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$steps$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["StepSchema"],
                    filePrefix: `${params.runId}-`,
                    sortOrder: params.pagination?.sortOrder ?? 'desc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('step'),
                    getId: (step)=>step.stepId
                });
                // If resolveData is "none", replace input/output with empty data
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((step)=>({
                                ...step,
                                input: [],
                                output: undefined
                            }))
                    };
                }
                return result;
            }
        },
        // Events - filesystem-backed storage
        events: {
            async create (runId, data, params) {
                const eventId = `evnt_${monotonicUlid()}`;
                const now = new Date();
                const result = {
                    ...data,
                    runId,
                    eventId,
                    createdAt: now
                };
                // Store event using composite key {runId}-{eventId}
                const compositeKey = `${runId}-${eventId}`;
                const eventPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events', `${compositeKey}.json`);
                await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["writeJSON"])(eventPath, result);
                const resolveData = params?.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                return filterEventData(result, resolveData);
            },
            async list (params) {
                const { runId } = params;
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"],
                    filePrefix: `${runId}-`,
                    // Events in chronological order (oldest first) by default,
                    // different from the default for other list calls.
                    sortOrder: params.pagination?.sortOrder ?? 'asc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('evnt'),
                    getId: (event)=>event.eventId
                });
                // If resolveData is "none", remove eventData from events
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((event)=>{
                            const { eventData: _eventData, ...rest } = event;
                            return rest;
                        })
                    };
                }
                return result;
            },
            async listByCorrelationId (params) {
                const correlationId = params.correlationId;
                const resolveData = params.resolveData ?? __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DEFAULT_RESOLVE_DATA_OPTION"];
                const result = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["paginatedFileSystemQuery"])({
                    directory: __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'events'),
                    schema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$40$4$2e$0$2e$1$2d$beta$2e$10_zod$40$4$2e$1$2e$11$2f$node_modules$2f40$workflow$2f$world$2f$dist$2f$events$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["EventSchema"],
                    // No filePrefix - search all events
                    filter: (event)=>event.correlationId === correlationId,
                    // Events in chronological order (oldest first) by default,
                    // different from the default for other list calls.
                    sortOrder: params.pagination?.sortOrder ?? 'asc',
                    limit: params.pagination?.limit,
                    cursor: params.pagination?.cursor,
                    getCreatedAt: getObjectCreatedAt('evnt'),
                    getId: (event)=>event.eventId
                });
                // If resolveData is "none", remove eventData from events
                if (resolveData === 'none') {
                    return {
                        ...result,
                        data: result.data.map((event)=>{
                            const { eventData: _eventData, ...rest } = event;
                            return rest;
                        })
                    };
                }
                return result;
            }
        },
        // Hooks
        hooks: createHooksStorage(basedir)
    };
} //# sourceMappingURL=storage.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/streamer.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createStreamer",
    ()=>createStreamer,
    "deserializeChunk",
    ()=>deserializeChunk,
    "serializeChunk",
    ()=>serializeChunk
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$events__$5b$external$5d$__$28$node$3a$events$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:events [external] (node:events, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/node:path [external] (node:path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/ulid@3.0.1/node_modules/ulid/dist/node/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/fs.js [app-route] (ecmascript)");
;
;
;
;
// Create a monotonic ULID factory that ensures ULIDs are always increasing
// even when generated within the same millisecond
const monotonicUlid = (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$ulid$40$3$2e$0$2e$1$2f$node_modules$2f$ulid$2f$dist$2f$node$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["monotonicFactory"])(()=>Math.random());
function serializeChunk(chunk) {
    const eofByte = Buffer.from([
        chunk.eof ? 1 : 0
    ]);
    return Buffer.concat([
        eofByte,
        chunk.chunk
    ]);
}
function deserializeChunk(serialized) {
    const eof = serialized[0] === 1;
    // Create a copy instead of a view to prevent ArrayBuffer detachment
    const chunk = Buffer.from(serialized.subarray(1));
    return {
        eof,
        chunk
    };
}
function createStreamer(basedir) {
    const streamEmitter = new __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$events__$5b$external$5d$__$28$node$3a$events$2c$__cjs$29$__["EventEmitter"]();
    return {
        async writeToStream (name, _runId, chunk) {
            // Await runId if it's a promise to ensure proper flushing
            await _runId;
            const chunkId = `strm_${monotonicUlid()}`;
            // Convert chunk to buffer for serialization
            let chunkBuffer;
            if (typeof chunk === 'string') {
                chunkBuffer = Buffer.from(new TextEncoder().encode(chunk));
            } else if (chunk instanceof Buffer) {
                chunkBuffer = chunk;
            } else {
                chunkBuffer = Buffer.from(chunk);
            }
            const serialized = serializeChunk({
                chunk: chunkBuffer,
                eof: false
            });
            const chunkPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks', `${name}-${chunkId}.json`);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["write"])(chunkPath, serialized);
            // Emit real-time event with Uint8Array (create copy to prevent ArrayBuffer detachment)
            const chunkData = Uint8Array.from(chunkBuffer);
            streamEmitter.emit(`chunk:${name}`, {
                streamName: name,
                chunkData,
                chunkId
            });
        },
        async closeStream (name, _runId) {
            // Await runId if it's a promise to ensure proper flushing
            await _runId;
            const chunkId = `strm_${monotonicUlid()}`;
            const chunkPath = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks', `${name}-${chunkId}.json`);
            await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["write"])(chunkPath, serializeChunk({
                chunk: Buffer.from([]),
                eof: true
            }));
            streamEmitter.emit(`close:${name}`, {
                streamName: name
            });
        },
        async listStreamsByRunId (runId) {
            const chunksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks');
            const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(chunksDir);
            // Convert runId (wrun_{ULID}) to stream prefix (strm_{ULID}_user)
            const streamPrefix = runId.replace('wrun_', 'strm_') + '_user';
            // Extract unique stream names that match the run's prefix
            const streamNames = new Set();
            for (const file of files){
                // Files are named: {streamName}-{chunkId}
                // Find the last occurrence of '-strm_' to split correctly
                const lastDashIndex = file.lastIndexOf('-strm_');
                if (lastDashIndex === -1) {
                    // Try splitting at the last dash for legacy format
                    const parts = file.split('-');
                    if (parts.length >= 2) {
                        parts.pop(); // Remove chunkId
                        const streamName = parts.join('-');
                        if (streamName.startsWith(streamPrefix)) {
                            streamNames.add(streamName);
                        }
                    }
                } else {
                    const streamName = file.substring(0, lastDashIndex);
                    if (streamName.startsWith(streamPrefix)) {
                        streamNames.add(streamName);
                    }
                }
            }
            return Array.from(streamNames);
        },
        async readFromStream (name, startIndex = 0) {
            const chunksDir = __TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(basedir, 'streams', 'chunks');
            let removeListeners = ()=>{};
            return new ReadableStream({
                async start (controller) {
                    // Track chunks delivered via events to prevent duplicates and maintain order.
                    const deliveredChunkIds = new Set();
                    // Buffer for chunks that arrive via events during disk reading
                    const bufferedEventChunks = [];
                    let isReadingFromDisk = true;
                    const chunkListener = (event)=>{
                        deliveredChunkIds.add(event.chunkId);
                        // Skip empty chunks to maintain consistency with disk reading behavior
                        // Empty chunks are not enqueued when read from disk (see line 184-186)
                        if (event.chunkData.byteLength === 0) {
                            return;
                        }
                        if (isReadingFromDisk) {
                            // Buffer chunks that arrive during disk reading to maintain order
                            // Create a copy to prevent ArrayBuffer detachment when enqueued later
                            bufferedEventChunks.push({
                                chunkId: event.chunkId,
                                chunkData: Uint8Array.from(event.chunkData)
                            });
                        } else {
                            // After disk reading is complete, deliver chunks immediately
                            // Create a copy to prevent ArrayBuffer detachment
                            controller.enqueue(Uint8Array.from(event.chunkData));
                        }
                    };
                    const closeListener = ()=>{
                        // Remove listeners before closing
                        streamEmitter.off(`chunk:${name}`, chunkListener);
                        streamEmitter.off(`close:${name}`, closeListener);
                        try {
                            controller.close();
                        } catch  {
                        // Ignore if controller is already closed (e.g., from cancel() or EOF)
                        }
                    };
                    removeListeners = closeListener;
                    // Set up listeners FIRST to avoid missing events
                    streamEmitter.on(`chunk:${name}`, chunkListener);
                    streamEmitter.on(`close:${name}`, closeListener);
                    // Now load existing chunks from disk
                    const files = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["listJSONFiles"])(chunksDir);
                    const chunkFiles = files.filter((file)=>file.startsWith(`${name}-`)).sort(); // ULID lexicographic sort = chronological order
                    // Process existing chunks, skipping any already delivered via events
                    let isComplete = false;
                    for(let i = startIndex; i < chunkFiles.length; i++){
                        const file = chunkFiles[i];
                        // Extract chunk ID from filename: "streamName-chunkId"
                        const chunkId = file.substring(name.length + 1);
                        // Skip if already delivered via event
                        if (deliveredChunkIds.has(chunkId)) {
                            continue;
                        }
                        const chunk = deserializeChunk(await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$fs$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["readBuffer"])(__TURBOPACK__imported__module__$5b$externals$5d2f$node$3a$path__$5b$external$5d$__$28$node$3a$path$2c$__cjs$29$__["default"].join(chunksDir, `${file}.json`)));
                        if (chunk?.eof === true) {
                            isComplete = true;
                            break;
                        }
                        if (chunk.chunk.byteLength) {
                            // Create a copy to prevent ArrayBuffer detachment
                            controller.enqueue(Uint8Array.from(chunk.chunk));
                        }
                    }
                    // Finished reading from disk - now deliver buffered event chunks in chronological order
                    isReadingFromDisk = false;
                    // Sort buffered chunks by ULID (chronological order)
                    bufferedEventChunks.sort((a, b)=>a.chunkId.localeCompare(b.chunkId));
                    for (const buffered of bufferedEventChunks){
                        // Create a copy for defense in depth (already copied at storage, but be extra safe)
                        controller.enqueue(Uint8Array.from(buffered.chunkData));
                    }
                    if (isComplete) {
                        removeListeners();
                        try {
                            controller.close();
                        } catch  {
                        // Ignore if controller is already closed (e.g., from closeListener event)
                        }
                        return;
                    }
                },
                cancel () {
                    removeListeners();
                }
            });
        }
    };
} //# sourceMappingURL=streamer.js.map
}),
"[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/index.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createLocalWorld",
    ()=>createLocalWorld
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/config.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/queue.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/storage.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+world-local@4.0.1-beta.16/node_modules/@workflow/world-local/dist/streamer.js [app-route] (ecmascript)");
;
;
;
;
function createLocalWorld(args) {
    const definedArgs = args ? Object.fromEntries(Object.entries(args).filter(([, value])=>value !== undefined)) : {};
    const mergedConfig = {
        ...__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$config$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["config"].value,
        ...definedArgs
    };
    return {
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$queue$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createQueue"])(mergedConfig),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$storage$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStorage"])(mergedConfig.dataDir),
        ...(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$world$2d$local$40$4$2e$0$2e$1$2d$beta$2e$16$2f$node_modules$2f40$workflow$2f$world$2d$local$2f$dist$2f$streamer$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createStreamer"])(mergedConfig.dataDir)
    };
} //# sourceMappingURL=index.js.map
}),
];

//# sourceMappingURL=_7b9c9527._.js.map