module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/frontend/workflows/ops-agent/approval-store.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/workflows/ops-agent/approval-store.ts
__turbopack_context__.s([
    "createApproval",
    ()=>createApproval,
    "getApproval",
    ()=>getApproval,
    "getLatestApproval",
    ()=>getLatestApproval,
    "setApprovalDecision",
    ()=>setApprovalDecision
]);
const approvals = new Map();
let latestId = null;
function createApproval(id, amount, reason) {
    const rec = {
        id,
        status: "pending",
        amount,
        reason
    };
    approvals.set(id, rec);
    latestId = id;
}
function setApprovalDecision(id, decision) {
    const current = approvals.get(id) ?? {
        id,
        status: "pending"
    };
    current.status = decision === "approve" ? "approved" : "rejected";
    current.decidedAt = new Date().toISOString();
    approvals.set(id, current);
    latestId = id;
}
function getApproval(id) {
    return approvals.get(id) ?? null;
}
function getLatestApproval() {
    if (!latestId) return null;
    return approvals.get(latestId) ?? null;
}
}),
"[project]/frontend/app/api/slack-decision/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/app/api/slack-decision/route.ts
__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$approval$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/workflows/ops-agent/approval-store.ts [app-route] (ecmascript)");
;
;
async function GET(req) {
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    const decision = url.searchParams.get("decision");
    if (!id || decision !== "approve" && decision !== "reject") {
        return new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"]("Missing or invalid id/decision", {
            status: 400
        });
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$approval$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["setApprovalDecision"])(id, decision);
    return new __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$next$40$16$2e$0$2e$7_react$2d$dom$40$19$2e$2$2e$0_react$40$19$2e$2$2e$0_$5f$react$40$19$2e$2$2e$0$2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"]("✅ Approval recorded.\nYou can close this window.", {
        status: 200,
        headers: {
            "Content-Type": "text/plain; charset=utf-8"
        }
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__23ef1cd4._.js.map