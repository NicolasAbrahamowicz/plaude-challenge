module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/node:async_hooks [external] (node:async_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:async_hooks", () => require("node:async_hooks"));

module.exports = mod;
}),
"[externals]/node:module [external] (node:module, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:module", () => require("node:module"));

module.exports = mod;
}),
"[externals]/node:path [external] (node:path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:path", () => require("node:path"));

module.exports = mod;
}),
"[externals]/node:fs/promises [external] (node:fs/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs/promises", () => require("node:fs/promises"));

module.exports = mod;
}),
"[externals]/node:util [external] (node:util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:util", () => require("node:util"));

module.exports = mod;
}),
"[externals]/node:child_process [external] (node:child_process, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:child_process", () => require("node:child_process"));

module.exports = mod;
}),
"[externals]/node:timers/promises [external] (node:timers/promises, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:timers/promises", () => require("node:timers/promises"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[externals]/node:crypto [external] (node:crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:crypto", () => require("node:crypto"));

module.exports = mod;
}),
"[externals]/node:assert [external] (node:assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:assert", () => require("node:assert"));

module.exports = mod;
}),
"[externals]/node:http [external] (node:http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:http", () => require("node:http"));

module.exports = mod;
}),
"[externals]/node:stream [external] (node:stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:stream", () => require("node:stream"));

module.exports = mod;
}),
"[externals]/node:net [external] (node:net, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:net", () => require("node:net"));

module.exports = mod;
}),
"[externals]/node:buffer [external] (node:buffer, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:buffer", () => require("node:buffer"));

module.exports = mod;
}),
"[externals]/node:querystring [external] (node:querystring, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:querystring", () => require("node:querystring"));

module.exports = mod;
}),
"[externals]/node:events [external] (node:events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:events", () => require("node:events"));

module.exports = mod;
}),
"[externals]/node:zlib [external] (node:zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:zlib", () => require("node:zlib"));

module.exports = mod;
}),
"[externals]/node:perf_hooks [external] (node:perf_hooks, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:perf_hooks", () => require("node:perf_hooks"));

module.exports = mod;
}),
"[externals]/node:util/types [external] (node:util/types, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:util/types", () => require("node:util/types"));

module.exports = mod;
}),
"[externals]/node:worker_threads [external] (node:worker_threads, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:worker_threads", () => require("node:worker_threads"));

module.exports = mod;
}),
"[externals]/node:diagnostics_channel [external] (node:diagnostics_channel, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:diagnostics_channel", () => require("node:diagnostics_channel"));

module.exports = mod;
}),
"[externals]/node:tls [external] (node:tls, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:tls", () => require("node:tls"));

module.exports = mod;
}),
"[externals]/node:http2 [external] (node:http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:http2", () => require("node:http2"));

module.exports = mod;
}),
"[externals]/string_decoder [external] (string_decoder, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("string_decoder", () => require("string_decoder"));

module.exports = mod;
}),
"[externals]/node:url [external] (node:url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:url", () => require("node:url"));

module.exports = mod;
}),
"[externals]/node:console [external] (node:console, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:console", () => require("node:console"));

module.exports = mod;
}),
"[externals]/node:dns [external] (node:dns, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:dns", () => require("node:dns"));

module.exports = mod;
}),
"[externals]/node:fs [external] (node:fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:fs", () => require("node:fs"));

module.exports = mod;
}),
"[externals]/node:os [external] (node:os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:os", () => require("node:os"));

module.exports = mod;
}),
"[project]/frontend/ai/ops-instructions.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OPS_AGENT_INSTRUCTIONS",
    ()=>OPS_AGENT_INSTRUCTIONS
]);
const OPS_AGENT_INSTRUCTIONS = `
LANGUAGE & STYLE
----------------
- Detect the language of the latest user message.
- If the user writes primarily in English, reply 100% in English.
- If the user writes primarily in Spanish, reply 100% in Spanish.
- Do NOT mix languages in the same message.
- Keep responses short, clear, and friendly.
- Never reply in Spanglish unless the user explicitly does and asks you to mirror it.

ROLE
----
You are the Plaude Operations Agent.

Your job is to help Plaude operators with everyday operations such as:
- issuing refunds,
- closing or re-opening accounts,
- changing account details (email, payout destination, etc.),
- exporting or deleting user data,
- explaining internal policies in clear language.

You always act as a careful, policy-aligned agent:
- You never actually move money or touch real systems.
  Instead, you call tools that simulate those actions.
- You always explain what you are doing in plain language.

Very important:
- Never mention internal implementation details, tools, or function tags in your replies.
- Never show strings like "<function=...>" to the user.
- Never promise that you will proactively send updates without the user sending a new message.

HUMAN APPROVAL POLICY
---------------------
Use human approval via Slack **before** doing ANY of the following:

1) Refunds
   - Refunds higher than $50 (or equivalent) ALWAYS require human approval.
   - ANY refund where the user mentions fraud, chargeback, or dispute also requires approval
     even if the amount is small.

2) High-value or risky operations
   - Closing or permanently disabling an account.
   - Changing primary email, payout wallet, or anything that could lock the user out.
   - Increasing spending limits or risk thresholds.
   - Exporting or permanently deleting a user's personal data.

3) Ambiguous or conflicting requests
   - When the user request is unclear or could have more than one interpretation.
   - When you are not confident you understood what they want, and a wrong action could be risky.

For low-risk operations you may proceed without approval, for example:
- explaining policies,
- checking the status of an order,
- small goodwill gestures below $50 that the policies clearly allow.

HOW TO USE THE APPROVAL TOOL
----------------------------
When you decide human approval is required:

1) First, tell the user what you are about to do, in their language:

   If the user is in Spanish:
   - "Déjame revisar un segundo internamente. Voy a pedir una aprobación interna antes de continuar."

   If the user is in English:
   - "Let me quickly check this internally. I’ll request internal approval before proceeding."

2) Then call the \`requestSlackApproval\` tool with:
   - operationType = "refund", "high_value", "ambiguous" or "account_change",
   - risk = "low" | "medium" | "high",
   - reason = a short explanation,
   - amount if there is a monetary value.

3) Wait for the human decision.
4) After approval or rejection, explain the outcome to the user, again in their language.

ABSOLUTE RULES ABOUT APPROVAL
-----------------------------
- Never say something "requires internal approval" without calling the tool.
- Never pretend the operation was approved or rejected if the tool (and human) haven’t responded.
- Your job is to:
  - decide if approval is needed,
  - call the tool when needed,
  - communicate clearly what is happening.

EXAMPLES (ENGLISH)
------------------
User: "I need to refund $200 for order #220."
Assistant:
  1) "Let me quickly check this internally. Since this is a high-value refund, I’ll request internal approval before proceeding."
  2) Then call \`requestSlackApproval\` with:
     - operationType: "refund"
     - risk: "medium" or "high"
     - reason: short explanation
     - amount: 200

EXAMPLES (SPANISH)
------------------
Usuario: "Necesito reembolsar 200 USD de la orden #220."
Asistente:
  1) "Déjame revisar un segundo internamente. Como es un reembolso de alto monto, voy a pedir una aprobación interna antes de continuar."
  2) Luego llama \`requestSlackApproval\` con:
     - operationType: "refund"
     - risk: "medium" o "high"
     - reason: explicación corta
     - amount: 200

GENERAL STYLE
-------------
Always keep responses concise, friendly, and focused on giving the user clarity and next steps.

--------------------------------
SLACK DECISION TOOL
--------------------------------

You have access to a tool called "checkLatestApprovalStatus" that tells you
the MOST RECENT decision a human made in Slack (approve or reject) for a risky operation.

- After you call "requestSlackApproval", tell the user that you're waiting for human approval.
- Later, if the user asks what happened with their refund / account change
  (e.g. "is it approved?", "what was the decision?", "any update?"),
  you MUST call "checkLatestApprovalStatus".
- If the tool returns "approve":
  - Clearly tell the user that the operation has been approved.
  - Explain what will happen next and any timelines.
- If the tool returns "reject":
  - Clearly tell the user it was rejected.
  - Explain why (if the policies suggest a reason) and offer next steps or alternatives.

`;
}),
"[project]/frontend/workflows/ops-agent/approval-store.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/workflows/ops-agent/approval-store.ts
__turbopack_context__.s([
    "createApproval",
    ()=>createApproval,
    "getApproval",
    ()=>getApproval,
    "getLatestApproval",
    ()=>getLatestApproval,
    "setApprovalDecision",
    ()=>setApprovalDecision
]);
const approvals = new Map();
let latestId = null;
function createApproval(id, amount, reason) {
    const rec = {
        id,
        status: "pending",
        amount,
        reason
    };
    approvals.set(id, rec);
    latestId = id;
}
function setApprovalDecision(id, decision) {
    const current = approvals.get(id) ?? {
        id,
        status: "pending"
    };
    current.status = decision === "approve" ? "approved" : "rejected";
    current.decidedAt = new Date().toISOString();
    approvals.set(id, current);
    latestId = id;
}
function getApproval(id) {
    return approvals.get(id) ?? null;
}
function getLatestApproval() {
    if (!latestId) return null;
    return approvals.get(latestId) ?? null;
}
}),
"[project]/frontend/workflows/ops-agent/tools.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// frontend/workflows/ops-agent/tools.ts
__turbopack_context__.s([
    "opsTools",
    ()=>opsTools
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/provider-utils/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$stdlib$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/stdlib.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/zod@3.25.76/node_modules/zod/v3/external.js [app-route] (ecmascript) <export * as z>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$approval$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/workflows/ops-agent/approval-store.ts [app-route] (ecmascript)");
;
;
;
;
const SLACK_APPROVAL_WEBHOOK_URL = process.env.SLACK_APPROVAL_WEBHOOK_URL;
const PUBLIC_BASE_URL = process.env.NEXT_PUBLIC_BASE_URL || process.env.PUBLIC_BASE_URL;
/**
 * No podemos usar node:crypto en workflows, así que generamos
 * un UUID “v4-like” a mano con Math.random (sobrado para el challenge).
 */ function generateApprovalId() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c)=>{
        const r = Math.random() * 16 | 0;
        const v = c === "x" ? r : r & 0x3 | 0x8;
        return v.toString(16);
    });
}
const opsTools = {
    requestSlackApproval: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$provider$2d$utils$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["tool"])({
        description: "Send a request to Slack so a human operator can approve or reject a risky operation.",
        inputSchema: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].object({
            operationType: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
                "refund",
                "high_value",
                "ambiguous",
                "account_change"
            ]),
            risk: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].enum([
                "low",
                "medium",
                "high"
            ]),
            reason: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].string(),
            amount: __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$zod$40$3$2e$25$2e$76$2f$node_modules$2f$zod$2f$v3$2f$external$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$export__$2a$__as__z$3e$__["z"].number().optional()
        }),
        async execute (input) {
            "use workflow";
            if (!SLACK_APPROVAL_WEBHOOK_URL) {
                console.error("[ops-tools] Missing SLACK_APPROVAL_WEBHOOK_URL env var");
                return {
                    ok: false,
                    messageForUser: "I tried to request human approval in Slack, but the Slack configuration is missing.",
                    approvalId: null
                };
            }
            const approvalId = generateApprovalId();
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$approval$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createApproval"])(approvalId, input.amount, input.reason);
            const baseUrl = (PUBLIC_BASE_URL || "").replace(/\/$/, "");
            if (!baseUrl) {
                console.warn("[ops-tools] PUBLIC_BASE_URL / NEXT_PUBLIC_BASE_URL is empty; buttons will have invalid URLs");
            }
            const approveUrl = `${baseUrl}/api/slack-decision?id=${approvalId}&decision=approve&amount=${input.amount ?? ""}`;
            const rejectUrl = `${baseUrl}/api/slack-decision?id=${approvalId}&decision=reject&amount=${input.amount ?? ""}`;
            const lines = [
                "*Plaude Agent – approval requested*",
                `• Operation type: ${input.operationType}`,
                `• Risk level: ${input.risk}`,
                `• Amount: ${input.amount ?? "n/a"}`,
                `• Reason: ${input.reason}`,
                `• Approval ID: ${approvalId}`
            ];
            const text = lines.join("\n");
            try {
                const res = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$stdlib$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["fetch"])(SLACK_APPROVAL_WEBHOOK_URL, {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        // 👈 Slack NECESITA este campo para no tirar "no_text"
                        text,
                        blocks: [
                            {
                                type: "section",
                                text: {
                                    type: "mrkdwn",
                                    text
                                }
                            },
                            {
                                type: "section",
                                text: {
                                    type: "mrkdwn",
                                    text: "*Decision:*"
                                }
                            },
                            {
                                type: "actions",
                                elements: [
                                    {
                                        type: "button",
                                        text: {
                                            type: "plain_text",
                                            text: "✅ Approve"
                                        },
                                        style: "primary",
                                        url: approveUrl
                                    },
                                    {
                                        type: "button",
                                        text: {
                                            type: "plain_text",
                                            text: "❌ Reject"
                                        },
                                        style: "danger",
                                        url: rejectUrl
                                    }
                                ]
                            }
                        ]
                    })
                });
                if (!res.ok) {
                    let body = "";
                    try {
                        body = await res.text();
                    } catch  {
                    // ignore
                    }
                    console.error("[ops-tools] Slack webhook HTTP error", res.status, body);
                    return {
                        ok: false,
                        messageForUser: "I'm having trouble notifying a human operator in Slack for approval.",
                        approvalId
                    };
                }
                return {
                    ok: true,
                    messageForUser: "I've sent your request to an internal operator in Slack for approval.",
                    approvalId
                };
            } catch (err) {
                console.error("[ops-tools] Slack webhook exception", err);
                return {
                    ok: false,
                    messageForUser: "I'm having trouble contacting a human operator in Slack for approval.",
                    approvalId
                };
            }
        }
    })
};
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/node:vm [external] (node:vm, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("node:vm", () => require("node:vm"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[project]/frontend/app/.well-known/workflow/v1/step/route.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

// biome-ignore-all lint: generated file
/* eslint-disable */ __turbopack_context__.s([]);
// node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/internal/builtins.js
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$internal$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/internal/private.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/private.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/index.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$gateway$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/ai/node_modules/@ai-sdk/gateway/dist/index.mjs [app-route] (ecmascript)");
// ../node_modules/@workflow/ai/dist/agent/stream-text-iterator.js
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$workflow$2f$ai$2f$dist$2f$agent$2f$tools$2d$to$2d$model$2d$tools$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@workflow/ai/dist/agent/tools-to-model-tools.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$groq$40$2$2e$0$2e$33_zod$40$3$2e$25$2e$76$2f$node_modules$2f40$ai$2d$sdk$2f$groq$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@ai-sdk+groq@2.0.33_zod@3.25.76/node_modules/@ai-sdk/groq/dist/index.mjs [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$ai$2f$ops$2d$instructions$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/ai/ops-instructions.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$tools$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/workflows/ops-agent/tools.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$workflows$2f$ops$2d$agent$2f$approval$2d$store$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/frontend/workflows/ops-agent/approval-store.ts [app-route] (ecmascript)");
// virtual-entry.js
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f$workflow$40$4$2e$0$2e$1$2d$beta$2e$29_$40$aws_cc16d9f11f38d350ff750197b89bf9e0$2f$node_modules$2f$workflow$2f$dist$2f$runtime$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/runtime.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime.js [app-route] (ecmascript) <locals>");
var __defProp = Object.defineProperty;
var __name = (target, value)=>__defProp(target, "name", {
        value,
        configurable: true
    });
;
async function __builtin_response_array_buffer(res) {
    return res.arrayBuffer();
}
__name(__builtin_response_array_buffer, "__builtin_response_array_buffer");
async function __builtin_response_json(res) {
    return res.json();
}
__name(__builtin_response_json, "__builtin_response_json");
async function __builtin_response_text(res) {
    return res.text();
}
__name(__builtin_response_text, "__builtin_response_text");
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("__builtin_response_array_buffer", __builtin_response_array_buffer);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("__builtin_response_json", __builtin_response_json);
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("__builtin_response_text", __builtin_response_text);
;
;
;
;
;
;
;
;
async function doStreamStep(conversationPrompt, modelInit, writable, tools, options) {
    let model;
    if (typeof modelInit === "string") {
        model = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$ai$2f$node_modules$2f40$ai$2d$sdk$2f$gateway$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["gateway"])(modelInit);
    } else if (typeof modelInit === "function") {
        model = await modelInit();
    } else {
        throw new Error('Invalid "model initialization" argument. Must be a string or a function that returns a LanguageModelV2 instance.');
    }
    const result = await model.doStream({
        prompt: conversationPrompt,
        tools
    });
    let finish;
    const toolCalls = [];
    const chunks = [];
    await result.stream.pipeThrough(new TransformStream({
        transform (chunk, controller) {
            if (chunk.type === "tool-call") {
                toolCalls.push({
                    ...chunk,
                    input: chunk.input || "{}"
                });
            } else if (chunk.type === "finish") {
                finish = chunk;
            }
            chunks.push(chunk);
            controller.enqueue(chunk);
        }
    })).pipeThrough(new TransformStream({
        start: /* @__PURE__ */ __name((controller)=>{
            if (options?.sendStart) {
                controller.enqueue({
                    type: "start"
                });
            }
            controller.enqueue({
                type: "start-step"
            });
        }, "start"),
        flush: /* @__PURE__ */ __name((controller)=>{
            controller.enqueue({
                type: "finish-step"
            });
        }, "flush"),
        transform: /* @__PURE__ */ __name(async (part, controller)=>{
            const partType = part.type;
            switch(partType){
                case "text-start":
                    {
                        controller.enqueue({
                            type: "text-start",
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case "text-delta":
                    {
                        controller.enqueue({
                            type: "text-delta",
                            id: part.id,
                            delta: part.delta,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case "text-end":
                    {
                        controller.enqueue({
                            type: "text-end",
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case "reasoning-start":
                    {
                        controller.enqueue({
                            type: "reasoning-start",
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case "reasoning-delta":
                    {
                        controller.enqueue({
                            type: "reasoning-delta",
                            id: part.id,
                            delta: part.delta,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                case "reasoning-end":
                    {
                        controller.enqueue({
                            type: "reasoning-end",
                            id: part.id,
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                // case "file": {
                //   controller.enqueue({
                //     type: "file",
                //     mediaType: part.file.mediaType,
                //     url: `data:${part.file.mediaType};base64,${part.file.base64}`,
                //   });
                //   break;
                // }
                // case "source": {
                //   if (sendSources && part.sourceType === "url") {
                //     controller.enqueue({
                //       type: "source-url",
                //       sourceId: part.id,
                //       url: part.url,
                //       title: part.title,
                //       ...(part.providerMetadata != null
                //         ? { providerMetadata: part.providerMetadata }
                //         : {}),
                //     });
                //   }
                //   if (sendSources && part.sourceType === "document") {
                //     controller.enqueue({
                //       type: "source-document",
                //       sourceId: part.id,
                //       mediaType: part.mediaType,
                //       title: part.title,
                //       filename: part.filename,
                //       ...(part.providerMetadata != null
                //         ? { providerMetadata: part.providerMetadata }
                //         : {}),
                //     });
                //   }
                //   break;
                // }
                // case "tool-input-start": {
                //   const dynamic = isDynamic(part);
                //   controller.enqueue({
                //     type: "tool-input-start",
                //     toolCallId: part.id,
                //     toolName: part.toolName,
                //     ...(part.providerExecuted != null
                //       ? { providerExecuted: part.providerExecuted }
                //       : {}),
                //     ...(dynamic != null ? { dynamic } : {}),
                //   });
                //   break;
                // }
                // case "tool-input-delta": {
                //   controller.enqueue({
                //     type: "tool-input-delta",
                //     toolCallId: part.id,
                //     inputTextDelta: part.delta,
                //   });
                //   break;
                // }
                case "tool-call":
                    {
                        controller.enqueue({
                            type: "tool-input-available",
                            toolCallId: part.toolCallId,
                            toolName: part.toolName,
                            input: JSON.parse(part.input || "{}"),
                            ...part.providerExecuted != null ? {
                                providerExecuted: part.providerExecuted
                            } : {},
                            ...part.providerMetadata != null ? {
                                providerMetadata: part.providerMetadata
                            } : {}
                        });
                        break;
                    }
                // case "tool-approval-request": {
                //   controller.enqueue({
                //     type: "tool-approval-request",
                //     approvalId: part.approvalId,
                //     toolCallId: part.toolCall.toolCallId,
                //   });
                //   break;
                // }
                // case "tool-result": {
                //   const dynamic = isDynamic(part);
                //   controller.enqueue({
                //     type: "tool-output-available",
                //     toolCallId: part.toolCallId,
                //     output: part.output,
                //     ...(part.providerExecuted != null
                //       ? { providerExecuted: part.providerExecuted }
                //       : {}),
                //     ...(part.preliminary != null
                //       ? { preliminary: part.preliminary }
                //       : {}),
                //     ...(dynamic != null ? { dynamic } : {}),
                //   });
                //   break;
                // }
                // case "tool-error": {
                //   const dynamic = isDynamic(part);
                //   controller.enqueue({
                //     type: "tool-output-error",
                //     toolCallId: part.toolCallId,
                //     errorText: onError(part.error),
                //     ...(part.providerExecuted != null
                //       ? { providerExecuted: part.providerExecuted }
                //       : {}),
                //     ...(dynamic != null ? { dynamic } : {}),
                //   });
                //   break;
                // }
                // case "tool-output-denied": {
                //   controller.enqueue({
                //     type: "tool-output-denied",
                //     toolCallId: part.toolCallId,
                //   });
                //   break;
                // }
                case "error":
                    {
                        const error = part.error;
                        controller.enqueue({
                            type: "error",
                            errorText: error instanceof Error ? error.message : String(error)
                        });
                        break;
                    }
            }
        }, "transform")
    })).pipeTo(writable, {
        preventClose: true
    });
    const step = chunksToStep(chunks, toolCalls, conversationPrompt, finish);
    return {
        toolCalls,
        finish,
        step
    };
}
__name(doStreamStep, "doStreamStep");
function chunksToStep(chunks, toolCalls, conversationPrompt, finish) {
    const text = chunks.filter((chunk)=>chunk.type === "text-delta").map((chunk)=>chunk.delta).join("");
    const reasoning = chunks.filter((chunk)=>chunk.type === "reasoning-delta");
    const reasoningText = reasoning.map((chunk)=>chunk.delta).join("");
    const streamStart = chunks.find((chunk)=>chunk.type === "stream-start");
    const responseMetadata = chunks.find((chunk)=>chunk.type === "response-metadata");
    const stepResult = {
        content: [
            ...text ? [
                {
                    type: "text",
                    text
                }
            ] : [],
            ...toolCalls.map((toolCall)=>({
                    type: "tool-call",
                    toolCallId: toolCall.toolCallId,
                    toolName: toolCall.toolName,
                    input: JSON.parse(toolCall.input),
                    dynamic: true
                }))
        ],
        text,
        reasoning: reasoning.map((chunk)=>({
                type: "reasoning",
                text: chunk.delta
            })),
        reasoningText: reasoningText || void 0,
        files: [],
        sources: [],
        toolCalls: toolCalls.map((toolCall)=>({
                type: "tool-call",
                toolCallId: toolCall.toolCallId,
                toolName: toolCall.toolName,
                input: JSON.parse(toolCall.input),
                dynamic: true
            })),
        staticToolCalls: [],
        dynamicToolCalls: toolCalls.map((toolCall)=>({
                type: "tool-call",
                toolCallId: toolCall.toolCallId,
                toolName: toolCall.toolName,
                input: JSON.parse(toolCall.input),
                dynamic: true
            })),
        toolResults: [],
        staticToolResults: [],
        dynamicToolResults: [],
        finishReason: finish?.finishReason || "unknown",
        usage: finish?.usage || {
            inputTokens: 0,
            outputTokens: 0,
            totalTokens: 0
        },
        warnings: streamStart?.warnings,
        request: {
            body: JSON.stringify({
                prompt: conversationPrompt,
                tools: toolCalls.map((toolCall)=>({
                        type: "tool-call",
                        toolCallId: toolCall.toolCallId,
                        toolName: toolCall.toolName,
                        input: JSON.parse(toolCall.input),
                        dynamic: true
                    }))
            })
        },
        response: {
            id: responseMetadata?.id ?? "unknown",
            timestamp: responseMetadata?.timestamp ?? /* @__PURE__ */ new Date(),
            modelId: responseMetadata?.modelId ?? "unknown",
            messages: []
        },
        providerMetadata: finish?.providerMetadata || {}
    };
    return stepResult;
}
__name(chunksToStep, "chunksToStep");
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("step//node_modules/@workflow/ai/dist/agent/do-stream-step.js//doStreamStep", doStreamStep);
;
async function writeToolOutputToUI(writable, toolResults) {
    const writer = writable.getWriter();
    try {
        for (const result of toolResults){
            await writer.write({
                type: "tool-output-available",
                toolCallId: result.toolCallId,
                output: JSON.stringify(result) ?? ""
            });
        }
    } finally{
        writer.releaseLock();
    }
}
__name(writeToolOutputToUI, "writeToolOutputToUI");
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("step//node_modules/@workflow/ai/dist/agent/stream-text-iterator.js//writeToolOutputToUI", writeToolOutputToUI);
// ../node_modules/@workflow/ai/dist/agent/durable-agent.js
async function closeStream(writable, preventClose, sendFinish) {
    if (sendFinish) {
        const writer = writable.getWriter();
        try {
            await writer.write({
                type: "finish"
            });
        } finally{
            writer.releaseLock();
        }
    }
    if (!preventClose) {
        await writable.close();
    }
}
__name(closeStream, "closeStream");
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("step//node_modules/@workflow/ai/dist/agent/durable-agent.js//closeStream", closeStream);
;
;
;
;
;
async function opsModel() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$ai$2d$sdk$2b$groq$40$2$2e$0$2e$33_zod$40$3$2e$25$2e$76$2f$node_modules$2f40$ai$2d$sdk$2f$groq$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["groq"])(process.env.GROQ_MODEL || "llama-3.1-8b-instant", {
        apiKey: process.env.GROQ_API_KEY
    });
}
__name(opsModel, "opsModel");
async function opsAgentWorkflow(messagesFromClient) {
    throw new Error("You attempted to execute workflow opsAgentWorkflow function directly. To start a workflow, use start(opsAgentWorkflow) from workflow/api");
}
__name(opsAgentWorkflow, "opsAgentWorkflow");
opsAgentWorkflow.workflowId = "workflow//workflows/ops-agent/workflow.ts//opsAgentWorkflow";
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("step//workflows/ops-agent/workflow.ts//opsModel", opsModel);
;
async function fetch(...args) {
    return globalThis.fetch(...args);
}
__name(fetch, "fetch");
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("step//node_modules/.pnpm/workflow@4.0.1-beta.29_@aws_cc16d9f11f38d350ff750197b89bf9e0/node_modules/workflow/dist/stdlib.js//fetch", fetch);
;
async function fetch2(...args) {
    return globalThis.fetch(...args);
}
__name(fetch2, "fetch");
(0, __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$private$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["registerStepFunction"])("step//node_modules/workflow/dist/stdlib.js//fetch", fetch2);
;
;
}),
"[project]/frontend/app/.well-known/workflow/v1/step/route.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "POST",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["stepEntrypoint"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$app$2f2e$well$2d$known$2f$workflow$2f$v1$2f$step$2f$route$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/app/.well-known/workflow/v1/step/route.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$frontend$2f$node_modules$2f2e$pnpm$2f40$workflow$2b$core$40$4$2e$0$2e$1$2d$beta$2e$25_$40$aws$2d$sdk$2b$client$2d$sts$40$3$2e$948$2e$0$2f$node_modules$2f40$workflow$2f$core$2f$dist$2f$runtime$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/frontend/node_modules/.pnpm/@workflow+core@4.0.1-beta.25_@aws-sdk+client-sts@3.948.0/node_modules/@workflow/core/dist/runtime.js [app-route] (ecmascript) <locals>");
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__830c5fcc._.js.map