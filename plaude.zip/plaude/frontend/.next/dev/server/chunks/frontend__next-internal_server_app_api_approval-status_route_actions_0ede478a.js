module.exports = [
"[project]/frontend/.next-internal/server/app/api/approval-status/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=frontend__next-internal_server_app_api_approval-status_route_actions_0ede478a.js.map