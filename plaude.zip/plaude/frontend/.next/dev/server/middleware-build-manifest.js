globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/09dc3_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_f809e475._.js",
    "static/chunks/09dc3_next_dist_compiled_react-dom_81fe59d6._.js",
    "static/chunks/09dc3_next_dist_compiled_react-server-dom-turbopack_38d1ce17._.js",
    "static/chunks/09dc3_next_dist_compiled_next-devtools_index_ba2b8658.js",
    "static/chunks/09dc3_next_dist_compiled_49c4dae8._.js",
    "static/chunks/09dc3_next_dist_client_11d8dc17._.js",
    "static/chunks/09dc3_next_dist_2019bf85._.js",
    "static/chunks/f1f29_@swc_helpers_cjs_3e84b336._.js",
    "static/chunks/frontend_a0ff3932._.js",
    "static/chunks/turbopack-frontend_b8dd3fed._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];