var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/slack-decision/route.js")
R.c("server/chunks/_3d8dcdf9._.js")
R.c("server/chunks/[root-of-the-server]__74eb2948._.js")
R.c("server/chunks/frontend__next-internal_server_app_api_slack-decision_route_actions_3ec6f52f.js")
R.m("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/frontend/app/api/slack-decision/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/frontend/app/api/slack-decision/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
