var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/approval-status/route.js")
R.c("server/chunks/_339b5ae0._.js")
R.c("server/chunks/[root-of-the-server]__248df974._.js")
R.c("server/chunks/frontend__next-internal_server_app_api_approval-status_route_actions_0ede478a.js")
R.m("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/frontend/app/api/approval-status/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/frontend/node_modules/.pnpm/next@16.0.7_react-dom@19.2.0_react@19.2.0__react@19.2.0/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/frontend/app/api/approval-status/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
